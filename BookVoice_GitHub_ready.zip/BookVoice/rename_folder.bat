@echo off
rem Renames or moves this program folder (the work is done by move_app.py).
rem It is started with the BASE python named in venv\pyvenv.cfg, not with venv\Scripts\python.exe:
rem a python.exe running from inside the folder would block the rename.
set "APP=%~dp0"
set "BASEPY="
if not exist "%APP%venv\pyvenv.cfg" goto nocfg
for /f "usebackq tokens=1,* delims== " %%a in ("%APP%venv\pyvenv.cfg") do if /i "%%a"=="home" set "BASEPY=%%b\python.exe"
:nocfg
if not defined BASEPY goto trypath
if exist "%BASEPY%" goto run
:trypath
set "BASEPY=python"
:run
cd /d "%APP%.."
"%BASEPY%" -c "import sys" >nul 2>nul
if errorlevel 1 goto nopython
"%BASEPY%" "%APP%move_app.py" "%APP%." & exit /b
:nopython
echo Python was not found, so nothing was changed.
echo Install Python, or start it by hand from a console:  python move_app.py "%APP%."
pause
