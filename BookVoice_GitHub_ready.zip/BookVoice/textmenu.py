"""Меню правой кнопки мыши «Вырезать / Копировать / Вставить / Выделить всё» для всех полей программы.

install(root, colors) вешает его на классы виджетов Tk (а не на каждое поле), поэтому оно работает в редакторе,
в словаре, на вкладке «Книга», в окнах правил и во всех диалогах, в том числе в полях, созданных позже.
В тексте редактора правая кнопка по слову открывает собственное меню (орфография, ударения); стандартные
пункты добавляет в него add_edit_items().

Логика (выделение, буфер обмена, вставка) вынесена в обычные функции и не зависит от меню, чтобы её можно было
проверить без окна.
"""
import os
import re
import tkinter as tk

# Классы виджетов Tk, в которых есть текст. Текст у Text, остальные - однострочные поля.
TEXT_CLASSES = ('Text',)
ENTRY_CLASSES = ('Entry', 'TEntry', 'Spinbox', 'TSpinbox', 'TCombobox')

# Ctrl+буква на русской раскладке в Tk (Windows) не срабатывает: приходит русская буква, а не латинская.
# Коды клавиш при этом остаются прежними, по ним и определяем нужное действие.
_CTRL_KEYCODES = {67: 'copy', 86: 'paste', 88: 'cut', 65: 'select_all'}
_LATIN = {'copy': 'c', 'paste': 'v', 'cut': 'x', 'select_all': 'a'}


def widget_kind(w):
    """'text' для многострочного поля, 'entry' для однострочного, None для всего остального."""
    try:
        cls = w.winfo_class()
    except Exception:
        return None
    if cls in TEXT_CLASSES:
        return 'text'
    if cls in ENTRY_CLASSES:
        return 'entry'
    return None


def _state(w):
    try:
        return str(w.cget('state'))
    except Exception:
        return 'normal'


def is_editable(w):
    return _state(w) == 'normal'


def selection_range(w):
    """(начало, конец) выделения в индексах виджета или None."""
    try:
        a, b = w.index('sel.first'), w.index('sel.last')
    except tk.TclError:
        return None
    return (a, b) if a != b else None


def selected_text(w):
    rng = selection_range(w)
    if rng is None:
        return ''
    a, b = rng
    if widget_kind(w) == 'entry':
        return w.get()[int(a):int(b)]
    return w.get(a, b)


def clipboard_text(w):
    try:
        return w.clipboard_get()
    except tk.TclError:
        return ''


def can_copy(w):
    return bool(selected_text(w))


def can_cut(w):
    return is_editable(w) and can_copy(w)


def can_paste(w):
    return is_editable(w) and bool(clipboard_text(w))


def _changed(w):
    """Текст изменили не клавиатурой: даём окну знать (счётчики знаков и т. п. обновляются по KeyRelease)."""
    if widget_kind(w) == 'text':
        try:
            w.event_generate('<KeyRelease>')
        except Exception:
            pass


def do_copy(w):
    s = selected_text(w)
    if not s:
        return False
    w.clipboard_clear()
    w.clipboard_append(s)
    return True


def _delete_selection(w):
    rng = selection_range(w)
    if rng is None:
        return
    w.delete(*rng)


def do_cut(w):
    if not can_cut(w):
        return False
    do_copy(w)
    _separator(w)
    _delete_selection(w)
    _separator(w)
    _changed(w)
    return True


def do_paste(w):
    data = clipboard_text(w)
    if not data or not is_editable(w):
        return False
    if widget_kind(w) == 'entry':
        data = re.sub(r'\s*[\r\n]+\s*', ' ', data).strip()          # в однострочное поле переводы строк не вставляем
    else:
        data = data.replace('\r\n', '\n').replace('\r', '\n')
    _separator(w)
    _delete_selection(w)               # вставка заменяет выделенное, как в любом редакторе
    w.insert('insert', data)
    _separator(w)
    try:
        w.see('insert')
    except Exception:
        pass
    _changed(w)
    return True


def do_select_all(w):
    if widget_kind(w) == 'entry':
        w.select_range(0, 'end')
        w.icursor('end')
    else:
        w.tag_add('sel', '1.0', 'end-1c')
        w.mark_set('insert', 'end-1c')
    return True


def _separator(w):
    """Граница отмены (Ctrl+Z) в тексте с включённой отменой; у остальных полей её нет."""
    if widget_kind(w) != 'text':
        return
    try:
        w.edit_separator()
    except Exception:
        pass


def place_cursor(w, event):
    """Правая кнопка вне выделения снимает его и ставит курсор в точку щелчка (как в Блокноте), чтобы
    «указал курсор - правая - вставить» вставляло именно туда. Щелчок внутри выделения его сохраняет."""
    kind = widget_kind(w)
    try:
        w.focus_set()
        if kind == 'text':
            idx = w.index(f'@{event.x},{event.y}')
            rng = selection_range(w)
            if rng and w.compare(rng[0], '<=', idx) and w.compare(idx, '<', rng[1]):
                return
            w.tag_remove('sel', '1.0', 'end')
            w.mark_set('insert', idx)
        elif kind == 'entry' and _state(w) != 'disabled':
            idx = int(w.index(f'@{event.x}'))
            rng = selection_range(w)
            if rng and int(rng[0]) <= idx < int(rng[1]):
                return
            w.selection_clear()
            w.icursor(idx)
    except (tk.TclError, ValueError):
        pass


COMMANDS = (('Вырезать', 'Ctrl+X', do_cut, can_cut),
            ('Копировать', 'Ctrl+C', do_copy, can_copy),
            ('Вставить', 'Ctrl+V', do_paste, can_paste),
            None,
            ('Выделить всё', 'Ctrl+A', do_select_all, lambda w: True))


def add_edit_items(menu, w):
    """Добавить в готовое меню стандартные пункты правки и разделитель после них."""
    for item in COMMANDS:
        if item is None:
            menu.add_separator()
            continue
        label, hint, action, enabled = item
        menu.add_command(label=label, accelerator=hint, command=lambda a=action: a(w),
                         state='normal' if enabled(w) else 'disabled')
    menu.add_separator()


def _skip(w):
    """Полей, для которых меню не нужно: недоступные и списки «только выбор»."""
    state = _state(w)
    if state == 'disabled' and widget_kind(w) == 'entry':
        return True
    return w.winfo_class() == 'TCombobox' and state == 'readonly'


def show_menu(event, colors):
    w = event.widget
    kind = widget_kind(w)
    if kind is None or _skip(w):
        return None
    place_cursor(w, event)
    menu = tk.Menu(w, tearoff=0, bg=colors['PANEL'], fg=colors['FG'], activebackground='#3b3f57',
                   activeforeground=colors['ACCENT'], disabledforeground=colors['MUTED'])
    for item in COMMANDS:
        if item is None:
            menu.add_separator()
            continue
        label, hint, action, enabled = item
        menu.add_command(label=label, accelerator=hint, command=lambda a=action: a(w),
                         state='normal' if enabled(w) else 'disabled')
    try:
        menu.tk_popup(event.x_root, event.y_root)
    finally:
        menu.grab_release()
    return 'break'


def on_ctrl_key(event):
    """Ctrl+C/V/X/A на любой раскладке: если Tk сам действие не выполнит (русская буква), делаем его здесь."""
    if os.name != 'nt':
        return None
    action = _CTRL_KEYCODES.get(getattr(event, 'keycode', -1))
    if action is None:
        return None
    if str(getattr(event, 'keysym', '')).lower() == _LATIN[action]:
        return None                       # латинская раскладка: стандартная привязка Tk справится
    w = event.widget
    if widget_kind(w) is None:
        return None
    {'copy': do_copy, 'paste': do_paste, 'cut': do_cut, 'select_all': do_select_all}[action](w)
    return 'break'


def install(root, colors):
    """Один раз при запуске: меню правой кнопки и Ctrl+C/V/X/A на любой раскладке для всех полей."""
    for cls in TEXT_CLASSES + ENTRY_CLASSES:
        root.bind_class(cls, '<Button-3>', lambda e: show_menu(e, colors), add='+')
        root.bind_class(cls, '<Control-KeyPress>', on_ctrl_key, add='+')
