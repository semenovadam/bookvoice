"""Окно «Модели ударений RUAccent»: какие модели есть на сервере и на диске, проверка обновлений,
скачивание выбранной модели, переключение между ними без перезапуска, обновление пакета ruaccent.

Логика (список моделей, версии, настройки) лежит в model_manager.py; здесь только окно. Скачивание идёт
отдельным процессом (как в окне «Модели»), сама программа при этом остаётся без сети: единственный
запрос из программы - кнопка «Проверить обновления» (читает список файлов на huggingface.co и версию
пакета на pypi.org, ничего не скачивает и не устанавливает)."""
import threading
import tkinter as tk
from tkinter import messagebox, ttk

import model_dirs
import model_manager
from model_manager import RUACCENT_MODELS, job_title

COLUMNS = (('name', 'Модель', 120), ('desc', 'Что это', 360), ('size', 'Размер', 80),
           ('date', 'На сервере', 90), ('state', 'Состояние', 190))

STATE_TEXT = {'missing': 'не скачана', 'installed': '✓ скачана', 'current': '✓ актуальна',
              'update': '⬆ есть обновление', 'unknown': '✓ скачана (версия неизвестна)'}

MEMORY_HINT = ('Лучшее качество: словарь целиком включён, лёгкий режим выключен (RUAccent просит около 3 ГБ '
               'памяти; на слабом компьютере лёгкий режим и модель tiny требуют около 0,5 ГБ, но ударения хуже).')


def build_rows(remote, installed, records, active):
    """Строки таблицы: [(имя, описание, размер, дата на сервере, состояние)] - новые модели сверху.
    remote - ответ fetch_ruaccent_models или None (проверка ещё не делалась)."""
    names = set(RUACCENT_MODELS) | set(installed) | set(remote or {})
    rows = []
    for name in sorted(names, key=model_manager.ruaccent_sort_key):
        info = (remote or {}).get(name) or {}
        desc = RUACCENT_MODELS.get(name) or 'новая модель на сервере, описания пока нет'
        size = model_manager.fmt_size(info['size']) if info.get('size') else '—'
        date = (info.get('updated') or '')[:10] or '—'
        state = STATE_TEXT[model_manager.ruaccent_model_state(name, installed, remote, records)]
        if remote is not None and name not in remote and name not in installed:
            state = 'нет на сервере'
        if name == active:
            state += '  ◀ используется'
        rows.append((name, desc, size, date, state))
    return rows


class RuaccentWindow:
    def __init__(self, app, runner_factory=model_manager.Runner, fetch=None, pkg_latest=None):
        self.app = app
        self.colors = app.colors
        self.fetch = fetch or model_manager.fetch_ruaccent_models
        self.pkg_latest = pkg_latest or model_manager.fetch_ruaccent_pkg_latest
        self.remote = None              # ответ сервера после «Проверить обновления»
        self.latest_pkg = None          # последняя версия пакета на PyPI (после проверки)
        self.pending_use = None         # модель, которую включить сразу после скачивания
        self.totals = {}
        self.win = tk.Toplevel(app.root)
        self.win.title('Модели ударений RUAccent')
        sw, sh = app.root.winfo_screenwidth(), app.root.winfo_screenheight()
        self.win.geometry(f'{min(980, sw - 40)}x{min(820, sh - 80)}')
        self.win.configure(bg=self.colors['BG'])
        self.win.transient(app.root)
        self.win.bind('<Escape>', lambda e: self.close())
        self.win.protocol('WM_DELETE_WINDOW', self.close)
        self.runner = runner_factory(self._on_event_thread)
        self._build()
        self.refresh()

    # ---- построение окна
    def _build(self):
        box = ttk.Frame(self.win, padding=14)
        box.pack(fill='both', expand=True)
        self.pkg_lbl = ttk.Label(box, text='')
        self.pkg_lbl.pack(anchor='w')
        self.dir_lbl = ttk.Label(box, text='', style='M.TLabel')
        self.dir_lbl.pack(anchor='w', pady=(2, 0))
        self.active_lbl = ttk.Label(box, text='', foreground=self.colors['ACCENT'])
        self.active_lbl.pack(anchor='w', pady=(2, 8))

        frame = ttk.Frame(box)
        frame.pack(fill='both', expand=True)
        self.tree = ttk.Treeview(frame, columns=[c[0] for c in COLUMNS], show='headings',
                                 selectmode='browse', height=11)
        for key, title, width in COLUMNS:
            self.tree.heading(key, text=title)
            self.tree.column(key, width=width, anchor='w', stretch=(key == 'desc'))
        sc = ttk.Scrollbar(frame, command=self.tree.yview)
        self.tree.configure(yscrollcommand=sc.set)
        sc.pack(side='right', fill='y')
        self.tree.pack(side='left', fill='both', expand=True)
        self.tree.bind('<Double-1>', lambda e: self.use_selected())

        self.summary_lbl = ttk.Label(box, text='', wraplength=920, style='M.TLabel')
        self.summary_lbl.pack(anchor='w', pady=(6, 6))

        bar = ttk.Frame(box)
        bar.pack(fill='x', pady=(0, 6))
        self.b_check = ttk.Button(bar, text='Проверить обновления', command=self.check)
        self.b_check.pack(side='left')
        self.b_download = ttk.Button(bar, text='Скачать выбранную', style='Accent.TButton',
                                     command=self.download_selected)
        self.b_download.pack(side='left', padx=6)
        self.b_use = ttk.Button(bar, text='Использовать выбранную', command=self.use_selected)
        self.b_use.pack(side='left')
        self.b_pkg = ttk.Button(bar, text='Обновить пакет ruaccent', command=self.update_pkg)
        self.b_pkg.pack(side='left', padx=6)
        self.b_stop = ttk.Button(bar, text='Остановить', command=self.stop, state='disabled')
        self.b_stop.pack(side='left')
        ttk.Button(bar, text='Закрыть', command=self.close).pack(side='right')

        opts = ttk.Frame(box)
        opts.pack(fill='x', pady=(4, 0))
        self.v_dict = tk.BooleanVar(value=model_manager.ruaccent_use_dictionary())
        self.v_tiny = tk.BooleanVar(value=model_manager.ruaccent_tiny_mode())
        ttk.Checkbutton(opts, text='Словарь ударений целиком (точнее, больше памяти)',
                        variable=self.v_dict).pack(side='left')
        ttk.Checkbutton(opts, text='Лёгкий режим tiny_mode (без правил и словаря)',
                        variable=self.v_tiny).pack(side='left', padx=12)
        self.b_apply = ttk.Button(opts, text='Применить настройки', command=self.apply_options)
        self.b_apply.pack(side='left')
        ttk.Label(box, text=MEMORY_HINT, wraplength=920, style='M.TLabel').pack(anchor='w', pady=(4, 8))

        self.pb = ttk.Progressbar(box, mode='determinate', maximum=100)
        self.pb.pack(fill='x')
        self.stage_lbl = ttk.Label(box, text='', style='M.TLabel')
        self.stage_lbl.pack(anchor='w', pady=(4, 6))
        logbox = ttk.Frame(box)
        logbox.pack(fill='both', expand=True)
        self.log_txt = self.app.textbox(logbox, 6)
        lsc = ttk.Scrollbar(logbox, command=self.log_txt.yview)
        self.log_txt.configure(yscrollcommand=lsc.set, state='disabled')
        lsc.pack(side='right', fill='y')
        self.log_txt.pack(side='left', fill='both', expand=True)

    # ---- состояние
    def alive(self):
        try:
            return bool(self.win.winfo_exists())
        except tk.TclError:
            return False

    def running(self):
        return self.runner.running()

    def selected(self):
        sel = self.tree.selection()
        return str(sel[0]) if sel else None

    def refresh(self):
        installed = model_manager.ruaccent_installed_models()
        records = model_manager.ruaccent_records()
        active = model_manager.ruaccent_effective()[0]
        ver = model_manager.ruaccent_pkg_version()
        self.pkg_lbl.configure(text='Пакет ruaccent: ' + (ver or 'не найден') + self._latest_text())
        self.dir_lbl.configure(text=f'Модели ударений: {model_dirs.RUACCENT_DIR}')
        chosen, note = model_manager.ruaccent_chosen(), model_manager.ruaccent_effective()[2]
        self.active_lbl.configure(text=f'Выбрана: {chosen}' + (f'. {note}' if note else ''))
        keep = self.selected()
        for item in self.tree.get_children():
            self.tree.delete(item)
        for row in build_rows(self.remote, installed, records, active):
            self.tree.insert('', 'end', iid=row[0], values=row)
        if keep and self.tree.exists(keep):
            self.tree.selection_set(keep)

    def _latest_text(self):
        latest = getattr(self, 'latest_pkg', None)
        if latest is None:
            return ''
        ver = model_manager.ruaccent_pkg_version()
        return f' (на PyPI: {latest}' + ('; ✓ последняя)' if ver == latest else '; можно обновить)')

    def _set_running(self, running):
        for b in (self.b_check, self.b_download, self.b_use, self.b_pkg, self.b_apply):
            b.configure(state='disabled' if running else 'normal')
        self.b_stop.configure(state='normal' if running else 'disabled')
        if not running:
            self.pb.stop()
            self.pb.configure(mode='determinate', value=0)

    def _log(self, line):
        self.log_txt.configure(state='normal')
        self.log_txt.insert('end', line + '\n')
        self.log_txt.see('end')
        self.log_txt.configure(state='disabled')

    # ---- проверка обновлений
    def check(self):
        if self.running():
            return
        self.summary_lbl.configure(text='Спрашиваю сервер…')
        self._set_running(True)

        def work():
            remote, err, latest = None, None, None
            try:
                remote = self.fetch()
            except Exception as e:
                err = f'{type(e).__name__}: {e}'
            latest = self.pkg_latest()
            self.app.ui(lambda: self._checked(remote, err, latest))
        threading.Thread(target=work, daemon=True).start()

    def _checked(self, remote, err, latest):
        if not self.alive():
            return
        self._set_running(False)
        self.latest_pkg = latest
        if remote is None:
            self.summary_lbl.configure(text=f'Не удалось получить список моделей ({err}). Проверь интернет. '
                                            'Список выше построен по тому, что известно заранее и что скачано.')
            self.refresh()
            return
        self.remote = remote
        installed = model_manager.ruaccent_installed_models()
        records = model_manager.ruaccent_records()
        text, updates = model_manager.ruaccent_summary(remote, installed, records, model_manager.ruaccent_chosen())
        self.summary_lbl.configure(text=text)
        self.refresh()
        chosen = model_manager.ruaccent_chosen()
        if chosen in updates:
            if messagebox.askyesno('RUAccent', f'У модели «{chosen}», которую ты используешь, есть обновление. '
                                               'Скачать его сейчас?', parent=self.win):
                self.start_download(chosen, then_apply=True)

    # ---- скачивание и переключение
    def start_download(self, name, then_apply=False):
        if not model_manager.valid_ruaccent_name(name):
            return False
        free = model_manager.free_space(model_dirs.MODELS_DIR)
        need = (self.remote or {}).get(name, {}).get('size', 0) + (300 << 20)
        if free is not None and free < need * 1.1:
            if not messagebox.askyesno('Мало места', f'Свободно {model_manager.fmt_size(free)}, нужно примерно '
                                                     f'{model_manager.fmt_size(need)}. Всё равно начать?',
                                       parent=self.win):
                return False
        if not self.runner.start([f'ruaccent:{name}']):
            messagebox.showinfo('RUAccent', 'Скачивание уже идёт.', parent=self.win)
            return False
        self.pending_use = name if then_apply else None
        self._set_running(True)
        self._log(f'--- Скачиваю модель «{name}» (нужен интернет)')
        return True

    def download_selected(self):
        name = self.selected()
        if not name:
            messagebox.showinfo('RUAccent', 'Выбери модель в списке.', parent=self.win)
            return False
        return self.start_download(name)

    def use_selected(self):
        name = self.selected()
        if not name:
            messagebox.showinfo('RUAccent', 'Выбери модель в списке.', parent=self.win)
            return False
        if self.running():
            return False
        if name not in model_manager.ruaccent_installed_models():
            if messagebox.askyesno('RUAccent', f'Модель «{name}» ещё не скачана. Скачать и сразу включить?',
                                   parent=self.win):
                return self.start_download(name, then_apply=True)
            return False
        self.apply(name)
        return True

    def apply_options(self):
        if not self.running():
            self.apply(model_manager.ruaccent_chosen())

    def apply(self, name):
        """Запомнить выбор и загрузить RUAccent заново (если программа уже загрузила модели)."""
        self.app.set_ruaccent(model=name, dictionary=self.v_dict.get(), tiny=self.v_tiny.get())
        self.summary_lbl.configure(text=f'Включаю «{name}»…')
        self.refresh()
        self.app.apply_ruaccent(done=self._applied)

    def _applied(self, ok, message):
        if not self.alive():
            return
        self.summary_lbl.configure(text=message)
        self._log(('✓ ' if ok else '✗ ') + message)
        self.refresh()

    def update_pkg(self):
        if self.running():
            return False
        if not messagebox.askyesno('RUAccent', 'Обновить пакет ruaccent через pip? Нужен интернет. Новые версии '
                                               'пакета нужны новым моделям; после обновления перезапусти '
                                               'программу.', parent=self.win):
            return False
        if not self.runner.start(['ruaccent_pkg']):
            return False
        self.pending_use = None
        self._set_running(True)
        self._log('--- Обновляю пакет ruaccent (pip)')
        return True

    def stop(self):
        self.stage_lbl.configure(text='Останавливаю…')
        self.runner.cancel()

    def close(self):
        if self.running():
            if not messagebox.askyesno('RUAccent', 'Скачивание идёт. Остановить и закрыть окно?', parent=self.win):
                return
            self.runner.cancel()
        self.app.ruaccent_win = None
        try:
            self.win.destroy()
        except tk.TclError:
            pass

    # ---- ход скачивания
    def _on_event_thread(self, event):
        self.app.ui(lambda: self.alive() and self.on_event(event))

    def on_event(self, event):
        kind, cid = event[0], event[1] if len(event) > 1 else None
        if kind == 'start':
            self.totals.pop(cid, None)
            self.stage_lbl.configure(text=f'{job_title(cid)}: начинаю…')
            self.pb.configure(mode='indeterminate')
            self.pb.start(60)
        elif kind == 'stage':
            self.stage_lbl.configure(text=event[2])
            self._log('# ' + event[2])
        elif kind == 'total':
            self.totals[cid] = event[2]
        elif kind == 'progress':
            done, total = event[2], event[3] or self.totals.get(cid)
            if total:
                self.pb.stop()
                self.pb.configure(mode='determinate', value=min(100.0, 100.0 * done / total))
                self.stage_lbl.configure(
                    text=f'{job_title(cid)}: {model_manager.fmt_size(done)} из {model_manager.fmt_size(total)}'
                         f' ({min(100, int(100 * done / total))}%)')
            else:
                self.stage_lbl.configure(text=f'{job_title(cid)}: скачано {model_manager.fmt_size(done)}')
        elif kind == 'log':
            self._log(event[2])
        elif kind == 'end':
            self._log(('✓ ' if event[2] else '✗ ') + f'{job_title(cid)}: {event[3]}')
            self.refresh()
        elif kind == 'finished':
            done, failed, cancelled = event[1], event[2], event[3]
            self._set_running(False)
            self.stage_lbl.configure(text='Остановлено.' if cancelled else
                                     ('Не удалось: ' + ', '.join(job_title(c) for c in failed) +
                                      '. Подробности в журнале ниже.') if failed else 'Готово.')
            self.refresh()
            pending, self.pending_use = self.pending_use, None
            if pending and f'ruaccent:{pending}' in done:
                self.apply(pending)
            if 'ruaccent_pkg' in done:
                messagebox.showinfo('RUAccent', 'Пакет ruaccent обновлён. Перезапусти программу, чтобы он '
                                                'заработал (подробности в журнале окна).', parent=self.win)
            self.app.models_changed(done)
