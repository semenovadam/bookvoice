r"""Переименовать или перенести папку программы целиком. Запускается через rename_folder.bat.

Программа не привязана к имени и месту своей папки: bookvoice.bat запускает python из venv по
относительному пути, а модели лежат отдельно (D:\AI\models) и никуда не переезжают. Поэтому
после переименования или переноса всё продолжает работать. Этот файл делает перенос безопасно:
проверяет новое имя, ждёт, если папку что-то держит, при смене диска копирует и сверяет файлы
до удаления оригинала, а в конце проверяет, что python из venv запускается на новом месте.

Нужен только стандартный python. Он не должен быть тем, что лежит внутри переносимой папки
(venv\Scripts\python.exe), иначе Windows не даст её переименовать: rename_folder.bat берёт
для этого основной python, который указан в venv\pyvenv.cfg.
"""
import errno
import os
import shutil
import stat
import subprocess
import sys
import time
import traceback
from pathlib import Path

VENV_PYTHON = Path('venv') / 'Scripts' / 'python.exe'
LAUNCHER = 'bookvoice.bat'
RETRIES = 4          # попыток переименования, если папку что-то держит (антивирус, Проводник)
PAUSE = 1.5          # секунд между попытками
YES = ('да', 'д', 'yes', 'y')
_RESERVED = {'con', 'prn', 'aux', 'nul'} | {f'com{i}' for i in range(1, 10)} | {f'lpt{i}' for i in range(1, 10)}
# python из venv проверяет сам себя: его sys.prefix должен быть папкой venv на новом месте
CHECK = ('import os, sys; '
         'f = lambda p: os.path.normcase(os.path.realpath(p)); '
         'sys.exit(0 if f(sys.prefix) == f(sys.argv[1]) else 3)')


def _ask(prompt):
    try:
        return input(prompt)
    except EOFError:                                    # ввода нет: считаем «ничего»
        return ''


def _norm(p):
    return os.path.normcase(os.path.abspath(str(p)))


def _inside(x, y):
    """Путь x (уже приведённый _norm) лежит внутри пути y."""
    return x.startswith(y.rstrip(os.sep) + os.sep)


def _rmtree(path):
    def fix(func, p, _exc):                             # Windows: файл «только для чтения»
        os.chmod(p, stat.S_IWRITE)
        func(p)
    if sys.version_info >= (3, 12):
        shutil.rmtree(path, onexc=fix)
    else:
        shutil.rmtree(path, onerror=fix)


def _covered(src, dst):
    """Каждый файл из src есть и в dst, и размер тот же."""
    def fail(e):                                        # папку не удалось прочитать: считать проверенной нельзя
        raise e
    try:
        for root, _dirs, files in os.walk(src, onerror=fail):
            for name in files:
                a = Path(root) / name
                b = Path(dst) / a.relative_to(src)
                if not b.is_file() or b.stat().st_size != a.stat().st_size:
                    return False
    except OSError:
        return False
    return True


def _held(e):
    """Ошибка похожа на «папку что-то держит»: Windows отвечает отказом в доступе (5) или
    нарушением совместного доступа (32, 33). Другие ошибки (плохое имя, нет пути) повторять бессмысленно."""
    return isinstance(e, PermissionError) or getattr(e, 'winerror', None) in (5, 32, 33)


def _bad_name(name):
    """Имя папки, которое Windows не примет: текст ошибки или None."""
    if not name:
        return 'Нужно имя папки, а не только диск.'
    if any(c in name for c in '<>:"/\\|?*') or any(ord(c) < 32 for c in name):
        return f'В имени «{name}» есть запрещённые символы (< > : " / \\ | ? *).'
    if name != name.rstrip(' .'):
        return 'Имя папки не может заканчиваться пробелом или точкой.'
    if name.split('.')[0].lower() in _RESERVED:
        return f'«{name}» это зарезервированное имя Windows, выберите другое.'
    return None


def _is_empty_dir(p):
    try:
        return p.is_dir() and not any(p.iterdir())
    except OSError:
        return False


def parse_target(app, answer):
    """Ответ -> новая папка (Path). None, если ответ пустой; ValueError с пояснением, если путь
    не полный. Одно имя без диска и слэшей: папка остаётся на прежнем месте и переименовывается."""
    ans = answer.strip().strip('"').strip()
    if not ans:
        return None
    ans = os.path.expandvars(os.path.expanduser(ans))
    if not any(c in ans for c in '\\/:'):
        return Path(app).parent / ans
    new = Path(ans)
    if not new.is_absolute():
        raise ValueError('Нужен полный путь вместе с диском (например D:\\AI\\bookvoice) '
                         'или просто новое имя.')
    return new


def check_target(app, new):
    """Текст ошибки, если переносить нельзя, иначе None."""
    a, n = _norm(app), _norm(new)
    if a == n:
        return 'Новое имя совпадает с прежним, менять нечего.'
    bad = _bad_name(Path(new).name)
    if bad:
        return bad
    if _inside(n, a):
        return 'Нельзя переносить папку внутрь самой себя.'
    if Path(new).exists() and not _is_empty_dir(Path(new)):      # пустую папку, созданную вручную, можно занять
        return f'{new} уже существует: выберите другое имя.'
    return None


def move_folder(src, dst, say=print):
    """Тот же диск: переименование, мгновенно. Другой диск: копия, проверка и только потом
    удаление оригинала. Бросает OSError, при этом src остаётся нетронутой. Возвращает None
    или предупреждение (копия готова, а оригинал стереть не получилось)."""
    src, dst = Path(src), Path(dst)
    if dst.exists():
        if not _is_empty_dir(dst):
            raise FileExistsError(f'{dst} уже существует')
        dst.rmdir()                                     # пустая заготовка, созданная вручную, мешает переименованию
    dst.parent.mkdir(parents=True, exist_ok=True)
    busy = None
    for attempt in range(RETRIES):
        try:
            os.rename(src, dst)
            return None
        except OSError as e:
            if e.errno == errno.EXDEV or getattr(e, 'winerror', None) == 17:
                break                                   # другой диск: копируем
            if not _held(e):
                raise OSError(f'не получилось переименовать папку: {e}') from e
            busy = e
            if attempt + 1 < RETRIES:
                say(f'  папку что-то держит ({e}), пробую ещё раз...')
                time.sleep(PAUSE)
    else:
        raise OSError('папку держит какая-то программа: закройте bookvoice и его чёрное окно, '
                      'окна Проводника и консоли, открытые внутри этой папки, и запустите ещё раз '
                      f'({busy})') from busy
    say('  другой диск: копирую файлы (с venv это может занять несколько минут)...')
    part = dst.with_name(dst.name + '.part')
    try:
        if part.exists():
            _rmtree(part)                               # остаток прерванного копирования
        shutil.copytree(src, part)
        if not _covered(src, part):
            raise OSError('копия не совпала с оригиналом')
        part.rename(dst)                                # папка появляется сразу целиком
    except BaseException:
        shutil.rmtree(part, ignore_errors=True)
        raise
    try:
        _rmtree(src)
    except OSError as e:
        return f'копия готова, но прежнюю папку {src} стереть не получилось ({e}); удалите её вручную'
    return None


def venv_check(folder):
    """Запустить python из venv на новом месте. (True|False|None, пояснение); None: venv нет."""
    exe = Path(folder) / VENV_PYTHON
    if not exe.is_file():
        return None, 'venv рядом не найден'
    try:
        r = subprocess.run([str(exe), '-c', CHECK, str(Path(folder) / 'venv')],
                           capture_output=True, text=True, timeout=120)
    except (OSError, subprocess.SubprocessError) as e:
        return False, str(e)
    if r.returncode == 0:
        return True, ''
    if r.returncode == 3:
        return False, 'python считает своей другую папку'
    return False, (r.stderr.strip().splitlines() or [f'код выхода {r.returncode}'])[-1]


def run(app):
    app = Path(app).resolve()
    try:
        os.chdir(app.parent)        # чтобы эта консоль сама не держала переносимую папку
    except OSError:
        pass
    if not (app / 'app.py').is_file():
        print(f'{app} не похожа на папку программы (нет app.py): ничего не делаю.')
        return 1
    print(f'Папка программы: {app}\n')
    print('Впишите, во что её превратить:')
    print('  - только новое имя (папка останется рядом и просто переименуется), например  bookvoice')
    print('  - полный путь, если меняется и диск или место, например  E:\\Apps\\bookvoice')
    print('  - пустая строка: ничего не менять')
    print('Перед этим закройте программу (окно и чёрную консоль) и окна Проводника, открытые внутри папки.')
    try:
        new = parse_target(app, _ask('Новое имя или путь: '))
    except ValueError as e:
        print(e)
        return 1
    if new is None:
        print('Ничего не изменено.')
        return 0
    err = check_target(app, new)
    if err:
        print(err)
        return 1
    if not (app / LAUNCHER).is_file():
        print(f'\nВНИМАНИЕ: в папке нет {LAUNCHER}. Старый запуск (start_silero.bat) подключает venv через')
        print('activate.bat, а тот запоминает прежний путь: после переноса программа может не стартовать.')
        print(f'Сначала положите в папку новые файлы ({LAUNCHER} и остальные).')
        if _ask('Всё равно переносить? Введите да и нажмите Enter: ').strip().lower() not in YES:
            print('Ничего не изменено.')
            return 1
    print(f'\nПереношу: {app}\n      в: {new}')
    try:
        warn = move_folder(app, new)
    except OSError as e:
        print(f'\nНЕ УДАЛОСЬ: {e}')
        print('Папка осталась на старом месте, ничего не потеряно.')
        return 1
    print('  готово.')
    if warn:
        print(f'ВНИМАНИЕ: {warn}')
    ok, info = venv_check(new)
    if ok:
        print('Проверка: python из venv запускается на новом месте.')
    elif ok is None:
        print(f'Проверка пропущена: {info}.')
    else:
        print(f'\nВНИМАНИЕ: python из venv на новом месте работает неправильно ({info}).')
        print('Верните папку обратно (запустите rename_folder.bat ещё раз и впишите прежнее имя)')
        print('и покажите этот текст.')
    print(f'\nГотово. Папка программы теперь: {new}')
    print(f'Запускайте {LAUNCHER} из новой папки. Ярлыки, которые вели в старую, нужно сделать заново')
    print(f'(правый щелчок на {LAUNCHER} > Отправить > Рабочий стол (создать ярлык)).')
    print('Модели лежат отдельно от программы (где именно, покажет where_models.bat) и никуда не переехали.')
    return 2 if ok is False else 0


if __name__ == '__main__':
    try:
        code = run(sys.argv[1] if len(sys.argv) > 1 else os.getcwd())
    except KeyboardInterrupt:
        print('\nПрервано.')
        code = 1
    except Exception:
        traceback.print_exc()
        print('\nЧто-то пошло не так, текст ошибки выше.')
        code = 1
    _ask('\nНажмите Enter, чтобы закрыть окно...')
    sys.exit(code)
