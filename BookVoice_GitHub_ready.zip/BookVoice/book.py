import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

BASE = Path(__file__).parent
CH_RE = re.compile(r'^\s*(глава|часть|chapter|part|пролог|эпилог)\b', re.IGNORECASE)


def _clean(s):
    return re.sub(r'\s+', ' ', s.replace('\u00a0', ' ')).strip()


def read_txt(path):
    raw = path.read_bytes()
    try:
        text = raw.decode('utf-8-sig')
    except UnicodeDecodeError:
        text = raw.decode('cp1251')
    text = text.replace('\r\n', '\n')
    # абзацы: через пустую строку, а если пустых строк нет - по строкам
    blocks = re.split(r'\n\s*\n', text) if '\n\n' in text else text.split('\n')
    chapters, title, paras = [], 'Начало', []
    for b in blocks:
        b = _clean(b)
        if not b:
            continue
        if CH_RE.match(b) and len(b) < 80:
            if paras:
                chapters.append((title, paras))
            title, paras = b, []
        else:
            paras.append(b)
    if paras:
        chapters.append((title, paras))
    return chapters


def read_fb2(path):
    root = ET.parse(path).getroot()
    ln = lambda e: e.tag.rsplit('}', 1)[-1]
    text_of = lambda e: _clean(''.join(e.itertext()))
    chapters = []

    def walk(sec):
        title, paras = '', []
        for ch in sec:
            t = ln(ch)
            if t == 'title':
                title = text_of(ch)
            elif t == 'p':
                p = text_of(ch)
                if p:
                    paras.append(p)
            elif t in ('epigraph', 'poem', 'cite'):
                for x in ch.iter():
                    if ln(x) in ('p', 'v') and text_of(x):
                        paras.append(text_of(x))
        skip = sec.get('id') in ('titlepage', 'toc') or \
            title.lower().startswith(('содержание', 'оглавление'))
        if paras and not skip:
            chapters.append((title or f'Глава {len(chapters) + 1}', paras))
        for ch in sec:
            if ln(ch) == 'section':
                walk(ch)

    for body in root:
        if ln(body) == 'body' and body.get('name') != 'notes':
            for sec in body:
                if ln(sec) == 'section':
                    walk(sec)
    return chapters


def read_book(path):
    path = Path(path)
    if path.suffix.lower() == '.fb2':
        return read_fb2(path)
    return read_txt(path)


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print('Использование: python book.py "книга.fb2" [--save]')
        sys.exit(1)
    book = Path(sys.argv[1])
    chapters = read_book(book)
    print(f'Глав: {len(chapters)}')
    for i, (title, paras) in enumerate(chapters, 1):
        chars = sum(len(p) for p in paras)
        print(f'{i:3d}. {title[:50]:50s} абзацев {len(paras):4d}, знаков {chars}')
    if '--save' in sys.argv:
        out = BASE / 'chapters' / book.stem
        out.mkdir(parents=True, exist_ok=True)
        for i, (title, paras) in enumerate(chapters, 1):
            (out / f'{i:03d}.txt').write_text(title + '\n\n' + '\n\n'.join(paras),
                                              encoding='utf-8')
        print('сохранено в', out)