"""Изолированный воркер Shtorm-VoxCPM2-RU. stdout используется только для JSON-протокола.

Запускается python.exe из venv_voxcpm. Протокол тот же, что у shtorm_worker.py: одна JSON-строка на
команду (load, synthesize, shutdown), ответ - одна JSON-строка в чистом ASCII, звук - через файл .npy.
"""
import contextlib
import inspect
import json
import sys
from pathlib import Path

# Папка с кодом BookVoice попадает в sys.path первой (там лежат speak.py, test.py и другие файлы с общими
# именами): убираем её, чтобы они не заслонили пакеты среды (в том числе сам voxcpm).
_HERE = Path(__file__).resolve().parent
sys.path[:] = [p for p in sys.path if Path(p or '.').resolve() != _HERE]

import numpy as np

# Windows читает stdin процесса, подключённого к каналу, в кодировке ANSI (cp1251), а клиент пишет UTF-8:
# потоки переводим на UTF-8, ответы пишем в ASCII (\uXXXX), так что кодировка канала на обмен не влияет.
for _stream in (sys.stdin, sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass

model = None
voice_ref = None
prompt_text = ''
logged_texts = 0          # сколько первых текстов после загрузки уже записано в журнал


def reply(data):
    sys.stdout.write(json.dumps(data) + '\n')
    sys.stdout.flush()


def _explicit(func, **kw):
    """Оставить только параметры, названные в сигнатуре (без **kwargs): лишнее старая версия не примет."""
    try:
        params = inspect.signature(func).parameters
    except (TypeError, ValueError):
        return {}
    return {k: v for k, v in kw.items() if k in params}


def _generate_kwargs(func, **kw):
    """Как _explicit, но если функция принимает **kwargs, отдаём ей всё."""
    try:
        params = inspect.signature(func).parameters
    except (TypeError, ValueError):
        return kw
    if any(p.kind == p.VAR_KEYWORD for p in params.values()):
        return kw
    return {k: v for k, v in kw.items() if k in params}


def _load_model(model_dir):
    from voxcpm import VoxCPM
    kw = {'load_denoiser': False}          # шумоподавитель не нужен и занимает память
    # optimize=True включает torch.compile: на Windows без triton он падает или стартует очень долго.
    kw.update(_explicit(VoxCPM.from_pretrained, optimize=False, device='auto'))
    try:
        import torch
        if not torch.cuda.is_available():
            print('ВНИМАНИЕ: torch не видит видеокарту (CUDA). Модель на 2 млрд параметров на процессоре '
                  'будет работать очень медленно. Проверь, что в venv_voxcpm стоит torch с CUDA.',
                  file=sys.stderr, flush=True)
        else:
            print('CUDA: ' + torch.cuda.get_device_name(0), file=sys.stderr, flush=True)
    except Exception as exc:
        print(f'torch не импортируется: {exc!r}', file=sys.stderr, flush=True)
    return VoxCPM.from_pretrained(str(model_dir), **kw)


def _sample_rate(m):
    for obj in (getattr(m, 'tts_model', None), m):
        rate = getattr(obj, 'sample_rate', None)
        if rate:
            return int(rate)
    return 48000


def handle(req):
    global model, voice_ref, prompt_text, logged_texts
    cmd = req.get('cmd')
    if cmd == 'shutdown':
        return {'ok': True, 'shutdown': True}
    if cmd == 'load':
        d = Path(req['model_dir'])
        ref = Path(req['voice_ref'])
        if not (d / 'config.json').is_file():
            raise FileNotFoundError(f'В папке модели нет config.json: {d}')
        if not ref.is_file():
            raise FileNotFoundError(f'Не найден WAV-образец голоса: {ref}')
        # Библиотека может писать диагностику в stdout; протокол не загрязняем.
        with contextlib.redirect_stdout(sys.stderr):
            if model is None:
                model = _load_model(d)
        voice_ref, prompt_text = str(ref.resolve()), str(req.get('prompt_text') or '')
        logged_texts = 0
        result = {'ok': True, 'sample_rate': _sample_rate(model)}
        if 'probe' in req:
            result['probe'] = req['probe']          # клиент сверяет: русский текст дошёл без искажений
        return result
    if cmd == 'synthesize':
        if model is None or voice_ref is None:
            raise RuntimeError('Сначала загрузите модель и WAV-образец голоса')
        out_path = Path(req['out_path'])
        text = req.get('text', '')
        if logged_texts < 3:
            logged_texts += 1
            print('текст для модели: ' + repr(text[:160]), file=sys.stderr, flush=True)
        kw = {'text': text, 'cfg_value': float(req.get('cfg_value', 2.0)),
              'inference_timesteps': int(req.get('timesteps', 10)),
              'normalize': False,           # обязательно: встроенный нормализатор портит метки ударений
              'denoise': False,
              'reference_wav_path': voice_ref}
        if prompt_text:                      # режим Hi-Fi: тот же файл и его дословный текст
            kw['prompt_wav_path'] = voice_ref
            kw['prompt_text'] = prompt_text
        with contextlib.redirect_stdout(sys.stderr):
            audio = model.generate(**_generate_kwargs(model.generate, **kw))
        if hasattr(audio, 'detach'):
            audio = audio.detach().cpu().numpy()
        audio = np.asarray(audio, dtype=np.float32).reshape(-1)
        if not audio.size or not np.isfinite(audio).all():
            raise RuntimeError('Модель вернула пустой или некорректный аудиофрагмент')
        np.save(out_path, np.clip(audio, -1.0, 1.0), allow_pickle=False)
        return {'ok': True, 'out_path': str(out_path)}
    raise ValueError(f'Неизвестная команда: {cmd}')


def main():
    for line in sys.stdin:
        try:
            result = handle(json.loads(line))
            reply(result)
            if result.get('shutdown'):
                break
        except Exception as exc:
            reply({'ok': False, 'error': f'{type(exc).__name__}: {exc}'})


if __name__ == '__main__':
    main()
