"""Изолированный Pocket-TTS worker. stdout используется только для JSON-протокола."""
import contextlib
import inspect
import json
import sys
from pathlib import Path

import numpy as np

# Windows читает stdin процесса, подключённого к каналу, в кодировке ANSI (cp1251), а клиент пишет
# UTF-8: текст превращался в «РџСЂРѕ…», а заглавная «И» (байт 0x98) роняла процесс. Потоки переводим
# на UTF-8, а ответы пишем в ASCII (\uXXXX), так что кодировка канала на обмен не влияет.
for _stream in (sys.stdin, sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass

model = None
voice_state = None
variant_loaded = None
voice_ref_loaded = None
logged_texts = 0          # сколько первых текстов после загрузки уже записано в журнал
gen_loaded = {}           # параметры загрузки, с которыми создана модель
frames_after = None       # frames_after_eos для каждого фрагмента (None = по умолчанию модели)
LOAD_KEYS = ('temp', 'lsd_decode_steps', 'eos_threshold', 'noise_clamp')


def accepted(func, params):
    """Только те параметры, которые функция действительно принимает (в другой сборке Pocket-TTS их может не быть)."""
    try:
        sig = inspect.signature(func).parameters
    except (TypeError, ValueError):
        return {}
    if any(p.kind == p.VAR_KEYWORD for p in sig.values()):
        return dict(params)
    return {k: v for k, v in params.items() if k in sig}


def reply(data):
    sys.stdout.write(json.dumps(data) + '\n')
    sys.stdout.flush()


def handle(req):
    global model, voice_state, variant_loaded, voice_ref_loaded, logged_texts, gen_loaded, frames_after
    cmd = req.get('cmd')
    if cmd == 'shutdown':
        return {'ok': True, 'shutdown': True}
    if cmd == 'load':
        variant = req.get('variant', 'fast')
        if variant not in ('fast', 'slow'):
            raise ValueError('Вариант должен быть fast или slow')
        d = Path(req['model_dir'])
        config = d / ('config_fast.yaml' if variant == 'fast' else 'config_slow.yaml')
        ref = Path(req['voice_ref'])
        if not config.is_file() or not ref.is_file():
            raise FileNotFoundError('Не найден файл конфигурации модели или WAV-образец голоса')
        # Pocket-TTS может писать диагностические сообщения в stdout; протокол не загрязняем.
        with contextlib.redirect_stdout(sys.stderr):
            from pocket_tts import TTSModel
            gen = req.get('gen') or {}
            load_kw = accepted(TTSModel.load_model, {k: gen[k] for k in LOAD_KEYS if k in gen})
            if model is None or variant_loaded != variant or gen_loaded != load_kw:
                new_model = TTSModel.load_model(config=str(config), **load_kw)
            else:
                new_model = model
            new_voice = new_model.get_state_for_audio_prompt(str(ref))
        model, voice_state = new_model, new_voice
        gen_loaded = dict(load_kw)
        frames_after = gen.get('frames_after_eos')
        applied = dict(load_kw)
        if frames_after is not None and accepted(model.generate_audio, {'frames_after_eos': frames_after}):
            applied['frames_after_eos'] = frames_after
        else:
            frames_after = None
        logged_texts = 0
        variant_loaded, voice_ref_loaded = variant, str(ref.resolve())
        result = {'ok': True, 'sample_rate': int(getattr(model, 'sample_rate', 24000)), 'gen_applied': applied}
        if 'probe' in req:
            result['probe'] = req['probe']          # клиент сверяет: русский текст дошёл без искажений
        return result
    if cmd == 'synthesize':
        if model is None or voice_state is None:
            raise RuntimeError('Сначала загрузите модель и WAV-образец голоса')
        out_path = Path(req['out_path'])
        if logged_texts < 3:
            # В журнал (stderr) попадают первые тексты после загрузки: если озвучка вдруг пойдёт
            # «по буквам», здесь видно, что именно получила модель, и это можно сверить с консолью.
            logged_texts += 1
            print('текст для модели: ' + repr(req.get('text', '')[:120]), file=sys.stderr, flush=True)
        with contextlib.redirect_stdout(sys.stderr):
            extra = {'frames_after_eos': frames_after} if frames_after is not None else {}
            audio = model.generate_audio(voice_state, req.get('text', ''), **extra)
        if hasattr(audio, 'detach'):
            audio = audio.detach().cpu().numpy()
        audio = np.asarray(audio, dtype=np.float32).reshape(-1)
        if not audio.size or not np.isfinite(audio).all():
            raise RuntimeError('Модель вернула пустой или некорректный аудиофрагмент')
        np.save(out_path, np.clip(audio, -1.0, 1.0), allow_pickle=False)
        return {'ok': True, 'out_path': str(out_path)}
    raise ValueError(f'Неизвестная команда: {cmd}')


def main():
    for line in sys.stdin:
        try:
            result = handle(json.loads(line))
            reply(result)
            if result.get('shutdown'):
                break
        except Exception as exc:
            reply({'ok': False, 'error': f'{type(exc).__name__}: {exc}'})


if __name__ == '__main__':
    main()
