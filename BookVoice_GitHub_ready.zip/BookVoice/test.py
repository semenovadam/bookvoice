import torch, soundfile as sf

model, _ = torch.hub.load('snakers4/silero-models', 'silero_tts',
                          language='ru', speaker='v5_ru')
model.to(torch.device('cpu'))

text = 'Мама мыла раму. В двери был старинный зам+ок.'
audio = model.apply_tts(text=text, speaker='xenia', sample_rate=48000,
                        put_accent=True, put_yo=True)
sf.write('test.wav', audio.numpy(), 48000)
print('готово')