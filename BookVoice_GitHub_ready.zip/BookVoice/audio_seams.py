"""Стыки между фрагментами озвучки: измерение, исправление краёв, повторный синтез подозрительных, отчёт.

Каждый фрагмент синтезируется отдельно, и раньше склеивался как есть: обрыв посреди слова, щелчок на краю,
длинная тишина или скачок громкости были слышны как «склейка». Теперь каждый фрагмент измеряется (analyze),
получает причины подозрения (reasons), при серьёзных причинах синтезируется заново (Session.fragment; у
Shtorm и VoxCPM2 каждый запуск даёт другой результат), краям возвращается порядок (condition), а всё
сомнительное записывается в отчёт с временем в главе. Модуль без Tk и без звукового вывода: только numpy.

Пороги это стартовые значения, подобранные по общему устройству речевого сигнала, а не по вашим книгам. Их можно
править в settings.json (ключ "seams") после того, как отчёт покажет, какие стыки он видит, а какие пропускает.
"""
import re
from collections import deque

import numpy as np

DEFAULTS = {
    'engines': {'shtorm': True, 'voxcpm': True, 'tera': True, 'silero': False},   # где обрабатывать края и стыки
    'max_lead_ms': 60,          # тишина в начале длиннее обрезается до этого
    'max_tail_ms': 120,         # тишина в конце длиннее обрезается до этого
    'fade_in_ms': 5,            # плавный вход
    'fade_out_ms': 15,          # плавный выход (убирает щелчок)
    'forced_pause_ms': 60,      # пауза там, где таблица пауз дала 0 (фрагмент оборван без знака препинания)
    'retries': 2,               # сколько раз синтезировать заново при серьёзной причине (0 = не повторять)
    'level_match_db': 0,        # 0 = выкл.; иначе не больше стольки дБ подгонки громкости к соседним фрагментам
    'tail_loud_db': -14,        # конец громче этого (относительно речи) = речь оборвана
    'head_loud_db': -14,        # начало громче этого = речь начата с обрыва
    'rate_low': 0.5,            # темп «секунд речи на букву» меньше медианы во столько раз = пропущены слова
    'rate_high': 1.8,           # больше медианы во столько раз = бормотание, повтор или зависание
    'max_inner_silence_ms': 700,  # тишина внутри фрагмента (без многоточия) длиннее этого = сбой
    'click_level': 0.15,        # скачок на краю (доля от уровня речи) выше этого = щелчок
    'level_jump_db': 6,         # громкость отличается от соседей больше чем на столько = скачок
}

SEVERE = ('silent', 'clip', 'tail_cut', 'head_cut', 'rate', 'inner_gap')
TITLES = {
    'silent': 'тишина вместо речи', 'clip': 'перегрузка (клиппинг)', 'tail_cut': 'речь оборвана в конце',
    'head_cut': 'речь начата с обрыва', 'rate': 'неверная длительность (пропуск или бормотание)',
    'inner_gap': 'длинная тишина внутри', 'click_start': 'щелчок в начале', 'click_end': 'щелчок в конце',
    'long_lead': 'длинная тишина в начале', 'long_tail': 'длинная тишина в конце',
    'level_jump': 'скачок громкости', 'forced_cut': 'фрагмент оборван без знака препинания',
}


def config_from(raw):
    """Настройки из settings.json (ключ "seams") поверх DEFAULTS; всё негодное игнорируется."""
    cfg = {k: (dict(v) if isinstance(v, dict) else v) for k, v in DEFAULTS.items()}
    if isinstance(raw, dict):
        for key, default in DEFAULTS.items():
            value = raw.get(key)
            if key == 'engines' and isinstance(value, dict):
                cfg['engines'].update({str(k): bool(v) for k, v in value.items()})
            elif isinstance(default, (int, float)) and not isinstance(default, bool) \
                    and isinstance(value, (int, float)) and not isinstance(value, bool):
                cfg[key] = type(default)(value) if isinstance(default, int) else float(value)
    cfg['retries'] = max(0, min(5, int(cfg['retries'])))
    return cfg


def letters(text):
    return sum(ch.isalpha() for ch in re.sub(r'[+*]', '', text))


def frame_db(x, sr, hop_ms=5):
    hop = max(1, int(sr * hop_ms / 1000))
    n = len(x) // hop
    if n == 0:
        return np.zeros(0), hop
    f = x[:n * hop].reshape(n, hop).astype(np.float64)
    return 20 * np.log10(np.sqrt((f ** 2).mean(axis=1)) + 1e-9), hop


def _db(x):
    return 20 * np.log10(float(np.sqrt(np.mean(np.square(x, dtype=np.float64)))) + 1e-9) if len(x) else -120.0


def analyze(x, sr):
    """Измерения одного фрагмента (mono float32). Время в миллисекундах, уровни в дБ относительно полной шкалы
    (speech_db) или относительно речи (head_db, tail_db)."""
    x = np.asarray(x, dtype=np.float32).reshape(-1)
    n = len(x)
    out = {'samples': n, 'silent': True, 'peak': float(np.abs(x).max()) if n else 0.0,
           'dc': float(x.mean()) if n else 0.0}
    db, hop = frame_db(x, sr)
    if not len(db):
        return out
    speech_db = float(np.percentile(db, 90))
    thr = max(speech_db - 35.0, -60.0)
    voiced = db >= thr
    if speech_db < -55.0 or not voiced.any():
        return out
    first = int(np.argmax(voiced))
    last = len(voiced) - int(np.argmax(voiced[::-1]))                 # кадр после последнего звучащего
    inner, run, longest = voiced[first:last], 0, 0
    for v in inner:
        run = 0 if v else run + 1
        longest = max(longest, run)
    ref = 10 ** (speech_db / 20)
    head, tail = x[:int(sr * 0.010)], x[-int(sr * 0.030):]
    out.update({
        'silent': False, 'speech_db': speech_db,
        'lead_ms': first * hop * 1000.0 / sr,
        'tail_ms': (n - last * hop) * 1000.0 / sr,
        'speech_s': (last - first) * hop / sr,
        'inner_silence_ms': longest * hop * 1000.0 / sr,
        'head_db': _db(head) - speech_db, 'tail_db': _db(tail) - speech_db,
        'start_jump': abs(float(x[0])) / ref, 'end_jump': abs(float(x[-1])) / ref,
        'clipped': int(np.sum(np.abs(x) >= 0.999)),
    })
    return out


class Tracker:
    """Скользящая картина по принятым фрагментам: типичный темп и громкость."""

    def __init__(self, size=40):
        self.rates, self.levels = deque(maxlen=size), deque(maxlen=size)

    def add(self, m, text):
        n = letters(text)
        if not m.get('silent') and n >= 6 and m['speech_s'] > 0:
            self.rates.append(m['speech_s'] / n)
        if not m.get('silent'):
            self.levels.append(m['speech_db'])

    def rate(self):
        return float(np.median(self.rates)) if len(self.rates) >= 8 else None

    def level(self):
        return float(np.median(list(self.levels)[-8:])) if len(self.levels) >= 5 else None


def reasons(m, text, tracker, cfg):
    """(серьёзные причины, мелкие причины). Серьёзные вызывают повторный синтез, мелкие исправляются краями."""
    if m.get('silent'):
        return ['silent'], []
    severe, minor = [], []
    if m['clipped'] >= 3:
        severe.append('clip')
    if m['tail_db'] > cfg['tail_loud_db']:
        severe.append('tail_cut')
    if m['head_db'] > cfg['head_loud_db']:
        severe.append('head_cut')
    n, med = letters(text), tracker.rate()
    if med and n >= 12:
        ratio = (m['speech_s'] / n) / med
        if ratio < cfg['rate_low'] or ratio > cfg['rate_high']:
            severe.append('rate')
    if m['inner_silence_ms'] > cfg['max_inner_silence_ms'] and '…' not in text and '...' not in text:
        severe.append('inner_gap')
    if m['start_jump'] > cfg['click_level']:
        minor.append('click_start')
    if m['end_jump'] > cfg['click_level']:
        minor.append('click_end')
    if m['lead_ms'] > cfg['max_lead_ms']:
        minor.append('long_lead')
    if m['tail_ms'] > cfg['max_tail_ms']:
        minor.append('long_tail')
    lvl = tracker.level()
    if lvl is not None and abs(m['speech_db'] - lvl) > cfg['level_jump_db']:
        minor.append('level_jump')
    return severe, minor


def condition(x, sr, cfg, m=None, gain_db=0.0):
    """Привести края в порядок: убрать смещение, обрезать лишнюю тишину сверх допустимой, плавный вход и выход,
    при желании подогнать громкость, не допустить перегрузки."""
    x = np.asarray(x, dtype=np.float32).reshape(-1).copy()
    if not len(x):
        return x
    if abs(float(x.mean())) > 1e-4:
        x -= float(x.mean())
    m = m or analyze(x, sr)
    if not m.get('silent'):
        lead = max(0, int((m['lead_ms'] - cfg['max_lead_ms']) * sr / 1000))
        tail = max(0, int((m['tail_ms'] - cfg['max_tail_ms']) * sr / 1000))
        if lead or tail:
            x = x[lead:len(x) - tail] if tail else x[lead:]
    fi, fo = int(sr * cfg['fade_in_ms'] / 1000), int(sr * cfg['fade_out_ms'] / 1000)
    if fi > 1 and len(x) > fi:
        x[:fi] *= (0.5 - 0.5 * np.cos(np.linspace(0, np.pi, fi))).astype(np.float32)
    if fo > 1 and len(x) > fo:
        x[-fo:] *= (0.5 + 0.5 * np.cos(np.linspace(0, np.pi, fo))).astype(np.float32)
    if gain_db:
        x *= float(10 ** (gain_db / 20))
    peak = float(np.abs(x).max())
    if peak > 0.99:
        x *= 0.99 / peak
    return x


def clock(seconds):
    s = int(round(seconds))
    return f'{s // 3600}:{s % 3600 // 60:02d}:{s % 60:02d}' if s >= 3600 else f'{s // 60}:{s % 60:02d}'


class Report:
    """Копится по всей озвучке (несколько глав): итоговые счётчики и список подозрительных стыков."""

    def __init__(self):
        self.counts = {'fragments': 0, 'processed': 0, 'edges_fixed': 0, 'retried': 0, 'suspicious': 0, 'forced': 0}
        self.records = []

    def add(self, record):
        if len(self.records) < 1000:
            self.records.append(record)

    def summary(self):
        c = self.counts
        if not c['fragments']:
            return ''
        return (f'Стыки: фрагментов {c["fragments"]}, края исправлены у {c["edges_fixed"]}, повторный синтез '
                f'{c["retried"]}, остались подозрительными {c["suspicious"]}, без знака в конце {c["forced"]}.')

    def text(self):
        lines = [self.summary(), '']
        shown = [r for r in self.records if r['severe'] or r['tries'] or r['kind'] == 'forced']
        if shown:
            lines.append('Фрагменты, на которые стоит посмотреть (глава, время от начала главы):')
            for r in shown:
                why = ', '.join(TITLES.get(k, k) for k in (r['severe'] + r['minor']))
                note = f'; повторов: {r["tries"]}' if r['tries'] else ''
                end = ' (осталось)' if r['severe'] else (' (исправлено повтором)' if r['tries'] else '')
                lines.append(f'  {r["chapter"] or "-"} · {clock(r["t"])} · {why or "оборван без знака"}{note}{end} · «{r["text"]}»')
        else:
            lines.append('Подозрительных стыков не найдено.')
        minor = [r for r in self.records if r['minor'] and not r['severe'] and not r['tries']]
        if minor:
            lines += ['', f'Мелкие замечания (края исправлены автоматически): {len(minor)}']
        return '\n'.join(lines) + '\n'


class Session:
    """Обработка фрагментов одной главы. fragment() заменяет прямой вызов синтеза."""

    def __init__(self, engine, sr, cfg=None, report=None, chapter='', tracker=None):
        self.cfg = cfg or config_from(None)
        self.engine, self.sr, self.chapter = engine, sr, chapter
        self.report = report if report is not None else Report()
        self.tracker = tracker or Tracker()
        self.on = bool(self.cfg['engines'].get(engine))

    def pause_ms(self, base_ms, text=''):
        """Пауза после фрагмента: таблица пауз, а где она дала 0 (оборван без знака) небольшая своя."""
        if self.on and base_ms == 0 and self.cfg['forced_pause_ms']:
            self.report.counts['forced'] += 1
            return int(self.cfg['forced_pause_ms'])
        return base_ms

    def fragment(self, make, text, t=0.0, log=None):
        """make() -> float32. Возвращает обработанный звук; при серьёзной причине синтезирует заново."""
        cfg, rep = self.cfg, self.report
        rep.counts['fragments'] += 1
        if not self.on:
            return make()
        tries, best = 0, None
        while True:
            try:
                audio = make()
                m = analyze(audio, self.sr)
                severe, minor = reasons(m, text, self.tracker, cfg)
            except Exception as e:
                if tries >= cfg['retries']:
                    raise
                tries += 1
                rep.counts['retried'] += 1
                if log:
                    log(f'  повтор синтеза ({type(e).__name__}): {text[:50]}')
                continue
            if best is None or len(severe) < len(best[2]):
                best = (audio, m, severe, minor)
            if not severe or tries >= cfg['retries']:
                break
            tries += 1
            rep.counts['retried'] += 1
            if log:
                log('  повтор синтеза (' + ', '.join(TITLES[k] for k in severe) + f'): {text[:50]}')
        audio, m, severe, minor = best
        gain = 0.0
        lvl = self.tracker.level()
        if cfg['level_match_db'] and lvl is not None and not m.get('silent'):
            gain = float(np.clip(lvl - m['speech_db'], -cfg['level_match_db'], cfg['level_match_db']))
        out = condition(audio, self.sr, cfg, m, gain)
        rep.counts['processed'] += 1
        if minor:
            rep.counts['edges_fixed'] += 1
        if severe:
            rep.counts['suspicious'] += 1
        else:
            self.tracker.add(m, text)
        if severe or minor or tries:
            rep.add({'chapter': self.chapter, 't': t, 'text': text[:80], 'severe': severe, 'minor': minor,
                     'tries': tries, 'kind': 'fragment'})
        return out

    def note_forced(self, text, t):
        """Фрагмент без знака препинания в конце попадает в отчёт: это место возможной слышимой склейки."""
        self.report.add({'chapter': self.chapter, 't': t, 'text': text[:80], 'severe': [], 'minor': [],
                         'tries': 0, 'kind': 'forced'})
