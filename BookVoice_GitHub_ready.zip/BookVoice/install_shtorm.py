"""Загрузка файлов Shtorm в отдельную среду BookVoice (запускать через venv_shtorm)."""
from pathlib import Path
import sys

from huggingface_hub import snapshot_download
import model_dirs

REPO_ID = 'ArtShtorm/Shtorm-PocketTTS-RU'

def main():
    target = Path(model_dirs.SHTORM_DIR)
    target.mkdir(parents=True, exist_ok=True)
    print(f'Модель: {REPO_ID}')
    print(f'Папка: {target}')
    print('Загружаю обе конфигурации fast/slow (около 0,9 ГБ суммарно).')
    try:
        snapshot_download(
            repo_id=REPO_ID,
            local_dir=str(target),
            allow_patterns=[
                'config.yaml', 'config_fast.yaml', 'config_slow.yaml',
                'model_fast.safetensors', 'model_slow.safetensors', 'tokenizer.model',
            ],
        )
    except Exception as exc:
        print(f'Ошибка загрузки модели: {type(exc).__name__}: {exc}')
        print('Проверь интернет, свободное место и доступ к Hugging Face. Повтори установку: '
              'уже скачанные файлы будут использованы повторно.')
        return 1
    required = ['config_fast.yaml', 'config_slow.yaml', 'model_fast.safetensors',
                'model_slow.safetensors', 'tokenizer.model']
    missing = [name for name in required if not (target / name).is_file()]
    if missing:
        print('Загрузка не завершена, отсутствуют файлы: ' + ', '.join(missing))
        return 1
    # Конфиги репозитория указывают на hf:// URL. Переписываем только два пути
    # на локальные файлы, иначе offline-запуск BookVoice попробует обратиться к сети.
    prefix = target.resolve().as_posix().rstrip('/') + '/'
    for name in ('config.yaml', 'config_fast.yaml', 'config_slow.yaml'):
        cfg = target / name
        if not cfg.is_file():
            continue
        content = cfg.read_text(encoding='utf-8')
        content = content.replace('hf://ArtShtorm/Shtorm-PocketTTS-RU/model_fast.safetensors',
                                  prefix + 'model_fast.safetensors')
        content = content.replace('hf://ArtShtorm/Shtorm-PocketTTS-RU/model_slow.safetensors',
                                  prefix + 'model_slow.safetensors')
        content = content.replace('hf://ArtShtorm/Shtorm-PocketTTS-RU/tokenizer.model',
                                  prefix + 'tokenizer.model')
        cfg.write_text(content, encoding='utf-8')
    # Проверяем, что в конфигурациях больше не осталось сетевых путей к этим файлам.
    for name in ('config_fast.yaml', 'config_slow.yaml'):
        content = (target / name).read_text(encoding='utf-8')
        if 'hf://ArtShtorm/Shtorm-PocketTTS-RU/' in content:
            print(f'Не удалось перевести {name} в локальный режим.')
            return 1
    print('Файлы модели проверены; пути в конфигурациях настроены на локальные файлы.')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
