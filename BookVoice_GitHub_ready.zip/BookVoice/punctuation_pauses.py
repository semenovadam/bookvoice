"""Единые правила пунктуационных и абзацных пауз BookVoice.

Пауза после знака определяется по исходному тексту. Для одной границы выбирается
одно итоговое значение; пунктуационная и абзацная паузы не складываются.
"""
import re

# Длительности в миллисекундах. Значения намеренно различаются.
PUNCTUATION_MS = {
    ",": 120,
    "–": 150,
    "—": 180,
    ":": 220,
    ";": 320,
    ".": 400,
    "?": 450,
    "!": 500,
    "…": 900,
    "...": 900,
    "!!": 600,
    "!!!": 700,
    "??": 650,
    "???": 750,
    "?!": 800,
    "!?": 810,
    "!!?": 850,
    "?!?": 870,
    "...!": 1050,
    "...!!": 1070,
    "...?": 1080,
    "...??": 1090,
    "...?!": 1100,
    "...!?": 1120,
}

PARAGRAPH_MS = {
    0: 0,
    1: 350,
    2: 550,
    3: 750,
}
PARAGRAPH_MAX = 3

# Масштаб длительности пауз в режиме Silero. Уровень 4 = исходная таблица;
# уровень 3 немного быстрее и выбран стартовым, чтобы вернуться ближе к прежнему темпу.
PAUSE_LEVEL_FACTORS = {1: 0.55, 2: 0.70, 3: 0.85, 4: 1.00, 5: 1.15}
PAUSE_LEVEL = 4


def set_pause_level(level: int) -> int:
    """Устанавливает уровень 1–5 и возвращает нормализованное значение."""
    global PAUSE_LEVEL
    try:
        PAUSE_LEVEL = max(1, min(5, int(round(float(level)))))
    except (TypeError, ValueError):
        PAUSE_LEVEL = 3
    return PAUSE_LEVEL


def get_pause_level() -> int:
    return PAUSE_LEVEL


def _scaled(duration_ms: int) -> int:
    factor = PAUSE_LEVEL_FACTORS.get(PAUSE_LEVEL, 0.85)
    return max(0, int(round(duration_ms * factor)))

# Точные комбинации многоточия на границе абзаца имеют собственные значения.
ELLIPSIS_PARAGRAPH_MS = {
    1: 1000,
    2: 1150,
    3: 1300,
}

# Самостоятельные междометия с многоточием: даём синтезатору подсказку
# протянуть гласную автоматически, без пользовательских словарных замен.
_INTERJECTION_RE = re.compile(
    r"(?<![\wА-Яа-яЁё])([АаОоЭэУуЫы])(?:\.{3}|…)(?=[»”\"'’)]?(?:\s|$))", re.IGNORECASE
)


def _ending_token(text: str) -> str:
    """Возвращает самый длинный известный знак/комбинацию в конце фрагмента."""
    # Закрывающие кавычки и скобки, а также маркеры акцента * / ** не мешают видеть знак перед ними:
    # в «**Стоять!**» пауза всё равно определяется по «!».
    value = text.rstrip().rstrip('»”\"\'’)]}*')
    # Многоточие и цепочки знаков должны проверяться раньше одиночных знаков.
    for token in ("...?!", "...!?", "...!!", "...??", "...!", "...?",
                  "!!?", "?!?", "!!!", "???", "?!", "!?", "!!", "??",
                  "...", "…", "?", "!", ".", ";", ":", "—", "–", ","):
        if value.endswith(token):
            return token
    return ""


def _punctuation_pause_raw(text: str) -> int:
    """Возвращает базовую длительность без применения уровня ползунка."""
    token = _ending_token(text)
    if not token:
        return 0
    if token in PUNCTUATION_MS:
        return PUNCTUATION_MS[token]
    # Для длинных/необычных цепочек выбираем наиболее выразительный распознанный знак.
    for candidate in ("…", "...", "?!", "!?", "!!!", "???", "!!", "??", "?", "!"):
        if candidate in token:
            return PUNCTUATION_MS[candidate]
    return PUNCTUATION_MS.get(token[-1], 0)


def punctuation_pause_ms(text: str) -> int:
    """Пауза по знаку с применением выбранного уровня длительности."""
    return _scaled(_punctuation_pause_raw(text))


def pause_ms(text: str, paragraph_breaks: int = 0) -> int:
    """Единая пауза на границе; паузы не суммируются.

    paragraph_breaks: 0 — нет абзацного перехода; 1/2/3 — одинарный,
    двойной или тройной переход. Значения выше 3 нормализуются к 3.
    """
    count = max(0, min(PARAGRAPH_MAX, int(paragraph_breaks or 0)))
    token = _ending_token(text)
    if count and token in ("...", "…"):
        duration = ELLIPSIS_PARAGRAPH_MS[count]
    elif count:
        duration = max(_punctuation_pause_raw(text), PARAGRAPH_MS[count])
    else:
        duration = _punctuation_pause_raw(text)
    return _scaled(duration)


def prepare_tts_text(text: str) -> str:
    """Автоматически удлиняет короткие междометия перед многоточием для TTS."""
    def repl(match):
        letter = match.group(1)
        lower = letter.lower()
        # Повторение только в копии для синтеза. Оригинальный текст не меняется.
        return letter + lower * 3
    return _INTERJECTION_RE.sub(repl, text)
