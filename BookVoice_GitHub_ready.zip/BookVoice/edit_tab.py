import bisect
import itertools
import re
import threading
import time
import tkinter as tk
from io import BytesIO
from pathlib import Path
from tkinter import filedialog, messagebox, simpledialog, ttk

import numpy as np

import bookexport
import bookio
import layoutmarks as lm
import textmenu
from emphasis import inject_absolute_emphasis_ranges, ranges_to_paragraph_annotations
import accent_pipeline
from punctuation_pauses import pause_ms

BASE = Path(__file__).parent
USER_WORDS = BASE / 'user_words.txt'
WORD_RE = re.compile(r'[А-Яа-яЁё]+(?:-[А-Яа-яЁё]+)*')
ALPHA = 'абвгдеёжзийклмнопрстуфхцчшщъыьэюя'
TOKEN_RE = re.compile(r"[А-Яа-яЁё]+(?:['’-][А-Яа-яЁё]+)*")
VOWELS = 'аеёиоуыэюяАЕЁИОУЫЭЮЯ'


def sentence_spans(text):
    """Границы предложений в абзаце: те же, что при озвучке (accent_pipeline.sentence_spans: сокращения и
    инициалы не рвут предложение, «…» перед строчной буквой и «! — сказал он» тоже)."""
    return accent_pipeline.sentence_spans(text)


def widget_accent_ranges(w):
    """Акценты окна текста как [(начало, конец, уровень)]: смещения в символах от начала текста."""
    out = []
    for tag, level in (('accent1', 1), ('accent2', 2)):
        tag_ranges = w.tag_ranges(tag)
        for a, b in zip(tag_ranges[::2], tag_ranges[1::2]):
            try:
                out.append((len(w.get('1.0', a)), len(w.get('1.0', b)), level))
            except tk.TclError:
                continue
    return out


def stress_variants(word):
    """[(номер гласной, слово с + перед ней)]; у слова с «ё» ударение только на ней."""
    idxs = [i for i, c in enumerate(word) if c in VOWELS]
    yo = [i for i in idxs if word[i] in 'ёЁ']
    return [(i, word[:i] + '+' + word[i:]) for i in (yo or idxs)]


def typo_fix(p):
    """Типографика одного абзаца: тире, кавычки-ёлочки, многоточие, пробелы."""
    p = p.replace('\u00a0', ' ')
    p = re.sub(r'[ \t]{2,}', ' ', p).strip()
    p = re.sub(r'^[-–]\s*(?=[А-Яа-яЁёA-Za-z«"])', '— ', p)      # диалог
    p = re.sub(r'\s(?:-{1,2}|–)\s', ' — ', p)
    p = p.replace('...', '…')
    p = re.sub(r'[ ]+([,.;:!?…»)])', r'\1', p)
    p = re.sub(r'([,;!?])(?=[А-Яа-яЁёA-Za-z])', r'\1 ', p)
    p = p.replace('“', '«').replace('”', '»').replace('„', '«')
    out = []
    for c in p:
        if c == '"':
            prev = out[-1] if out else ' '
            out.append('«' if prev in ' ([—–-«' else '»')
        else:
            out.append(c)
    return ''.join(out)


def verse_line_numbers(w):
    """Строки окна (с нуля), которых касается тег «стих»: один запрос к Tk вместо проверки каждой строки."""
    out, ranges = set(), w.tag_ranges('verse')
    for a, b in zip(ranges[::2], ranges[1::2]):
        first, last = int(str(a).split('.')[0]), str(b)
        end = int(last.split('.')[0]) - (1 if last.endswith('.0') else 0)
        out.update(range(first - 1, max(first, end)))
    return out


def item_images(it):
    """Изображения, привязанные к главе (список лежит в самой главе)."""
    return it.setdefault('images', [])


def tail_images_of(tab):
    """Картинки после последней главы."""
    if getattr(tab, 'tail_images', None) is None:
        tab.tail_images = []
    return tab.tail_images


def give_images(tab, imgs, idx):
    """Передать картинки главе с номером idx (в её начало) или, если такой нет, в конец книги."""
    if not imgs:
        return
    target = item_images(tab.items[idx]) if idx < len(tab.items) else tail_images_of(tab)
    target[0:0] = list(imgs)


def center_line_numbers(w):
    """Номера строк окна (с нуля), помеченных оформлением «курсив, по центру»."""
    out, ranges = set(), w.tag_ranges('center_italic')
    for a, b in zip(ranges[::2], ranges[1::2]):
        first, last = int(str(a).split('.')[0]), str(b)
        end = int(last.split('.')[0]) - (1 if last.endswith('.0') else 0)
        out.update(range(first - 1, max(first, end)))
    return out


class EditTab(ttk.Frame):
    def __init__(self, parent, app, theme):
        super().__init__(parent, padding=12)
        self.app, self.t = app, theme
        self.items, self.cur, self.next_id = [], None, 1
        self.tail_images, self.next_img_id, self.sel_img = [], 1, None   # изображения глав и необязательный хвост книги
        self.cover, self.cover_img, self.save_path = None, None, None
        self.title_var, self.author_var = tk.StringVar(), tk.StringVar()
        self.lang_var = tk.StringVar(value='ru')
        self.ch_title = tk.StringVar()
        self.find_var, self.repl_var = tk.StringVar(), tk.StringVar()
        self.use_title, self.use_toc = tk.BooleanVar(value=True), tk.BooleanVar(value=True)
        self.number_start_id = None                      # глава, с которой начинается «Глава 1»
        self.number_excluded_ids = set()               # главы, исключённые из автоматической нумерации
        self.number_fmt = tk.StringVar(value=lm.DEFAULT_NUMBER_FORMAT)
        self.status = tk.StringVar(value='Открой книгу (fb2, txt, md, docx) или возьми ту, что открыта на вкладке «Книга». '
                                         'Несколько файлов сразу станут главами одной книги: «Открыть…» с выбором '
                                         'нескольких файлов, «Добавить файлы…» или перетаскивание в окно.')
        self.dnd_ok = False              # перетаскивание файлов из Проводника (нужен пакет tkinterdnd2)
        self.morph, self.user_words, self._known = None, set(), {}
        self._silent = False
        self.live, self.dragging = None, False
        self.snapshot, self.last_app_book = None, None   # для «есть ли несохранённые правки»
        self.accent_dirty = False        # акценты правили, а текст нет: подпись текста этого не видит
        self.build()
        self.after(300, self.tick)

    # ---------------------------------------------------------------- интерфейс
    def build(self):
        row = ttk.Frame(self)
        row.pack(fill='x')
        ttk.Button(row, text='Открыть…', command=self.open_file).pack(side='left')
        ttk.Button(row, text='Добавить файлы…', command=self.add_files).pack(side='left', padx=6)
        ttk.Button(row, text='Из вкладки «Книга»', command=self.from_book_tab).pack(side='left')
        ttk.Button(row, text='Сохранить', command=self.save).pack(side='left', padx=(6, 0))
        ttk.Button(row, text='Сохранить как…', command=self.save_as).pack(side='left', padx=6)
        ttk.Button(row, text='В озвучку →', style='Accent.TButton',
                   command=self.to_voicing).pack(side='right')

        meta = ttk.Frame(self)
        meta.pack(fill='x', pady=(8, 0))
        ttk.Label(meta, text='Название').pack(side='left')
        ttk.Entry(meta, textvariable=self.title_var, width=30).pack(side='left', padx=(4, 10))
        ttk.Label(meta, text='Автор').pack(side='left')
        ttk.Entry(meta, textvariable=self.author_var, width=22).pack(side='left', padx=(4, 10))
        ttk.Label(meta, text='Язык').pack(side='left')
        ttk.Entry(meta, textvariable=self.lang_var, width=4).pack(side='left', padx=(4, 10))
        ttk.Button(meta, text='Обложка…', command=self.choose_cover).pack(side='left')
        ttk.Button(meta, text='×', width=2, command=self.clear_cover).pack(side='left', padx=3)
        self.cover_lbl = ttk.Label(meta, text='без обложки', style='M.TLabel')
        self.cover_lbl.pack(side='left', padx=6)

        opt = ttk.Frame(self)
        opt.pack(fill='x', pady=6)
        ttk.Checkbutton(opt, text='Титульный лист с обложкой (fb2, epub, mobi)',
                        variable=self.use_title).pack(side='left')
        ttk.Checkbutton(opt, text='Содержание (fb2, epub, mobi)', variable=self.use_toc).pack(
            side='left', padx=14)
        ttk.Label(opt, text='Подпись главы').pack(side='left')
        ttk.Entry(opt, textvariable=self.number_fmt, width=22).pack(side='left', padx=(4, 0))

        pw = ttk.PanedWindow(self, orient='horizontal')
        pw.pack(fill='both', expand=True)
        left, right = ttk.Frame(pw), ttk.Frame(pw)
        pw.add(left, weight=1)
        pw.add(right, weight=3)

        box = ttk.Frame(left)
        box.pack(fill='both', expand=True)
        self.tree = ttk.Treeview(box, columns=('n', 'title', 'chars'), show='headings',
                                 selectmode='browse')
        for c, h, w in (('n', '№', 36), ('title', 'Глава', 170), ('chars', 'Знаков', 62)):
            self.tree.heading(c, text=h)
            self.tree.column(c, width=w, anchor='w' if c == 'title' else 'center')
        sc = ttk.Scrollbar(box, command=self.tree.yview)
        self.tree.configure(yscrollcommand=sc.set)
        self.tree.pack(side='left', fill='both', expand=True)
        sc.pack(side='right', fill='y')
        self.tree.bind('<<TreeviewSelect>>', self.on_select)

        b1, b2 = ttk.Frame(left), ttk.Frame(left)
        b1.pack(fill='x', pady=(6, 0))
        b2.pack(fill='x', pady=(4, 0))
        ttk.Button(b1, text='↑', width=3, command=lambda: self.move(-1)).pack(side='left')
        ttk.Button(b1, text='↓', width=3, command=lambda: self.move(1)).pack(side='left', padx=3)
        ttk.Button(b1, text='Новая', command=self.add_chapter).pack(side='left')
        ttk.Button(b1, text='Удалить', command=self.delete_chapter).pack(side='left', padx=3)
        ttk.Button(b2, text='Слить со следующей', command=self.merge_next).pack(side='left')
        ttk.Button(b2, text='Разбить здесь', command=self.split_here).pack(side='left', padx=3)
        b3 = ttk.Frame(left)
        b3.pack(fill='x', pady=(4, 0))
        self.img_btn = ttk.Button(b3, text='Вставить картинку…', command=lambda: self.insert_images('chapter'))
        self.img_btn.pack(side='left')
        b4 = ttk.Frame(left)
        b4.pack(fill='x', pady=(4, 0))
        self.num_btn = ttk.Button(b4, text='№ Глава 1 — с этой главы', command=self.toggle_number_start)
        self.num_btn.pack(side='left')
        ttk.Button(b4, text='Без главы', command=self.toggle_number_excluded).pack(side='left', padx=6)

        self.title_entry = ttk.Entry(right, textvariable=self.ch_title, font=('Georgia', 13, 'bold'))
        self.title_entry.pack(fill='x')
        self.ch_title.trace_add('write', lambda *a: self.title_changed())

        tb = ttk.Frame(right)
        tb.pack(fill='x', pady=6)
        ttk.Button(tb, text='↶', width=3, command=lambda: self.undo(False)).pack(side='left')
        ttk.Button(tb, text='↷', width=3, command=lambda: self.undo(True)).pack(
            side='left', padx=(3, 10))
        ttk.Label(tb, text='Найти').pack(side='left')
        self.find_entry = ttk.Entry(tb, textvariable=self.find_var, width=14)
        self.find_entry.pack(side='left', padx=(4, 4))
        self.find_entry.bind('<Return>', lambda e: self.find_next())
        ttk.Button(tb, text='Далее', command=self.find_next).pack(side='left')
        ttk.Label(tb, text='на').pack(side='left', padx=4)
        ttk.Entry(tb, textvariable=self.repl_var, width=14).pack(side='left')
        ttk.Button(tb, text='Заменить везде', command=self.replace_all).pack(
            side='left', padx=4)
        tb2 = ttk.Frame(right)
        tb2.pack(fill='x', pady=(0, 6))
        ttk.Button(tb2, text='Типографика (тире, ёлочки, …)', command=self.typography).pack(
            side='left')
        ttk.Button(tb2, text='Орфография', command=self.spell_check).pack(side='left', padx=6)
        tb3 = ttk.Frame(right)
        tb3.pack(fill='x', pady=(0, 6))
        ttk.Button(tb3, text='¶ Пустая строка', command=lambda: self.insert_mark(lm.KIND_EMPTY)).pack(side='left')
        ttk.Button(tb3, text='⎘ Новая страница', command=lambda: self.insert_mark(lm.KIND_PAGE)).pack(
            side='left', padx=6)
        ttk.Button(tb3, text='♪ Стих (курсив, вправо)', command=self.toggle_verse).pack(side='left')
        ttk.Button(tb3, text='Курсив, по центру', command=self.toggle_center_italic).pack(side='left', padx=6)

        self.editor_box = ttk.Frame(right)
        self.editor_box.pack(fill='both', expand=True)
        self.build_image_panel()

        pl = ttk.Frame(right)
        pl.pack(fill='x', pady=(8, 0))
        ttk.Button(pl, text='▶ с курсора', command=self.live_from_cursor).pack(side='left')
        ttk.Button(pl, text='⏹', width=3, command=self.live_stop_all).pack(
            side='left', padx=(8, 2))
        ttk.Button(pl, text='−10 с', width=5,
                   command=lambda: self.app.player.seek_seconds(-10)).pack(side='left', padx=2)
        self.b_play = ttk.Button(pl, text='▶', width=3, command=self.on_play)
        self.b_play.pack(side='left', padx=2)
        ttk.Button(pl, text='+10 с', width=5,
                   command=lambda: self.app.player.seek_seconds(10)).pack(side='left', padx=2)
        self.scale = ttk.Scale(pl, from_=0, to=1000)
        self.scale.pack(side='left', fill='x', expand=True, padx=8)
        self.scale.bind('<ButtonPress-1>', lambda e: setattr(self, 'dragging', True))
        self.scale.bind('<ButtonRelease-1>', self.on_seek)
        self.time_lbl = ttk.Label(pl, text='0:00 / 0:00', style='M.TLabel')
        self.time_lbl.pack(side='left')
        ttk.Label(right, textvariable=self.status, style='M.TLabel', wraplength=640).pack(
            anchor='w', pady=(6, 0))
        self.setup_dnd()

    def make_text(self):
        t = self.t
        w = tk.Text(self.editor_box, wrap='word', undo=True, maxundo=0, autoseparators=True,
                    bg=t['PANEL'], fg=t['FG'], insertbackground=t['ACCENT'], relief='flat',
                    font=('Georgia', 12), padx=14, pady=10, spacing3=6,
                    selectbackground='#3b3f57')
        w.tag_configure('found', background='#5a4d2e')
        w.tag_configure('miss', foreground='#ef7b7b', underline=True)
        w.tag_configure('sent', background='#2b2f40')
        w.tag_configure('speak', background='#7a6330', foreground='#fff3d6')
        w.tag_configure('accent1', background='#3b493f', underline=True)
        w.tag_configure('accent2', background='#6a4938', underline=True)
        w.tag_configure('verse', font=('Georgia', 12, 'italic'), lmargin1=48, lmargin2=48)
        w.tag_configure('center_italic', font=('Georgia', 12, 'italic'), justify='center')      # стих: курсив и сдвиг вправо
        w.tag_configure('layoutmark', foreground='#8f94ad', font=('Georgia', 10, 'italic'),
                        justify='center', background='#23263a')                               # [пустая строка], [новая страница]
        w.bind('<Control-KeyPress>', self.on_ctrl)
        # На некоторых раскладках Ctrl+C/V/X по keycode работает нестабильно;
        # on_ctrl обрабатывает clipboard напрямую, не полагаясь на виртуальные события.
        w.bind('<KeyRelease>', lambda e: self.update_counts())
        w.bind('<Button-3>', self.on_rclick)
        self.dnd_register(w)
        return w

    # ---------------------------------------------------------------- данные
    def by_id(self, i):
        return next((x for x in self.items if x['id'] == i), None)

    def new_item(self, title, paras):
        it = {'id': self.next_id, 'title': title, 'paras': list(paras), 'w': None, 'annotations': [], 'images': [],
              'layout': []}
        self.next_id += 1
        return it

    def render_text(self, w, paras, layout):
        """Положить в окно абзацы и оформление: пустые строки и новые страницы строками-метками, стих тегом.
        Возвращает номер строки (с нуля) каждого абзаца: акценты ссылаются на абзацы, а строк стало больше."""
        lines, para_line, verse_lines = lm.compose_lines(paras, layout)
        w.insert('1.0', '\n'.join(lines))
        for i, line in enumerate(lines, 1):
            if lm.is_mark(line):
                w.tag_add('layoutmark', f'{i}.0', f'{i + 1}.0')
            elif i - 1 in verse_lines:
                w.tag_add('verse', f'{i}.0', f'{i + 1}.0')
        center_paras = {e['paragraph'] for e in lm.clamp_layout(layout, len(paras)) if e['kind'] == lm.KIND_CENTER}
        for pi in center_paras:
            if pi < len(para_line):
                line = para_line[pi] + 1
                w.tag_add('center_italic', f'{line}.0', f'{line + 1}.0')
        return para_line

    def ensure_widget(self, it):
        if it['w'] is None:
            w = self.make_text()
            para_line = self.render_text(w, it['paras'], it.get('layout', []))
            for a in it.get('annotations', []):
                try:
                    line = para_line[int(a['paragraph'])] + 1
                    start, end = int(a['start']), int(a['end'])
                    if line < 1 or start < 0 or end <= start:
                        continue
                    tag = 'accent2' if int(a['level']) == 2 else 'accent1'
                    w.tag_add(tag, f'{line}.{start}', f'{line}.{end}')
                except (KeyError, ValueError, IndexError, tk.TclError):
                    continue
            w.edit_reset()                       # загрузка текста не должна отменяться
            it['w'] = w
        return it['w']

    def get_paras(self, it):
        if it['w'] is None:
            return list(it['paras'])
        return lm.parse_lines(it['w'].get('1.0', 'end').split('\n'))[0]

    def item_layout(self, it):
        """Оформление главы [{paragraph, kind}] (пустые строки, новые страницы, стих, центрированный курсив) относительно get_paras(it)."""
        w = it['w']
        if w is None:
            return [dict(e) for e in lm.clamp_layout(it.get('layout', []), len(it['paras']))]
        return lm.parse_lines(w.get('1.0', 'end-1c').split('\n'), verse_line_numbers(w),
                             center_line_numbers(w))[1]

    def number_index(self):
        """Номер (с нуля) главы, с которой начинается «Глава 1», или None."""
        sid = self.__dict__.get('number_start_id')
        return next((i for i, it in enumerate(self.items) if it['id'] == sid), None)

    def number_format(self):
        var = self.__dict__.get('number_fmt')
        fmt = var.get() if var is not None else lm.DEFAULT_NUMBER_FORMAT
        return fmt if lm.valid_number_format(fmt) else lm.DEFAULT_NUMBER_FORMAT

    def item_accents(self, it):
        """Акценты главы: [{paragraph, start, end, level}] относительно get_paras(it).

        Пустые строки и отступы в окне текста номера абзацев и столбцы не сдвигают: абзацы
        считаются так же, как в get_paras (непустые строки с обрезанными краями)."""
        w = it['w']
        if w is None:
            return [dict(a) for a in it.get('annotations', [])]
        return ranges_to_paragraph_annotations(w.get('1.0', 'end-1c'), widget_accent_ranges(w))

    def accent_records(self, it):
        """Акценты главы с цитатой и контекстом: по ним акцент находится заново после правки текста."""
        paras = self.get_paras(it)
        out = []
        for a in self.item_accents(it):
            try:
                pi, start, end, level = int(a['paragraph']), int(a['start']), int(a['end']), int(a['level'])
                text = paras[pi]
            except (IndexError, KeyError, TypeError, ValueError):
                continue
            if pi >= 0 and 0 <= start < end <= len(text):
                out.append({'paragraph': pi, 'start': start, 'end': end, 'level': level,
                            'quote': text[start:end],
                            'context': text[max(0, start - 24):min(len(text), end + 24)]})
        return out

    def set_paras(self, it, paras, records=None, layout=None):
        """Заменить текст главы. Акценты переносятся на то же слово в том же абзаце; если слово
        заменили и его больше нет, акцент пропадает. Оформление (пустые строки, страницы, стих) остаётся на
        своих абзацах (layout можно передать). Возвращает число потерянных акцентов."""
        if records is None:
            records = self.accent_records(it)
        layout = lm.clamp_layout(self.item_layout(it) if layout is None else layout, len(paras))
        w = it['w']
        para_line = []
        if w is None:
            it['paras'] = list(paras)
            it['layout'] = layout
        else:
            w.edit_separator()
            w.delete('1.0', 'end')
            para_line = self.render_text(w, paras, layout)
            w.edit_separator()
        fresh = bookio.normalize_annotations([dict(r, chapter=0) for r in records],
                                             [(it['title'], list(paras))])
        if w is None:
            it['annotations'] = fresh
        else:
            for a in fresh:
                line = para_line[a['paragraph']] + 1
                w.tag_add('accent2' if a['level'] == 2 else 'accent1',
                          f"{line}.{a['start']}", f"{line}.{a['end']}")
        return len(records) - len(fresh)

    def count_chars(self, it):
        return sum(len(p) for p in self.get_paras(it))

    def collect_book(self):
        b = bookio.Book(title=self.title_var.get().strip(), author=self.author_var.get().strip(),
                        lang=self.lang_var.get().strip() or 'ru', cover=self.cover)
        b.chapters = [(it['title'], self.get_paras(it)) for it in self.items]
        b.annotations = [dict(a, chapter=ci) for ci, it in enumerate(self.items)
                         for a in self.accent_records(it)]
        b.layout = [dict(e, chapter=ci) for ci, it in enumerate(self.items) for e in self.item_layout(it)]
        b.number_from, b.number_format = self.number_index(), self.number_format()
        b.number_excluded = [i for i, it in enumerate(self.items) if it['id'] in getattr(self, 'number_excluded_ids', set())]
        b.images = [{'slot': ci, 'data': im['data'], 'name': im['name']}
                    for ci, it in enumerate(self.items) for im in item_images(it)]
        b.images += [{'slot': len(self.items), 'data': im['data'], 'name': im['name']}
                     for im in tail_images_of(self)]
        return b

    # ---------------------------------------------------------------- загрузка
    def signature(self):
        return (self.title_var.get(), self.author_var.get(),
                tuple((it['title'], tuple(self.get_paras(it)), tuple(im['id'] for im in item_images(it)),
                       lm.layout_key(self.item_layout(it)))
                      for it in self.items),
                tuple(im['id'] for im in tail_images_of(self)),
                (self.number_index(), self.number_format() if self.number_index() is not None else None),
                tuple(it['id'] for it in self.items if it['id'] in getattr(self, 'number_excluded_ids', set())))

    def is_dirty(self):
        return bool(self.items) and (self.accent_dirty or self.signature() != self.snapshot)

    def mark_clean(self):
        self.snapshot = self.signature()
        self.accent_dirty = False

    def on_show(self):
        """Вошли во вкладку: если на вкладке «Книга» открыли другую книгу, подтягиваем её."""
        b = getattr(self.app, 'book', None)
        if not b or not Path(b).exists():
            return
        cur = str(Path(b).resolve())
        if self.items and cur == self.last_app_book:
            return                                    # книга на вкладке «Книга» не менялась
        if self.items and self.is_dirty() and not messagebox.askyesno(
                'Редактор', 'На вкладке «Книга» открыта другая книга. Загрузить её сюда?\n'
                            'Несохранённые правки в редакторе пропадут.'):
            self.last_app_book = cur                  # больше не спрашиваем про эту книгу
            return
        self.last_app_book = cur
        self.load_path(b)

    def reload_from_disk(self):
        """⟳ на вкладке «Книга»: файл мог измениться на диске, перечитываем и здесь."""
        b = getattr(self.app, 'book', None)
        if not b or not Path(b).exists() or not self.items:
            return
        if self.is_dirty() and not messagebox.askyesno(
                'Редактор', 'Книга на диске изменилась. Перечитать её в редакторе?\n'
                            'Несохранённые правки в редакторе пропадут.'):
            return
        self.last_app_book = str(Path(b).resolve())
        self.load_path(b, keep_pos=True)

    def from_book_tab(self):
        if not getattr(self.app, 'book', None) or not Path(self.app.book).exists():
            messagebox.showinfo('Редактор', 'На вкладке «Книга» нет открытого файла. Нажми «Открыть…».')
            return
        self.last_app_book = str(Path(self.app.book).resolve())
        self.load_path(self.app.book)

    BOOK_TYPES = [('Книги', '*.fb2 *.txt *.md *.markdown *.docx *.doc'), ('Все', '*.*')]

    def open_file(self):
        """Один файл открывается как книга, несколько (Ctrl или Shift в окне выбора) собираются в одну книгу."""
        ps = filedialog.askopenfilenames(title='Открыть книгу или несколько файлов', filetypes=self.BOOK_TYPES)
        if ps:
            self.load_paths(ps)

    def add_files(self):
        """Добавить файлы (md, txt, docx, fb2) в конец книги: каждый станет главой."""
        ps = filedialog.askopenfilenames(title='Добавить файлы как главы', filetypes=self.BOOK_TYPES)
        if ps:
            self.add_or_open(ps)

    def add_or_open(self, paths):
        """Пустой редактор: из файлов собирается новая книга. Книга уже есть: файлы добавляются главами в конец."""
        if self.items:
            self.append_paths(paths)
        else:
            self.load_paths(paths)

    def report_skipped(self, skipped):
        if skipped:
            lines = [f'{name}: {why}' for name, why in skipped[:10]]
            if len(skipped) > 10:
                lines.append(f'…и ещё {len(skipped) - 10}')
            messagebox.showwarning('Не все файлы взяты', 'Эти файлы пропущены:\n\n' + '\n'.join(lines))

    def load_paths(self, paths):
        """Открыть файлы как новую книгу: один файл как есть, несколько склеиваются главами по порядку имён."""
        files = bookio.expand_paths(paths)
        if not files:
            messagebox.showinfo('Открытие', 'Не нашёл файлов книги (fb2, txt, md, docx).')
            return
        if len(files) == 1:
            self.load_path(files[0])
            return
        if self.items and self.is_dirty() and not messagebox.askyesno(
                'Редактор', f'Из {len(files)} файлов будет собрана новая книга.\n'
                            'Несохранённые правки в редакторе пропадут. Продолжить?'):
            return
        merged = bookio.merge_files(files)
        self.report_skipped(merged.skipped)
        if not merged.book.chapters:
            messagebox.showerror('Открытие', 'Ни из одного файла не удалось взять текст.')
            return
        self.live_stop_all()
        self.load_book(merged.book)
        self.snapshot = None                  # собранная книга ещё нигде не сохранена
        self.accent_dirty = False
        self.save_path = None
        self.src_name = merged.book.title or 'book'
        self.status.set(f'Собрана книга из файлов: {len(merged.used)}, глав: {len(merged.book.chapters)}. '
                        'Проверь порядок (↑ ↓), название и автора, затем «Сохранить как…» (fb2).')

    def append_paths(self, paths):
        """Добавить файлы главами в конец открытой книги."""
        files = bookio.expand_paths(paths)
        if not files:
            messagebox.showinfo('Добавление', 'Не нашёл файлов книги (fb2, txt, md, docx).')
            return
        merged = bookio.merge_files(files)
        self.report_skipped(merged.skipped)
        if not merged.book.chapters:
            return
        new = []
        old_tail = list(tail_images_of(self))
        for title, paras in merged.book.chapters:
            it = self.new_item(title, paras)
            self.items.append(it)
            new.append(it)
        if merged.book.images:                        # картинки из добавленных файлов + прежний «хвост» книги
            self.tail_images = []
            give_images(self, old_tail, len(self.items) - len(new))
            for im in merged.book.images:
                try:
                    slot, img = int(im['slot']), self.new_image(im['data'], im.get('name') or 'картинка')
                except (KeyError, TypeError, ValueError):
                    continue
                (item_images(new[slot]) if 0 <= slot < len(new) else tail_images_of(self)).append(img)
        for e in getattr(merged.book, 'layout', []):
            try:
                new[int(e['chapter'])]['layout'].append({'paragraph': int(e['paragraph']), 'kind': e['kind']})
            except (KeyError, TypeError, ValueError, IndexError):
                continue
        for a in merged.book.annotations:
            try:
                new[int(a['chapter'])]['annotations'].append(dict(a))
            except (KeyError, TypeError, ValueError, IndexError):
                continue
        if not self.title_var.get().strip():
            self.title_var.set(merged.book.title)
        if not self.author_var.get().strip():
            self.author_var.set(merged.book.author)
        if not self.cover and merged.book.cover:
            self.set_cover(merged.book.cover)
        self.refresh_tree()
        self.select_item(new[0])
        self.status.set(f'Добавлено файлов: {len(merged.used)}, глав: {len(new)} (в конец книги).')

    # ---------------------------------------------------------------- перетаскивание файлов
    def setup_dnd(self):
        """Принимать файлы, брошенные из Проводника. Работает, если окно создано через tkinterdnd2
        (см. app.py); без этого пакета остаются кнопки «Открыть…» и «Добавить файлы…»."""
        try:
            from tkinterdnd2 import DND_FILES      # noqa: F401
            self.dnd_ok = hasattr(self.winfo_toplevel(), 'TkdndVersion')
        except Exception:
            self.dnd_ok = False
        if not self.dnd_ok:
            return False
        for w in (self, self.tree, self.editor_box):
            self.dnd_register(w)
        return True

    def dnd_register(self, w):
        if not self.dnd_ok:
            return
        try:
            from tkinterdnd2 import DND_FILES
            w.drop_target_register(DND_FILES)
            w.dnd_bind('<<Drop>>', self.on_drop)
        except Exception:
            pass

    def on_drop(self, event):
        try:
            paths = list(self.tk.splitlist(event.data))      # пути с пробелами приходят в фигурных скобках
        except Exception:
            paths = [str(getattr(event, 'data', ''))]
        paths = [p for p in paths if p]
        if paths and all(Path(p).suffix.lower() in bookexport.IMAGE_EXTS for p in paths):
            self.after(10, lambda: self.insert_images('after', paths))   # картинки: в книгу после выбранного
        elif paths:
            self.after(10, lambda: self.add_or_open(paths))  # окно Проводника отпускаем до диалогов
        return getattr(event, 'action', 'copy')

    def load_path(self, path, keep_pos=False):
        try:
            book = bookio.read_any(path)
        except Exception as e:
            messagebox.showerror('Открытие', str(e))
            return
        pos = self.index_of_cur() if keep_pos else 0
        self.live_stop_all()
        self.load_book(book)
        if keep_pos and self.items:
            self.select_item(self.items[min(max(pos, 0), len(self.items) - 1)])
        self.mark_clean()
        self.save_path = None
        self.src_name = Path(path).stem
        self.status.set(f'Открыто: {Path(path).name}, глав: {len(book.chapters)}.')

    def load_book(self, b):
        self.hide_image_panel()
        for it in self.items:
            if it['w'] is not None:
                it['w'].destroy()
        self.items, self.cur = [], None
        self.tail_images = []
        self.title_var.set(b.title)
        self.author_var.set(b.author)
        self.lang_var.set(b.lang or 'ru')
        self.set_cover(b.cover)
        self.items = [self.new_item(t, p) for t, p in b.chapters]
        for e in getattr(b, 'layout', []):               # оформление: пустые строки, страницы, стих
            try:
                ci = int(e['chapter'])
                if 0 <= ci < len(self.items):
                    self.items[ci]['layout'].append({'paragraph': int(e['paragraph']), 'kind': e['kind']})
            except (KeyError, TypeError, ValueError):
                continue
        start = getattr(b, 'number_from', None)
        self.number_start_id = self.items[start]['id'] if isinstance(start, int) and 0 <= start < len(self.items) else None
        self.number_excluded_ids = {self.items[i]['id'] for i in getattr(b, 'number_excluded', [])
                                    if isinstance(i, int) and 0 <= i < len(self.items)}
        if self.__dict__.get('number_fmt') is not None:
            self.number_fmt.set(getattr(b, 'number_format', None) or lm.DEFAULT_NUMBER_FORMAT)
        for a in getattr(b, 'annotations', []):
            try:
                ci = int(a['chapter'])
                if 0 <= ci < len(self.items):
                    self.items[ci]['annotations'].append(dict(a))
            except (KeyError, TypeError, ValueError):
                continue
        for im in getattr(b, 'images', []):
            try:
                slot = min(max(int(im['slot']), 0), len(self.items))
                img = self.new_image(im['data'], im.get('name') or 'картинка')
            except (KeyError, TypeError, ValueError):
                continue                              # повреждённую картинку пропускаем, книгу открываем
            (item_images(self.items[slot]) if slot < len(self.items) else self.tail_images).append(img)
        self.refresh_tree()
        if self.items:
            self.select_item(self.items[0])

    # ---------------------------------------------------------------- список глав
    def refresh_tree(self, select=None, select_img=None):
        self.tree.delete(*self.tree.get_children())

        def image_row(im):
            self.tree.insert('', 'end', iid=f"i{im['id']}",
                             values=('▣', im['name'], f"{max(1, len(im['data']) // 1024)} КБ"))
        start = self.number_index()
        chapter_no = 0
        for n, it in enumerate(self.items, 1):
            # Изображения отображаются сразу после главы, к которой они относятся.
            # при заданной нумерации в колонке «№» стоит номер главы, а у вводных глав точка
            if start is None:
                label = n
            elif n - 1 < start or it['id'] in getattr(self, 'number_excluded_ids', set()):
                label = '·'
            else:
                chapter_no += 1
                label = chapter_no
            self.tree.insert('', 'end', iid=str(it['id']),
                             values=(label, it['title'], self.count_chars(it)))
            for im in item_images(it):
                image_row(im)
        for im in tail_images_of(self):
            image_row(im)
        if select_img is not None and self.tree.exists(f"i{select_img['id']}"):
            self.tree.selection_set(f"i{select_img['id']}")
            self.tree.see(f"i{select_img['id']}")
        elif select is not None and self.tree.exists(str(select)):
            self.tree.selection_set(str(select))
            self.tree.see(str(select))

    def select_item(self, it):
        self.refresh_tree(select=it['id']) if not self.tree.exists(str(it['id'])) else None
        self.tree.selection_set(str(it['id']))
        self.tree.see(str(it['id']))
        self.show(it)

    def on_select(self, e=None):
        sel = self.tree.selection()
        if not sel:
            return
        if sel[0].startswith('i'):                     # строка-картинка: iid вида i<номер>
            img = self.find_image(int(sel[0][1:]))
            if img is not None and img is not self.sel_img:
                self.show_image(img)
            return
        it = self.by_id(int(sel[0]))
        if it is not None and it is not self.cur:
            self.show(it)

    def show(self, it):
        self.hide_image_panel()
        if self.cur is not None and self.cur['w'] is not None:
            self.cur['w'].pack_forget()
        self.cur = it
        self.ensure_widget(it).pack(fill='both', expand=True)
        self._silent = True
        self.ch_title.set(it['title'])
        self._silent = False
        self.update_counts()

    def title_changed(self):
        if self._silent or self.cur is None:
            return
        self.cur['title'] = self.ch_title.get()
        if self.tree.exists(str(self.cur['id'])):
            self.tree.set(str(self.cur['id']), 'title', self.cur['title'])

    def update_counts(self):
        if self.cur is None or self.cur['w'] is None:
            return
        text = '\n'.join(l for l in self.cur['w'].get('1.0', 'end').split('\n') if not lm.is_mark(l))
        chars = len(text.strip())
        if self.tree.exists(str(self.cur['id'])):
            self.tree.set(str(self.cur['id']), 'chars', chars)

    def index_of_cur(self):
        return self.items.index(self.cur) if self.cur in self.items else -1

    def move(self, d):
        if self.sel_img is not None:
            self.move_image(d)
            return
        i = self.index_of_cur()
        j = i + d
        if i < 0 or not (0 <= j < len(self.items)):
            return
        self.items[i], self.items[j] = self.items[j], self.items[i]
        self.refresh_tree(select=self.cur['id'])

    def add_chapter(self):
        it = self.new_item(f'Глава {len(self.items) + 1}', [])
        if self.sel_img is not None:                   # новая глава ставится после главы-владельца изображения
            _lst, owner = self.img_location(self.sel_img)
            self.items.insert(self.items.index(owner) + 1 if owner is not None else len(self.items), it)
        else:
            self.items.insert(self.index_of_cur() + 1, it)
        self.refresh_tree()
        self.select_item(it)

    def delete_chapter(self):
        if self.sel_img is not None:
            self.delete_image()
            return
        i = self.index_of_cur()
        if i < 0 or not messagebox.askyesno(
                'Удалить', f'Удалить главу «{self.cur["title"]}»?\nОтменить это нельзя.'):
            return
        it, self.cur = self.cur, None
        if it['w'] is not None:
            it['w'].destroy()
        self.items.remove(it)
        getattr(self, 'number_excluded_ids', set()).discard(it['id'])
        give_images(self, item_images(it), i)           # картинки перед удалённой главой достаются следующей
        if self.__dict__.get('number_start_id') == it['id']:             # «Глава 1» переходит к следующей главе
            self.number_start_id = self.items[min(i, len(self.items) - 1)]['id'] if self.items else None
        self.refresh_tree()
        if self.items:
            self.select_item(self.items[min(i, len(self.items) - 1)])

    def merge_next(self):
        i = self.index_of_cur()
        if i < 0 or i + 1 >= len(self.items):
            return
        nxt = self.items[i + 1]
        shift = len(self.get_paras(self.cur))
        records = self.accent_records(self.cur) + [dict(r, paragraph=r['paragraph'] + shift)
                                                   for r in self.accent_records(nxt)]
        layout = self.item_layout(self.cur) + lm.shift_layout(self.item_layout(nxt), shift)
        extra = {'layout': layout} if layout else {}               # оформление сливаемых глав едет вместе с текстом
        self.set_paras(self.cur, self.get_paras(self.cur) + self.get_paras(nxt), records=records, **extra)
        if nxt['w'] is not None:
            nxt['w'].destroy()
        self.items.remove(nxt)
        if self.__dict__.get('number_start_id') == nxt['id']:
            self.number_start_id = self.cur['id']
        item_images(self.cur).extend(item_images(nxt))  # изображения обеих глав остаются внутри объединённой главы
        getattr(self, 'number_excluded_ids', set()).discard(nxt['id'])
        self.refresh_tree(select=self.cur['id'])

    def split_here(self):
        if self.cur is None:
            return
        w = self.ensure_widget(self.cur)
        idx = w.index('insert')
        lines = w.get('1.0', 'end-1c').split('\n')
        verse = verse_line_numbers(w)
        row, col = (int(x) for x in idx.split('.'))
        rest_lines = [lines[row - 1][col:]] + lines[row:]                    # всё от курсива и до конца главы
        rest_verse = ({0} if row - 1 in verse else set()) | {i - (row - 1) for i in verse if i >= row}
        rest, rest_layout = lm.parse_lines(rest_lines, rest_verse,
                                          {n - (row - 1) for n in center_line_numbers(w) if n >= row - 1})
        if not rest:
            messagebox.showinfo('Разбить', 'Поставь курсор в место, с которого начинается новая глава.')
            return
        title = simpledialog.askstring('Разбить главу', 'Название новой главы:',
                                       initialvalue=f'Глава {len(self.items) + 1}',
                                       parent=self)
        if title is None:
            return
        start = len(w.get('1.0', idx))
        tail_ranges = [(max(0, a - start), b - start, level) for a, b, level in widget_accent_ranges(w)
                       if b > start]
        carried = ranges_to_paragraph_annotations(w.get(idx, 'end-1c'), tail_ranges)   # номера по rest
        w.edit_separator()
        w.delete(idx, 'end')
        w.edit_separator()
        it = self.new_item(title, rest)
        it['layout'] = rest_layout
        it['annotations'] = carried
        self.items.insert(self.index_of_cur() + 1, it)
        self.refresh_tree()
        self.select_item(it)

    # ---------------------------------------------------------------- оформление: пустые строки, страницы, стихи
    def text_widget(self):
        """Окно текста открытой главы (None, если выбрана картинка или главы нет)."""
        if self.cur is None or self.sel_img is not None:
            self.status.set('Выбери главу и поставь курсор в текст.')
            return None
        return self.ensure_widget(self.cur)

    def insert_mark(self, kind):
        """Вставить строку-метку «[пустая строка]» или «[новая страница]» под строкой с курсором
        (если строка пустая, метка встаёт на её место). Несколько нажатий подряд дают несколько меток."""
        w = self.text_widget()
        if w is None:
            return
        line = int(w.index('insert').split('.')[0])
        w.edit_separator()
        if w.get(f'{line}.0', f'{line}.end').strip():
            w.insert(f'{line}.end', '\n' + lm.MARK_TEXT[kind])
            line += 1
        else:
            w.delete(f'{line}.0', f'{line}.end')
            w.insert(f'{line}.0', lm.MARK_TEXT[kind])
        for tag in ('verse', 'accent1', 'accent2', 'miss', 'found'):      # вставленный текст наследует теги соседей
            w.tag_remove(tag, f'{line}.0', f'{line + 1}.0')
        w.tag_add('layoutmark', f'{line}.0', f'{line + 1}.0')
        w.mark_set('insert', f'{line}.end')
        w.edit_separator()
        w.focus_set()
        self.update_counts()
        self.status.set('Добавлена пустая строка.' if kind == lm.KIND_EMPTY else
                        'Добавлена «новая страница»: текст ниже начнётся с новой страницы (в FB2 это новая секция). '
                        'Метку можно стереть как обычную строку.')

    def toggle_verse(self):
        """Строки стиха: курсив и сдвиг вправо. Выделенные строки (или строка с курсором) включаются в стих;
        если все они уже стих, пометка снимается. В FB2 стих идёт стихотворением (эпиграфом, если стоит сразу
        после названия); пустая строка между строками стиха разделяет строфы."""
        w = self.text_widget()
        if w is None:
            return
        if w.tag_ranges('sel'):
            first = int(w.index('sel.first').split('.')[0])
            last_index = w.index('sel.last')
            last = int(last_index.split('.')[0]) - (1 if last_index.endswith('.0') and last_index != w.index('sel.first') else 0)
        else:
            first = last = int(w.index('insert').split('.')[0])
        rows = [n for n in range(first, max(first, last) + 1)
                if w.get(f'{n}.0', f'{n}.end').strip() and not lm.is_mark(w.get(f'{n}.0', f'{n}.end'))]
        if not rows:
            self.status.set('Поставь курсор в строку стиха или выдели строки.')
            return
        marked = verse_line_numbers(w)
        on = not all(n - 1 in marked for n in rows)
        w.edit_separator()
        for n in rows:
            (w.tag_add if on else w.tag_remove)('verse', f'{n}.0', f'{n + 1}.0')
        w.edit_separator()
        self.status.set(f'Стих: {"включён" if on else "снят"} для строк: {len(rows)}.')

    def toggle_center_italic(self):
        """Курсив и выравнивание по центру для выделенных абзацев (или абзаца с курсором)."""
        w = self.text_widget()
        if w is None:
            return
        if w.tag_ranges('sel'):
            first = int(w.index('sel.first').split('.')[0])
            last_index = w.index('sel.last')
            last = int(last_index.split('.')[0]) - (1 if last_index.endswith('.0') and last_index != w.index('sel.first') else 0)
        else:
            first = last = int(w.index('insert').split('.')[0])
        rows = [n for n in range(first, max(first, last) + 1)
                if w.get(f'{n}.0', f'{n}.end').strip() and not lm.is_mark(w.get(f'{n}.0', f'{n}.end'))]
        if not rows:
            self.status.set('Поставь курсор в абзац или выдели текст.')
            return
        marked = center_line_numbers(w)
        on = not all(n - 1 in marked for n in rows)
        w.edit_separator()
        for n in rows:
            (w.tag_add if on else w.tag_remove)('center_italic', f'{n}.0', f'{n + 1}.0')
        w.edit_separator()
        self.status.set(f'Курсив, по центру: {"включён" if on else "снят"} для абзацев: {len(rows)}.')

    def toggle_number_excluded(self):
        """Исключить выбранную главу из нумерации либо вернуть её в общий счёт."""
        if self.cur is None or self.sel_img is not None:
            self.status.set('Выбери главу в списке слева.')
            return
        if self.number_index() is None:
            self.status.set('Сначала включи нумерацию кнопкой «Глава 1 — с этой главы».')
            return
        if self.cur['id'] in self.number_excluded_ids:
            self.number_excluded_ids.remove(self.cur['id'])
            self.status.set('Глава возвращена в общую нумерацию.')
        else:
            self.number_excluded_ids.add(self.cur['id'])
            self.status.set('Глава исключена из нумерации. В содержании останется только её название.')
        self.refresh_tree(select=self.cur['id'])

    def toggle_number_start(self):
        """Отметить выбранную главу как «Глава 1»: до неё (вводные стихи, пролог) без номеров, с неё «Глава N - …»."""
        if self.cur is None or self.sel_img is not None:
            self.status.set('Выбери главу в списке слева.')
            return
        if self.number_start_id == self.cur['id']:
            self.number_start_id = None
            self.status.set('Нумерация глав выключена: названия остаются как есть.')
        else:
            self.number_start_id = self.cur['id']
            title = self.cur['title']
            self.status.set('Нумерация с этой главы: «' + lm.display_title(title, self.number_format(), 1) +
                            '». Главы выше неё в списке остаются без номера. Формат меняется в поле «Подпись главы».')
        self.refresh_tree(select=self.cur['id'])

    # ---------------------------------------------------------------- undo / горячие клавиши
    def undo(self, redo=False):
        if self.cur is None or self.cur['w'] is None:
            return
        try:
            self.cur['w'].edit_redo() if redo else self.cur['w'].edit_undo()
        except tk.TclError:
            pass
        self.update_counts()

    def on_ctrl(self, e):
        """Горячие клавиши редактора; clipboard обрабатываем явно для разных раскладок."""
        w = e.widget
        key = (getattr(e, 'keysym', '') or '').lower()
        # На разных раскладках keysym может меняться, поэтому оставляем keycode как fallback.
        k = getattr(e, 'keycode', -1)
        shift = bool(e.state & 0x1)
        if key == 'z' or k == 90:
            self.undo(redo=shift)
        elif key == 'y' or k == 89:
            self.undo(redo=True)
        elif key == 'c' or k == 67:
            try:
                a, b = w.index('sel.first'), w.index('sel.last')
                self.clipboard_clear()
                self.clipboard_append(w.get(a, b))
            except tk.TclError:
                pass
        elif key == 'v' or k == 86:
            try:
                data = self.clipboard_get()
                try:
                    w.delete('sel.first', 'sel.last')
                except tk.TclError:
                    pass
                w.insert('insert', data)
                w.see('insert')
            except tk.TclError:
                pass
        elif key == 'x' or k == 88:
            try:
                a, b = w.index('sel.first'), w.index('sel.last')
                self.clipboard_clear()
                self.clipboard_append(w.get(a, b))
                w.delete(a, b)
            except tk.TclError:
                pass
        elif key == 'a' or k == 65:
            w.tag_add('sel', '1.0', 'end-1c')
            w.mark_set('insert', 'end-1c')
        elif key == 's' or k == 83:
            self.save()
        elif key == 'f' or k == 70:
            self.find_entry.focus_set()
        else:
            return None
        return 'break'

    # ---------------------------------------------------------------- поиск и замена
    def find_next(self):
        pat = self.find_var.get()
        if not pat or self.cur is None:
            return
        w = self.ensure_widget(self.cur)
        pos = w.search(pat, w.index('insert'), stopindex='end', nocase=True)
        if not pos:
            n, i0 = len(self.items), self.index_of_cur()
            for k in range(1, n + 1):
                it = self.items[(i0 + k) % n]
                if pat.lower() in '\n'.join(self.get_paras(it)).lower():
                    self.select_item(it)
                    w = it['w']
                    pos = w.search(pat, '1.0', stopindex='end', nocase=True)
                    break
        if not pos:
            self.status.set('Не найдено.')
            return
        w.tag_remove('found', '1.0', 'end')
        end = f'{pos}+{len(pat)}c'
        w.tag_add('found', pos, end)
        w.mark_set('insert', end)
        w.see(pos)

    def replace_all(self):
        pat, rep = self.find_var.get(), self.repl_var.get()
        if not pat:
            return
        rx = re.compile(re.escape(pat), re.IGNORECASE)
        total = lost = 0
        for it in self.items:
            new, changed = [], 0
            for p in self.get_paras(it):
                q, n = rx.subn(lambda m: rep, p)
                changed += n
                new.append(q)
            if changed:
                lost += self.set_paras(it, new)
                total += changed
        self.refresh_tree(select=self.cur['id'] if self.cur else None)
        self.status.set(f'Заменено во всей книге: {total}. Ctrl+Z отменяет в текущей главе.'
                        + (f' Акцентов потеряно (слово заменено): {lost}.' if lost else ''))

    # ---------------------------------------------------------------- типографика
    def typography(self):
        if not self.items or not messagebox.askyesno(
                'Типографика',
                'Исправить во всей книге: дефис → тире в диалогах, "кавычки" → «ёлочки», '
                '... → …, лишние пробелы?\nВ открытой главе можно отменить через Ctrl+Z.'):
            return
        changed = lost = 0
        for it in self.items:
            old = self.get_paras(it)
            new = [typo_fix(p) for p in old]
            diff = sum(1 for a, b in zip(old, new) if a != b)
            if diff:
                lost += self.set_paras(it, new)
                changed += diff
        self.refresh_tree(select=self.cur['id'] if self.cur else None)
        self.status.set(f'Типографика: исправлено абзацев: {changed}.'
                        + (f' Акцентов потеряно: {lost}.' if lost else ''))

    # ---------------------------------------------------------------- орфография
    def load_morph(self):
        if self.morph is None:
            try:
                import pymorphy3
                self.morph = pymorphy3.MorphAnalyzer()
            except ImportError:
                messagebox.showinfo(
                    'Орфография',
                    'Нужен пакет pymorphy3. В cmd (venv активен):\n\n'
                    'pip install pymorphy3 pymorphy3-dicts-ru')
                return False
            if USER_WORDS.exists():
                self.user_words = {l.strip().lower() for l in
                                   USER_WORDS.read_text(encoding='utf-8').splitlines() if l.strip()}
        return True

    def word_ok(self, word):
        lw = word.lower()
        if lw in self.user_words:
            return True
        if lw not in self._known:
            self._known[lw] = all(len(part) < 2 or self.morph.word_is_known(part)
                                  for part in lw.split('-'))
        return self._known[lw]

    def spell_check(self):
        if self.cur is None or not self.load_morph():
            return
        w = self.ensure_widget(self.cur)
        w.tag_remove('miss', '1.0', 'end')
        n = 0
        for m in WORD_RE.finditer(w.get('1.0', 'end')):
            if not self.word_ok(m.group(0)):
                w.tag_add('miss', f'1.0+{m.start()}c', f'1.0+{m.end()}c')
                n += 1
        self.status.set(f'Орфография: подозрительных слов в главе: {n}. '
                        'Правый клик по красному слову: варианты, «добавить в словарь».')

    VOWEL_PAIRS = [{'о', 'а'}, {'е', 'и'}, {'е', 'э'}, {'е', 'ё'}, {'и', 'ы'}, {'я', 'е'}, {'ю', 'у'}]

    def suggest(self, word):
        """Варианты в одну правку; в начале типичные ошибки (о/а, е/и, двойные буквы)."""
        w = word.lower()
        cost = {}

        def add(c, k):
            if c != w and len(c) > 1 and k < cost.get(c, 9):
                cost[c] = k

        for i in range(len(w) + 1):
            a, b = w[:i], w[i:]
            if b:
                add(a + b[1:], 1 if (b[:1] == a[-1:] or b[:1] == b[1:2]) else 2)
            if len(b) > 1:
                add(a + b[1] + b[0] + b[2:], 1)
            for c in ALPHA:
                if b:
                    sub = 0 if {b[0], c} in self.VOWEL_PAIRS else 1
                    add(a + c + b[1:], sub)
                add(a + c + b, 1 if (c == a[-1:] or c == b[:1]) else 2)
        good = [c for c in cost if self.word_ok(c)]
        good.sort(key=lambda c: (cost[c], -self.morph.parse(c)[0].score))
        return [x.capitalize() if word[:1].isupper() else x for x in good[:6]]

    # ---------------------------------------------------------------- контекстное меню слова
    def on_rclick(self, e):
        w = e.widget
        textmenu.place_cursor(w, e)          # курсор в точку щелчка (выделение сохраняется, если щёлкнули по нему)
        idx = w.index(f'@{e.x},{e.y}')
        # Если пользователь уже выделил фразу и нажал по ней правой кнопкой,
        # меню действует на выделение, не сбрасывая его.
        try:
            sa, sb = w.index('sel.first'), w.index('sel.last')
            if w.compare(sa, '<=', idx) and w.compare(idx, '<', sb):
                start, end = sa, sb
                selected = w.get(start, end)
                word = selected
            else:
                raise tk.TclError
        except tk.TclError:
            line, col = (int(x) for x in idx.split('.'))
            text = w.get(f'{line}.0', f'{line}.end')
            m = next((m for m in TOKEN_RE.finditer(text) if m.start() <= col < m.end()), None)
            if not m:
                return None
            start, end, word = f'{line}.{m.start()}', f'{line}.{m.end()}', m.group(0)
        menu = self.build_word_menu(w, word, start, end)
        try:
            menu.tk_popup(e.x_root, e.y_root)
        finally:
            menu.grab_release()
        return 'break'

    def apply_text_accent(self, w, start, end, level):
        """Сохраняет акцент как тег редактора; текст книги не меняется."""
        self.accent_dirty = True                 # текст тот же, но сохранить правку нужно
        # Remove both levels first, then apply the requested level.
        w.tag_remove('accent1', start, end)
        w.tag_remove('accent2', start, end)
        if level in (1, 2):
            w.tag_add('accent2' if level == 2 else 'accent1', start, end)
        w.tag_remove('sel', '1.0', 'end')
        w.tag_add('sel', start, end)
        w.mark_set('insert', end)
        w.see(start)


    def build_word_menu(self, w, word, start, end):
        t = self.t
        menu = tk.Menu(self, tearoff=0, bg=t['PANEL'], fg=t['FG'],
                       activebackground='#3b3f57', activeforeground=t['ACCENT'])
        off = len(w.get('1.0', start))
        textmenu.add_edit_items(menu, w)             # Вырезать / Копировать / Вставить / Выделить всё

        def replace(new):
            w.edit_separator()
            w.delete(start, end)
            w.insert(start, new)
            w.edit_separator()

        single = bool(TOKEN_RE.fullmatch(word))      # выделена фраза: правила слова к ней не относятся
        if single and self.morph and 'miss' in w.tag_names(start):
            for c in self.suggest(word):
                menu.add_command(label=c, command=lambda c=c: replace(c))
            menu.add_command(label='Добавить в словарь пользователя',
                             command=lambda: self.add_user_word(word))
            menu.add_command(label='Пропустить', command=lambda: w.tag_remove('miss', start, end))
            menu.add_separator()
        menu.add_command(label='Лёгкий акцент  *…*',
                         command=lambda: self.apply_text_accent(w, start, end, 1))
        menu.add_command(label='Сильный акцент  **…**',
                         command=lambda: self.apply_text_accent(w, start, end, 2))
        menu.add_command(label='Убрать акцент',
                         command=lambda: self.apply_text_accent(w, start, end, 0))
        menu.add_separator()
        menu.add_command(label='▶ Читать отсюда', command=lambda: self.live_start(off))
        menu.add_command(label='Прослушать слово' if single else 'Прослушать выделенное',
                         command=lambda: self.app.speak_text_async(word.lower()))
        if single:
            menu.add_separator()
            menu.add_command(label='Ударение в слове:', state='disabled')
            for i, variant in stress_variants(word):
                menu.add_command(label='   ' + variant,
                                 command=lambda i=i: self.rule_dialog(word, i, off))
        return menu

    def rule_dialog(self, word, stress_i, off):
        if not getattr(self.app, 'dict_loaded', False) or self.app.tts is None:
            messagebox.showinfo('Правило', 'Словарь ещё не загружен, подожди.')
            return None
        return RuleDialog(self, word, stress_i, off)

    def add_user_word(self, word):
        self.user_words.add(word.lower())
        USER_WORDS.write_text('\n'.join(sorted(self.user_words)) + '\n', encoding='utf-8')
        self.spell_check()

    # ---------------------------------------------------------------- живое чтение и подсветка
    @staticmethod
    def fmt(sec):
        sec = int(sec)
        return f'{sec // 60}:{sec % 60:02d}'

    def on_play(self):
        p = self.app.player
        if p.n:
            p.toggle()
        else:
            self.live_from_cursor()

    def on_seek(self, e):
        self.dragging = False
        self.app.player.seek(self.scale.get() / 1000)

    def live_from_cursor(self):
        if self.cur is None:
            return
        w = self.ensure_widget(self.cur)
        self.live_start(len(w.get('1.0', 'insert')))

    def live_stop_all(self):
        p = self.app.player
        p.stop()
        p.version += 1                 # фоновая озвучка увидит это и остановится
        self.clear_highlight()
        self.live = None

    def build_live_units(self, text, offset, widget=None, pairs=None):
        """Все единицы чтения списком (см. iter_live_units)."""
        return list(EditTab.iter_live_units(self, text, offset, widget=widget, pairs=pairs))

    def iter_live_units(self, text, offset, widget=None, pairs=None):
        """Единицы чтения по абзацам, лениво. С pairs (словарь) ударения, омографы и словарь считаются на
        предложении целиком и только потом текст режется на фрагменты; ленивость нужна, чтобы чтение
        начиналось сразу, а не после обработки всей главы.

        Build live TTS units, carrying editor accent tags into TTS markers.

        Tk tags are not included in widget.get(), so reading the raw text alone
        silently discarded manual emphasis. Convert tag ranges to absolute text
        offsets, then inject markers into each sentence before TTS preprocessing.
        """
        sp = self.app.tts
        pos = 0
        tagged_ranges = []
        if widget is not None:
            tagged_ranges = [(a, b, level) for a, b, level in widget_accent_ranges(widget)
                             if 0 <= a < b <= len(text)]

        lines = text.split('\n')
        for line_index, line in enumerate(lines):
            lead = len(line) - len(line.lstrip())
            par = line.strip()
            base = pos + lead
            pos += len(line) + 1
            if not par or par in lm.MARKS or base + len(par) <= offset:    # метки оформления не читаются
                continue
            # Один переход — одна строка; пустые строки повышают уровень до трёх.
            blank_after = 0
            lookahead = line_index + 1
            while lookahead < len(lines) and (not lines[lookahead].strip() or lm.is_mark(lines[lookahead])):
                blank_after += 1
                lookahead += 1
            paragraph_breaks = min(3, 1 + blank_after)
            spans = sentence_spans(par)
            para_units = []
            for a, b in spans:
                if base + b <= offset:
                    continue
                sentence = par[a:b]
                sentence_start, sentence_end = base + a, base + b
                tts_sentence = inject_absolute_emphasis_ranges(
                    text, sentence_start, sentence_end, tagged_ranges)
                chunks = (sp.prepare_paragraph_ex(tts_sentence) if pairs is None
                          else sp.prepare_paragraph_ex(tts_sentence, pairs))
                mine = [c for _, c in chunks if re.search(r'[А-Яа-яЁёA-Za-z]', c)]
                if not mine:
                    continue
                # Word timings are approximate (as before), based on original text,
                # so the added control markers do not distort timing allocation.
                words = [(base + a + m.start(), base + a + m.end(),
                          max(1, len(re.sub(r'[^\w]', '', m.group(0)))))
                         for m in re.finditer(r'\S+', sentence)]
                plain_lengths = [max(1, len(re.sub(r'\*\*|\*|\+', '', c))) for c in mine]
                total = sum(plain_lengths) or 1
                acc = 0
                for c, chunk_len in zip(mine, plain_lengths):
                    w0 = round(acc / total * len(words))
                    acc += chunk_len
                    w1 = round(acc / total * len(words))
                    para_units.append({'text': c, 'words': words[w0:w1],
                                  'sent': (sentence_start, sentence_end), 'par_end': False})
            if para_units:
                para_units[-1]['par_end'] = True
                para_units[-1]['paragraph_breaks'] = paragraph_breaks
                para_units[-1]['pause_text'] = par
            yield from para_units

    def live_start(self, offset=0):
        app = self.app
        sp = app.tts
        if self.cur is None:
            return
        if sp is None:
            messagebox.showinfo('Чтение', 'Модели ещё загружаются, подожди.')
            return
        if app.tts_busy():
            messagebox.showinfo('Чтение', 'Сейчас идёт озвучка книги или загрузка. Подожди.')
            return
        self.live_stop_all()
        w = self.ensure_widget(self.cur)
        text = w.get('1.0', 'end-1c')
        sp.YO_FROM_BOOK = app.yo_book.get()
        sp.SPEAKER = app.voice.get()
        pairs = sp.load_dictionary(sp.DICT_FILE, book=app.book.stem if app.book else None)
        gen = self.iter_live_units(text, offset, widget=w, pairs=pairs)    # лениво: по абзацам
        first = next(gen, None)
        if first is None:
            self.status.set('С этого места читать нечего.')
            return
        units = itertools.chain([first], gen)
        ver = app.player.begin_stream(sp.SAMPLE_RATE)
        self.live = {'ver': ver, 'item': self.cur, 'text_len': len(text), 'last': None}
        threading.Thread(target=self._live_worker, args=(units, pairs, ver, sp),
                         daemon=True).start()
        self.status.set('Читаю с выбранного места. Пауза, затем правый клик по слову: '
                        'поставить ударение.')

    def _live_worker(self, units, pairs, ver, sp):
        p = self.app.player
        sr = sp.SAMPLE_RATE
        try:
            for u in units:
                if p.version != ver:
                    return
                while p.n - p.pos > 30 * sr and p.version == ver:
                    time.sleep(0.2)                      # буфер впереди достаточный
                audio = sp.say_sentence(u['text'], pairs)
                duration_ms = pause_ms(
                    u.get('pause_text', u['text']),
                    u.get('paragraph_breaks', 0) if u['par_end'] else 0)
                pause = np.zeros(int(sr * duration_ms / 1000), dtype=np.float32)
                start = p.n
                if not p.append(np.concatenate([audio, pause]), ver):
                    return
                words = u['words']
                if words:                                # время слов: пропорционально длине
                    total, acc, entries = sum(x[2] for x in words), 0, []
                    for k, (a, b, wt) in enumerate(words):
                        s0 = start + int(len(audio) * acc / total)
                        acc += wt
                        s1 = start + int(len(audio) * acc / total)
                        if k == len(words) - 1:
                            s1 = start + len(audio) + len(pause)
                        entries.append((s0, s1, a, b, u['sent'][0], u['sent'][1]))
                    p.add_words(entries, ver)
            p.finish(ver)
        except Exception as e:
            import traceback
            traceback.print_exc()
            err = repr(e)
            self.after(0, lambda: self.status.set('Ошибка чтения: ' + err))

    def clear_highlight(self):
        live = self.live
        if live and live['item']['w'] is not None:
            w = live['item']['w']
            w.tag_remove('speak', '1.0', 'end')
            w.tag_remove('sent', '1.0', 'end')

    def scroll_to(self, w, index):
        bb = w.bbox(index)
        if bb is None or bb[1] > w.winfo_height() * 0.65 or bb[1] < 0:
            line = int(index.split('.')[0])
            w.yview(f'{max(1, line - 3)}.0')

    def update_highlight(self):
        live, p = self.live, self.app.player
        if not live or live['ver'] != p.version or self.cur is not live['item'] \
                or live['item']['w'] is None:
            return
        n = len(p.tl_starts)
        i = bisect.bisect_right(p.tl_starts, p.pos, 0, n) - 1
        if i < 0 or p.pos >= p.tl[i][1]:
            return
        if i == live['last']:
            return
        w = live['item']['w']
        if len(w.get('1.0', 'end-1c')) != live['text_len']:       # текст правили: смещения не верны
            live['last'] = i
            self.clear_highlight()
            self.status.set('Текст изменён после старта: подсветка отключена. Запусти чтение заново.')
            return
        s0, e0, a, b, sa, sb = p.tl[i]
        w.tag_remove('speak', '1.0', 'end')
        w.tag_remove('sent', '1.0', 'end')
        w.tag_add('sent', f'1.0+{sa}c', f'1.0+{sb}c')
        w.tag_add('speak', f'1.0+{a}c', f'1.0+{b}c')
        self.scroll_to(w, w.index(f'1.0+{a}c'))
        live['last'] = i

    def tick(self):
        p = self.app.player
        if p.n:
            if not self.dragging:
                self.scale.set(1000 * p.pos / max(p.n, 1))
            self.time_lbl.configure(text=f'{self.fmt(p.pos / p.sr)} / {self.fmt(p.n / p.sr)}')
        self.b_play.configure(text='⏸' if p.playing else '▶')
        try:
            self.update_highlight()
        except Exception:
            pass
        self.after(120, self.tick)

    # ---------------------------------------------------------------- изображения внутри глав
    IMG_TYPES = [('Картинки', '*.png *.jpg *.jpeg *.gif'), ('PNG (с прозрачностью)', '*.png'), ('Все', '*.*')]

    def new_image(self, data, name):
        """Картинка для книги; ValueError с понятным текстом, если файл не годится."""
        img = {'id': self.next_img_id, 'data': data, 'name': name, 'info': bookexport.check_image(data, name)}
        self.next_img_id += 1
        return img

    def find_image(self, image_id):
        for lst in [item_images(it) for it in self.items] + [tail_images_of(self)]:
            for im in lst:
                if im['id'] == image_id:
                    return im
        return None

    def img_location(self, img):
        """(список, глава): в каком списке лежит картинка и перед какой она главой (None = в конце книги)."""
        for it in self.items:
            if img in item_images(it):
                return item_images(it), it
        return tail_images_of(self), None

    def flat_sequence(self):
        """Книга одним рядом: глава, её изображения, маркер хвоста и изображения после книги."""
        seq = []
        for it in self.items:
            seq.append(('ch', it))
            seq += [('img', im) for im in item_images(it)]
        return seq + [('tail', None)] + [('img', im) for im in tail_images_of(self)]

    def apply_sequence(self, seq):
        """Обратно: изображения прикрепляются к ближайшей главе слева; после маркера хвоста остаются в конце книги."""
        owner = None
        self.tail_images = []
        for kind, obj in seq:
            if kind == 'tail':
                owner = None
            elif kind == 'ch':
                owner = obj
                owner['images'] = []
            elif kind == 'img':
                if owner is not None:
                    owner.setdefault('images', []).append(obj)
                else:
                    self.tail_images.append(obj)

    def image_menu(self):
        # Совместимость со старыми вызовами: изображение вставляется в выбранную главу.
        self.insert_images('chapter')

    def insert_images(self, where='after', paths=None):
        """Вставить картинки (можно несколько сразу) перед / после выбранной главы или картинки либо в конец."""
        if not self.items:
            messagebox.showinfo('Картинки', 'Сначала открой книгу.')
            return
        if paths is None:
            paths = filedialog.askopenfilenames(title='Вставить картинку в выбранную главу', filetypes=self.IMG_TYPES)
        added, errors = [], []
        for p in self.tk.splitlist(paths) if isinstance(paths, str) else paths:
            try:
                added.append(self.new_image(Path(p).read_bytes(), Path(p).name))
            except (OSError, ValueError) as e:
                errors.append(str(e))
        if errors:
            messagebox.showwarning('Картинки', '\n'.join(errors[:8]))
        if not added:
            return
        owner_title = None
        if where == 'chapter':
            if self.cur in self.items:
                owner = self.cur
                lst, pos = item_images(owner), len(item_images(owner))
            elif self.sel_img is not None:
                lst, owner = self.img_location(self.sel_img)
                if owner is None:
                    messagebox.showinfo('Картинки', 'Выбери главу, к которой нужно добавить изображение.')
                    return
                pos = lst.index(self.sel_img) + 1
            else:
                messagebox.showinfo('Картинки', 'Сначала выбери главу в списке слева.')
                return
            owner_title = owner['title']
        elif where == 'end':
            lst, pos = tail_images_of(self), len(tail_images_of(self))
        elif self.sel_img is not None:
            lst, _owner = self.img_location(self.sel_img)
            pos = lst.index(self.sel_img) + (0 if where == 'before' else 1)
        elif self.cur in self.items:
            lst = item_images(self.cur)
            pos = 0 if where == 'before' else len(lst)
        else:
            messagebox.showinfo('Картинки', 'Сначала выбери главу в списке слева.')
            return
        lst[pos:pos] = added
        self.refresh_tree(select_img=added[0])
        self.show_image(added[0])
        suffix = f' Они относятся к главе «{owner_title}».' if owner_title else ''
        self.status.set(f'Картинок добавлено: {len(added)}.{suffix} Стрелки ↑ ↓ меняют порядок.')

    def replace_image(self):
        img = self.sel_img
        if img is None:
            return
        p = filedialog.askopenfilename(title='Заменить картинку', filetypes=self.IMG_TYPES)
        if not p:
            return
        try:
            new = self.new_image(Path(p).read_bytes(), Path(p).name)
        except (OSError, ValueError) as e:
            messagebox.showwarning('Картинки', str(e))
            return
        lst, _owner = self.img_location(img)
        lst[lst.index(img)] = new
        self.refresh_tree(select_img=new)
        self.show_image(new)

    def delete_image(self):
        img = self.sel_img
        if img is None or not messagebox.askyesno('Удалить', f'Удалить картинку «{img["name"]}» из книги?\n'
                                                              'Файл на диске останется.'):
            return
        seq = self.flat_sequence()
        k = seq.index(('img', img)) if ('img', img) in seq else 0
        lst, _owner = self.img_location(img)
        lst.remove(img)
        self.sel_img = None
        left = [x for x in seq if x != ('img', img) and x[0] != 'tail']
        near = left[min(k, len(left) - 1)] if left else None
        self.refresh_tree()
        if near is not None and near[0] == 'ch':
            self.select_item(near[1])
        elif near is not None:
            self.refresh_tree(select_img=near[1])
            self.show_image(near[1])
        else:
            self.hide_image_panel()

    def move_image(self, d):
        img = self.sel_img
        seq = self.flat_sequence()
        if ('img', img) not in seq:
            return
        i = seq.index(('img', img))
        j = i + d
        if not 0 <= j < len(seq):
            return
        if d < 0 and j == 0 and seq[j][0] == 'ch':  # изображение первой главы не может оказаться до книги
            return
        seq[i], seq[j] = seq[j], seq[i]
        self.apply_sequence(seq)
        self.refresh_tree(select_img=img)

    def build_image_panel(self):
        self.img_panel = ttk.Frame(self.editor_box)
        self.img_photo = None
        self.img_label = ttk.Label(self.img_panel, anchor='center')
        self.img_label.pack(fill='both', expand=True, pady=(0, 8))
        self.img_info = ttk.Label(self.img_panel, style='M.TLabel', wraplength=620)
        self.img_info.pack(anchor='w')
        row = ttk.Frame(self.img_panel)
        row.pack(fill='x', pady=(6, 0))
        ttk.Button(row, text='Заменить…', command=self.replace_image).pack(side='left')
        ttk.Button(row, text='Удалить', command=self.delete_image).pack(side='left', padx=6)

    def make_preview(self, data, max_w, max_h):
        """Картинка для окна просмотра. Прозрачные места показываются шахматным фоном."""
        try:
            from PIL import Image, ImageTk
            im = Image.open(BytesIO(data)).convert('RGBA')
            im.thumbnail((max_w, max_h))
            w, h = im.size
            y, x = np.indices((h, w))
            tone = np.where(((x // 10 + y // 10) % 2 == 0), 217, 245).astype(np.uint8)
            bg = Image.fromarray(np.stack([tone, tone, tone], axis=-1), 'RGB').convert('RGBA')
            return ImageTk.PhotoImage(Image.alpha_composite(bg, im).convert('RGB'))
        except Exception:
            try:                                       # без Pillow Tk сам читает PNG и GIF (без шахматного фона)
                import base64
                return tk.PhotoImage(data=base64.b64encode(data))
            except Exception:
                return None

    def show_image(self, img):
        if self.cur is not None and self.cur['w'] is not None:
            self.cur['w'].pack_forget()
        self.cur = None                                # пока открыта картинка, операции с главами отключены
        self.sel_img = img
        self._silent = True
        self.ch_title.set(f'Картинка: {img["name"]}')
        self._silent = False
        self.title_entry.state(['disabled'])
        w = max(240, self.editor_box.winfo_width() - 24)
        h = max(200, self.editor_box.winfo_height() - 110)
        self.img_photo = self.make_preview(img['data'], w, h)
        self.img_label.configure(image=self.img_photo or '', text='' if self.img_photo else 'Предпросмотр недоступен')
        info = img['info']
        self.img_info.configure(
            text=f'{img["name"]}: {info["width"]}×{info["height"]}, {max(1, len(img["data"]) // 1024)} КБ, '
                 f'{info["ext"].upper()}, ' + ('есть прозрачность' if info['alpha'] else 'без прозрачности'))
        self.img_panel.pack(fill='both', expand=True)

    def hide_image_panel(self):
        if self.sel_img is not None:
            self.img_panel.pack_forget()
            self.sel_img = None
            self.title_entry.state(['!disabled'])

    # ---------------------------------------------------------------- обложка
    def choose_cover(self):
        p = filedialog.askopenfilename(filetypes=[('Картинки', '*.jpg *.jpeg *.png')])
        if p:
            self.set_cover(Path(p).read_bytes())

    def clear_cover(self):
        self.set_cover(None)

    def set_cover(self, data):
        self.cover = data
        self.cover_img = None
        if not data:
            self.cover_lbl.configure(text='без обложки', image='')
            return
        text = f'обложка: {len(data) // 1024} КБ'
        try:                                          # миниатюра, если установлен Pillow
            from PIL import Image, ImageTk
            im = Image.open(BytesIO(data))
            im.thumbnail((40, 56))
            self.cover_img = ImageTk.PhotoImage(im)
            self.cover_lbl.configure(text=text, image=self.cover_img, compound='left')
        except Exception:
            self.cover_lbl.configure(text=text, image='')

    # ---------------------------------------------------------------- сохранение и озвучка
    def save_as(self):
        if not self.items:
            messagebox.showinfo('Сохранение', 'Сначала открой книгу.')
            return
        name = (self.title_var.get().strip() or getattr(self, 'src_name', 'book')) + '.fb2'
        p = filedialog.asksaveasfilename(
            defaultextension='.fb2', initialfile=re.sub(r'[\\/:*?"<>|]', '_', name),
            filetypes=[('FB2', '*.fb2'), ('EPUB', '*.epub'), ('MOBI (Kindle)', '*.mobi'),
                       ('Текст', '*.txt'), ('Markdown', '*.md')])
        if p:
            self.save_path = p
            self.save()

    def save(self):
        if not self.items:
            return
        if not self.save_path:
            self.save_as()
            return
        try:
            book = self.collect_book()
            ext = Path(self.save_path).suffix.lower()
            if book.annotations and ext != '.fb2':
                if not messagebox.askyesno(
                        'Акценты BookVoice',
                        'Выбранный формат не поддерживает встроенные аннотации BookVoice. '
                        'При сохранении в этот формат акценты не сохранятся. Продолжить?'):
                    return
            if book.layout and ext != '.fb2':
                if not messagebox.askyesno(
                        'Оформление',
                        'Пустые строки, «новая страница» и оформление стихов сохраняются только в FB2. '
                        'В выбранном формате они пропадут (в редакторе останутся). Продолжить?'):
                    return
            if book.images and ext not in ('.fb2', '.epub', '.mobi'):
                if not messagebox.askyesno(
                        'Картинки',
                        'В текстовом формате картинки сохранить нельзя: они пропадут из файла '
                        '(в редакторе останутся). Продолжить?'):
                    return
            bookio.write_any(book, self.save_path,
                             titlepage=self.use_title.get(), toc=self.use_toc.get())
            self.mark_clean()
            note = ''
            if ext == '.mobi' and any(im['info']['alpha'] for it in self.items for im in item_images(it)) or \
                    ext == '.mobi' and any(im['info']['alpha'] for im in tail_images_of(self)):
                note = ' В MOBI прозрачность упрощена до однобитной (полная есть в EPUB и FB2).'
            self.status.set(f'Сохранено: {self.save_path}.{note}')
        except Exception as e:
            messagebox.showerror('Сохранение', repr(e))

    def to_voicing(self):
        if not self.items:
            return
        name = self.title_var.get().strip() or getattr(self, 'src_name', 'book')
        book = self.collect_book()
        self.app.set_chapters(bookio.annotations_as_markers(book), name=name)
        self.app.nb.select(self.app.tab_book)


class RuleDialog:
    """Окно «Правило ударения»: целые слова / окончание / группа, затем запись в словарь."""

    def __init__(self, tab, word, stress_i, off):
        self.tab, self.app = tab, tab.app
        self.plain, self.st, self.off = word.lower(), stress_i, off
        t = tab.t
        win = self.win = tk.Toplevel(tab)
        win.title('Правило ударения')
        win.configure(bg=t['BG'])
        win.transient(tab.winfo_toplevel())
        win.bind('<Escape>', lambda e: win.destroy())
        f = ttk.Frame(win, padding=14)
        f.pack(fill='both', expand=True)
        stressed = self.plain[:stress_i] + '+' + self.plain[stress_i:]
        ttk.Label(f, text=f'Слово: {word}     Ударение: {stressed}',
                  font=('Georgia', 13, 'bold'), foreground=t['ACCENT']).pack(anchor='w')
        self.whole = tk.BooleanVar(value=True)
        self.open = tk.BooleanVar(value=False)
        self.cut = tk.IntVar(value=1 if word[:1].isupper() else 0)
        self.group = tk.StringVar(value=self.app.default_group())
        self.reread = tk.BooleanVar(value=self.app.player.n > 0)
        self.c_whole = ttk.Checkbutton(f, text='Целые слова (+ от RUAccent не мешают). Рекомендуется',
                                       variable=self.whole, command=self.update)
        self.c_whole.pack(anchor='w', pady=(10, 0))
        row = ttk.Frame(f)
        row.pack(anchor='w', pady=(6, 0))
        self.c_open = ttk.Checkbutton(row, text='Любое окончание (падежи, имена). Отбросить с конца букв:',
                                      variable=self.open, command=self.update)
        self.c_open.pack(side='left')
        self.sp = ttk.Spinbox(row, from_=0, to=5, width=3, textvariable=self.cut,
                              command=self.update)
        self.sp.pack(side='left', padx=6)
        names = self.app.group_names()
        bg = self.app.book_group()
        ttk.Label(f, text='Группа', style='M.TLabel').pack(anchor='w', pady=(10, 2))
        ttk.Combobox(f, textvariable=self.group, state='readonly', width=40,
                     values=names + ([bg] if bg and bg not in names else [])).pack(anchor='w')
        self.prev = ttk.Label(f, text='', font=('Consolas', 11), foreground='#9fd3a8')
        self.prev.pack(anchor='w', pady=(12, 0))
        self.warn = ttk.Label(f, text='', foreground='#ef7b7b', wraplength=520)
        self.warn.pack(anchor='w')
        ttk.Checkbutton(f, text='Перечитать с этого места после сохранения',
                        variable=self.reread).pack(anchor='w', pady=(8, 0))
        bar = ttk.Frame(f)
        bar.pack(fill='x', pady=(12, 0))
        ttk.Button(bar, text='▶ Прослушать слово', command=self.hear).pack(side='left')
        ttk.Button(bar, text='Отмена', command=win.destroy).pack(side='right')
        ttk.Button(bar, text='Сохранить', style='Accent.TButton', command=self.save).pack(
            side='right', padx=8)
        for v in (self.whole, self.open, self.cut, self.group):
            v.trace_add('write', lambda *a: self.update())
        self.update()

    def make_rule(self):
        """-> (правило, текст ошибки)"""
        plain, st = self.plain, self.st
        whole = self.whole.get()
        opened = whole and self.open.get()
        try:
            cut = max(0, int(self.cut.get())) if opened else 0
        except (tk.TclError, ValueError):
            cut = 0
        stem = plain[:len(plain) - cut] if cut else plain
        if st >= len(stem):
            return None, 'Ударение попало в отбрасываемое окончание: уменьши число букв или сними «любое окончание».'
        if len(stem) < 3 and opened:
            return None, 'Слишком короткая основа: правило заденет чужие слова.'
        repl = stem[:st] + '+' + stem[st:]
        key = stem + ('*' if opened else '')
        return {'kind': 'rule', 'word': whole, 'key': key, 'repl': repl,
                'group': self.group.get() or self.app.default_group()}, ''

    def update(self):
        try:
            self.c_open.state(['!disabled'] if self.whole.get() else ['disabled'])
            self.sp.state(['!disabled'] if (self.whole.get() and self.open.get()) else ['disabled'])
        except tk.TclError:
            pass
        r, err = self.make_rule()
        self.warn.configure(text=err or ('' if self.whole.get() else
                                         'Без «целых слов» оригинал должен точно совпасть с текстом после RUAccent.'))
        self.prev.configure(text=(self.app.rule_line(r) if r else ''))

    def hear(self):
        self.app.speak_text_async(self.plain[:self.st] + '+' + self.plain[self.st:], 'слово')

    def save(self):
        r, err = self.make_rule()
        if not r:
            messagebox.showinfo('Правило', err, parent=self.win)
            return None
        app = self.app
        app.ensure_group(r['group'])
        k = app.norm_key(r['key'])
        old = next((x for x in app.rules if x['kind'] == 'rule' and x['group'] == r['group']
                    and app.norm_key(x['key']) == k), None)
        if old:
            old.update(r)                      # то же слово в группе: меняем ударение
        else:
            app.rules.append(r)
        app.save_dict()
        app.refresh_dict()
        self.tab.status.set(f"Правило сохранено в «{r['group']}»: {app.rule_line(r)}")
        self.win.destroy()
        if self.reread.get():
            self.tab.live_start(self.off)
        return r