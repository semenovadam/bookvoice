import json
import os
import re
import subprocess
import threading
import traceback
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, simpledialog, ttk

import model_dirs
model_dirs.apply()              # куда класть модели (см. model_dirs.py): до загрузки torch
for _name in ('HF_HUB_OFFLINE', 'TRANSFORMERS_OFFLINE'):
    os.environ.setdefault(_name, '1')   # сама программа работает без сети; скачивание моделей идёт отдельным процессом (⚙)

import model_manager
model_manager.ensure_ffmpeg_on_path()   # ffmpeg из папки моделей, если в системе его нет

import numpy as np
import soundfile as sf
import sounddevice as sd

import bookio
import models_ui
import ruaccent_ui
import audio_seams as seams
import tera
import textmenu
import shtorm
import shtorm_vox
from edit_tab import EditTab
from punctuation_pauses import pause_ms, set_pause_level

BG, PANEL, FG, MUTED, ACCENT = '#1b1c23', '#252733', '#ece8e1', '#8d8f9c', '#d2ad6b'
VOICES = ['xenia', 'kseniya', 'baya', 'aidar', 'eugene']        # голоса Silero
ENGINES = {'silero': 'Silero', 'tera': 'TeraTTS v2', 'shtorm': 'Shtorm-PocketTTS-RU',
           'voxcpm': 'Shtorm-VoxCPM2-RU'}
SETTINGS = Path(__file__).parent / 'settings.json'   # последний движок, голоса, длительность Tera
speak = None


def build_units(title, paras, pairs=None, limit=None):
    """Книга -> (фрагмент, конец); абзацные уровни кодируются как par1/par2/par3.
    С pairs (словарь) ударения, омографы и словарь обрабатываются на предложении целиком, и только потом текст
    режется на фрагменты (speak.prepare_paragraph_ex); без pairs это просто нарезка (для подсчёта объёма).
    limit: остановиться, как только набрано столько фрагментов (кнопка «Тест» не обрабатывает всю главу)."""
    units = []
    if title.strip().lower() not in ('', 'начало'):
        title_parts = [s for s in speak.prepare_paragraph(title, pairs)
                       if re.search(r'[А-Яа-яЁёA-Za-z]', s)]
        for i, part in enumerate(title_parts):
            units.append((part, 'title' if i == len(title_parts) - 1 else None))

    # Пустые абзацы, если они сохранены источником, усиливают паузу; больше трёх
    # уровней считаем оформительским мусором.
    index = 0
    paras = list(paras)
    while index < len(paras):
        text = paras[index]
        if not str(text).strip():
            index += 1
            continue
        blank_after = 0
        lookahead = index + 1
        while lookahead < len(paras) and not str(paras[lookahead]).strip():
            blank_after += 1
            lookahead += 1
        paragraph_level = min(3, 1 + blank_after)
        sents = [s for s in speak.prepare_paragraph(str(text), pairs)
                 if re.search(r'[А-Яа-яЁёA-Za-z]', s)]
        for i, part in enumerate(sents):
            end = f'par{paragraph_level}' if i == len(sents) - 1 else None
            units.append((part, end))
        if limit is not None and len(units) >= limit:
            break
        index += 1
    return units

HELP_TEXT = """# Как писать правила словаря
Слева «Оригинал», справа «Замена»: программа находит оригинал в тексте и читает вместо него замену.

# Знак +  (ударение)
Плюс ставится ПЕРЕД ударной гласной:
    з+амок   (здание)        зам+ок   (на двери)
Букву «ё» в замене можно писать как обычно. В односложных словах (орк, не, ты) ударение ставит сама Silero, писать его не нужно.

# Галочка «Целые слова»  (в файле: * в начале строки)
Ищет слово или сочетание целиком, и знаки + от RUAccent ему не мешают. Регистр не важен, заглавная буква в начале предложения сохраняется. Для почти всех правил выбирай её.
    Оригинал: Бродог        Замена: Брод+ог
    Оригинал: замок на двери  Замена: зам+ок на двери
Слово «орк» с этой галочкой не заденет «оркестр».

# Без галочки  (запись типа «обычная»)
Точная подстановка в текст ПОСЛЕ RUAccent: в оригинале нужны и его плюсы, один в один (смотри консоль). Нужна только для особых случаев.
    закр+ыл зам+ок на зам+ок = закр+ыл з+амок на зам+ок

# Галочка «Любое окончание (для имён)»  (в файле: * в конце слова)
Правило работает для всех падежей: окончание дописывается само, ударение остаётся там, где ты поставил.
    Оригинал: Бродог   Замена: Брод+ог
    ловит: Бродог, Бродога, Бродогу, Бродогом
Если в каком-то падеже ударение прыгает, сделай для него отдельную строку без этой галочки. Не включай её для коротких слов: «орк» с окончанием заденет «оркестр».

# Порядок и проверка
Правила применяются сверху вниз. Жёлтые строки в таблице: дубли, красные: одно слово с разными заменами. Проверить на слух можно кнопками ▶ Оригинал / ▶ Замена (или Enter в поле «Замена»). Знак = в записях использовать нельзя.

# Группы: общие правила и правила книги
Каждое правило лежит в группе. «Общий» работает всегда. «Список: …» это тематические списки (например, заимствования с твёрдым «э»). «Книга: …» работает только пока открыта эта книга. Новое правило по умолчанию попадает в группу открытой книги, а если книга не открыта, то в «Общий». Другую группу выбираешь в поле «Группа» под таблицей. У готовых правил группу меняют так: выдели строки (Ctrl или Shift) и нажми «В группу».
Меню «Включено ▾» включает и выключает группу целиком. Список «Группа» над таблицей только фильтрует показ.

# Что побеждает, если слово есть в нескольких группах
Книга, потом «Общий», потом списки. Перекрытые правила в таблице тусклые синие. Чтобы в этой книге слово читалось «как обычно», запиши в группе книги замену из одного знака !
    Оригинал: модель     Замена: !
Такое правило ничего не меняет, но отключает правила того же слова из групп ниже.

# Правила, меняющие только буквы
Если в замене нет + и она той же длины, что оригинал, программа меняет только буквы, а ударение оставляет, как поставил RUAccent. Так устроены списки «твёрдого э»:
    Оригинал: индекс  (любое окончание)     Замена: индэкс

# Четыре движка: Silero, TeraTTS v2, Shtorm-PocketTTS-RU и Shtorm-VoxCPM2-RU
Кнопки справа сверху переключают движок. Silero использует встроенные голоса; TeraTTS имеет свои голоса и настройки длительности. Shtorm использует выбранный WAV-образец голоса и варианты fast/slow (при первом выборе Shtorm программа сама спрашивает образец, дальше он запоминается, а сменить его можно кнопкой справа); его пакеты ставятся в отдельную среду venv_shtorm, чтобы не менять пакеты Silero/Tera. Shtorm пока не поддерживает латиницу, а его текст нужно подавать короткими фрагментами; BookVoice делит длинные фразы автоматически. Shtorm-VoxCPM2-RU (русская VoxCPM2 от ArtShtorm) тоже клонирует голос из WAV-образца (5–15 секунд чистой речи); для более точного голоса впиши в поле «Текст образца» дословный текст образца без меток. Метки ударений «+» модель понимает как есть, поэтому RUAccent и словарь работают с ней напрямую (метки на односложных словах и перед «ё» программа снимает сама). «cfg» и «Шагов» меняют точность и скорость: больше шагов значит чище, но медленнее. Нужна видеокарта NVIDIA: модель около 5 ГБ, ставится в свою среду venv_voxcpm (⚙ → «Модели…»), первая загрузка занимает минуту-две. Для каждого движка создаётся своя папка out, чтобы аудиофайлы не смешивались.

# Редактор: книга из нескольких файлов
Чтобы собрать один fb2 из нескольких файлов (md, txt, docx, fb2), на вкладке «Редактор» нажми «Открыть…» и выдели файлы в окне выбора (Ctrl или Shift) либо перетащи их из Проводника в окно: каждый файл станет главой, в порядке имён с учётом чисел (гл2 раньше гл10). Название главы берётся из заголовка файла (# Название) или из имени файла; название книги из имени общей папки. Если книга уже открыта, «Добавить файлы…» и перетаскивание добавляют главы в конец. Порядок меняют кнопки ↑ ↓, потом «Сохранить как…» (fb2). Перетаскивание работает, если установлен пакет tkinterdnd2 (pip install tkinterdnd2); без него есть кнопки.

# Редактор: EPUB, MOBI и изображения внутри глав
«Сохранить как…» умеет fb2, epub, mobi (Kindle), txt и md. Титульный лист и «Содержание» (галочки над списком глав) попадают в fb2, epub и mobi. Изображения внутри глав: выбери главу в списке слева, нажми «Вставить картинку…» и выбери один или несколько файлов (PNG, JPEG, GIF; можно также перетащить файлы в окно). Изображения отображаются сразу под главой, к которой относятся, и при перемещении главы перемещаются вместе с ней. Стрелки ↑ ↓ меняют порядок изображений; справа доступны предпросмотр, «Заменить…» и «Удалить». Изображения сохраняются в FB2, EPUB и MOBI; в TXT и MD их нет. PNG с прозрачностью целиком сохраняется в EPUB и FB2; в MOBI (формат Kindle) прозрачность однобитная: полупрозрачные края становятся резкими. Акценты BookVoice и оформление абзацев сохраняются в FB2. При открытии DOCX, MD и TXT изображения не загружаются.

# Правая кнопка мыши
В любом поле и тексте (редактор, словарь, поиск, названия) правая кнопка открывает меню «Вырезать / Копировать / Вставить / Выделить всё». Выдели текст, правая кнопка, «Копировать»; щёлкни, где нужен курсор, правая кнопка, «Вставить». В тексте редактора эти пункты стоят в начале меню слова. Ctrl+C, Ctrl+V, Ctrl+X и Ctrl+A теперь работают и на русской раскладке.

# Значок ⚙: модели и перенос на другой компьютер
Значок ⚙ стоит правее кнопок движков и открывает список команд:
    Модели: скачать и проверить…      окно со всеми моделями (Silero, ударения RUAccent, TeraTTS, Shtorm, Shtorm-VoxCPM2, ffmpeg для mp3): что есть, чего нет; «Скачать выбранные» берёт недостающее из интернета, ход виден, скачивание можно остановить
    Модели ударений RUAccent…         то же окно, что кнопка «RUAccent» справа от ⚙: выбор модели (turbo3.1, tiny2.1, turbo и др.), «Проверить обновления», скачивание одной модели, переключение без перезапуска, обновление пакета ruaccent
    Папка моделей…                    куда складывать модели (любой диск). Модели из прежней папки не переносятся; Silero и ударения подхватят новую папку после перезапуска
    Открыть папку моделей / программы открыть в Проводнике
    Обновить Silero                   скачать более новую версию модели Silero
    Что где лежит (отчёт)             папки, размеры, старые копии на диске C:
    Очистить старый кэш на диске C:…  удалить старые копии моделей, которые уже лежат на новом месте
    Собрать папку для другого компьютера…   копия программы только с нужными файлами, твоим словарём и точными версиями пакетов; на новом месте start.bat сам создаст среду
    Сохранить версии пакетов          файл requirements.lock.txt для start.bat
Номер модели Silero задаётся в model_dirs.py (SILERO_MODEL). На основном компьютере по-прежнему работают bookvoice.bat и вспомогательные bat-файлы (install_tera.bat, install_shtorm.bat, clean_old_cache.bat и другие); в копии для другого компьютера их нет, там всё это делает ⚙. Имя и место папки программы на основном компьютере меняет rename_folder.bat: запуск bookvoice.bat от них не зависит.

# Контекстные омографы (файл «омографы.json»)
Если одно и то же слово в разных местах читается по-разному, можно задать правило по соседним словам. Файл лежит рядом с app.py; правила применяются после RUAccent и обычного словаря, поэтому вручную заданное ударение побеждает автоматическое.
Пример:
    [
      {"word": "замок", "right": ["на", "двери"], "replacement": "зам+ок"},
      {"word": "замок", "right": ["стоял", "на", "холме"], "replacement": "з+амок"}
    ]
«right» — слова сразу после омографа; «left» — слова сразу перед ним. Контекст задаётся списком слов в обычном порядке. Достаточно одной стороны, но чем точнее контекст, тем меньше ложных срабатываний. Правила проверяются сверху вниз; первое совпавшее правило побеждает. Ударение обозначается знаком + перед гласной. Для правил только одной книги используй существующий словарь с группой «Книга: …».

# Что делается само (писать не нужно)
Ударения в обычных словах (RUAccent и Silero); «ё» только как в книге; -ого/-его читаются как -ово/-ево (четвёртого → четвёртова; у TeraTTS это выключено, включается флажком «-ого читать как -ово» под выбором голоса); интонация вопросов у Silero — как у самой модели (автоматическая звёздочка на последнем слове вопроса выключена; включается настройкой QUESTION_STARS в speak.py).
"""


class Player:
    """Плеер на sounddevice: пауза, перемотка, позиция. Умеет доигрывать растущий буфер
    (живое чтение в редакторе) и хранит разметку слов (tl) для подсветки."""

    def __init__(self):
        self.buf = np.zeros(0, dtype=np.float32)
        self.n, self.pos, self.sr = 0, 0, 48000
        self.playing, self.done, self.stream = False, True, None
        self.lock = threading.Lock()
        self.version = 0                    # растёт при каждой новой загрузке
        self.tl, self.tl_starts = [], []    # слова: (start, end, a, b, sent_a, sent_b)

    @property
    def data(self):
        return self.buf[:self.n] if self.n else None

    def _open(self, sr):
        self.sr = sr
        self.stream = sd.OutputStream(samplerate=sr, channels=1, dtype='float32',
                                      callback=self._cb)
        self.stream.start()

    def load(self, data, sr):
        self.close()
        with self.lock:
            self.buf = np.ascontiguousarray(data, dtype=np.float32)
            self.n, self.pos, self.done = len(self.buf), 0, True
            self.tl, self.tl_starts = [], []
            self.version += 1
        self._open(sr)
        self.playing = True

    def begin_stream(self, sr):
        """Пустой буфер, который будет дополняться (append); возвращает номер версии."""
        self.close()
        with self.lock:
            self.buf = np.zeros(sr * 60, dtype=np.float32)
            self.n, self.pos, self.done = 0, 0, False
            self.tl, self.tl_starts = [], []
            self.version += 1
            v = self.version
        self._open(sr)
        self.playing = True
        return v

    def append(self, chunk, version):
        with self.lock:
            if version != self.version:
                return False
            need = self.n + len(chunk)
            if need > len(self.buf):
                nb = np.zeros(max(need, len(self.buf) * 2), dtype=np.float32)
                nb[:self.n] = self.buf[:self.n]
                self.buf = nb
            self.buf[self.n:need] = chunk
            self.n = need
        return True

    def add_words(self, entries, version):
        with self.lock:
            if version == self.version:
                self.tl.extend(entries)
                self.tl_starts.extend(e[0] for e in entries)

    def finish(self, version):
        with self.lock:
            if version == self.version:
                self.done = True

    def _cb(self, outdata, frames, time_info, status):
        outdata.fill(0)
        with self.lock:
            if not self.playing or self.n == 0:
                return
            k = min(frames, self.n - self.pos)
            if k > 0:
                outdata[:k, 0] = self.buf[self.pos:self.pos + k]
                self.pos += k
            elif self.done:
                self.playing = False

    def toggle(self):
        if self.n == 0:
            return
        with self.lock:
            if self.pos >= self.n and self.done:
                self.pos = 0
            self.playing = not self.playing

    def seek(self, frac):
        if self.n:
            self.pos = int(max(0.0, min(1.0, frac)) * self.n)

    def seek_seconds(self, delta):
        if self.n:
            self.pos = int(max(0, min(self.n - 1, self.pos + delta * self.sr)))

    def stop(self):
        self.playing = False
        self.pos = 0

    def close(self):
        self.playing = False
        self.done = True
        if self.stream is not None:
            try:
                self.stream.stop()
                self.stream.close()
            except Exception:
                pass
            self.stream = None


class App:
    def __init__(self, root):
        self.root = root
        self.chapters, self.book = [], None
        self.stop_flag = threading.Event()
        self.dict_loaded = False
        self.player = Player()
        self.dragging = False
        self.cur = None            # номер главы, которая сейчас в плеере
        self.yo_book = tk.BooleanVar(value=True)
        self.cfg = self.load_cfg()
        self.colors = dict(BG=BG, PANEL=PANEL, FG=FG, MUTED=MUTED, ACCENT=ACCENT)
        textmenu.install(root, self.colors)      # правая кнопка: вырезать/копировать/вставить во всех полях
        self.models_win = None                                    # окно «Модели» (одно на всех)
        self.ruaccent_win = None                                  # окно «Модели ударений RUAccent»
        saved_dir = self.cfg.get('models_dir')
        self.models_dir_cfg = saved_dir if isinstance(saved_dir, str) and saved_dir.strip() else None
        try:
            saved_pause_level = max(1, min(5, int(self.cfg.get('pause_level', 3))))
        except (TypeError, ValueError):
            saved_pause_level = 3
        self.pause_level = tk.IntVar(value=saved_pause_level)
        set_pause_level(saved_pause_level)
        self.voice_by_engine = {'silero': VOICES[0], 'tera': tera.VOICES[0],
                                'shtorm': 'образец голоса',
                                'voxcpm': 'образец голоса'}   # голос/источник на каждый движок
        for k, v in (self.cfg.get('voices') or {}).items():
            if k in self.voice_by_engine and isinstance(v, str):
                self.voice_by_engine[k] = v
        if self.voice_by_engine['silero'] not in VOICES:
            self.voice_by_engine['silero'] = VOICES[0]
        try:
            speed = min(1.4, max(0.6, float(self.cfg.get('tera_speed', 1.0))))
        except (TypeError, ValueError):
            speed = 1.0
        self.shtorm_variant = tk.StringVar(value=self.cfg.get('shtorm_variant', 'fast'))
        if self.shtorm_variant.get() not in shtorm.VARIANTS:
            self.shtorm_variant.set('fast')
        self.shtorm_voice_ref = tk.StringVar(value=str(self.cfg.get('shtorm_voice_ref', '')))
        self.voxcpm_voice_ref = tk.StringVar(value=str(self.cfg.get('voxcpm_voice_ref', '')))
        self.voxcpm_prompt = tk.StringVar(value=str(self.cfg.get('voxcpm_prompt_text', '')))
        cfg_v, steps_v = str(self.cfg.get('voxcpm_cfg', '2.0')), str(self.cfg.get('voxcpm_steps', '10'))
        self.voxcpm_cfg = tk.StringVar(value=cfg_v if cfg_v in shtorm_vox.CFG_CHOICES else '2.0')
        self.voxcpm_steps = tk.StringVar(value=steps_v if steps_v in shtorm_vox.STEP_CHOICES else '10')
        shtorm_vox.CFG_VALUE, shtorm_vox.TIMESTEPS = float(self.voxcpm_cfg.get()), int(self.voxcpm_steps.get())
        self.engine = tk.StringVar(value='silero')       # то, что показывает переключатель
        self.shown_engine = 'silero'     # чьи голоса и настройки сейчас на экране
        self.tera_speed = tk.DoubleVar(value=speed)      # duration_scale TeraTTS
        self.tera_g = tk.BooleanVar(value=bool(self.cfg.get('tera_g', False)))   # «-ого» как «-ово»
        self.speed_auto = False          # длительность выставлена само (английский голос), не вручную
        root.title('BookVoice · Silero')
        sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
        w, h = min(2080, sw - 60), min(1640, sh - 100)          # вдвое больше прежних 1040x820
        self.win_geom = f'{w}x{h}+{(sw - w) // 2}+{max(0, (sh - h) // 2 - 20)}'
        root.geometry(self.win_geom)
        root.minsize(900, 640)
        root.attributes('-fullscreen', True)
        root.bind('<F11>', lambda e: self.toggle_fullscreen())
        root.bind('<Escape>', lambda e: self.toggle_fullscreen(False))
        root.configure(bg=BG)
        self.style()

        ttk.Label(root, text='BookVoice', style='H.TLabel').pack(
            anchor='w', padx=20, pady=(14, 0))
        self.sub_lbl = ttk.Label(root, text='Silero · голос, главы, словарь', style='M.TLabel')
        self.sub_lbl.pack(anchor='w', padx=20, pady=(0, 8))
        corner = ttk.Frame(root)                  # правый верхний угол: переключатель и ⛶
        corner.place(relx=1.0, x=-18, y=16, anchor='ne')
        seg = ttk.Frame(corner)                   # переключатель движка: Silero | TeraTTS v2
        seg.pack(side='left', padx=(0, 8))
        self.engine_btns = []
        for i, key in enumerate(ENGINES):
            b = ttk.Radiobutton(seg, text=ENGINES[key], value=key, variable=self.engine,
                                style='Seg.Toolbutton', command=self.on_engine_click)
            b.pack(side='left', padx=(0, 1) if i == 0 else 0)
            self.engine_btns.append(b)
        # ⚙ правее Shtorm: модели, папка моделей, очистка, перенос на другое устройство
        self.settings_btn, self.settings_menu = models_ui.build_settings_menu(self, corner)
        self.settings_btn.pack(side='left', padx=(0, 8))
        # отдельная кнопка: выбор, проверка и скачивание моделей ударений RUAccent
        self.ruaccent_btn = ttk.Button(corner, text='RUAccent', command=self.open_ruaccent)
        self.ruaccent_btn.pack(side='left', padx=(0, 8))
        ttk.Button(corner, text='⛶', width=3, command=self.toggle_fullscreen).pack(side='left')
        nb = ttk.Notebook(root)
        nb.pack(fill='both', expand=True, padx=14, pady=(0, 14))
        self.nb = nb
        self.tab_book, self.tab_dict = ttk.Frame(nb, padding=12), ttk.Frame(nb, padding=12)
        self.tab_edit = EditTab(nb, self, dict(BG=BG, PANEL=PANEL, FG=FG, MUTED=MUTED,
                                               ACCENT=ACCENT))
        nb.add(self.tab_book, text='  Книга  ')
        nb.add(self.tab_edit, text='  Редактор  ')
        nb.add(self.tab_dict, text='  Словарь  ')
        nb.bind('<<NotebookTabChanged>>', lambda e: self.on_tab())
        self.build_book_tab()
        self.build_dict_tab()
        self.set_busy(True, loading=True)
        self.tick()
        root.bind('<Control-s>', lambda e: self.save_dict())
        root.protocol('WM_DELETE_WINDOW', self.on_close)
        threading.Thread(target=self._load, daemon=True).start()

    # ---------- оформление ----------
    def style(self):
        s = ttk.Style()
        s.theme_use('clam')
        f = ('Segoe UI', 10)
        s.configure('.', background=BG, foreground=FG, font=f, borderwidth=0)
        s.configure('TFrame', background=BG)
        s.configure('TLabel', background=BG, foreground=FG)
        s.configure('H.TLabel', font=('Georgia', 22, 'bold'), foreground=ACCENT)
        s.configure('M.TLabel', foreground=MUTED)
        s.configure('TButton', background=PANEL, foreground=FG, padding=(12, 6))
        s.map('TButton', background=[('active', '#33364a'), ('disabled', BG)],
              foreground=[('disabled', MUTED)])
        s.configure('Accent.TButton', background=ACCENT, foreground='#1b1c23',
                    font=('Segoe UI', 10, 'bold'))
        s.map('Accent.TButton', background=[('active', '#e0bf82'), ('disabled', '#5a5040')])
        s.configure('TNotebook', background=BG, tabmargins=(0, 0, 0, 0))
        s.configure('TNotebook.Tab', background=BG, foreground=MUTED, padding=(14, 8))
        s.map('TNotebook.Tab', background=[('selected', PANEL)],
              foreground=[('selected', ACCENT)])
        s.configure('Treeview', background=PANEL, fieldbackground=PANEL, foreground=FG,
                    rowheight=28, borderwidth=0)
        s.map('Treeview', background=[('selected', '#3b3f57')],
              foreground=[('selected', ACCENT)])
        s.configure('Treeview.Heading', background=BG, foreground=MUTED,
                    font=('Segoe UI', 9, 'bold'))
        s.configure('TCheckbutton', background=BG, foreground=FG)
        s.configure('TCombobox', fieldbackground=PANEL, background=PANEL, foreground=FG)
        s.configure('TSpinbox', fieldbackground=PANEL, background=PANEL, foreground=FG)
        s.configure('TEntry', fieldbackground=PANEL, foreground=FG, insertcolor=ACCENT, padding=4)
        s.configure('TMenubutton', background=PANEL, foreground=FG, padding=(10, 6),
                    arrowcolor=ACCENT)
        s.map('TMenubutton', background=[('active', '#33364a')])
        s.configure('Seg.Toolbutton', background=PANEL, foreground=FG, padding=(14, 6),
                    anchor='center', borderwidth=0, relief='flat')       # переключатель движка
        s.map('Seg.Toolbutton',
              background=[('selected', ACCENT), ('disabled', BG), ('active', '#33364a')],
              foreground=[('selected', '#1b1c23'), ('disabled', MUTED)],
              relief=[('selected', 'flat'), ('active', 'flat'), ('pressed', 'flat')])
        s.configure('Horizontal.TProgressbar', troughcolor=PANEL, background=ACCENT,
                    thickness=8)

    def textbox(self, parent, height):
        t = tk.Text(parent, height=height, bg=PANEL, fg=FG, insertbackground=ACCENT,
                    relief='flat', font=('Consolas', 10), padx=10, pady=8, wrap='word',
                    selectbackground='#3b3f57')
        return t

    # ---------- вкладка «Книга» ----------
    def build_book_tab(self):
        t = self.tab_book
        bar = ttk.Frame(t)
        bar.pack(fill='x')
        self.b_open = ttk.Button(bar, text='Открыть книгу…', command=self.open_book)
        self.b_open.pack(side='left')
        self.b_close = ttk.Button(bar, text='Закрыть', command=self.close_book)
        self.b_close.pack(side='left', padx=6)
        self.b_reload = ttk.Button(bar, text='⟳', width=3, command=self.reload_book)
        self.b_reload.pack(side='left', padx=(0, 6))
        self.b_all = ttk.Button(bar, text='Выбрать все главы', command=self.select_all)
        self.b_all.pack(side='left')
        self.book_lbl = ttk.Label(bar, text='книга не открыта', style='M.TLabel')
        self.book_lbl.pack(side='right')

        box = ttk.Frame(t)
        box.pack(fill='both', expand=True, pady=10)
        self.tree = ttk.Treeview(box, columns=('n', 'title', 'chars'), show='headings',
                                 selectmode='extended')
        for c, h, w in (('n', '№', 50), ('title', 'Глава', 520), ('chars', 'Знаков', 90)):
            self.tree.heading(c, text=h)
            self.tree.column(c, width=w, anchor='w' if c == 'title' else 'center')
        sc = ttk.Scrollbar(box, command=self.tree.yview)
        self.tree.configure(yscrollcommand=sc.set)
        self.tree.pack(side='left', fill='both', expand=True)
        sc.pack(side='right', fill='y')

        row = self.row_voice = ttk.Frame(t)
        row.pack(fill='x')
        ttk.Label(row, text='Голос').pack(side='left')
        self.voice = tk.StringVar(value=self.voice_by_engine['silero'])
        self.cb_voice = ttk.Combobox(row, textvariable=self.voice, values=VOICES,
                                     state='readonly', width=9)
        self.cb_voice.pack(side='left', padx=(6, 14))
        self.cb_voice.bind('<<ComboboxSelected>>', self.on_voice)
        self.skip = tk.BooleanVar(value=True)
        ttk.Checkbutton(row, text='Пропускать готовые', variable=self.skip).pack(side='left')
        ttk.Checkbutton(row, text='«ё» как в книге', variable=self.yo_book).pack(
            side='left', padx=(12, 0))
        ttk.Label(row, text='Тест, предложений').pack(side='left', padx=(18, 6))
        self.n_test = tk.IntVar(value=5)
        ttk.Spinbox(row, from_=1, to=200, textvariable=self.n_test, width=5).pack(side='left')

        # Регулятор длительности пунктуационных пауз — только для Silero.
        self.pause_row = ttk.Frame(t)
        pause_line = ttk.Frame(self.pause_row)
        pause_line.pack(fill='x')
        ttk.Label(pause_line, text='Паузы Silero').pack(side='left')
        self.pause_scale = ttk.Scale(
            pause_line, from_=1, to=5, variable=self.pause_level,
            command=self.on_pause_scale, length=250)
        self.pause_scale.pack(side='left', padx=(10, 8))
        self.pause_level_lbl = ttk.Label(pause_line, width=20)
        self.pause_level_lbl.pack(side='left')
        ttk.Label(self.pause_row, style='M.TLabel', text=
                  '1 — короткие · 3 — средние · 5 — длинные. Настройка влияет на паузы '
                  'в книге и редакторе; сами знаки и текст не меняются.').pack(anchor='w')
        self.pause_row.pack(fill='x', pady=(8, 0), after=self.row_voice)
        self.update_pause_level_label()

        # Настройки TeraTTS: строка показывается только когда включён этот движок.
        self.tera_row = ttk.Frame(t)
        line = ttk.Frame(self.tera_row)
        line.pack(fill='x')
        ttk.Label(line, text='Длительность речи').pack(side='left')
        ttk.Scale(line, from_=0.6, to=1.4, variable=self.tera_speed, length=200,
                  command=self.on_scale).pack(side='left', padx=10)
        self.speed_lbl = ttk.Label(line, text='×1.00', width=6)
        self.speed_lbl.pack(side='left')
        ttk.Checkbutton(line, text='«-ого» читать как «-ово»', variable=self.tera_g,
                        command=self.sync_speak).pack(side='left', padx=(18, 0))
        ttk.Label(self.tera_row, style='M.TLabel',
                  text='Длительность: больше значит медленнее; английские голоса (eng_*) с русским '
                       'текстом лучше начинать с 0.8. Флажок включай, если «четвёртого» звучит '
                       'как «четвёртого», а не «четвёртово».').pack(anchor='w', pady=(2, 0))
        self.on_speed()

        # Настройки Shtorm: модель клонирует голос из выбранного WAV-образца.
        self.shtorm_row = ttk.Frame(t)
        sline = ttk.Frame(self.shtorm_row)
        sline.pack(fill='x')
        ttk.Label(sline, text='Подача').pack(side='left')
        self.shtorm_variant_cb = ttk.Combobox(sline, textvariable=self.shtorm_variant,
                                               values=('fast', 'slow'), state='readonly', width=8)
        self.shtorm_variant_cb.pack(side='left', padx=(6, 14))
        self.shtorm_variant_cb.bind('<<ComboboxSelected>>', self.on_shtorm_variant)
        self.shtorm_voice_btn = ttk.Button(sline, text='Выбрать WAV-образец голоса…',
                                           command=self.choose_shtorm_voice)
        self.shtorm_voice_btn.pack(side='left')
        self.shtorm_ref_lbl = ttk.Label(self.shtorm_row, style='M.TLabel',
                                         text=self.shtorm_voice_ref.get() or 'Образец не выбран')
        self.shtorm_ref_lbl.pack(anchor='w', pady=(4, 0))
        ttk.Label(self.shtorm_row, style='M.TLabel',
                  text='Нужен WAV с примерно 5 секундами чистой речи. Используй только голос, '
                       'который разрешено использовать. Модель около 0,9 ГБ; первый запуск требует интернета. '
                       'Длинные фрагменты автоматически делятся на части. Английский текст модель пока не читает: '
                       'латинские слова нужно предварительно записать по-русски.').pack(anchor='w', pady=(2, 0))

        # Настройки Shtorm-VoxCPM2-RU: клон голоса из WAV и (для точности) его дословный текст.
        self.voxcpm_row = ttk.Frame(t)
        vline = ttk.Frame(self.voxcpm_row)
        vline.pack(fill='x')
        ttk.Label(vline, text='cfg').pack(side='left')
        self.voxcpm_cfg_cb = ttk.Combobox(vline, textvariable=self.voxcpm_cfg, values=shtorm_vox.CFG_CHOICES,
                                          state='readonly', width=5)
        self.voxcpm_cfg_cb.pack(side='left', padx=(6, 14))
        self.voxcpm_cfg_cb.bind('<<ComboboxSelected>>', self.on_voxcpm_params)
        ttk.Label(vline, text='Шагов').pack(side='left')
        self.voxcpm_steps_cb = ttk.Combobox(vline, textvariable=self.voxcpm_steps, values=shtorm_vox.STEP_CHOICES,
                                            state='readonly', width=5)
        self.voxcpm_steps_cb.pack(side='left', padx=(6, 14))
        self.voxcpm_steps_cb.bind('<<ComboboxSelected>>', self.on_voxcpm_params)
        self.voxcpm_voice_btn = ttk.Button(vline, text='Выбрать WAV-образец голоса…',
                                           command=self.choose_voxcpm_voice)
        self.voxcpm_voice_btn.pack(side='left')
        self.voxcpm_ref_lbl = ttk.Label(self.voxcpm_row, style='M.TLabel',
                                        text=self.voxcpm_voice_ref.get() or 'Образец не выбран')
        self.voxcpm_ref_lbl.pack(anchor='w', pady=(4, 0))
        pline = ttk.Frame(self.voxcpm_row)
        pline.pack(fill='x', pady=(4, 0))
        ttk.Label(pline, text='Текст образца').pack(side='left')
        self.voxcpm_prompt_entry = ttk.Entry(pline, textvariable=self.voxcpm_prompt)
        self.voxcpm_prompt_entry.pack(side='left', fill='x', expand=True, padx=(6, 0))
        self.voxcpm_prompt_entry.bind('<Return>', self.on_voxcpm_prompt)
        self.voxcpm_prompt_entry.bind('<FocusOut>', self.on_voxcpm_prompt)
        ttk.Label(self.voxcpm_row, style='M.TLabel',
                  text='WAV: 5–15 секунд чистой речи, только голос, который разрешено использовать. '
                       'В поле впиши дословный текст образца без меток (если рядом лежит файл с тем же именем '
                       'и расширением .txt, он подставится сам): с ним голос точнее и стабильнее; без текста '
                       'модель берёт только тембр. Модель около 5 ГБ, нужна видеокарта NVIDIA; первая '
                       'загрузка занимает минуту-две. Метки ударений «+» модель понимает как есть.'
                  ).pack(anchor='w', pady=(2, 0))

        row2 = ttk.Frame(t)
        row2.pack(fill='x', pady=10)
        self.b_test = ttk.Button(row2, text='▶ Тест (без сохранения)', command=self.on_test)
        self.b_test.pack(side='left')
        self.b_run = ttk.Button(row2, text='Озвучить выбранные главы', style='Accent.TButton',
                                command=self.on_run)
        self.b_run.pack(side='left', padx=8)
        self.b_stop = ttk.Button(row2, text='Стоп', command=self.on_stop)
        self.b_stop.pack(side='left')
        ttk.Button(row2, text='♪ Прослушать главу', command=self.listen).pack(
            side='left', padx=8)
        self.tree.bind('<Double-1>', lambda e: self.listen())

        pl = ttk.Frame(t)
        pl.pack(fill='x', pady=(0, 10))
        ttk.Button(pl, text='⏮', width=3, command=lambda: self.step(-1)).pack(side='left')
        self.b_play = ttk.Button(pl, text='▶', width=3, command=self.on_play)
        self.b_play.pack(side='left', padx=4)
        ttk.Button(pl, text='⏭', width=3, command=lambda: self.step(1)).pack(side='left')
        self.scale = ttk.Scale(pl, from_=0, to=1000)
        self.scale.pack(side='left', fill='x', expand=True, padx=10)
        self.scale.bind('<ButtonPress-1>', lambda e: setattr(self, 'dragging', True))
        self.scale.bind('<ButtonRelease-1>', self.on_seek)
        self.time_lbl = ttk.Label(pl, text='0:00 / 0:00', style='M.TLabel')
        self.time_lbl.pack(side='left')
        self.play_lbl = ttk.Label(pl, text='', style='M.TLabel')
        self.play_lbl.pack(side='left', padx=(10, 0))

        self.pb = ttk.Progressbar(t, mode='determinate')
        self.pb.pack(fill='x')
        self.logbox = self.textbox(t, 6)
        self.logbox.pack(fill='x', pady=(10, 0))
        self.logbox.configure(state='disabled')

    # ---------- вкладка «Словарь» ----------
    GENERAL, ALL_GROUPS = 'Общий', 'Все группы'
    HEADER_RE = re.compile(r'^\[(.+?)\]\s*(off)?\s*$', re.IGNORECASE)

    def build_dict_tab(self):
        t = self.tab_dict
        self.rules = []                      # записи файла; у каждой есть 'group'
        self.groups = [{'name': self.GENERAL, 'enabled': True}]
        self.group_vars = {}
        top = ttk.Frame(t)
        top.pack(fill='x')
        ttk.Label(top, text='Поиск').pack(side='left')
        self.q = tk.StringVar()
        self.q.trace_add('write', lambda *a: self.refresh_dict())
        ttk.Entry(top, textvariable=self.q, width=18).pack(side='left', padx=(6, 10))
        ttk.Label(top, text='Группа').pack(side='left')
        self.view_group = tk.StringVar(value=self.ALL_GROUPS)
        self.cb_view = ttk.Combobox(top, textvariable=self.view_group, state='readonly',
                                    width=26, values=[self.ALL_GROUPS])
        self.cb_view.pack(side='left', padx=(6, 6))
        self.cb_view.bind('<<ComboboxSelected>>', lambda e: self.refresh_dict())
        mb = ttk.Menubutton(top, text='Включено ▾')
        self.group_menu = tk.Menu(mb, tearoff=0, bg=PANEL, fg=FG,
                                  activebackground='#3b3f57', activeforeground=ACCENT)
        mb.configure(menu=self.group_menu)
        mb.pack(side='left')
        self.only_bad = tk.BooleanVar(value=False)
        ttk.Checkbutton(top, text='Только дубли', variable=self.only_bad,
                        command=self.refresh_dict).pack(side='left', padx=10)
        ttk.Button(top, text='?', width=3, command=self.show_help).pack(side='right')
        self.dict_lbl = ttk.Label(t, text='', style='M.TLabel')
        self.dict_lbl.pack(anchor='w', pady=(6, 0))

        box = ttk.Frame(t)
        box.pack(fill='both', expand=True, pady=6)
        self.dtree = ttk.Treeview(box, columns=('group', 'type', 'key', 'repl'),
                                  show='headings', selectmode='extended')
        for c, h, w in (('group', 'Группа', 190), ('type', 'Тип', 120),
                        ('key', 'Оригинал', 230), ('repl', 'Замена', 230)):
            self.dtree.heading(c, text=h)
            self.dtree.column(c, width=w, anchor='w')
        self.dtree.tag_configure('dup', foreground='#e6c566')     # одинаковые в одной группе
        self.dtree.tag_configure('conf', foreground='#ef7b7b')    # то же слово, разные замены
        self.dtree.tag_configure('off', foreground='#5c5e6b')     # группа выключена / чужая книга
        self.dtree.tag_configure('over', foreground='#7f93b8')    # перекрыто группой выше
        sc = ttk.Scrollbar(box, command=self.dtree.yview)
        self.dtree.configure(yscrollcommand=sc.set)
        self.dtree.pack(side='left', fill='both', expand=True)
        sc.pack(side='right', fill='y')
        self.dtree.bind('<<TreeviewSelect>>', self.on_rule_select)
        self.dtree.bind('<Double-1>', lambda e: self.rule_speak())

        form = ttk.Frame(t)
        form.pack(fill='x')
        ttk.Label(form, text='Оригинал', style='M.TLabel').grid(row=0, column=0, sticky='w')
        ttk.Label(form, text='Замена (+ перед ударной гласной)',
                  style='M.TLabel').grid(row=0, column=1, sticky='w', padx=(8, 0))
        self.f_key, self.f_repl = tk.StringVar(), tk.StringVar()
        ttk.Entry(form, textvariable=self.f_key).grid(row=1, column=0, sticky='ew')
        e_repl = ttk.Entry(form, textvariable=self.f_repl)
        e_repl.grid(row=1, column=1, sticky='ew', padx=(8, 0))
        e_repl.bind('<Return>', lambda e: self.rule_speak())
        ttk.Button(form, text='▶ Оригинал', command=lambda: self.rule_speak('key')).grid(
            row=2, column=0, sticky='w', pady=(6, 0))
        ttk.Button(form, text='▶ Замена', command=self.rule_speak).grid(
            row=2, column=1, sticky='w', padx=(8, 0), pady=(6, 0))
        form.columnconfigure((0, 1), weight=1)

        opts = ttk.Frame(t)
        opts.pack(fill='x', pady=6)
        self.f_word = tk.BooleanVar(value=True)
        self.f_open = tk.BooleanVar(value=False)
        ttk.Checkbutton(opts, text='Целые слова', variable=self.f_word).pack(side='left')
        ttk.Checkbutton(opts, text='Любое окончание', variable=self.f_open).pack(
            side='left', padx=12)
        ttk.Label(opts, text='Группа').pack(side='left', padx=(10, 6))
        self.f_group = tk.StringVar(value=self.GENERAL)
        self.cb_form_group = ttk.Combobox(opts, textvariable=self.f_group, state='readonly',
                                          width=30, values=[self.GENERAL])
        self.cb_form_group.pack(side='left')

        r1 = ttk.Frame(t)
        r1.pack(fill='x')
        ttk.Button(r1, text='Добавить', style='Accent.TButton',
                   command=self.rule_add).pack(side='left')
        ttk.Button(r1, text='Сохранить выбранное', command=self.rule_update).pack(
            side='left', padx=6)
        ttk.Button(r1, text='Удалить', command=self.rule_delete).pack(side='left')
        self.b_move = ttk.Button(r1, text='В группу ▾', command=self.show_move_menu)
        self.b_move.pack(side='left', padx=(12, 0))
        r2 = ttk.Frame(t)
        r2.pack(fill='x', pady=(6, 0))
        ttk.Button(r2, text='Убрать дубли', command=self.dedupe).pack(side='left')
        ttk.Button(r2, text='Привести к единому виду', command=self.normalize_rules).pack(
            side='left', padx=6)
        ttk.Button(r2, text='Импорт списка…', command=self.import_rules).pack(side='left')
        ttk.Button(r2, text='В блокноте', command=self.open_notepad).pack(side='left', padx=6)
        ttk.Button(r2, text='Перечитать', command=self.load_dict).pack(side='left')
        self.dict_msg = ttk.Label(t, text='', style='M.TLabel')
        self.dict_msg.pack(anchor='w', pady=(8, 0))

    # --- группы ---
    @staticmethod
    def kind(name):
        if name == 'Общий':
            return 'general'
        return 'book' if name.startswith('Книга: ') else 'list'

    def book_group(self):
        return f'Книга: {self.book.stem}' if self.book else None

    def default_group(self):
        return self.book_group() or self.GENERAL

    def group_names(self):
        return [g['name'] for g in self.groups]

    def gdef(self, name):
        return next((g for g in self.groups if g['name'] == name), None)

    def ensure_group(self, name, enabled=True):
        if not self.gdef(name):
            self.groups.append({'name': name, 'enabled': enabled})

    def is_active(self, name):
        g = self.gdef(name)
        if not g or not g['enabled']:
            return False
        return name == self.book_group() if self.kind(name) == 'book' else True

    def prio(self, name):
        return {'list': 0, 'general': 1, 'book': 2}[self.kind(name)]

    def fix_group_name(self, name):
        name = (name or '').strip()
        if not name:
            return None
        if name != self.GENERAL and not name.startswith(('Книга: ', 'Список: ')):
            name = 'Список: ' + name
        return name

    def rebuild_group_menu(self):
        m = self.group_menu
        m.delete(0, 'end')
        self.group_vars = {}
        bg = self.book_group()
        for g in self.groups:
            n = g['name']
            v = tk.BooleanVar(value=g['enabled'])
            self.group_vars[n] = v
            note = ''
            if self.kind(n) == 'book':
                note = '   · эта книга' if n == bg else '   · другая книга'
            m.add_checkbutton(label=n + note, variable=v,
                              command=lambda n=n: self.toggle_group(n))
        m.add_separator()
        m.add_command(label='Новая группа…', command=self.group_new)
        m.add_command(label='Переименовать группу из фильтра…', command=self.group_rename)
        m.add_command(label='Удалить группу из фильтра…', command=self.group_delete)

    def toggle_group(self, name):
        self.gdef(name)['enabled'] = self.group_vars[name].get()
        self.save_dict()
        self.refresh_dict()

    def group_new(self):
        name = self.fix_group_name(simpledialog.askstring(
            'Новая группа', 'Название группы (например: Мои слова):', parent=self.root))
        if name:
            self.ensure_group(name)
            self.save_dict()
            self.refresh_dict()

    def target_group(self):
        g = self.view_group.get()
        if g in (self.ALL_GROUPS, self.GENERAL):
            messagebox.showinfo('Группа', 'Выбери нужную группу в списке «Группа» над таблицей '
                                '(группу «Общий» менять нельзя).')
            return None
        return g

    def group_rename(self):
        old = self.target_group()
        if not old:
            return
        new = self.fix_group_name(simpledialog.askstring(
            'Переименовать', 'Новое название:', initialvalue=old, parent=self.root))
        if not new or new == old or self.gdef(new):
            return
        self.gdef(old)['name'] = new
        for r in self.rules:
            if r['group'] == old:
                r['group'] = new
        self.view_group.set(new)
        self.save_dict()
        self.refresh_dict()

    def group_delete(self):
        g = self.target_group()
        if not g:
            return
        n = sum(1 for r in self.rules if r['group'] == g and r['kind'] == 'rule')
        if not messagebox.askyesno('Удалить группу', f'Удалить группу «{g}» и все её правила ({n})?'):
            return
        self.rules = [r for r in self.rules if r['group'] != g]
        self.groups = [x for x in self.groups if x['name'] != g]
        self.view_group.set(self.ALL_GROUPS)
        self.save_dict()
        self.refresh_dict()

    def show_move_menu(self):
        if not self.dtree.selection():
            messagebox.showinfo('Группа', 'Выдели строки в таблице (Ctrl/Shift для нескольких).')
            return
        m = tk.Menu(self.root, tearoff=0, bg=PANEL, fg=FG,
                    activebackground='#3b3f57', activeforeground=ACCENT)
        names = self.group_names()
        bg = self.book_group()
        if bg and bg not in names:
            names.append(bg)
        for n in names:
            m.add_command(label=n, command=lambda n=n: self.move_selected(n))
        b = self.b_move
        m.tk_popup(b.winfo_rootx(), b.winfo_rooty() + b.winfo_height())

    def move_selected(self, name):
        self.ensure_group(name)
        for iid in self.dtree.selection():
            self.rules[int(iid)]['group'] = name
        self.save_dict()
        self.refresh_dict()

    def on_book_changed(self):
        if getattr(self, 'dict_loaded', False):
            self.f_group.set(self.default_group())
            self.refresh_dict()

    # --- разбор и запись файла ---
    @staticmethod
    def norm_key(key):
        k = key.lower().replace('+', '').rstrip('*')
        return re.sub(r'\s+', ' ', k).strip()

    @staticmethod
    def parse_line(s):
        if s.startswith('#') or '=' not in s:
            return {'kind': 'raw', 'raw': s}
        orig, repl = (x.strip() for x in s.split('=', 1))
        if not orig:
            return {'kind': 'raw', 'raw': s}
        word = orig[0] in '~*'
        return {'kind': 'rule', 'word': word,
                'key': orig[1:].strip() if word else orig, 'repl': repl}

    def parse_dict(self, text):
        """Файл с секциями [Группа] / [Группа] off. Строки до первой секции: «Общий»."""
        groups, rules, cur = [{'name': self.GENERAL, 'enabled': True}], [], self.GENERAL
        for line in text.splitlines():
            s = line.strip()
            if not s:
                continue
            m = self.HEADER_RE.match(s)
            if m:
                cur = m.group(1).strip()
                g = next((x for x in groups if x['name'] == cur), None)
                if g is None:
                    groups.append({'name': cur, 'enabled': not m.group(2)})
                else:
                    g['enabled'] = not m.group(2)
                continue
            r = self.parse_line(s)
            r['group'] = cur
            rules.append(r)
        return groups, rules

    @staticmethod
    def rule_line(r):
        if r['kind'] == 'raw':
            return r['raw']
        return f"{'* ' if r['word'] else ''}{r['key']} = {r['repl']}"

    def serialize(self):
        out = []
        for g in self.groups:
            out.append(f"[{g['name']}]" + ('' if g['enabled'] else ' off'))
            out += [self.rule_line(r) for r in self.rules if r['group'] == g['name']]
            out.append('')
        return '\n'.join(out).rstrip() + '\n'

    def load_dict(self):
        p = speak.DICT_FILE
        text = p.read_text(encoding='utf-8-sig') if p.exists() else ''
        self.groups, self.rules = self.parse_dict(text)
        self.dict_loaded = True
        self.f_group.set(self.default_group())
        self.dict_msg.configure(text='файл: ' + str(p))
        self.refresh_dict()

    def save_dict(self):
        if speak is None or not self.dict_loaded:      # не затираем файл пустотой
            return
        speak.DICT_FILE.write_text(self.serialize(), encoding='utf-8')
        self.dict_msg.configure(text='сохранено: ' + str(speak.DICT_FILE))

    def open_notepad(self):
        self.save_dict()
        try:
            os.startfile(str(speak.DICT_FILE))
        except Exception as e:
            messagebox.showerror('Ошибка', repr(e))

    # --- таблица, поиск, дубли ---
    def analyze(self):
        """status: дубли/конфликты внутри одной группы; over: правила, перекрытые
        группой с более высоким приоритетом (книга > общий > списки)."""
        same = {}
        for i, r in enumerate(self.rules):
            if r['kind'] == 'rule':
                same.setdefault((r['group'], self.norm_key(r['key'])), []).append(i)
        status = {}
        for idxs in same.values():
            if len(idxs) > 1:
                ident = len({self.rules[i]['repl'] for i in idxs}) == 1
                for i in idxs:
                    status[i] = 'dup' if ident else 'conf'
        order = {n: k for k, n in enumerate(self.group_names())}
        best = {}
        for i, r in enumerate(self.rules):
            if r['kind'] == 'rule' and self.is_active(r['group']):
                rank = (self.prio(r['group']), order[r['group']], i)
                nk = self.norm_key(r['key'])
                if nk not in best or rank > best[nk][0]:
                    best[nk] = (rank, i)
        over = set()
        for i, r in enumerate(self.rules):
            if r['kind'] == 'rule' and self.is_active(r['group']):
                w = best[self.norm_key(r['key'])][1]
                if w != i and self.rules[w]['group'] != r['group']:
                    over.add(i)
        return status, over

    def refresh_dict(self):
        if not hasattr(self, 'dtree'):
            return
        names = self.group_names()
        bg = self.book_group()
        self.cb_view.configure(values=[self.ALL_GROUPS] + names)
        if self.view_group.get() not in [self.ALL_GROUPS] + names:
            self.view_group.set(self.ALL_GROUPS)
        self.cb_form_group.configure(values=names + ([bg] if bg and bg not in names else []))
        self.rebuild_group_menu()
        self.dtree.delete(*self.dtree.get_children())
        status, over = self.analyze()
        q = self.norm_key(self.q.get())
        vg = self.view_group.get()
        shown = total = 0
        for i, r in enumerate(self.rules):
            if r['kind'] != 'rule':
                continue
            total += 1
            if vg != self.ALL_GROUPS and r['group'] != vg:
                continue
            st = status.get(i)
            if self.only_bad.get() and not st:
                continue
            if q and q not in self.norm_key(r['key']) \
                    and q not in r['repl'].lower().replace('+', ''):
                continue
            if not r['word']:
                typ = 'обычная'
            elif r['key'].endswith('*'):
                typ = 'слово + окончания'
            else:
                typ = 'фраза' if ' ' in r['key'] else 'слово'
            tag = ('off' if not self.is_active(r['group']) else
                   st or ('over' if i in over else ''))
            self.dtree.insert('', 'end', iid=str(i),
                              values=(r['group'], typ, r['key'], r['repl']),
                              tags=(tag,) if tag else ())
            shown += 1
        dups = sum(1 for v in status.values() if v == 'dup')
        confs = sum(1 for v in status.values() if v == 'conf')
        self.dict_lbl.configure(
            text=f'правил: {total} · показано: {shown} · дублей: {dups} · '
                 f'конфликтов: {confs} · перекрыто: {len(over)}')

    def on_rule_select(self, e=None):
        sel = self.dtree.selection()
        if not sel:
            return
        r = self.rules[int(sel[0])]
        self.f_key.set(r['key'].rstrip('*').strip() if r['word'] else r['key'])
        self.f_repl.set(r['repl'])
        self.f_word.set(r['word'])
        self.f_open.set(bool(r['word'] and r['key'].endswith('*')))
        self.f_group.set(r['group'])

    # --- правка записей ---
    def form_rule(self):
        key, repl = self.f_key.get().strip(), self.f_repl.get().strip()
        if not key or not repl:
            messagebox.showinfo('Словарь', 'Заполни «Оригинал» и «Замена».')
            return None
        if '=' in key or '=' in repl:
            messagebox.showinfo('Словарь', 'Знак «=» в записях использовать нельзя.')
            return None
        word = self.f_word.get()
        if word:
            key = key.rstrip('*').strip() + ('*' if self.f_open.get() else '')
        grp = self.f_group.get() or self.default_group()
        return {'kind': 'rule', 'word': word, 'key': key, 'repl': repl, 'group': grp}

    def rule_add(self):
        r = self.form_rule()
        if not r:
            return
        k = self.norm_key(r['key'])
        if any(x['kind'] == 'rule' and x['group'] == r['group']
               and self.norm_key(x['key']) == k for x in self.rules):
            if not messagebox.askyesno('Словарь', 'В этой группе такое слово уже есть. '
                                                  'Добавить ещё одну запись?'):
                return
        self.ensure_group(r['group'])
        self.rules.append(r)
        self.refresh_dict()
        iid = str(len(self.rules) - 1)
        if self.dtree.exists(iid):
            self.dtree.selection_set(iid)
            self.dtree.see(iid)
        self.save_dict()

    def rule_update(self):
        sel = self.dtree.selection()
        if not sel:
            messagebox.showinfo('Словарь', 'Выбери запись в таблице.')
            return
        r = self.form_rule()
        if not r:
            return
        self.ensure_group(r['group'])
        self.rules[int(sel[0])] = r
        self.refresh_dict()
        self.save_dict()

    def rule_delete(self):
        sel = sorted((int(i) for i in self.dtree.selection()), reverse=True)
        for i in sel:
            del self.rules[i]
        if sel:
            self.refresh_dict()
            self.save_dict()

    def show_help(self):
        win = tk.Toplevel(self.root)
        win.title('Как писать правила словаря')
        win.geometry('720x680')
        win.configure(bg=BG)
        win.transient(self.root)
        win.bind('<Escape>', lambda e: win.destroy())
        box = ttk.Frame(win, padding=12)
        box.pack(fill='both', expand=True)
        txt = self.textbox(box, 10)
        txt.configure(font=('Segoe UI', 11), spacing3=4)
        sc = ttk.Scrollbar(box, command=txt.yview)
        txt.configure(yscrollcommand=sc.set)
        sc.pack(side='right', fill='y')
        txt.pack(side='left', fill='both', expand=True)
        txt.tag_configure('h', foreground=ACCENT, font=('Georgia', 13, 'bold'), spacing1=10)
        txt.tag_configure('code', foreground='#9fd3a8', font=('Consolas', 10), lmargin1=24,
                          lmargin2=24)
        for line in HELP_TEXT.strip().splitlines():
            if line.startswith('# '):
                txt.insert('end', line[2:] + '\n', 'h')
            elif line.startswith('    '):
                txt.insert('end', line.strip() + '\n', 'code')
            else:
                txt.insert('end', line + '\n')
        txt.configure(state='disabled')

    def rule_speak(self, which='repl'):
        """Озвучить замену (или оригинал) из формы, чтобы услышать, как это звучит."""
        text = self.f_repl.get().strip() if which == 'repl' else \
            self.f_key.get().strip().rstrip('*').strip()
        if speak is None or not text:
            messagebox.showinfo('Словарь', 'Выбери запись или впиши текст.')
            return
        if str(self.b_run['state']) == 'disabled':
            messagebox.showinfo('Словарь', 'Подожди: идёт загрузка или озвучка.')
            return
        self.sync_speak()
        self.dict_msg.configure(text='озвучиваю…')
        threading.Thread(target=self._rule_speak, args=(text, self.voice.get()),
                         daemon=True).start()

    def _rule_speak(self, text, voice):
        try:
            audio, sr = speak.say_plain(text, voice)           # текущим движком
            self.ui(lambda: (self.play_array(audio, sr, 'словарь: ' + text[:40]),
                             self.dict_msg.configure(text='')))
        except Exception as e:
            err = repr(e)
            self.ui(lambda: self.dict_msg.configure(text='Ошибка: ' + err))

    def dedupe(self):
        same = {}
        for i, r in enumerate(self.rules):
            if r['kind'] == 'rule':
                same.setdefault((r['group'], self.norm_key(r['key'])), []).append(i)
        drop = set()
        for idxs in same.values():
            if len(idxs) > 1 and len({self.rules[i]['repl'] for i in idxs}) == 1:
                drop.update(idxs[1:])
        if not drop:
            messagebox.showinfo('Дубли', 'Одинаковых дублей внутри групп нет.')
            return
        self.rules = [r for i, r in enumerate(self.rules) if i not in drop]
        self.refresh_dict()
        self.save_dict()
        messagebox.showinfo('Дубли', f'Удалено дублей: {len(drop)}.\n'
                                     'Конфликты (красные) разбери вручную.')

    def normalize_rules(self):
        """Единая запись: пробелы, '~' -> '*', а обычные правила без '+' в ключе
        превращаются в надёжные «целые слова» (ищутся независимо от + от RUAccent)."""
        cand = [r for r in self.rules if r['kind'] == 'rule' and not r['word']
                and '+' not in r['key']]
        convert = bool(cand) and messagebox.askyesno(
            'Единый вид',
            f'Обычных правил без «+» в оригинале: {len(cand)}.\n'
            'Они могут не срабатывать, если RUAccent поставил своё ударение.\n'
            'Сделать их правилами «целые слова»?')
        for r in self.rules:
            if r['kind'] != 'rule':
                continue
            r['key'] = re.sub(r'\s+', ' ', r['key']).strip()
            r['repl'] = re.sub(r'\s+', ' ', r['repl']).strip()
            if convert and r in cand:
                r['word'] = True
        self.refresh_dict()
        self.save_dict()
        messagebox.showinfo('Единый вид', 'Готово. Теперь можно нажать «Убрать дубли».')

    def import_rules(self):
        p = filedialog.askopenfilename(filetypes=[('Словари', '*.txt *.json'), ('Все', '*.*')])
        if not p:
            return
        p = Path(p)
        enabled = True
        try:
            if Path(p).suffix.lower() == '.json':
                import json
                d = json.loads(p.read_text(encoding='utf-8-sig'))
                vals = list(d.values()) if isinstance(d, dict) else []
                if not vals or not all(isinstance(v, str) for v in vals):
                    messagebox.showinfo(
                        'Импорт', 'Поддерживается JSON вида {"слово": "сл+ово"}.\n'
                        'Списки вариантов (омографы) и номера букв сюда не подходят: '
                        'без контекста их не подставить.')
                    return
                if len(d) > 5000:
                    messagebox.showinfo(
                        'Импорт', 'Больше 5000 записей: правила применяются по очереди, '
                        'программа станет очень медленной.')
                    return
                new = [{'kind': 'rule', 'word': True, 'key': k.strip(), 'repl': v.strip()}
                       for k, v in d.items() if k.strip() and v.strip()]
            else:
                text = p.read_text(encoding='utf-8-sig')
                lines = [l.strip() for l in text.splitlines() if l.strip()]
                enabled = '#! off' not in lines            # список может быть выключен по умолчанию
                new = [self.parse_line(l) for l in lines if not self.HEADER_RE.match(l)]
                new = [r for r in new if r['kind'] == 'rule']
        except Exception as e:
            messagebox.showerror('Ошибка', repr(e))
            return
        name = self.fix_group_name(simpledialog.askstring(
            'Импорт', 'В какую группу импортировать?', initialvalue=f'Список: {p.stem}',
            parent=self.root))
        if not name:
            return
        new_group = not self.gdef(name)
        self.ensure_group(name, enabled)
        have = {self.norm_key(r['key']): r['repl'] for r in self.rules
                if r['kind'] == 'rule' and r['group'] == name}
        added = skipped = 0
        conflicts = []
        for r in new:
            k = self.norm_key(r['key'])
            if k in have:
                if have[k] == r['repl']:
                    skipped += 1
                else:
                    conflicts.append(f"{r['key']}: в группе «{have[k]}», в файле «{r['repl']}»")
            else:
                r['group'] = name
                self.rules.append(r)
                have[k] = r['repl']
                added += 1
        self.view_group.set(name)
        self.refresh_dict()
        self.save_dict()
        msg = (f'Группа: {name}' + (' (выключена)' if new_group and not enabled else '') +
               f'\nДобавлено: {added}\nСовпало с имеющимися: {skipped}\n'
               f'Конфликтов: {len(conflicts)} (остались прежние значения)')
        if conflicts:
            msg += '\n\n' + '\n'.join(conflicts[:10])
        messagebox.showinfo('Импорт', msg)

    # ---------- служебное ----------
    def ui(self, fn):
        self.root.after(0, fn)

    def log(self, s):
        print(s, flush=True)          # дублируем журнал в консоль
        def w():
            self.logbox.configure(state='normal')
            self.logbox.insert('end', s + '\n')
            self.logbox.see('end')
            self.logbox.configure(state='disabled')
        self.ui(w)

    def set_busy(self, busy, loading=False):
        st = 'disabled' if busy else 'normal'
        for b in (self.b_open, self.b_close, self.b_reload, self.b_all, self.b_test, self.b_run,
                  self.shtorm_voice_btn, self.shtorm_variant_cb, self.voxcpm_voice_btn,
                  self.voxcpm_prompt_entry, *self.engine_btns):
            b.configure(state=st)
        for cb in (self.voxcpm_cfg_cb, self.voxcpm_steps_cb):      # списки остаются «только выбор»
            cb.configure(state='disabled' if busy else 'readonly')
        self.b_stop.configure(state='normal' if busy and not loading else 'disabled')

    def _load(self):
        global speak
        self.log('Загружаю модели (около минуты)…')
        try:
            import speak as m
            speak = m
            speak.OUT_DIR.mkdir(exist_ok=True)
            self.ui(self.load_dict)
            self.log('Готово. Открой книгу.')
            self.ui(lambda: self.set_busy(False))
            saved_engine = self.cfg.get('engine', 'silero')
            if saved_engine in ('tera', 'shtorm', 'voxcpm'):
                self.ui(lambda name=saved_engine: self.switch_engine(name, quiet=True))
        except Exception as e:
            self.log('Ошибка загрузки: ' + repr(e))
            self.ui(self.models_hint)

    def update_pause_level_label(self):
        labels = {1: '1 · очень короткие', 2: '2 · короткие',
                  3: '3 · средние', 4: '4 · длинные', 5: '5 · очень длинные'}
        level = max(1, min(5, int(round(self.pause_level.get()))))
        self.pause_level_lbl.configure(text=labels[level])

    def on_pause_scale(self, value):
        """Применить один из пяти уровней длительности пауз Silero."""
        level = max(1, min(5, int(round(float(value)))))
        if self.pause_level.get() != level:
            self.pause_level.set(level)
        if self.cur_engine() == 'silero':
            set_pause_level(level)
        self.update_pause_level_label()
        self.save_cfg()

    # ---------- движки: Silero / TeraTTS / Shtorm ----------
    def load_cfg(self):
        try:
            d = json.loads(SETTINGS.read_text(encoding='utf-8-sig'))     # с BOM или без
            return d if isinstance(d, dict) else {}
        except Exception:
            return {}

    def save_cfg(self):
        try:
            self.remember_voice()
            # движок берём с переключателя: он показывает и тот, на который идёт загрузка;
            # пока модели не загружены вовсе, прошлый выбор не затираем
            engine = self.engine.get() if speak is not None else self.cfg.get('engine', 'silero')
            cfg = {'engine': engine, 'voices': self.voice_by_engine,
                   'tera_speed': round(self.tera_speed.get(), 2),
                   'tera_g': bool(self.tera_g.get()),
                   'shtorm_variant': self.shtorm_variant.get(),
                   'shtorm_voice_ref': self.shtorm_voice_ref.get(),
                   'voxcpm_voice_ref': self.voxcpm_voice_ref.get(),
                   'voxcpm_prompt_text': self.voxcpm_prompt.get(),
                   'voxcpm_cfg': self.voxcpm_cfg.get(),
                   'voxcpm_steps': self.voxcpm_steps.get(),
                   'pause_level': int(round(self.pause_level.get()))}
            if self.models_dir_cfg:
                cfg['models_dir'] = self.models_dir_cfg        # выбрано в ⚙ → «Папка моделей…»
            for key in (*model_manager.RUACCENT_SETTING_KEYS, 'seams', 'shtorm_gen'):    # окно RUAccent; стыки; Shtorm
                if key in self.cfg:
                    cfg[key] = self.cfg[key]
            SETTINGS.write_text(json.dumps(cfg, ensure_ascii=False, indent=1), encoding='utf-8')
        except Exception:
            pass

    def cur_engine(self):
        """Движок, который сейчас реально работает (переключатель может опережать загрузку)."""
        return speak.ENGINE if speak is not None else 'silero'

    def remember_voice(self):
        self.voice_by_engine[self.shown_engine] = self.voice.get()

    def sync_speak(self):
        """Передать модулю озвучки то, что выбрано в интерфейсе: «ё», голос, длительность Tera."""
        try:                                     # cfg и число шагов VoxCPM2 действуют сразу, без перезагрузки
            shtorm_vox.CFG_VALUE = float(self.voxcpm_cfg.get())
            shtorm_vox.TIMESTEPS = int(self.voxcpm_steps.get())
        except ValueError:
            pass
        if speak is None:
            return
        speak.YO_FROM_BOOK = self.yo_book.get()
        speak.SPEAKER = self.voice.get()
        speak.TERA_SPEED = round(self.tera_speed.get(), 2)
        speak.TERA_PHONETIC_G = bool(self.tera_g.get())

    def on_voice(self, e=None):
        self.remember_voice()
        v, s = self.voice.get(), round(self.tera_speed.get(), 2)
        if self.shown_engine == 'tera':          # совет авторов TeraTTS для английских голосов
            if v.startswith('eng_') and s == 1.0:
                self.set_speed(0.8)
                self.speed_auto = True
                self.log('Английский голос читает русский текст: длительность 0.80 '
                         '(рекомендация авторов TeraTTS, меняется ползунком).')
            elif v.startswith('ru_') and self.speed_auto and s == 0.8:
                self.set_speed(1.0)              # возвращаем только то, что подвинули сами
                self.speed_auto = False
        self.sync_speak()

    def set_speed(self, v):
        self.tera_speed.set(v)
        self.on_speed()

    def on_scale(self, _=None):
        """Ползунок двигает человек: выставленное им значение само больше не меняем."""
        self.speed_auto = False
        self.on_speed()

    def on_speed(self, _=None):
        s = round(round(self.tera_speed.get() * 20) / 20, 2)       # шаг 0.05
        if abs(s - self.tera_speed.get()) > 1e-9:
            self.tera_speed.set(s)
        self.speed_lbl.configure(text=f'×{s:.2f}')
        if speak is not None:
            speak.TERA_SPEED = s

    def on_engine_click(self):
        want = self.engine.get()
        if speak is None or want == self.cur_engine():
            self.engine.set(self.cur_engine())
            if want != 'shtorm':
                self.shtorm_row.pack_forget()
            if want != 'voxcpm':
                self.voxcpm_row.pack_forget()
            return
        self.switch_engine(want)

    def switch_engine(self, name, quiet=False):
        """Переключить движок в фоне; тяжёлые модели грузятся вне GUI-потока."""
        variant = self.shtorm_variant.get()
        voice_ref = self.shtorm_voice_ref.get().strip()
        prompt = ''
        if name == 'voxcpm':
            voice_ref = self.voxcpm_voice_ref.get().strip()
            prompt = self.voxcpm_prompt.get().strip()
        if name == 'voxcpm' and not (voice_ref and Path(voice_ref).is_file()):
            # То же, что для Shtorm: активный движок не трогаем, выбор WAV открываем сразу (при запуске программы
            # только подсказываем) и после выбора переключение продолжается само.
            self.engine.set(self.cur_engine())
            self.voxcpm_row.pack(fill='x', pady=(8, 0), after=self.row_voice)
            self.voxcpm_ref_lbl.configure(
                text=f'Файл не найден: {voice_ref}' if voice_ref else 'Образец не выбран')
            if quiet:
                self.log('Для Shtorm-VoxCPM2-RU выбери WAV-образец голоса (кнопка справа), '
                         'затем модель загрузится автоматически.')
            else:
                self.log('Shtorm-VoxCPM2-RU клонирует голос из WAV-образца (5–15 секунд чистой речи): выбери файл.')
                if not self.choose_voxcpm_voice():
                    self.log('Образец не выбран, остаётся прежний движок.')
            return
        if name == 'shtorm' and not (voice_ref and Path(voice_ref).is_file()):
            # Образца нет (или файл пропал): ничего не блокируем (раньше кнопки отключались и не
            # включались обратно, в том числе кнопка выбора WAV). Активный движок остаётся прежним.
            # Когда движок выбрал человек, выбор WAV открывается сразу и сам продолжит переключение;
            # при запуске программы (quiet) окно с вопросом не открываем, а только подсказываем.
            self.engine.set(self.cur_engine())
            self.shtorm_row.pack(fill='x', pady=(8, 0), after=self.row_voice)
            self.shtorm_ref_lbl.configure(
                text=f'Файл не найден: {voice_ref}' if voice_ref else 'Образец не выбран')
            if quiet:
                self.log('Для Shtorm выбери WAV-образец голоса (кнопка справа), '
                         'затем модель загрузится автоматически.')
            else:
                self.log('Shtorm клонирует голос из WAV-образца (около 5 секунд чистой речи): выбери файл.')
                if not self.choose_shtorm_voice():
                    self.log('Образец не выбран, остаётся прежний движок.')
            return
        self.remember_voice()
        self.engine.set(name)                   # переключатель показывает выбор сразу
        if getattr(self.tab_edit, 'live', None):
            self.tab_edit.live_stop_all()       # чтение в редакторе не должно пережить смену движка
        self.set_busy(True, loading=True)
        if name == 'tera' and not tera.is_loaded():
            self.log('Загружаю TeraTTS v2…')
        elif name == 'shtorm':
            self.log(f'Загружаю Shtorm-PocketTTS-RU ({variant}) и образец голоса…')
        elif name == 'voxcpm':
            self.log('Загружаю Shtorm-VoxCPM2-RU (модель около 5 ГБ, первый раз это минута-две)…')
        args = (name, quiet, variant, voice_ref) + ((prompt,) if name == 'voxcpm' else ())
        threading.Thread(target=self._switch, args=args, daemon=True).start()

    def _switch(self, name, quiet, variant='fast', voice_ref='', prompt=''):
        try:
            if name == 'tera' and not tera.is_loaded():
                tera.load()
            elif name == 'shtorm':
                shtorm.configure(self.cfg.get('shtorm_gen'))      # параметры генерации из settings.json (если заданы)
                shtorm.load(variant, voice_ref)
            elif name == 'voxcpm':
                shtorm_vox.load(voice_ref, prompt)
            speak.set_engine(name)
            self.ui(lambda: self.apply_engine_ui(name))
            self.log(f'Движок: {ENGINES[name]}')
        except Exception as e:
            traceback.print_exc()
            msg = str(e) if isinstance(e, RuntimeError) else (
                f'Ошибка загрузки {ENGINES[name]}: {e!r}\n'
                + ('Если модель ещё не установлена, скачай её: ⚙ → «Модели…».' if name in ('tera', 'shtorm', 'voxcpm') else ''))
            self.log(f'Не удалось включить {ENGINES[name]}: {msg}')

            def fail():
                self.engine.set(self.cur_engine())
                self.save_cfg()
                if not quiet:
                    messagebox.showerror(ENGINES[name], msg)
            self.ui(fail)
        finally:
            self.ui(lambda: self.set_busy(False))

    def choose_shtorm_voice(self):
        """Выбрать WAV-образец голоса. True, если файл принят (переключение на Shtorm продолжится само)."""
        last = self.shtorm_voice_ref.get().strip()
        start = Path(last).parent if last else None
        opts = {'initialdir': str(start)} if start is not None and start.is_dir() else {}
        path = filedialog.askopenfilename(
            title='Образец голоса для Shtorm (WAV, около 5 секунд чистой речи)',
            filetypes=[('WAV audio', '*.wav'), ('Все файлы', '*.*')], **opts)
        if not path:
            return False
        if Path(path).suffix.lower() != '.wav':
            messagebox.showwarning('Shtorm', 'Выбери WAV-файл. Другие форматы пока не поддерживаются.')
            return False
        if not Path(path).is_file():
            messagebox.showwarning('Shtorm', f'Файл не найден:\n{path}')
            return False
        self.shtorm_voice_ref.set(path)
        self.shtorm_ref_lbl.configure(text=path)
        self.save_cfg()
        if speak is not None:
            self.switch_engine('shtorm')
        return True

    def choose_voxcpm_voice(self):
        """Выбрать WAV-образец для VoxCPM2. True, если файл принят (переключение продолжится само)."""
        last = self.voxcpm_voice_ref.get().strip()
        start = Path(last).parent if last else None
        opts = {'initialdir': str(start)} if start is not None and start.is_dir() else {}
        path = filedialog.askopenfilename(
            title='Образец голоса для Shtorm-VoxCPM2-RU (WAV, 5–15 секунд чистой речи)',
            filetypes=[('WAV audio', '*.wav'), ('Все файлы', '*.*')], **opts)
        if not path:
            return False
        if Path(path).suffix.lower() != '.wav':
            messagebox.showwarning('Shtorm-VoxCPM2-RU', 'Выбери WAV-файл. Другие форматы пока не поддерживаются.')
            return False
        if not Path(path).is_file():
            messagebox.showwarning('Shtorm-VoxCPM2-RU', f'Файл не найден:\n{path}')
            return False
        if path != last:
            # Текст образца относится к конкретной записи: от прежнего файла он только испортил бы клонирование.
            self.voxcpm_prompt.set(self._read_prompt_txt(path))
        self.voxcpm_voice_ref.set(path)
        self.voxcpm_ref_lbl.configure(text=path)
        self.save_cfg()
        if not self.voxcpm_prompt.get().strip():
            self.log('Совет: впиши в поле «Текст образца» дословный текст этой записи: с ним голос точнее.')
        if speak is not None:
            self.switch_engine('voxcpm')
        return True

    @staticmethod
    def _read_prompt_txt(wav_path):
        """Дословный текст образца из файла рядом (voice.wav -> voice.txt); пусто, если файла нет."""
        txt = Path(wav_path).with_suffix('.txt')
        try:
            return ' '.join(txt.read_text(encoding='utf-8-sig').split()) if txt.is_file() else ''
        except (OSError, UnicodeDecodeError):
            return ''

    def on_voxcpm_params(self, _event=None):
        self.sync_speak()
        self.save_cfg()

    def on_voxcpm_prompt(self, _event=None):
        """Текст образца изменён: запоминаем и, если VoxCPM2 уже работает, обновляем голос (без перезагрузки модели)."""
        self.save_cfg()
        if speak is None or self.cur_engine() != 'voxcpm':
            return
        ref = self.voxcpm_voice_ref.get().strip()
        if ref and not shtorm_vox.is_loaded(ref, self.voxcpm_prompt.get()):
            self.switch_engine('voxcpm', quiet=True)

    def on_shtorm_variant(self, _event=None):
        if self.shtorm_variant.get() not in shtorm.VARIANTS:
            self.shtorm_variant.set('fast')
        self.save_cfg()
        if self.cur_engine() == 'shtorm' and speak is not None:
            self.switch_engine('shtorm')

    # ---------- RUAccent: модели ударений ----------
    def open_ruaccent(self):
        """Окно «Модели ударений RUAccent» (одно на всех)."""
        win = self.ruaccent_win
        if win is not None and win.alive():
            win.win.deiconify()
            win.win.lift()
            return win
        self.ruaccent_win = ruaccent_ui.RuaccentWindow(self)
        return self.ruaccent_win

    def set_ruaccent(self, model=None, dictionary=None, tiny=None):
        """Запомнить выбор в settings.json (ключи ruaccent_*); к загрузке применяет apply_ruaccent()."""
        if model is not None:
            self.cfg['ruaccent_model'] = model
        if dictionary is not None:
            self.cfg['ruaccent_dictionary'] = bool(dictionary)
        if tiny is not None:
            self.cfg['ruaccent_tiny'] = bool(tiny)
        self.save_cfg()

    def apply_ruaccent(self, done=None):
        """Загрузить RUAccent заново с выбранными настройками, без перезапуска программы.
        done(успех, текст) вызывается в потоке окна."""
        def finish(ok, msg):
            self.log(msg)
            if done:
                done(ok, msg)
        if speak is None:
            finish(True, 'RUAccent: настройки сохранены, применятся, когда загрузятся модели.')
            return
        if str(self.b_run['state']) == 'disabled':
            finish(False, 'RUAccent: сейчас идёт озвучка или загрузка. Настройки сохранены: нажми «Применить» '
                          'позже или перезапусти программу.')
            return
        self.set_busy(True, loading=True)
        self.log('RUAccent: загружаю заново (несколько секунд, озвучка на это время ждёт)…')

        def work():
            try:
                kw = speak.reload_accentizer()
                ok, msg = True, ('RUAccent готов: модель ' + str(kw.get('omograph_model_size')) +
                                 (', словарь целиком' if kw.get('use_dictionary') else ', без словаря') +
                                 (', tiny_mode' if kw.get('tiny_mode') else ''))
            except Exception as e:
                ok, msg = False, f'RUAccent не загрузился: {e!r}'

            def fin():
                self.set_busy(False)
                finish(ok, msg)
            self.ui(fin)
        threading.Thread(target=work, daemon=True).start()

    # ---------- ⚙: модели, папка моделей, обслуживание ----------
    def models_loaded(self):
        return speak is not None

    def open_models(self, banner=None, run=None):
        """Окно «Модели»; run - список компонентов, которые сразу начать скачивать."""
        win = self.models_win
        if win is not None and win.alive():
            win.win.deiconify()
            win.win.lift()
        else:
            win = self.models_win = models_ui.ModelsWindow(self, banner=banner or '')
        if banner:
            win.show_banner(banner)
        if run:
            win.start(run)
        return win

    def choose_models_dir(self):
        return models_ui.choose_models_dir(self)

    def refresh_models_window(self):
        if self.models_win is not None and self.models_win.alive():
            self.models_win.refresh()

    def update_silero(self):
        self.open_models(run=['silero_update'])

    def show_report(self):
        models_ui.show_report(self)

    def clean_old_cache(self):
        models_ui.clean_old_cache(self)

    def save_lockfile(self):
        models_ui.save_lockfile(self)

    def build_portable(self):
        models_ui.build_portable(self)

    def models_hint(self):
        """Не загрузились модели: показать, чего не хватает, и предложить скачать."""
        missing = model_manager.missing_required()
        if missing:
            names = ', '.join(model_manager.TITLES[c].split(' (')[0] for c in missing)
            self.log(f'Не хватает моделей: {names}. Открой ⚙ → «Модели…» и скачай их (нужен интернет).')
            self.open_models(banner=f'Не удалось загрузить модели. Не хватает: {names}. '
                                    'Они отмечены ниже: нажми «Скачать выбранные» (нужен интернет).')
        else:
            self.log('Файлы моделей на месте, причина другая: смотри сообщение об ошибке выше.')

    def models_changed(self, done):
        """Скачивание завершилось: ffmpeg подхватывается сразу, а если программа ещё не загрузила
        модели (первый запуск), загрузка начинается без перезапуска."""
        model_manager.ensure_ffmpeg_on_path()
        if done and speak is None and not model_manager.missing_required():
            self.reload_models()

    def reload_models(self):
        self.set_busy(True, loading=True)
        threading.Thread(target=self._load, daemon=True).start()

    def apply_engine_ui(self, name):
        """Голоса, ползунок, заголовок и сохранённые настройки под выбранный движок."""
        label = ENGINES[name]
        voices = (tera.VOICES if name == 'tera' else
                  ['образец голоса'] if name in ('shtorm', 'voxcpm') else VOICES)
        self.shown_engine = name
        self.engine.set(name)
        self.cb_voice.configure(values=voices, width=16 if name == 'tera' else 9)
        v = self.voice_by_engine.get(name)
        self.voice.set(v if v in voices else voices[0])
        if name == 'silero':
            self.pause_row.pack(fill='x', pady=(8, 0), after=self.row_voice)
            self.pause_scale.configure(state='normal')
            set_pause_level(self.pause_level.get())
        else:
            self.pause_scale.configure(state='disabled')
            # Нейтральный масштаб: ползунок не меняет паузы TeraTTS/Shtorm.
            set_pause_level(4)
            self.pause_row.pack_forget()
        if name == 'tera':
            self.tera_row.pack(fill='x', pady=(8, 0), after=self.row_voice)
        else:
            self.tera_row.pack_forget()
        if name == 'shtorm':
            self.shtorm_row.pack(fill='x', pady=(8, 0), after=self.row_voice)
            self.shtorm_ref_lbl.configure(text=self.shtorm_voice_ref.get() or 'Образец не выбран')
        else:
            self.shtorm_row.pack_forget()
        if name == 'voxcpm':
            self.voxcpm_row.pack(fill='x', pady=(8, 0), after=self.row_voice)
            self.voxcpm_ref_lbl.configure(text=self.voxcpm_voice_ref.get() or 'Образец не выбран')
        else:
            self.voxcpm_row.pack_forget()
        self.root.title(f'BookVoice · {label}')
        self.sub_lbl.configure(text=f'{label} · голос, главы, словарь')
        self.sync_speak()
        self.save_cfg()

    # ---------- книга ----------
    def open_book(self):
        p = filedialog.askopenfilename(filetypes=[('Книги', '*.fb2 *.txt *.md *.docx'), ('Все', '*.*')])
        if not p:
            return
        try:
            loaded_book = bookio.read_any(p)
            self.chapters = bookio.annotations_as_markers(loaded_book) if Path(p).suffix.lower() == '.fb2' else loaded_book.chapters
        except Exception as e:
            messagebox.showerror('Ошибка', repr(e))
            return
        self.book = Path(p)
        self.tree.delete(*self.tree.get_children())
        for i, (title, paras) in enumerate(self.chapters):
            self.tree.insert('', 'end', iid=str(i),
                             values=(i + 1, title, sum(len(x) for x in paras)))
        self.book_lbl.configure(text=f'{self.book.name} · глав: {len(self.chapters)}')
        self.log(f'Открыта книга: {self.book.name}')
        self.on_book_changed()

    def toggle_fullscreen(self, state=None):
        """F11 или кнопка ⛶: полный экран / окно; Esc: выйти из полного экрана."""
        cur = bool(self.root.attributes('-fullscreen'))
        new = (not cur) if state is None else state
        if new == cur:
            return
        self.root.attributes('-fullscreen', new)
        if not new:
            self.root.geometry(self.win_geom)

    def reload_book(self):
        """⟳ Перечитать открытую книгу с диска (правили файл в другой программе)."""
        if not self.book or not self.book.exists():
            messagebox.showinfo('Обновить', 'Нет открытой книги (или файла больше нет на диске).')
            return
        try:
            loaded_book = bookio.read_any(self.book)
            chapters = bookio.annotations_as_markers(loaded_book) if self.book.suffix.lower() == '.fb2' else loaded_book.chapters
        except Exception as e:
            messagebox.showerror('Ошибка', str(e))
            return
        keep = self.selected()
        self.chapters = chapters
        self.tree.delete(*self.tree.get_children())
        for i, (title, paras) in enumerate(chapters):
            self.tree.insert('', 'end', iid=str(i),
                             values=(i + 1, title, sum(len(x) for x in paras)))
        ok = [str(i) for i in keep if i < len(chapters)]
        if ok:
            self.tree.selection_set(ok)
        self.book_lbl.configure(text=f'{self.book.name} · глав: {len(chapters)}')
        self.log(f'Книга обновлена с диска: {self.book.name}, глав: {len(chapters)}')
        self.tab_edit.reload_from_disk()
        self.on_book_changed()

    @property
    def tts(self):
        return speak

    def tts_busy(self):
        return str(self.b_run['state']) == 'disabled'

    def speak_text_async(self, text, label='слово'):
        """Озвучить короткий текст (слово) прямо сейчас; для редактора и словаря."""
        if speak is None:
            messagebox.showinfo('Озвучка', 'Модели ещё загружаются, подожди.')
            return
        self.sync_speak()
        voice = self.voice.get()

        def work():
            try:
                audio, sr = speak.say_plain(text, voice)           # текущим движком
                self.ui(lambda: self.play_array(audio, sr, f'{label}: {text[:30]}'))
            except Exception as e:
                traceback.print_exc()
                self.log('Ошибка озвучки: ' + repr(e))
        threading.Thread(target=work, daemon=True).start()

    def on_tab(self):
        if self.nb.select() == str(self.tab_edit):
            self.tab_edit.on_show()

    def set_chapters(self, chapters, name=None):
        """Принять главы из вкладки «Редактор» для озвучки."""
        self.chapters = [(t, list(p)) for t, p in chapters]
        if self.book is None:
            safe = re.sub(r'[\\/:*?"<>|]', '_', name or 'book').strip() or 'book'
            self.book = Path(safe + '.fb2')
        self.tree.delete(*self.tree.get_children())
        for i, (title, paras) in enumerate(self.chapters):
            self.tree.insert('', 'end', iid=str(i),
                             values=(i + 1, title, sum(len(x) for x in paras)))
        self.book_lbl.configure(
            text=f'{self.book.name} · глав: {len(self.chapters)} (из редактора)')
        self.log('Главы получены из редактора.')
        self.on_book_changed()

    def close_book(self):
        self.chapters, self.book = [], None
        self.tree.delete(*self.tree.get_children())
        self.book_lbl.configure(text='книга не открыта')
        self.pb.configure(value=0)
        self.on_book_changed()

    def select_all(self):
        self.tree.selection_set(self.tree.get_children())

    def selected(self):
        return sorted(int(i) for i in self.tree.selection())

    # ---------- озвучка ----------
    def render(self, units, pairs, step, label=''):
        """Фрагменты -> один звук. Каждый фрагмент проходит seams.Session: края, щелчки, обрывы и повторный
        синтез подозрительных (только у движков, где это включено в настройках, по умолчанию Shtorm, VoxCPM2, Tera);
        паузы после фрагментов по таблице пауз. label: подпись главы для отчёта о стыках."""
        sr = speak.SAMPLE_RATE
        report = self.__dict__.setdefault('seam_report', seams.Report())
        sess = seams.Session(speak.ENGINE, sr, seams.config_from(self.cfg.get('seams')), report, chapter=label)
        out, pos = [], 0
        for s, end in units:
            if self.stop_flag.is_set():
                return None
            try:
                audio = sess.fragment(lambda s=s: speak.say_sentence(s, pairs), s, t=pos / sr, log=self.log)
            except Exception as e:
                self.log(f'пропуск: {s[:50]}… {e!r}')
                continue
            out.append(audio)
            pos += len(audio)
            if end == 'title':
                duration_ms = 1000
            elif isinstance(end, str) and end.startswith('par'):
                try:
                    level = int(end[3:])
                except ValueError:
                    level = 1
                duration_ms = pause_ms(s, level)
            else:
                duration_ms = pause_ms(s)
            if sess.on and duration_ms == 0:
                sess.note_forced(s, pos / sr)
            duration_ms = sess.pause_ms(duration_ms, s)
            if duration_ms:
                silence = np.zeros(int(sr * duration_ms / 1000), dtype=np.float32)
                out.append(silence)
                pos += len(silence)
            step()
        return np.concatenate(out) if out else None

    def start(self, target):
        if not self.chapters:
            messagebox.showinfo('Книга', 'Сначала открой книгу.')
            return
        self.stop_flag.clear()
        self.tab_edit.live_stop_all()
        self.save_dict()
        self.sync_speak()
        self.set_busy(True)
        threading.Thread(target=target, daemon=True).start()

    def on_stop(self):
        self.stop_flag.set()
        self.log('Останавливаю…')

    def on_test(self):
        sel = self.selected()
        i = sel[0] if sel else 0
        self.start(lambda: self._test(i, max(1, self.n_test.get())))

    def _test(self, i, n):
        try:
            pairs = speak.load_dictionary(speak.DICT_FILE, book=self.book.stem if self.book else None)
            speak.reset_accent_report()
            self.seam_report = seams.Report()
            units = build_units(*self.chapters[i], pairs=pairs, limit=n)[:n]
            self.log(f'Тест: глава {i + 1}, предложений {len(units)}, голос {speak.SPEAKER}')
            audio = self.render(units, pairs, lambda: None, label=f'тест {i + 1}')
            self.log_accent_summary()
            if audio is not None:
                self.ui(lambda: self.play_array(audio, speak.SAMPLE_RATE,
                                                f'тест, глава {i + 1}'))
        except Exception as e:
            traceback.print_exc()
            self.log('Ошибка: ' + repr(e))
        finally:
            self.ui(lambda: self.set_busy(False))

    def on_run(self):
        sel = self.selected()
        if not sel:
            messagebox.showinfo('Главы', 'Выбери главы в списке (Ctrl/Shift) или «Выбрать все».')
            return
        self.start(lambda: self._run(sel))

    def _run(self, idxs):
        try:
            pairs = speak.load_dictionary(speak.DICT_FILE, book=self.book.stem)
            outdir = speak.out_dir(self.book.stem)          # у каждого движка своя папка
            outdir.mkdir(parents=True, exist_ok=True)
            speak.reset_accent_report()
            self.seam_report = seams.Report()
            # Объём для полосы хода считаем по быстрой нарезке без ударений; сами ударения ставятся
            # по главе перед её озвучкой (RUAccent видит предложения целиком, потом текст режется).
            counts = {i: len(build_units(*self.chapters[i])) for i in idxs}
            total, done = sum(counts.values()), [0]

            def step(k=1):
                done[0] += k
                self.ui(lambda: self.pb.configure(value=min(100, 100 * done[0] / max(total, 1))))

            for i in idxs:
                mp3 = outdir / f'{i + 1:03d}.mp3'
                title = self.chapters[i][0]
                if self.skip.get() and mp3.exists():
                    self.log(f'{i + 1}. {title}: уже готово, пропускаю '
                             '(сними галочку «Пропускать готовые», чтобы озвучить заново)')
                    step(counts[i])
                    continue
                self.log(f'{i + 1}. {title}: расставляю ударения (предложения целиком)…')
                units_i = build_units(*self.chapters[i], pairs=pairs)
                if self.stop_flag.is_set():
                    self.log('Остановлено.')
                    break
                self.log(f'{i + 1}. {title}: озвучиваю…')
                audio = self.render(units_i, pairs, step, label=f'{i + 1:03d}')
                if audio is None:
                    self.log('Остановлено.')
                    break
                wav = mp3.with_suffix('.wav')
                sf.write(str(wav), audio, speak.SAMPLE_RATE)
                # ID3 TIT3 (Subtitle/Description): название главы для плееров,
                # которые читают этот тег. TIT2 остаётся названием дорожки.
                subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', str(wav),
                                '-codec:a', 'libmp3lame', '-q:a', '3',
                                '-metadata', f'title={title}',
                                '-metadata', f'TIT3={title}', str(mp3)], check=True)
                wav.unlink()
                self.log(f'   сохранено: {mp3.name}')
            else:
                self.log('Готово.')
        except Exception as e:
            traceback.print_exc()
            self.log('Ошибка: ' + repr(e))
        finally:
            self.finish_accent_report(locals().get('outdir'))
            self.ui(lambda: self.set_busy(False))

    def log_accent_summary(self):
        """Одна строка в журнал: как RUAccent справился с предложениями (подробности в отчёте)."""
        c = speak.accent_pipeline.REPORT.counts
        if not c['sentences']:
            return
        self.log(f'Ударения: предложений {c["sentences"]}; целиком {c["sentence"]}, по частям {c["clauses"]}, '
                 f'частично без RUAccent {c["partial"]}, совсем без него {c["plain"]}.')

    def finish_accent_report(self, outdir=None):
        """Итог по ударениям: строка в журнале и файл отчёта рядом с озвучкой (что обошли, какие омографы)."""
        try:
            self.log_accent_summary()
            if outdir and speak.accent_pipeline.REPORT.counts['sentences']:
                (Path(outdir) / 'ударения_отчёт.txt').write_text(speak.accent_report_text(), encoding='utf-8')
                self.log('Отчёт по ударениям: ударения_отчёт.txt в папке озвучки.')
            seam = self.__dict__.get('seam_report')
            if seam is not None and seam.counts['fragments']:
                if seam.counts['processed']:
                    self.log(seam.summary())
                if outdir and seam.counts['processed']:
                    (Path(outdir) / 'стыки_отчёт.txt').write_text(seam.text(), encoding='utf-8')
                    self.log('Отчёт по стыкам: стыки_отчёт.txt в папке озвучки (глава, время, причина).')
        except Exception as e:
            self.log('Отчёт по ударениям не сохранён: ' + repr(e))

    # ---------- плеер ----------
    @staticmethod
    def fmt(sec):
        sec = int(sec)
        return f'{sec // 60}:{sec % 60:02d}'

    def play_array(self, data, sr, name):
        try:
            self.player.load(data, sr)
            self.cur = None
            self.play_lbl.configure(text=name)
        except Exception as e:
            messagebox.showerror('Ошибка воспроизведения', repr(e))

    def chapter_mp3(self, i):
        return speak.out_dir(self.book.stem) / f'{i + 1:03d}.mp3'

    @staticmethod
    def load_mp3(path):
        """mp3 -> float32, моно, частота текущего движка, через ffmpeg (не зависит от libsndfile)."""
        r = subprocess.run(['ffmpeg', '-v', 'error', '-i', str(path), '-f', 'f32le',
                            '-ac', '1', '-ar', str(speak.SAMPLE_RATE), '-'],
                           capture_output=True, check=True)
        return np.frombuffer(r.stdout, dtype=np.float32), speak.SAMPLE_RATE

    def play_chapter(self, i):
        try:
            data, sr = self.load_mp3(self.chapter_mp3(i))
            self.play_array(data, sr, f'глава {i + 1}: {self.chapters[i][0][:40]}')
            self.cur = i
            self.tree.selection_set(str(i))
            self.tree.see(str(i))
        except Exception as e:
            traceback.print_exc()
            messagebox.showerror('Ошибка воспроизведения', repr(e))

    def on_play(self):
        """▶/⏸: пауза и продолжение; если ничего не загружено (или выбрана другая
        глава, а плеер стоит) - запускает выбранную озвученную главу."""
        sel = self.selected()
        p = self.player
        other = bool(sel) and self.cur is not None and sel[0] != self.cur and not p.playing
        if p.data is not None and not other:
            p.toggle()
            return
        if not self.book:
            messagebox.showinfo('Плеер', 'Сначала открой книгу.')
            return
        if sel:
            self.listen()
            return
        for j in range(len(self.chapters)):          # ничего не выбрано: первая озвученная
            if self.chapter_mp3(j).exists():
                self.play_chapter(j)
                return
        messagebox.showinfo('Плеер', f'Глав, озвученных движком {ENGINES[self.cur_engine()]}, '
                                     'пока нет (у каждого движка своя папка).')

    def listen(self):
        sel = self.selected()
        if not (self.book and sel):
            messagebox.showinfo('Прослушать', 'Выбери главу в списке.')
            return
        if not self.chapter_mp3(sel[0]).exists():
            messagebox.showinfo('Прослушать', 'Эта глава ещё не озвучена движком '
                                              f'{ENGINES[self.cur_engine()]}.')
            return
        self.play_chapter(sel[0])

    def step(self, d):
        """Предыдущая/следующая ОЗВУЧЕННАЯ глава."""
        if not self.book:
            return
        sel = self.selected()
        base = self.cur if self.cur is not None else (
            sel[0] if sel else (-1 if d > 0 else len(self.chapters)))
        j = base + d
        while 0 <= j < len(self.chapters):
            if self.chapter_mp3(j).exists():
                self.play_chapter(j)
                return
            j += d
        messagebox.showinfo('Плеер', 'Дальше глав, озвученных движком '
                                     f'{ENGINES[self.cur_engine()]}, нет.')

    def on_seek(self, e):
        self.dragging = False
        self.player.seek(self.scale.get() / 1000)

    def tick(self):
        p = self.player
        if p.data is not None:
            if not self.dragging:
                self.scale.set(1000 * p.pos / max(len(p.data), 1))
            self.time_lbl.configure(
                text=f'{self.fmt(p.pos / p.sr)} / {self.fmt(len(p.data) / p.sr)}')
        self.b_play.configure(text='⏸' if p.playing else '▶')
        self.root.after(150, self.tick)

    def on_close(self):
        try:
            unsaved = self.tab_edit.is_dirty()
        except Exception:
            unsaved = False
        if unsaved and not messagebox.askyesno(
                'Редактор', 'В редакторе есть несохранённые правки (текст или акценты).\n'
                            'Закрыть программу без сохранения?'):
            return
        win = getattr(self, 'models_win', None)
        if win is not None and win.alive() and win.running():
            if not messagebox.askyesno('Модели', 'Идёт скачивание моделей. Остановить его и закрыть программу?'):
                return
        if win is not None:
            win.runner.cancel()
        self.save_dict()
        self.save_cfg()
        self.stop_flag.set()
        self.player.close()
        self.root.destroy()


if __name__ == '__main__':
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass
    try:                                         # перетаскивание файлов в редактор (pip install tkinterdnd2)
        from tkinterdnd2 import TkinterDnD
        root = TkinterDnD.Tk()
    except Exception:
        root = tk.Tk()
    App(root)
    root.mainloop()