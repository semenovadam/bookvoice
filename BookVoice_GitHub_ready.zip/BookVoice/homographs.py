"""Context-aware manual overrides for Russian homographs in BookVoice.

Rules live in homographs.json and are applied after RUAccent and the ordinary
pronunciation dictionary. They only change explicitly listed word forms when
neighboring words match, so the same word can have different stress by context.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

BASE = Path(__file__).resolve().parent
RULES_FILE = BASE / 'омографы.json'
_WORD = re.compile(r'[А-Яа-яЁё+]+')
_CACHE_MTIME = None
_CACHE_RULES = ()


def _plain(value: str) -> str:
    return value.replace('+', '').lower().replace('ё', 'е')


def _load_rules(path: Path = RULES_FILE):
    """Load and validate rules; malformed entries are skipped with diagnostics."""
    global _CACHE_MTIME, _CACHE_RULES
    try:
        mtime = path.stat().st_mtime_ns
    except OSError:
        _CACHE_MTIME, _CACHE_RULES = None, ()
        return ()
    if path == RULES_FILE and mtime == _CACHE_MTIME:
        return _CACHE_RULES

    try:
        data = json.loads(path.read_text(encoding='utf-8-sig'))
        if not isinstance(data, list):
            raise ValueError('верхний уровень должен быть JSON-списком')
    except Exception as exc:
        print(f'  контекстные омографы: не удалось прочитать {path.name}: {exc}')
        data = []

    rules = []
    for i, item in enumerate(data, 1):
        if not isinstance(item, dict):
            continue
        word, replacement = item.get('word'), item.get('replacement')
        left, right = item.get('left', []), item.get('right', [])
        if not isinstance(word, str) or not word.strip() or not isinstance(replacement, str):
            print(f'  контекстные омографы: правило {i} пропущено (нужны word и replacement)')
            continue
        if not isinstance(left, list) or not isinstance(right, list):
            print(f'  контекстные омографы: правило {i} пропущено (left/right должны быть списками)')
            continue
        if not left and not right:
            print(f'  контекстные омографы: правило {i} пропущено (нужен контекст left или right)')
            continue
        if not all(isinstance(x, str) and x.strip() for x in left + right):
            continue
        if not re.fullmatch(r'[А-Яа-яЁё+]+', word.strip()):
            print(f'  контекстные омографы: правило {i} пропущено (word должен быть одним словом)')
            continue
        if not re.fullmatch(r'[А-Яа-яЁё+]+', replacement.strip()):
            print(f'  контекстные омографы: правило {i} пропущено (replacement должен быть одним словом)')
            continue
        rules.append({
            'word': _plain(word.strip()),
            'replacement': replacement.strip(),
            'left': tuple(_plain(x) for x in left),
            'right': tuple(_plain(x) for x in right),
            'line': i,
        })
    result = tuple(rules)
    if path == RULES_FILE:
        _CACHE_MTIME, _CACHE_RULES = mtime, result
    return result


def _context_matches(words, index, left, right):
    before = tuple(_plain(m.group()) for m in words[max(0, index - len(left)):index])
    after = tuple(_plain(m.group()) for m in words[index + 1:index + 1 + len(right)])
    return (len(before) == len(left) and before == left and
            len(after) == len(right) and after == right)


def apply_context_overrides(text: str, path: Path = RULES_FILE) -> str:
    """Apply matching overrides, preserving punctuation and initial capitalization.

    left/right are contiguous context words in natural reading order, nearest to
    the target at the end of left and beginning of right. Empty side is allowed.
    Rules are global; keep book-specific exceptions in the existing grouped dictionary.
    """
    rules = _load_rules(path)
    if not rules or not text:
        return text
    words = list(_WORD.finditer(text))
    if not words:
        return text
    replacements = {}
    for i, match in enumerate(words):
        target = _plain(match.group())
        for rule in rules:
            if target != rule['word']:
                continue
            if _context_matches(words, i, rule['left'], rule['right']):
                repl = rule['replacement']
                original = match.group().replace('+', '')
                letters = ''.join(c for c in original if c.isalpha())
                if letters and letters.isupper():
                    repl = ''.join(c.upper() if c.isalpha() else c for c in repl)
                elif original[:1].isupper():
                    for j, ch in enumerate(repl):
                        if ch.isalpha():
                            repl = repl[:j] + ch.upper() + repl[j + 1:]
                            break
                replacements[match.span()] = repl
                break  # first matching rule wins
    if not replacements:
        return text
    out, pos = [], 0
    for (start, end), repl in sorted(replacements.items()):
        out.extend((text[pos:start], repl))
        pos = end
    out.append(text[pos:])
    return ''.join(out)
