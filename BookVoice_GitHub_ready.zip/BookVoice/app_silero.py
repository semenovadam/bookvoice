import os
import re
import subprocess
import threading
import traceback
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, simpledialog, ttk

import numpy as np
import soundfile as sf
import sounddevice as sd

import bookio
from edit_tab import EditTab
from punctuation_pauses import pause_ms

BG, PANEL, FG, MUTED, ACCENT = '#1b1c23', '#252733', '#ece8e1', '#8d8f9c', '#d2ad6b'
VOICES = ['xenia', 'kseniya', 'baya', 'aidar', 'eugene']
speak = None


def build_units(title, paras):
    """Книга -> (фрагмент, конец); абзацные уровни кодируются как par1/par2/par3."""
    units = []
    if title.strip().lower() not in ('', 'начало'):
        title_parts = [s for s in speak.prepare_paragraph(title)
                       if re.search(r'[А-Яа-яЁёA-Za-z]', s)]
        for i, part in enumerate(title_parts):
            units.append((part, 'title' if i == len(title_parts) - 1 else None))

    # Пустые абзацы, если они сохранены источником, усиливают паузу; больше трёх
    # уровней считаем оформительским мусором.
    index = 0
    paras = list(paras)
    while index < len(paras):
        text = paras[index]
        if not str(text).strip():
            index += 1
            continue
        blank_after = 0
        lookahead = index + 1
        while lookahead < len(paras) and not str(paras[lookahead]).strip():
            blank_after += 1
            lookahead += 1
        paragraph_level = min(3, 1 + blank_after)
        sents = [s for s in speak.prepare_paragraph(str(text))
                 if re.search(r'[А-Яа-яЁёA-Za-z]', s)]
        for i, part in enumerate(sents):
            end = f'par{paragraph_level}' if i == len(sents) - 1 else None
            units.append((part, end))
        index += 1
    return units

HELP_TEXT = """# Как писать правила словаря
Слева «Оригинал», справа «Замена»: программа находит оригинал в тексте и читает вместо него замену.

# Знак +  (ударение)
Плюс ставится ПЕРЕД ударной гласной:
    з+амок   (здание)        зам+ок   (на двери)
Букву «ё» в замене можно писать как обычно. В односложных словах (орк, не, ты) ударение ставит сама Silero, писать его не нужно.

# Галочка «Целые слова»  (в файле: * в начале строки)
Ищет слово или сочетание целиком, и знаки + от RUAccent ему не мешают. Регистр не важен, заглавная буква в начале предложения сохраняется. Для почти всех правил выбирай её.
    Оригинал: Бродог        Замена: Брод+ог
    Оригинал: замок на двери  Замена: зам+ок на двери
Слово «орк» с этой галочкой не заденет «оркестр».

# Без галочки  (запись типа «обычная»)
Точная подстановка в текст ПОСЛЕ RUAccent: в оригинале нужны и его плюсы, один в один (смотри консоль). Нужна только для особых случаев.
    закр+ыл зам+ок на зам+ок = закр+ыл з+амок на зам+ок

# Галочка «Любое окончание (для имён)»  (в файле: * в конце слова)
Правило работает для всех падежей: окончание дописывается само, ударение остаётся там, где ты поставил.
    Оригинал: Бродог   Замена: Брод+ог
    ловит: Бродог, Бродога, Бродогу, Бродогом
Если в каком-то падеже ударение прыгает, сделай для него отдельную строку без этой галочки. Не включай её для коротких слов: «орк» с окончанием заденет «оркестр».

# Порядок и проверка
Правила применяются сверху вниз. Жёлтые строки в таблице: дубли, красные: одно слово с разными заменами. Проверить на слух можно кнопками ▶ Оригинал / ▶ Замена (или Enter в поле «Замена»). Знак = в записях использовать нельзя.

# Группы: общие правила и правила книги
Каждое правило лежит в группе. «Общий» работает всегда. «Список: …» это тематические списки (например, заимствования с твёрдым «э»). «Книга: …» работает только пока открыта эта книга. Новое правило по умолчанию попадает в группу открытой книги, а если книга не открыта, то в «Общий». Другую группу выбираешь в поле «Группа» под таблицей. У готовых правил группу меняют так: выдели строки (Ctrl или Shift) и нажми «В группу».
Меню «Включено ▾» включает и выключает группу целиком. Список «Группа» над таблицей только фильтрует показ.

# Что побеждает, если слово есть в нескольких группах
Книга, потом «Общий», потом списки. Перекрытые правила в таблице тусклые синие. Чтобы в этой книге слово читалось «как обычно», запиши в группе книги замену из одного знака !
    Оригинал: модель     Замена: !
Такое правило ничего не меняет, но отключает правила того же слова из групп ниже.

# Правила, меняющие только буквы
Если в замене нет + и она той же длины, что оригинал, программа меняет только буквы, а ударение оставляет, как поставил RUAccent. Так устроены списки «твёрдого э»:
    Оригинал: индекс  (любое окончание)     Замена: индэкс

# Что делается само (писать не нужно)
Ударения в обычных словах (RUAccent и Silero); «ё» только как в книге; -ого/-его читаются как -ово/-ево (четвёртого → четвёртова); интонация вопроса на последнем слове.
"""


class Player:
    """Плеер на sounddevice: пауза, перемотка, позиция. Умеет доигрывать растущий буфер
    (живое чтение в редакторе) и хранит разметку слов (tl) для подсветки."""

    def __init__(self):
        self.buf = np.zeros(0, dtype=np.float32)
        self.n, self.pos, self.sr = 0, 0, 48000
        self.playing, self.done, self.stream = False, True, None
        self.lock = threading.Lock()
        self.version = 0                    # растёт при каждой новой загрузке
        self.tl, self.tl_starts = [], []    # слова: (start, end, a, b, sent_a, sent_b)

    @property
    def data(self):
        return self.buf[:self.n] if self.n else None

    def _open(self, sr):
        self.sr = sr
        self.stream = sd.OutputStream(samplerate=sr, channels=1, dtype='float32',
                                      callback=self._cb)
        self.stream.start()

    def load(self, data, sr):
        self.close()
        with self.lock:
            self.buf = np.ascontiguousarray(data, dtype=np.float32)
            self.n, self.pos, self.done = len(self.buf), 0, True
            self.tl, self.tl_starts = [], []
            self.version += 1
        self._open(sr)
        self.playing = True

    def begin_stream(self, sr):
        """Пустой буфер, который будет дополняться (append); возвращает номер версии."""
        self.close()
        with self.lock:
            self.buf = np.zeros(sr * 60, dtype=np.float32)
            self.n, self.pos, self.done = 0, 0, False
            self.tl, self.tl_starts = [], []
            self.version += 1
            v = self.version
        self._open(sr)
        self.playing = True
        return v

    def append(self, chunk, version):
        with self.lock:
            if version != self.version:
                return False
            need = self.n + len(chunk)
            if need > len(self.buf):
                nb = np.zeros(max(need, len(self.buf) * 2), dtype=np.float32)
                nb[:self.n] = self.buf[:self.n]
                self.buf = nb
            self.buf[self.n:need] = chunk
            self.n = need
        return True

    def add_words(self, entries, version):
        with self.lock:
            if version == self.version:
                self.tl.extend(entries)
                self.tl_starts.extend(e[0] for e in entries)

    def finish(self, version):
        with self.lock:
            if version == self.version:
                self.done = True

    def _cb(self, outdata, frames, time_info, status):
        outdata.fill(0)
        with self.lock:
            if not self.playing or self.n == 0:
                return
            k = min(frames, self.n - self.pos)
            if k > 0:
                outdata[:k, 0] = self.buf[self.pos:self.pos + k]
                self.pos += k
            elif self.done:
                self.playing = False

    def toggle(self):
        if self.n == 0:
            return
        with self.lock:
            if self.pos >= self.n and self.done:
                self.pos = 0
            self.playing = not self.playing

    def seek(self, frac):
        if self.n:
            self.pos = int(max(0.0, min(1.0, frac)) * self.n)

    def seek_seconds(self, delta):
        if self.n:
            self.pos = int(max(0, min(self.n - 1, self.pos + delta * self.sr)))

    def stop(self):
        self.playing = False
        self.pos = 0

    def close(self):
        self.playing = False
        self.done = True
        if self.stream is not None:
            try:
                self.stream.stop()
                self.stream.close()
            except Exception:
                pass
            self.stream = None


class App:
    def __init__(self, root):
        self.root = root
        self.chapters, self.book = [], None
        self.stop_flag = threading.Event()
        self.dict_loaded = False
        self.player = Player()
        self.dragging = False
        self.cur = None            # номер главы, которая сейчас в плеере
        self.yo_book = tk.BooleanVar(value=True)
        root.title('BookVoice · Silero')
        sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
        w, h = min(2080, sw - 60), min(1640, sh - 100)          # вдвое больше прежних 1040x820
        self.win_geom = f'{w}x{h}+{(sw - w) // 2}+{max(0, (sh - h) // 2 - 20)}'
        root.geometry(self.win_geom)
        root.minsize(900, 640)
        root.attributes('-fullscreen', True)
        root.bind('<F11>', lambda e: self.toggle_fullscreen())
        root.bind('<Escape>', lambda e: self.toggle_fullscreen(False))
        root.configure(bg=BG)
        self.style()

        ttk.Label(root, text='BookVoice', style='H.TLabel').pack(
            anchor='w', padx=20, pady=(14, 0))
        ttk.Label(root, text='Silero · голос, главы, словарь', style='M.TLabel').pack(
            anchor='w', padx=20, pady=(0, 8))
        ttk.Button(root, text='⛶', width=3, command=self.toggle_fullscreen).place(
            relx=1.0, x=-18, y=16, anchor='ne')
        nb = ttk.Notebook(root)
        nb.pack(fill='both', expand=True, padx=14, pady=(0, 14))
        self.nb = nb
        self.tab_book, self.tab_dict = ttk.Frame(nb, padding=12), ttk.Frame(nb, padding=12)
        self.tab_edit = EditTab(nb, self, dict(BG=BG, PANEL=PANEL, FG=FG, MUTED=MUTED,
                                               ACCENT=ACCENT))
        nb.add(self.tab_book, text='  Книга  ')
        nb.add(self.tab_edit, text='  Редактор  ')
        nb.add(self.tab_dict, text='  Словарь  ')
        nb.bind('<<NotebookTabChanged>>', lambda e: self.on_tab())
        self.build_book_tab()
        self.build_dict_tab()
        self.set_busy(True, loading=True)
        self.tick()
        root.bind('<Control-s>', lambda e: self.save_dict())
        root.protocol('WM_DELETE_WINDOW', self.on_close)
        threading.Thread(target=self._load, daemon=True).start()

    # ---------- оформление ----------
    def style(self):
        s = ttk.Style()
        s.theme_use('clam')
        f = ('Segoe UI', 10)
        s.configure('.', background=BG, foreground=FG, font=f, borderwidth=0)
        s.configure('TFrame', background=BG)
        s.configure('TLabel', background=BG, foreground=FG)
        s.configure('H.TLabel', font=('Georgia', 22, 'bold'), foreground=ACCENT)
        s.configure('M.TLabel', foreground=MUTED)
        s.configure('TButton', background=PANEL, foreground=FG, padding=(12, 6))
        s.map('TButton', background=[('active', '#33364a'), ('disabled', BG)],
              foreground=[('disabled', MUTED)])
        s.configure('Accent.TButton', background=ACCENT, foreground='#1b1c23',
                    font=('Segoe UI', 10, 'bold'))
        s.map('Accent.TButton', background=[('active', '#e0bf82'), ('disabled', '#5a5040')])
        s.configure('TNotebook', background=BG, tabmargins=(0, 0, 0, 0))
        s.configure('TNotebook.Tab', background=BG, foreground=MUTED, padding=(14, 8))
        s.map('TNotebook.Tab', background=[('selected', PANEL)],
              foreground=[('selected', ACCENT)])
        s.configure('Treeview', background=PANEL, fieldbackground=PANEL, foreground=FG,
                    rowheight=28, borderwidth=0)
        s.map('Treeview', background=[('selected', '#3b3f57')],
              foreground=[('selected', ACCENT)])
        s.configure('Treeview.Heading', background=BG, foreground=MUTED,
                    font=('Segoe UI', 9, 'bold'))
        s.configure('TCheckbutton', background=BG, foreground=FG)
        s.configure('TCombobox', fieldbackground=PANEL, background=PANEL, foreground=FG)
        s.configure('TSpinbox', fieldbackground=PANEL, background=PANEL, foreground=FG)
        s.configure('TEntry', fieldbackground=PANEL, foreground=FG, insertcolor=ACCENT, padding=4)
        s.configure('TMenubutton', background=PANEL, foreground=FG, padding=(10, 6),
                    arrowcolor=ACCENT)
        s.map('TMenubutton', background=[('active', '#33364a')])
        s.configure('Horizontal.TProgressbar', troughcolor=PANEL, background=ACCENT,
                    thickness=8)

    def textbox(self, parent, height):
        t = tk.Text(parent, height=height, bg=PANEL, fg=FG, insertbackground=ACCENT,
                    relief='flat', font=('Consolas', 10), padx=10, pady=8, wrap='word',
                    selectbackground='#3b3f57')
        return t

    # ---------- вкладка «Книга» ----------
    def build_book_tab(self):
        t = self.tab_book
        bar = ttk.Frame(t)
        bar.pack(fill='x')
        self.b_open = ttk.Button(bar, text='Открыть книгу…', command=self.open_book)
        self.b_open.pack(side='left')
        self.b_close = ttk.Button(bar, text='Закрыть', command=self.close_book)
        self.b_close.pack(side='left', padx=6)
        self.b_reload = ttk.Button(bar, text='⟳', width=3, command=self.reload_book)
        self.b_reload.pack(side='left', padx=(0, 6))
        self.b_all = ttk.Button(bar, text='Выбрать все главы', command=self.select_all)
        self.b_all.pack(side='left')
        self.book_lbl = ttk.Label(bar, text='книга не открыта', style='M.TLabel')
        self.book_lbl.pack(side='right')

        box = ttk.Frame(t)
        box.pack(fill='both', expand=True, pady=10)
        self.tree = ttk.Treeview(box, columns=('n', 'title', 'chars'), show='headings',
                                 selectmode='extended')
        for c, h, w in (('n', '№', 50), ('title', 'Глава', 520), ('chars', 'Знаков', 90)):
            self.tree.heading(c, text=h)
            self.tree.column(c, width=w, anchor='w' if c == 'title' else 'center')
        sc = ttk.Scrollbar(box, command=self.tree.yview)
        self.tree.configure(yscrollcommand=sc.set)
        self.tree.pack(side='left', fill='both', expand=True)
        sc.pack(side='right', fill='y')

        row = ttk.Frame(t)
        row.pack(fill='x')
        ttk.Label(row, text='Голос').pack(side='left')
        self.voice = tk.StringVar(value=VOICES[0])
        ttk.Combobox(row, textvariable=self.voice, values=VOICES, state='readonly',
                     width=9).pack(side='left', padx=(6, 14))
        self.skip = tk.BooleanVar(value=True)
        ttk.Checkbutton(row, text='Пропускать готовые', variable=self.skip).pack(side='left')
        ttk.Checkbutton(row, text='«ё» как в книге', variable=self.yo_book).pack(
            side='left', padx=(12, 0))
        ttk.Label(row, text='Тест, предложений').pack(side='left', padx=(18, 6))
        self.n_test = tk.IntVar(value=5)
        ttk.Spinbox(row, from_=1, to=200, textvariable=self.n_test, width=5).pack(side='left')

        row2 = ttk.Frame(t)
        row2.pack(fill='x', pady=10)
        self.b_test = ttk.Button(row2, text='▶ Тест (без сохранения)', command=self.on_test)
        self.b_test.pack(side='left')
        self.b_run = ttk.Button(row2, text='Озвучить выбранные главы', style='Accent.TButton',
                                command=self.on_run)
        self.b_run.pack(side='left', padx=8)
        self.b_stop = ttk.Button(row2, text='Стоп', command=self.on_stop)
        self.b_stop.pack(side='left')
        ttk.Button(row2, text='♪ Прослушать главу', command=self.listen).pack(
            side='left', padx=8)
        self.tree.bind('<Double-1>', lambda e: self.listen())

        pl = ttk.Frame(t)
        pl.pack(fill='x', pady=(0, 10))
        ttk.Button(pl, text='⏮', width=3, command=lambda: self.step(-1)).pack(side='left')
        self.b_play = ttk.Button(pl, text='▶', width=3, command=self.on_play)
        self.b_play.pack(side='left', padx=4)
        ttk.Button(pl, text='⏭', width=3, command=lambda: self.step(1)).pack(side='left')
        self.scale = ttk.Scale(pl, from_=0, to=1000)
        self.scale.pack(side='left', fill='x', expand=True, padx=10)
        self.scale.bind('<ButtonPress-1>', lambda e: setattr(self, 'dragging', True))
        self.scale.bind('<ButtonRelease-1>', self.on_seek)
        self.time_lbl = ttk.Label(pl, text='0:00 / 0:00', style='M.TLabel')
        self.time_lbl.pack(side='left')
        self.play_lbl = ttk.Label(pl, text='', style='M.TLabel')
        self.play_lbl.pack(side='left', padx=(10, 0))

        self.pb = ttk.Progressbar(t, mode='determinate')
        self.pb.pack(fill='x')
        self.logbox = self.textbox(t, 6)
        self.logbox.pack(fill='x', pady=(10, 0))
        self.logbox.configure(state='disabled')

    # ---------- вкладка «Словарь» ----------
    GENERAL, ALL_GROUPS = 'Общий', 'Все группы'
    HEADER_RE = re.compile(r'^\[(.+?)\]\s*(off)?\s*$', re.IGNORECASE)

    def build_dict_tab(self):
        t = self.tab_dict
        self.rules = []                      # записи файла; у каждой есть 'group'
        self.groups = [{'name': self.GENERAL, 'enabled': True}]
        self.group_vars = {}
        top = ttk.Frame(t)
        top.pack(fill='x')
        ttk.Label(top, text='Поиск').pack(side='left')
        self.q = tk.StringVar()
        self.q.trace_add('write', lambda *a: self.refresh_dict())
        ttk.Entry(top, textvariable=self.q, width=18).pack(side='left', padx=(6, 10))
        ttk.Label(top, text='Группа').pack(side='left')
        self.view_group = tk.StringVar(value=self.ALL_GROUPS)
        self.cb_view = ttk.Combobox(top, textvariable=self.view_group, state='readonly',
                                    width=26, values=[self.ALL_GROUPS])
        self.cb_view.pack(side='left', padx=(6, 6))
        self.cb_view.bind('<<ComboboxSelected>>', lambda e: self.refresh_dict())
        mb = ttk.Menubutton(top, text='Включено ▾')
        self.group_menu = tk.Menu(mb, tearoff=0, bg=PANEL, fg=FG,
                                  activebackground='#3b3f57', activeforeground=ACCENT)
        mb.configure(menu=self.group_menu)
        mb.pack(side='left')
        self.only_bad = tk.BooleanVar(value=False)
        ttk.Checkbutton(top, text='Только дубли', variable=self.only_bad,
                        command=self.refresh_dict).pack(side='left', padx=10)
        ttk.Button(top, text='?', width=3, command=self.show_help).pack(side='right')
        self.dict_lbl = ttk.Label(t, text='', style='M.TLabel')
        self.dict_lbl.pack(anchor='w', pady=(6, 0))

        box = ttk.Frame(t)
        box.pack(fill='both', expand=True, pady=6)
        self.dtree = ttk.Treeview(box, columns=('group', 'type', 'key', 'repl'),
                                  show='headings', selectmode='extended')
        for c, h, w in (('group', 'Группа', 190), ('type', 'Тип', 120),
                        ('key', 'Оригинал', 230), ('repl', 'Замена', 230)):
            self.dtree.heading(c, text=h)
            self.dtree.column(c, width=w, anchor='w')
        self.dtree.tag_configure('dup', foreground='#e6c566')     # одинаковые в одной группе
        self.dtree.tag_configure('conf', foreground='#ef7b7b')    # то же слово, разные замены
        self.dtree.tag_configure('off', foreground='#5c5e6b')     # группа выключена / чужая книга
        self.dtree.tag_configure('over', foreground='#7f93b8')    # перекрыто группой выше
        sc = ttk.Scrollbar(box, command=self.dtree.yview)
        self.dtree.configure(yscrollcommand=sc.set)
        self.dtree.pack(side='left', fill='both', expand=True)
        sc.pack(side='right', fill='y')
        self.dtree.bind('<<TreeviewSelect>>', self.on_rule_select)
        self.dtree.bind('<Double-1>', lambda e: self.rule_speak())

        form = ttk.Frame(t)
        form.pack(fill='x')
        ttk.Label(form, text='Оригинал', style='M.TLabel').grid(row=0, column=0, sticky='w')
        ttk.Label(form, text='Замена (+ перед ударной гласной)',
                  style='M.TLabel').grid(row=0, column=1, sticky='w', padx=(8, 0))
        self.f_key, self.f_repl = tk.StringVar(), tk.StringVar()
        ttk.Entry(form, textvariable=self.f_key).grid(row=1, column=0, sticky='ew')
        e_repl = ttk.Entry(form, textvariable=self.f_repl)
        e_repl.grid(row=1, column=1, sticky='ew', padx=(8, 0))
        e_repl.bind('<Return>', lambda e: self.rule_speak())
        ttk.Button(form, text='▶ Оригинал', command=lambda: self.rule_speak('key')).grid(
            row=2, column=0, sticky='w', pady=(6, 0))
        ttk.Button(form, text='▶ Замена', command=self.rule_speak).grid(
            row=2, column=1, sticky='w', padx=(8, 0), pady=(6, 0))
        form.columnconfigure((0, 1), weight=1)

        opts = ttk.Frame(t)
        opts.pack(fill='x', pady=6)
        self.f_word = tk.BooleanVar(value=True)
        self.f_open = tk.BooleanVar(value=False)
        ttk.Checkbutton(opts, text='Целые слова', variable=self.f_word).pack(side='left')
        ttk.Checkbutton(opts, text='Любое окончание', variable=self.f_open).pack(
            side='left', padx=12)
        ttk.Label(opts, text='Группа').pack(side='left', padx=(10, 6))
        self.f_group = tk.StringVar(value=self.GENERAL)
        self.cb_form_group = ttk.Combobox(opts, textvariable=self.f_group, state='readonly',
                                          width=30, values=[self.GENERAL])
        self.cb_form_group.pack(side='left')

        r1 = ttk.Frame(t)
        r1.pack(fill='x')
        ttk.Button(r1, text='Добавить', style='Accent.TButton',
                   command=self.rule_add).pack(side='left')
        ttk.Button(r1, text='Сохранить выбранное', command=self.rule_update).pack(
            side='left', padx=6)
        ttk.Button(r1, text='Удалить', command=self.rule_delete).pack(side='left')
        self.b_move = ttk.Button(r1, text='В группу ▾', command=self.show_move_menu)
        self.b_move.pack(side='left', padx=(12, 0))
        r2 = ttk.Frame(t)
        r2.pack(fill='x', pady=(6, 0))
        ttk.Button(r2, text='Убрать дубли', command=self.dedupe).pack(side='left')
        ttk.Button(r2, text='Привести к единому виду', command=self.normalize_rules).pack(
            side='left', padx=6)
        ttk.Button(r2, text='Импорт списка…', command=self.import_rules).pack(side='left')
        ttk.Button(r2, text='В блокноте', command=self.open_notepad).pack(side='left', padx=6)
        ttk.Button(r2, text='Перечитать', command=self.load_dict).pack(side='left')
        self.dict_msg = ttk.Label(t, text='', style='M.TLabel')
        self.dict_msg.pack(anchor='w', pady=(8, 0))

    # --- группы ---
    @staticmethod
    def kind(name):
        if name == 'Общий':
            return 'general'
        return 'book' if name.startswith('Книга: ') else 'list'

    def book_group(self):
        return f'Книга: {self.book.stem}' if self.book else None

    def default_group(self):
        return self.book_group() or self.GENERAL

    def group_names(self):
        return [g['name'] for g in self.groups]

    def gdef(self, name):
        return next((g for g in self.groups if g['name'] == name), None)

    def ensure_group(self, name, enabled=True):
        if not self.gdef(name):
            self.groups.append({'name': name, 'enabled': enabled})

    def is_active(self, name):
        g = self.gdef(name)
        if not g or not g['enabled']:
            return False
        return name == self.book_group() if self.kind(name) == 'book' else True

    def prio(self, name):
        return {'list': 0, 'general': 1, 'book': 2}[self.kind(name)]

    def fix_group_name(self, name):
        name = (name or '').strip()
        if not name:
            return None
        if name != self.GENERAL and not name.startswith(('Книга: ', 'Список: ')):
            name = 'Список: ' + name
        return name

    def rebuild_group_menu(self):
        m = self.group_menu
        m.delete(0, 'end')
        self.group_vars = {}
        bg = self.book_group()
        for g in self.groups:
            n = g['name']
            v = tk.BooleanVar(value=g['enabled'])
            self.group_vars[n] = v
            note = ''
            if self.kind(n) == 'book':
                note = '   · эта книга' if n == bg else '   · другая книга'
            m.add_checkbutton(label=n + note, variable=v,
                              command=lambda n=n: self.toggle_group(n))
        m.add_separator()
        m.add_command(label='Новая группа…', command=self.group_new)
        m.add_command(label='Переименовать группу из фильтра…', command=self.group_rename)
        m.add_command(label='Удалить группу из фильтра…', command=self.group_delete)

    def toggle_group(self, name):
        self.gdef(name)['enabled'] = self.group_vars[name].get()
        self.save_dict()
        self.refresh_dict()

    def group_new(self):
        name = self.fix_group_name(simpledialog.askstring(
            'Новая группа', 'Название группы (например: Мои слова):', parent=self.root))
        if name:
            self.ensure_group(name)
            self.save_dict()
            self.refresh_dict()

    def target_group(self):
        g = self.view_group.get()
        if g in (self.ALL_GROUPS, self.GENERAL):
            messagebox.showinfo('Группа', 'Выбери нужную группу в списке «Группа» над таблицей '
                                '(группу «Общий» менять нельзя).')
            return None
        return g

    def group_rename(self):
        old = self.target_group()
        if not old:
            return
        new = self.fix_group_name(simpledialog.askstring(
            'Переименовать', 'Новое название:', initialvalue=old, parent=self.root))
        if not new or new == old or self.gdef(new):
            return
        self.gdef(old)['name'] = new
        for r in self.rules:
            if r['group'] == old:
                r['group'] = new
        self.view_group.set(new)
        self.save_dict()
        self.refresh_dict()

    def group_delete(self):
        g = self.target_group()
        if not g:
            return
        n = sum(1 for r in self.rules if r['group'] == g and r['kind'] == 'rule')
        if not messagebox.askyesno('Удалить группу', f'Удалить группу «{g}» и все её правила ({n})?'):
            return
        self.rules = [r for r in self.rules if r['group'] != g]
        self.groups = [x for x in self.groups if x['name'] != g]
        self.view_group.set(self.ALL_GROUPS)
        self.save_dict()
        self.refresh_dict()

    def show_move_menu(self):
        if not self.dtree.selection():
            messagebox.showinfo('Группа', 'Выдели строки в таблице (Ctrl/Shift для нескольких).')
            return
        m = tk.Menu(self.root, tearoff=0, bg=PANEL, fg=FG,
                    activebackground='#3b3f57', activeforeground=ACCENT)
        names = self.group_names()
        bg = self.book_group()
        if bg and bg not in names:
            names.append(bg)
        for n in names:
            m.add_command(label=n, command=lambda n=n: self.move_selected(n))
        b = self.b_move
        m.tk_popup(b.winfo_rootx(), b.winfo_rooty() + b.winfo_height())

    def move_selected(self, name):
        self.ensure_group(name)
        for iid in self.dtree.selection():
            self.rules[int(iid)]['group'] = name
        self.save_dict()
        self.refresh_dict()

    def on_book_changed(self):
        if getattr(self, 'dict_loaded', False):
            self.f_group.set(self.default_group())
            self.refresh_dict()

    # --- разбор и запись файла ---
    @staticmethod
    def norm_key(key):
        k = key.lower().replace('+', '').rstrip('*')
        return re.sub(r'\s+', ' ', k).strip()

    @staticmethod
    def parse_line(s):
        if s.startswith('#') or '=' not in s:
            return {'kind': 'raw', 'raw': s}
        orig, repl = (x.strip() for x in s.split('=', 1))
        if not orig:
            return {'kind': 'raw', 'raw': s}
        word = orig[0] in '~*'
        return {'kind': 'rule', 'word': word,
                'key': orig[1:].strip() if word else orig, 'repl': repl}

    def parse_dict(self, text):
        """Файл с секциями [Группа] / [Группа] off. Строки до первой секции: «Общий»."""
        groups, rules, cur = [{'name': self.GENERAL, 'enabled': True}], [], self.GENERAL
        for line in text.splitlines():
            s = line.strip()
            if not s:
                continue
            m = self.HEADER_RE.match(s)
            if m:
                cur = m.group(1).strip()
                g = next((x for x in groups if x['name'] == cur), None)
                if g is None:
                    groups.append({'name': cur, 'enabled': not m.group(2)})
                else:
                    g['enabled'] = not m.group(2)
                continue
            r = self.parse_line(s)
            r['group'] = cur
            rules.append(r)
        return groups, rules

    @staticmethod
    def rule_line(r):
        if r['kind'] == 'raw':
            return r['raw']
        return f"{'* ' if r['word'] else ''}{r['key']} = {r['repl']}"

    def serialize(self):
        out = []
        for g in self.groups:
            out.append(f"[{g['name']}]" + ('' if g['enabled'] else ' off'))
            out += [self.rule_line(r) for r in self.rules if r['group'] == g['name']]
            out.append('')
        return '\n'.join(out).rstrip() + '\n'

    def load_dict(self):
        p = speak.DICT_FILE
        text = p.read_text(encoding='utf-8-sig') if p.exists() else ''
        self.groups, self.rules = self.parse_dict(text)
        self.dict_loaded = True
        self.f_group.set(self.default_group())
        self.dict_msg.configure(text='файл: ' + str(p))
        self.refresh_dict()

    def save_dict(self):
        if speak is None or not self.dict_loaded:      # не затираем файл пустотой
            return
        speak.DICT_FILE.write_text(self.serialize(), encoding='utf-8')
        self.dict_msg.configure(text='сохранено: ' + str(speak.DICT_FILE))

    def open_notepad(self):
        self.save_dict()
        try:
            os.startfile(str(speak.DICT_FILE))
        except Exception as e:
            messagebox.showerror('Ошибка', repr(e))

    # --- таблица, поиск, дубли ---
    def analyze(self):
        """status: дубли/конфликты внутри одной группы; over: правила, перекрытые
        группой с более высоким приоритетом (книга > общий > списки)."""
        same = {}
        for i, r in enumerate(self.rules):
            if r['kind'] == 'rule':
                same.setdefault((r['group'], self.norm_key(r['key'])), []).append(i)
        status = {}
        for idxs in same.values():
            if len(idxs) > 1:
                ident = len({self.rules[i]['repl'] for i in idxs}) == 1
                for i in idxs:
                    status[i] = 'dup' if ident else 'conf'
        order = {n: k for k, n in enumerate(self.group_names())}
        best = {}
        for i, r in enumerate(self.rules):
            if r['kind'] == 'rule' and self.is_active(r['group']):
                rank = (self.prio(r['group']), order[r['group']], i)
                nk = self.norm_key(r['key'])
                if nk not in best or rank > best[nk][0]:
                    best[nk] = (rank, i)
        over = set()
        for i, r in enumerate(self.rules):
            if r['kind'] == 'rule' and self.is_active(r['group']):
                w = best[self.norm_key(r['key'])][1]
                if w != i and self.rules[w]['group'] != r['group']:
                    over.add(i)
        return status, over

    def refresh_dict(self):
        if not hasattr(self, 'dtree'):
            return
        names = self.group_names()
        bg = self.book_group()
        self.cb_view.configure(values=[self.ALL_GROUPS] + names)
        if self.view_group.get() not in [self.ALL_GROUPS] + names:
            self.view_group.set(self.ALL_GROUPS)
        self.cb_form_group.configure(values=names + ([bg] if bg and bg not in names else []))
        self.rebuild_group_menu()
        self.dtree.delete(*self.dtree.get_children())
        status, over = self.analyze()
        q = self.norm_key(self.q.get())
        vg = self.view_group.get()
        shown = total = 0
        for i, r in enumerate(self.rules):
            if r['kind'] != 'rule':
                continue
            total += 1
            if vg != self.ALL_GROUPS and r['group'] != vg:
                continue
            st = status.get(i)
            if self.only_bad.get() and not st:
                continue
            if q and q not in self.norm_key(r['key']) \
                    and q not in r['repl'].lower().replace('+', ''):
                continue
            if not r['word']:
                typ = 'обычная'
            elif r['key'].endswith('*'):
                typ = 'слово + окончания'
            else:
                typ = 'фраза' if ' ' in r['key'] else 'слово'
            tag = ('off' if not self.is_active(r['group']) else
                   st or ('over' if i in over else ''))
            self.dtree.insert('', 'end', iid=str(i),
                              values=(r['group'], typ, r['key'], r['repl']),
                              tags=(tag,) if tag else ())
            shown += 1
        dups = sum(1 for v in status.values() if v == 'dup')
        confs = sum(1 for v in status.values() if v == 'conf')
        self.dict_lbl.configure(
            text=f'правил: {total} · показано: {shown} · дублей: {dups} · '
                 f'конфликтов: {confs} · перекрыто: {len(over)}')

    def on_rule_select(self, e=None):
        sel = self.dtree.selection()
        if not sel:
            return
        r = self.rules[int(sel[0])]
        self.f_key.set(r['key'].rstrip('*').strip() if r['word'] else r['key'])
        self.f_repl.set(r['repl'])
        self.f_word.set(r['word'])
        self.f_open.set(bool(r['word'] and r['key'].endswith('*')))
        self.f_group.set(r['group'])

    # --- правка записей ---
    def form_rule(self):
        key, repl = self.f_key.get().strip(), self.f_repl.get().strip()
        if not key or not repl:
            messagebox.showinfo('Словарь', 'Заполни «Оригинал» и «Замена».')
            return None
        if '=' in key or '=' in repl:
            messagebox.showinfo('Словарь', 'Знак «=» в записях использовать нельзя.')
            return None
        word = self.f_word.get()
        if word:
            key = key.rstrip('*').strip() + ('*' if self.f_open.get() else '')
        grp = self.f_group.get() or self.default_group()
        return {'kind': 'rule', 'word': word, 'key': key, 'repl': repl, 'group': grp}

    def rule_add(self):
        r = self.form_rule()
        if not r:
            return
        k = self.norm_key(r['key'])
        if any(x['kind'] == 'rule' and x['group'] == r['group']
               and self.norm_key(x['key']) == k for x in self.rules):
            if not messagebox.askyesno('Словарь', 'В этой группе такое слово уже есть. '
                                                  'Добавить ещё одну запись?'):
                return
        self.ensure_group(r['group'])
        self.rules.append(r)
        self.refresh_dict()
        iid = str(len(self.rules) - 1)
        if self.dtree.exists(iid):
            self.dtree.selection_set(iid)
            self.dtree.see(iid)
        self.save_dict()

    def rule_update(self):
        sel = self.dtree.selection()
        if not sel:
            messagebox.showinfo('Словарь', 'Выбери запись в таблице.')
            return
        r = self.form_rule()
        if not r:
            return
        self.ensure_group(r['group'])
        self.rules[int(sel[0])] = r
        self.refresh_dict()
        self.save_dict()

    def rule_delete(self):
        sel = sorted((int(i) for i in self.dtree.selection()), reverse=True)
        for i in sel:
            del self.rules[i]
        if sel:
            self.refresh_dict()
            self.save_dict()

    def show_help(self):
        win = tk.Toplevel(self.root)
        win.title('Как писать правила словаря')
        win.geometry('720x680')
        win.configure(bg=BG)
        win.transient(self.root)
        win.bind('<Escape>', lambda e: win.destroy())
        box = ttk.Frame(win, padding=12)
        box.pack(fill='both', expand=True)
        txt = self.textbox(box, 10)
        txt.configure(font=('Segoe UI', 11), spacing3=4)
        sc = ttk.Scrollbar(box, command=txt.yview)
        txt.configure(yscrollcommand=sc.set)
        sc.pack(side='right', fill='y')
        txt.pack(side='left', fill='both', expand=True)
        txt.tag_configure('h', foreground=ACCENT, font=('Georgia', 13, 'bold'), spacing1=10)
        txt.tag_configure('code', foreground='#9fd3a8', font=('Consolas', 10), lmargin1=24,
                          lmargin2=24)
        for line in HELP_TEXT.strip().splitlines():
            if line.startswith('# '):
                txt.insert('end', line[2:] + '\n', 'h')
            elif line.startswith('    '):
                txt.insert('end', line.strip() + '\n', 'code')
            else:
                txt.insert('end', line + '\n')
        txt.configure(state='disabled')

    def rule_speak(self, which='repl'):
        """Озвучить замену (или оригинал) из формы, чтобы услышать, как это звучит."""
        text = self.f_repl.get().strip() if which == 'repl' else \
            self.f_key.get().strip().rstrip('*').strip()
        if speak is None or not text:
            messagebox.showinfo('Словарь', 'Выбери запись или впиши текст.')
            return
        if str(self.b_run['state']) == 'disabled':
            messagebox.showinfo('Словарь', 'Подожди: идёт загрузка или озвучка.')
            return
        speak.YO_FROM_BOOK = self.yo_book.get()
        self.dict_msg.configure(text='…')
        threading.Thread(target=self._rule_speak, args=(text, self.voice.get()),
                         daemon=True).start()

    def _rule_speak(self, text, voice):
        try:
            text = speak.phonetic_g(text) if speak.PHONETIC_G else text
            with speak.TTS_LOCK:
                audio = speak.model.apply_tts(text=speak.mark_question(text), speaker=voice,
                                              sample_rate=speak.SAMPLE_RATE,
                                              put_accent=True,
                                              put_yo=not speak.YO_FROM_BOOK).numpy()
            self.ui(lambda: (self.play_array(audio, speak.SAMPLE_RATE, 'словарь: ' + text[:40]),
                             self.dict_msg.configure(text='')))
        except Exception as e:
            err = repr(e)
            self.ui(lambda: self.dict_msg.configure(text='Ошибка: ' + err))

    def dedupe(self):
        same = {}
        for i, r in enumerate(self.rules):
            if r['kind'] == 'rule':
                same.setdefault((r['group'], self.norm_key(r['key'])), []).append(i)
        drop = set()
        for idxs in same.values():
            if len(idxs) > 1 and len({self.rules[i]['repl'] for i in idxs}) == 1:
                drop.update(idxs[1:])
        if not drop:
            messagebox.showinfo('Дубли', 'Одинаковых дублей внутри групп нет.')
            return
        self.rules = [r for i, r in enumerate(self.rules) if i not in drop]
        self.refresh_dict()
        self.save_dict()
        messagebox.showinfo('Дубли', f'Удалено дублей: {len(drop)}.\n'
                                     'Конфликты (красные) разбери вручную.')

    def normalize_rules(self):
        """Единая запись: пробелы, '~' -> '*', а обычные правила без '+' в ключе
        превращаются в надёжные «целые слова» (ищутся независимо от + от RUAccent)."""
        cand = [r for r in self.rules if r['kind'] == 'rule' and not r['word']
                and '+' not in r['key']]
        convert = bool(cand) and messagebox.askyesno(
            'Единый вид',
            f'Обычных правил без «+» в оригинале: {len(cand)}.\n'
            'Они могут не срабатывать, если RUAccent поставил своё ударение.\n'
            'Сделать их правилами «целые слова»?')
        for r in self.rules:
            if r['kind'] != 'rule':
                continue
            r['key'] = re.sub(r'\s+', ' ', r['key']).strip()
            r['repl'] = re.sub(r'\s+', ' ', r['repl']).strip()
            if convert and r in cand:
                r['word'] = True
        self.refresh_dict()
        self.save_dict()
        messagebox.showinfo('Единый вид', 'Готово. Теперь можно нажать «Убрать дубли».')

    def import_rules(self):
        p = filedialog.askopenfilename(filetypes=[('Словари', '*.txt *.json'), ('Все', '*.*')])
        if not p:
            return
        p = Path(p)
        enabled = True
        try:
            if Path(p).suffix.lower() == '.json':
                import json
                d = json.loads(p.read_text(encoding='utf-8-sig'))
                vals = list(d.values()) if isinstance(d, dict) else []
                if not vals or not all(isinstance(v, str) for v in vals):
                    messagebox.showinfo(
                        'Импорт', 'Поддерживается JSON вида {"слово": "сл+ово"}.\n'
                        'Списки вариантов (омографы) и номера букв сюда не подходят: '
                        'без контекста их не подставить.')
                    return
                if len(d) > 5000:
                    messagebox.showinfo(
                        'Импорт', 'Больше 5000 записей: правила применяются по очереди, '
                        'программа станет очень медленной.')
                    return
                new = [{'kind': 'rule', 'word': True, 'key': k.strip(), 'repl': v.strip()}
                       for k, v in d.items() if k.strip() and v.strip()]
            else:
                text = p.read_text(encoding='utf-8-sig')
                lines = [l.strip() for l in text.splitlines() if l.strip()]
                enabled = '#! off' not in lines            # список может быть выключен по умолчанию
                new = [self.parse_line(l) for l in lines if not self.HEADER_RE.match(l)]
                new = [r for r in new if r['kind'] == 'rule']
        except Exception as e:
            messagebox.showerror('Ошибка', repr(e))
            return
        name = self.fix_group_name(simpledialog.askstring(
            'Импорт', 'В какую группу импортировать?', initialvalue=f'Список: {p.stem}',
            parent=self.root))
        if not name:
            return
        new_group = not self.gdef(name)
        self.ensure_group(name, enabled)
        have = {self.norm_key(r['key']): r['repl'] for r in self.rules
                if r['kind'] == 'rule' and r['group'] == name}
        added = skipped = 0
        conflicts = []
        for r in new:
            k = self.norm_key(r['key'])
            if k in have:
                if have[k] == r['repl']:
                    skipped += 1
                else:
                    conflicts.append(f"{r['key']}: в группе «{have[k]}», в файле «{r['repl']}»")
            else:
                r['group'] = name
                self.rules.append(r)
                have[k] = r['repl']
                added += 1
        self.view_group.set(name)
        self.refresh_dict()
        self.save_dict()
        msg = (f'Группа: {name}' + (' (выключена)' if new_group and not enabled else '') +
               f'\nДобавлено: {added}\nСовпало с имеющимися: {skipped}\n'
               f'Конфликтов: {len(conflicts)} (остались прежние значения)')
        if conflicts:
            msg += '\n\n' + '\n'.join(conflicts[:10])
        messagebox.showinfo('Импорт', msg)

    # ---------- служебное ----------
    def ui(self, fn):
        self.root.after(0, fn)

    def log(self, s):
        print(s, flush=True)          # дублируем журнал в консоль
        def w():
            self.logbox.configure(state='normal')
            self.logbox.insert('end', s + '\n')
            self.logbox.see('end')
            self.logbox.configure(state='disabled')
        self.ui(w)

    def set_busy(self, busy, loading=False):
        st = 'disabled' if busy else 'normal'
        for b in (self.b_open, self.b_close, self.b_reload, self.b_all, self.b_test, self.b_run):
            b.configure(state=st)
        self.b_stop.configure(state='normal' if busy and not loading else 'disabled')

    def _load(self):
        global speak
        self.log('Загружаю модели (около минуты)…')
        try:
            import speak as m
            speak = m
            speak.OUT_DIR.mkdir(exist_ok=True)
            self.ui(self.load_dict)
            self.log('Готово. Открой книгу.')
            self.ui(lambda: self.set_busy(False))
        except Exception as e:
            self.log('Ошибка загрузки: ' + repr(e))

    # ---------- книга ----------
    def open_book(self):
        p = filedialog.askopenfilename(filetypes=[('Книги', '*.fb2 *.txt *.md *.docx'), ('Все', '*.*')])
        if not p:
            return
        try:
            loaded_book = bookio.read_any(p)
            self.chapters = bookio.annotations_as_markers(loaded_book) if Path(p).suffix.lower() == '.fb2' else loaded_book.chapters
        except Exception as e:
            messagebox.showerror('Ошибка', repr(e))
            return
        self.book = Path(p)
        self.tree.delete(*self.tree.get_children())
        for i, (title, paras) in enumerate(self.chapters):
            self.tree.insert('', 'end', iid=str(i),
                             values=(i + 1, title, sum(len(x) for x in paras)))
        self.book_lbl.configure(text=f'{self.book.name} · глав: {len(self.chapters)}')
        self.log(f'Открыта книга: {self.book.name}')
        self.on_book_changed()

    def toggle_fullscreen(self, state=None):
        """F11 или кнопка ⛶: полный экран / окно; Esc: выйти из полного экрана."""
        cur = bool(self.root.attributes('-fullscreen'))
        new = (not cur) if state is None else state
        if new == cur:
            return
        self.root.attributes('-fullscreen', new)
        if not new:
            self.root.geometry(self.win_geom)

    def reload_book(self):
        """⟳ Перечитать открытую книгу с диска (правили файл в другой программе)."""
        if not self.book or not self.book.exists():
            messagebox.showinfo('Обновить', 'Нет открытой книги (или файла больше нет на диске).')
            return
        try:
            loaded_book = bookio.read_any(self.book)
            chapters = bookio.annotations_as_markers(loaded_book) if self.book.suffix.lower() == '.fb2' else loaded_book.chapters
        except Exception as e:
            messagebox.showerror('Ошибка', str(e))
            return
        keep = self.selected()
        self.chapters = chapters
        self.tree.delete(*self.tree.get_children())
        for i, (title, paras) in enumerate(chapters):
            self.tree.insert('', 'end', iid=str(i),
                             values=(i + 1, title, sum(len(x) for x in paras)))
        ok = [str(i) for i in keep if i < len(chapters)]
        if ok:
            self.tree.selection_set(ok)
        self.book_lbl.configure(text=f'{self.book.name} · глав: {len(chapters)}')
        self.log(f'Книга обновлена с диска: {self.book.name}, глав: {len(chapters)}')
        self.tab_edit.reload_from_disk()
        self.on_book_changed()

    @property
    def tts(self):
        return speak

    def tts_busy(self):
        return str(self.b_run['state']) == 'disabled'

    def speak_text_async(self, text, label='слово'):
        """Озвучить короткий текст (слово) прямо сейчас; для редактора и словаря."""
        if speak is None:
            messagebox.showinfo('Озвучка', 'Модели ещё загружаются, подожди.')
            return
        speak.YO_FROM_BOOK = self.yo_book.get()
        voice = self.voice.get()

        def work():
            try:
                t = speak.phonetic_g(text) if speak.PHONETIC_G else text
                with speak.TTS_LOCK:
                    audio = speak.model.apply_tts(
                        text=speak.mark_question(t), speaker=voice,
                        sample_rate=speak.SAMPLE_RATE, put_accent=True,
                        put_yo=not speak.YO_FROM_BOOK).numpy()
                self.ui(lambda: self.play_array(audio, speak.SAMPLE_RATE, f'{label}: {text[:30]}'))
            except Exception as e:
                traceback.print_exc()
                self.log('Ошибка озвучки: ' + repr(e))
        threading.Thread(target=work, daemon=True).start()

    def on_tab(self):
        if self.nb.select() == str(self.tab_edit):
            self.tab_edit.on_show()

    def set_chapters(self, chapters, name=None):
        """Принять главы из вкладки «Редактор» для озвучки."""
        self.chapters = [(t, list(p)) for t, p in chapters]
        if self.book is None:
            safe = re.sub(r'[\\/:*?"<>|]', '_', name or 'book').strip() or 'book'
            self.book = Path(safe + '.fb2')
        self.tree.delete(*self.tree.get_children())
        for i, (title, paras) in enumerate(self.chapters):
            self.tree.insert('', 'end', iid=str(i),
                             values=(i + 1, title, sum(len(x) for x in paras)))
        self.book_lbl.configure(
            text=f'{self.book.name} · глав: {len(self.chapters)} (из редактора)')
        self.log('Главы получены из редактора.')
        self.on_book_changed()

    def close_book(self):
        self.chapters, self.book = [], None
        self.tree.delete(*self.tree.get_children())
        self.book_lbl.configure(text='книга не открыта')
        self.pb.configure(value=0)
        self.on_book_changed()

    def select_all(self):
        self.tree.selection_set(self.tree.get_children())

    def selected(self):
        return sorted(int(i) for i in self.tree.selection())

    # ---------- озвучка ----------
    def render(self, units, pairs, step):
        sr = speak.SAMPLE_RATE
        out = []
        for s, end in units:
            if self.stop_flag.is_set():
                return None
            try:
                out.append(speak.say_sentence(s, pairs))
            except Exception as e:
                self.log(f'пропуск: {s[:50]}… {e!r}')
                continue
            if end == 'title':
                duration_ms = 1000
            elif isinstance(end, str) and end.startswith('par'):
                try:
                    level = int(end[3:])
                except ValueError:
                    level = 1
                duration_ms = pause_ms(s, level)
            else:
                duration_ms = pause_ms(s)
            if duration_ms:
                out.append(np.zeros(int(sr * duration_ms / 1000), dtype=np.float32))
            step()
        return np.concatenate(out) if out else None

    def start(self, target):
        if not self.chapters:
            messagebox.showinfo('Книга', 'Сначала открой книгу.')
            return
        self.stop_flag.clear()
        self.tab_edit.live_stop_all()
        self.save_dict()
        speak.YO_FROM_BOOK = self.yo_book.get()
        speak.SPEAKER = self.voice.get()
        self.set_busy(True)
        threading.Thread(target=target, daemon=True).start()

    def on_stop(self):
        self.stop_flag.set()
        self.log('Останавливаю…')

    def on_test(self):
        sel = self.selected()
        i = sel[0] if sel else 0
        self.start(lambda: self._test(i, max(1, self.n_test.get())))

    def _test(self, i, n):
        try:
            pairs = speak.load_dictionary(speak.DICT_FILE, book=self.book.stem if self.book else None)
            units = build_units(*self.chapters[i])[:n]
            self.log(f'Тест: глава {i + 1}, предложений {len(units)}, голос {speak.SPEAKER}')
            audio = self.render(units, pairs, lambda: None)
            if audio is not None:
                self.ui(lambda: self.play_array(audio, speak.SAMPLE_RATE,
                                                f'тест, глава {i + 1}'))
        except Exception as e:
            traceback.print_exc()
            self.log('Ошибка: ' + repr(e))
        finally:
            self.ui(lambda: self.set_busy(False))

    def on_run(self):
        sel = self.selected()
        if not sel:
            messagebox.showinfo('Главы', 'Выбери главы в списке (Ctrl/Shift) или «Выбрать все».')
            return
        self.start(lambda: self._run(sel))

    def _run(self, idxs):
        try:
            pairs = speak.load_dictionary(speak.DICT_FILE, book=self.book.stem)
            outdir = speak.OUT_DIR / self.book.stem
            outdir.mkdir(parents=True, exist_ok=True)
            units = {i: build_units(*self.chapters[i]) for i in idxs}
            total, done = sum(len(u) for u in units.values()), [0]

            def step(k=1):
                done[0] += k
                self.ui(lambda: self.pb.configure(value=100 * done[0] / max(total, 1)))

            for i in idxs:
                mp3 = outdir / f'{i + 1:03d}.mp3'
                title = self.chapters[i][0]
                if self.skip.get() and mp3.exists():
                    self.log(f'{i + 1}. {title}: уже готово, пропускаю '
                             '(сними галочку «Пропускать готовые», чтобы озвучить заново)')
                    step(len(units[i]))
                    continue
                self.log(f'{i + 1}. {title}: озвучиваю…')
                audio = self.render(units[i], pairs, step)
                if audio is None:
                    self.log('Остановлено.')
                    break
                wav = mp3.with_suffix('.wav')
                sf.write(str(wav), audio, speak.SAMPLE_RATE)
                # ID3 TIT3 (Subtitle/Description): название главы для плееров,
                # которые читают этот тег. TIT2 остаётся названием дорожки.
                subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', str(wav),
                                '-codec:a', 'libmp3lame', '-q:a', '3',
                                '-metadata', f'title={title}',
                                '-metadata', f'TIT3={title}', str(mp3)], check=True)
                wav.unlink()
                self.log(f'   сохранено: {mp3.name}')
            else:
                self.log('Готово.')
        except Exception as e:
            traceback.print_exc()
            self.log('Ошибка: ' + repr(e))
        finally:
            self.ui(lambda: self.set_busy(False))

    # ---------- плеер ----------
    @staticmethod
    def fmt(sec):
        sec = int(sec)
        return f'{sec // 60}:{sec % 60:02d}'

    def play_array(self, data, sr, name):
        try:
            self.player.load(data, sr)
            self.cur = None
            self.play_lbl.configure(text=name)
        except Exception as e:
            messagebox.showerror('Ошибка воспроизведения', repr(e))

    def chapter_mp3(self, i):
        return speak.OUT_DIR / self.book.stem / f'{i + 1:03d}.mp3'

    @staticmethod
    def load_mp3(path):
        """mp3 -> float32, моно, 48 кГц через ffmpeg (не зависит от версии libsndfile)."""
        r = subprocess.run(['ffmpeg', '-v', 'error', '-i', str(path), '-f', 'f32le',
                            '-ac', '1', '-ar', str(speak.SAMPLE_RATE), '-'],
                           capture_output=True, check=True)
        return np.frombuffer(r.stdout, dtype=np.float32), speak.SAMPLE_RATE

    def play_chapter(self, i):
        try:
            data, sr = self.load_mp3(self.chapter_mp3(i))
            self.play_array(data, sr, f'глава {i + 1}: {self.chapters[i][0][:40]}')
            self.cur = i
            self.tree.selection_set(str(i))
            self.tree.see(str(i))
        except Exception as e:
            traceback.print_exc()
            messagebox.showerror('Ошибка воспроизведения', repr(e))

    def on_play(self):
        """▶/⏸: пауза и продолжение; если ничего не загружено (или выбрана другая
        глава, а плеер стоит) - запускает выбранную озвученную главу."""
        sel = self.selected()
        p = self.player
        other = bool(sel) and self.cur is not None and sel[0] != self.cur and not p.playing
        if p.data is not None and not other:
            p.toggle()
            return
        if not self.book:
            messagebox.showinfo('Плеер', 'Сначала открой книгу.')
            return
        if sel:
            self.listen()
            return
        for j in range(len(self.chapters)):          # ничего не выбрано: первая озвученная
            if self.chapter_mp3(j).exists():
                self.play_chapter(j)
                return
        messagebox.showinfo('Плеер', 'Озвученных глав пока нет.')

    def listen(self):
        sel = self.selected()
        if not (self.book and sel):
            messagebox.showinfo('Прослушать', 'Выбери главу в списке.')
            return
        if not self.chapter_mp3(sel[0]).exists():
            messagebox.showinfo('Прослушать', 'Эта глава ещё не озвучена.')
            return
        self.play_chapter(sel[0])

    def step(self, d):
        """Предыдущая/следующая ОЗВУЧЕННАЯ глава."""
        if not self.book:
            return
        sel = self.selected()
        base = self.cur if self.cur is not None else (
            sel[0] if sel else (-1 if d > 0 else len(self.chapters)))
        j = base + d
        while 0 <= j < len(self.chapters):
            if self.chapter_mp3(j).exists():
                self.play_chapter(j)
                return
            j += d
        messagebox.showinfo('Плеер', 'Дальше озвученных глав нет.')

    def on_seek(self, e):
        self.dragging = False
        self.player.seek(self.scale.get() / 1000)

    def tick(self):
        p = self.player
        if p.data is not None:
            if not self.dragging:
                self.scale.set(1000 * p.pos / max(len(p.data), 1))
            self.time_lbl.configure(
                text=f'{self.fmt(p.pos / p.sr)} / {self.fmt(len(p.data) / p.sr)}')
        self.b_play.configure(text='⏸' if p.playing else '▶')
        self.root.after(150, self.tick)

    def on_close(self):
        self.save_dict()
        self.stop_flag.set()
        self.player.close()
        self.root.destroy()


if __name__ == '__main__':
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass
    root = tk.Tk()
    App(root)
    root.mainloop()