@echo off
cd /d "%~dp0"
if not exist "venv\Scripts\python.exe" goto novenv
set "VIRTUAL_ENV=%~dp0venv"
set "PATH=%~dp0venv\Scripts;%PATH%"
set "PYTHONHOME="
python model_dirs.py clean
goto done
:novenv
echo venv\Scripts\python.exe was not found in %~dp0
:done
echo.
pause
