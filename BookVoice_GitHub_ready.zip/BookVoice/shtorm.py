"""Клиент изолированного процесса Shtorm-PocketTTS-RU.

Pocket-TTS имеет собственные зависимости (в том числе более новую numpy/torch), поэтому
он работает в отдельном venv_shtorm и не может обновлением пакетов сломать Silero/Tera.
"""
import atexit
import json
import os
import subprocess
import tempfile
import threading
from pathlib import Path

import numpy as np
import model_dirs

SAMPLE_RATE = 24000
MAX_LEN = 160
VARIANTS = {'fast': 'config_fast.yaml', 'slow': 'config_slow.yaml'}
BASE = Path(__file__).resolve().parent
WORKER = BASE / 'shtorm_worker.py'
PYTHON = BASE / 'venv_shtorm' / 'Scripts' / 'python.exe'
# Параметры генерации Pocket-TTS (settings.json, ключ "shtorm_gen"). Пусто = как раньше, значения по умолчанию модели.
# temp: случайность (меньше = ровнее и стабильнее); lsd_decode_steps: качество против скорости;
# eos_threshold: чувствительность «речь закончилась» (слишком чувствительный обрывает слова);
# noise_clamp: ограничение выбросов шума; frames_after_eos: сколько кадров (по 80 мс) договорить после конца.
GEN_LIMITS = {'temp': (0.05, 1.5, float), 'lsd_decode_steps': (1, 8, int), 'eos_threshold': (-10.0, 0.0, float),
              'noise_clamp': (0.0, 5.0, float), 'frames_after_eos': (0, 8, int)}
_gen = {}
_loaded_gen = {}
last_gen_applied = {}
_model_variant = None
_voice_ref = None
_sample_rate = SAMPLE_RATE
_proc = None
_log_handle = None
_lock = threading.RLock()

# Строка для проверки канала связи с процессом: кириллица, заглавная «И» (в cp1251 байт 0x98 не
# существует), «й», «ё», акут и типографские знаки должны вернуться из процесса без изменений.
PROBE = 'Привет, Иван! Ёжик — «съе\u0301л» йод'


def clean_gen(raw):
    """Только известные параметры с числами в допустимых пределах; остальное отбрасывается."""
    out = {}
    if isinstance(raw, dict):
        for key, (lo, hi, kind) in GEN_LIMITS.items():
            v = raw.get(key)
            if isinstance(v, (int, float)) and not isinstance(v, bool) and lo <= v <= hi:
                out[key] = kind(v)
    return out


def configure(raw):
    """Задать параметры генерации; вступают в силу при следующей загрузке модели (load перезагрузит, если они изменились)."""
    global _gen
    _gen = clean_gen(raw)


def model_dir():
    return Path(model_dirs.SHTORM_DIR)


def installed(variant='fast'):
    if variant not in VARIANTS:
        return False
    d = model_dir()
    weight = d / ('model_fast.safetensors' if variant == 'fast' else 'model_slow.safetensors')
    return (d / VARIANTS[variant]).is_file() and (d / 'tokenizer.model').is_file() and weight.is_file()


def not_installed_message(variant='fast'):
    return (f'Файлы Shtorm-PocketTTS-RU ({variant}) не найдены в {model_dir()}.\n'
            'Скачай их: ⚙ → «Модели…» (нужен интернет), затем снова выбери Shtorm.')


def _start_worker():
    global _proc, _log_handle
    if _proc is not None and _proc.poll() is None:
        return
    if _proc is not None:                   # прежний процесс умер: его каналы закрываем, а не ждём сборщика мусора
        for pipe in (_proc.stdin, _proc.stdout):
            try:
                pipe.close()
            except Exception:
                pass
    if not PYTHON.is_file():
        raise RuntimeError('Изолированная среда Shtorm не установлена. Создай её: ⚙ → «Модели…» → Shtorm.')
    if not WORKER.is_file():
        raise RuntimeError(f'Не найден файл движка: {WORKER.name}')
    log_path = model_dir() / 'bookvoice_worker.log'
    log_path.parent.mkdir(parents=True, exist_ok=True)
    if _log_handle is not None:             # процесс упал и запускается заново: старый журнал закрываем
        try:
            _log_handle.close()
        except Exception:
            pass
    _log_handle = open(log_path, 'a', encoding='utf-8', buffering=1)
    env = os.environ.copy()
    env['HF_HUB_OFFLINE'] = '1'
    env['TRANSFORMERS_OFFLINE'] = '1'
    # Потоки процесса, подключённого к каналу, Windows по умолчанию читает в кодировке ANSI (cp1251),
    # а клиент пишет UTF-8: русский текст доходил до модели как «РџСЂРѕ…» и озвучивался по буквам.
    # Поэтому обмен ведётся в чистом ASCII (см. _request), а сам процесс ещё и переводится на UTF-8.
    env['PYTHONUTF8'] = '1'
    env['PYTHONIOENCODING'] = 'utf-8'
    _proc = subprocess.Popen(
        [str(PYTHON), '-u', str(WORKER)], cwd=str(BASE), env=env,
        stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=_log_handle,
        text=True, encoding='utf-8', errors='replace', bufsize=1,
        creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))


def _request(payload):
    _start_worker()
    try:
        # ensure_ascii (по умолчанию): кириллица уходит как \uXXXX, так что кодировка канала не важна
        _proc.stdin.write(json.dumps(payload) + '\n')
        _proc.stdin.flush()
        line = _proc.stdout.readline()
    except (OSError, BrokenPipeError) as e:
        raise RuntimeError(f'Процесс Shtorm остановился. Журнал: {model_dir() / "bookvoice_worker.log"}') from e
    if not line:
        try:
            code = _proc.wait(timeout=2)        # канал закрыт: процесс умирает, дожидаемся, чтобы is_loaded() это видел
        except Exception:
            code = _proc.poll()
        raise RuntimeError(f'Процесс Shtorm завершился (код {code}). Журнал: '
                           f'{model_dir() / "bookvoice_worker.log"}')
    try:
        response = json.loads(line)
    except json.JSONDecodeError as e:
        raise RuntimeError('Процесс Shtorm вернул некорректный ответ. Проверь bookvoice_worker.log.') from e
    if not response.get('ok'):
        raise RuntimeError(response.get('error') or 'Неизвестная ошибка Shtorm')
    return response


def is_loaded(variant=None, voice_ref=None):
    with _lock:
        ref = str(Path(voice_ref).expanduser().resolve()) if voice_ref else None
        return (_proc is not None and _proc.poll() is None and _model_variant is not None and
                (variant is None or variant == _model_variant) and
                (ref is None or ref == _voice_ref))


def _relocalize_configs():
    """Пути к весам в конфигурациях ведут в нынешнюю папку (она могла смениться: модели скопировали с другого
    компьютера или перенесли). Не получилось записать - не страшно, Shtorm сам скажет, чего не нашёл."""
    try:
        import model_manager
        model_manager.patch_shtorm_configs(model_dir(), strict=False)
    except Exception:
        pass


def load(variant='fast', voice_ref=None):
    global _model_variant, _voice_ref, _sample_rate, SAMPLE_RATE, _loaded_gen
    if variant not in VARIANTS:
        raise ValueError('Вариант Shtorm должен быть fast или slow')
    if not voice_ref:
        raise RuntimeError('Для Shtorm выбери WAV-файл с образцом голоса (примерно 5 секунд чистой речи).')
    ref = Path(voice_ref).expanduser().resolve()
    if not ref.is_file():
        raise RuntimeError(f'Файл образца голоса не найден: {ref}')
    if ref.suffix.lower() != '.wav':
        raise RuntimeError('Образец голоса должен быть WAV-файлом.')
    if not installed(variant):
        raise RuntimeError(not_installed_message(variant))
    with _lock:
        if is_loaded(variant, str(ref)) and _loaded_gen == _gen:
            return
        _relocalize_configs()
        response = _request({'cmd': 'load', 'variant': variant, 'voice_ref': str(ref),
                             'model_dir': str(model_dir()), 'probe': PROBE, 'gen': dict(_gen)})
        if response.get('probe', PROBE) != PROBE:
            # Страховка: если канал всё же искажает русский текст, лучше остановиться сразу,
            # чем озвучить книгу «по буквам».
            shutdown()
            raise RuntimeError('Процесс Shtorm искажает русский текст при обмене данными '
                               f'(получено {response.get("probe")!r}). Озвучка остановлена.')
        rate = int(response.get('sample_rate', SAMPLE_RATE))
        if rate <= 0:
            raise RuntimeError(f'Некорректная частота дискретизации Shtorm: {rate}')
        _model_variant, _voice_ref, _sample_rate = variant, str(ref), rate
        _loaded_gen.clear()
        _loaded_gen.update(_gen)
        last_gen_applied.clear()
        last_gen_applied.update(response.get('gen_applied') or {})
        SAMPLE_RATE = rate


def synthesize(text):
    """Синтезировать текст в mono float32; модель постоянно живёт в отдельном процессе."""
    if not text or not text.strip():
        return np.zeros(0, dtype=np.float32)
    with _lock:
        if not is_loaded():
            raise RuntimeError('Shtorm не загружен: выбери движок и образец голоса.')
        fd, out_path = tempfile.mkstemp(prefix='bookvoice_shtorm_', suffix='.npy')
        os.close(fd)
        try:
            response = _request({'cmd': 'synthesize', 'text': text, 'out_path': out_path})
            actual = Path(response.get('out_path', out_path))
            arr = np.load(actual, allow_pickle=False).astype(np.float32, copy=False).reshape(-1)
            if not arr.size:
                raise RuntimeError('Shtorm вернул пустой аудиофрагмент.')
            if not np.isfinite(arr).all():
                raise RuntimeError('Shtorm вернул некорректные значения аудио (NaN/Inf).')
            return np.clip(arr, -1.0, 1.0)
        finally:
            try:
                Path(out_path).unlink(missing_ok=True)
            except OSError:
                pass


def plus_to_acute(text):
    """Преобразовать метки ударения BookVoice (+перед буквой) в акут после буквы."""
    import re
    text = re.sub(r'\+([А-Яа-яЁё])', lambda m: m.group(1) + '\u0301', text)
    return text.replace('+', '').replace('*', '')


def shutdown():
    global _proc, _log_handle
    with _lock:
        if _proc is not None:
            try:
                if _proc.poll() is None:
                    _proc.stdin.write('{"cmd":"shutdown"}\n')
                    _proc.stdin.flush()
                    _proc.wait(timeout=3)
            except Exception:
                try:
                    _proc.terminate()
                    _proc.wait(timeout=3)
                except Exception:
                    pass
            for pipe in (_proc.stdin, _proc.stdout):      # каналы закрываем, иначе они висят до сборки мусора
                try:
                    pipe.close()
                except Exception:
                    pass
            _proc = None
        if _log_handle is not None:
            try:
                _log_handle.close()
            except Exception:
                pass
            _log_handle = None


atexit.register(shutdown)
