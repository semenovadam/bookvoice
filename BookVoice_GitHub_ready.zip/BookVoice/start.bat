@echo off
setlocal
cd /d "%~dp0"
title BookVoice
rem ---------------------------------------------------------------------------
rem BookVoice launcher for a second computer (Windows, 64-bit).
rem First run: finds Python, creates the "venv" folder next to this file and
rem installs the packages (internet needed, several GB). Next runs just start
rem the program. The models are downloaded from inside the program: gear icon
rem at the top right, then "Models".
rem Plain ASCII only, and no activate.bat: the python.exe of the venv is started
rem directly, so the folder can be moved or renamed.
rem ---------------------------------------------------------------------------
if not exist "app.py" goto noapp
if not exist "venv\Scripts\python.exe" goto findpython
if not exist "venv\bookvoice_ready.txt" goto install
goto run

:findpython
set "PYCMD="
set "PYVER="
if exist "PYTHON_VERSION.txt" for /f "usebackq tokens=1" %%v in ("PYTHON_VERSION.txt") do set "PYVER=%%v"
if not defined PYVER goto trylist
echo %PYVER%| findstr /r /c:"^3\.[0-9][0-9]*$" >nul
if errorlevel 1 goto badver
py -%PYVER% -c "import sys" >nul 2>nul
if not errorlevel 1 set "PYCMD=py -%PYVER%"
if defined PYCMD goto foundpy
echo Python %PYVER% (the version used on the main computer) was not found.
echo Trying other Python versions; if the exact package list does not fit,
echo the general list requirements.txt will be used instead.
goto trylist
:badver
set "PYVER="
:trylist
for %%v in (3.12 3.11 3.13 3.10) do if not defined PYCMD py -%%v -c "import sys" >nul 2>nul && set "PYCMD=py -%%v"
if defined PYCMD goto foundpy
python -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
if not errorlevel 1 set "PYCMD=python"
if defined PYCMD goto foundpy
goto nopython

:foundpy
echo Using Python:
%PYCMD% --version
echo.
echo Creating the environment in "%~dp0venv" ...
%PYCMD% -m venv venv
if errorlevel 1 goto fail
"venv\Scripts\python.exe" -c "import tkinter" >nul 2>nul
if errorlevel 1 goto notk
"venv\Scripts\python.exe" -c "import struct, sys; sys.exit(0 if struct.calcsize('P') == 8 else 1)" >nul 2>nul
if errorlevel 1 goto no64

:install
echo.
echo Installing the packages. This needs the internet and can take 10-30 minutes.
echo Do not close this window. If it stops half way, just run start.bat again.
"venv\Scripts\python.exe" -m pip install --disable-pip-version-check --upgrade pip
if exist "requirements.lock.txt" goto installlock
goto installgeneral

:installlock
echo.
echo Installing the exact package versions from requirements.lock.txt ...
"venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r requirements.lock.txt
if not errorlevel 1 goto check
echo.
echo The exact versions could not be installed (another Python version, or a package
echo that is no longer available). Trying the general list requirements.txt instead ...

:installgeneral
if not exist "requirements.txt" goto noreq
echo.
echo Installing the packages from requirements.txt ...
"venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r requirements.txt
if errorlevel 1 goto fail

:check
echo.
echo Checking the installation ...
"venv\Scripts\python.exe" -c "import numpy, soundfile, sounddevice, torch, num2words, pymorphy3, PIL, ruaccent, tkinter"
if errorlevel 1 goto fail
echo ok> "venv\bookvoice_ready.txt"

:run
set "VIRTUAL_ENV=%~dp0venv"
set "PATH=%~dp0venv\Scripts;%PATH%"
set "PYTHONHOME="
"venv\Scripts\python.exe" app.py
if errorlevel 1 pause
goto :eof

:noapp
echo app.py was not found in %~dp0
echo Run start.bat from the BookVoice folder (the one with app.py).
goto stop
:nopython
echo.
echo Python was not found. Install 64-bit Python 3.10 or newer.
if defined PYVER echo The main computer uses Python %PYVER%: install the same version if you can.
echo Download: https://www.python.org/downloads/windows/
echo During the installation tick "Add python.exe to PATH" and keep "tcl/tk and IDLE".
echo Or run in a command prompt:  winget install -e --id Python.Python.3.12
echo Then run start.bat again.
goto stop
:notk
echo.
echo This Python has no Tk, and the program window needs it. Reinstall Python and keep
echo "tcl/tk and IDLE" ticked, then run start.bat again.
rmdir /s /q "venv"
goto stop
:no64
echo.
echo This is a 32-bit Python. The program needs 64-bit Python (x64). Install it, then
echo run start.bat again.
rmdir /s /q "venv"
goto stop
:noreq
echo.
echo requirements.txt was not found next to start.bat.
goto stop
:fail
echo.
echo Something went wrong, see the messages above. Check the internet connection and
echo run start.bat again. If it keeps failing, delete the "venv" folder and start again.
:stop
echo.
pause
exit /b 1
