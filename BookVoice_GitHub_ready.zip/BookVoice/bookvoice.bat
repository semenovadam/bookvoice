@echo off
cd /d "%~dp0"
rem Works from any folder and under any folder name. The venv is NOT "activated":
rem venv\Scripts\activate.bat remembers the old folder path and breaks after a rename.
rem Its python.exe is started directly instead, and that keeps working in the new place.
if not exist "venv\Scripts\python.exe" goto novenv
set "VIRTUAL_ENV=%~dp0venv"
set "PATH=%~dp0venv\Scripts;%PATH%"
set "PYTHONHOME="
set HF_HUB_OFFLINE=1
set TRANSFORMERS_OFFLINE=1
"venv\Scripts\python.exe" app.py
if errorlevel 1 pause
goto :eof
:novenv
echo venv\Scripts\python.exe was not found in %~dp0
echo Run this file from the program folder (the one with app.py and the venv folder).
pause
