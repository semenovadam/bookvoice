"""Клиент изолированного процесса Shtorm-VoxCPM2-RU (русская VoxCPM2 с ударениями по меткам «+»).

VoxCPM2 тянет свои версии torch и десятки пакетов, поэтому работает в отдельном venv_voxcpm и не может
обновлением пакетов сломать Silero/Tera/Shtorm-PocketTTS. Модуль назван shtorm_vox, а не voxcpm: иначе он
заслонил бы одноимённый pip-пакет внутри процесса.

Модель весит около 5 ГБ и грузится один раз на запуск программы. Смена образца голоса, его текста,
cfg и числа шагов модель не перезагружает.
"""
import atexit
import json
import os
import re
import subprocess
import tempfile
import threading
from pathlib import Path

import numpy as np
import model_dirs

SAMPLE_RATE = 48000          # уточняется у модели при загрузке (model.tts_model.sample_rate)
MAX_LEN = 300                # автор советует озвучивать по предложениям; совсем длинные BookVoice режет сама
CFG_VALUE = 2.0              # cfg_value: выше - точнее следует тексту и образцу, но может звучать жёстче
TIMESTEPS = 10               # inference_timesteps: больше - чище, но медленнее
CFG_CHOICES = ('1.5', '2.0', '2.5', '3.0')
STEP_CHOICES = ('6', '8', '10', '15', '20')
BASE = Path(__file__).resolve().parent
WORKER = BASE / 'shtorm_vox_worker.py'
PYTHON = BASE / 'venv_voxcpm' / 'Scripts' / 'python.exe'

# Что должно лежать в папке модели (репозиторий ArtShtorm/Shtorm-VoxCPM2-RU).
REQUIRED_FILES = ('config.json', 'model.safetensors', 'audiovae.pth', 'tokenizer.json',
                  'tokenizer_config.json', 'special_tokens_map.json', 'tokenization_voxcpm2.py')

_voice_ref = None
_prompt_text = ''
_sample_rate = SAMPLE_RATE
_loaded = False
_proc = None
_log_handle = None
_lock = threading.RLock()

# Строка для проверки канала связи с процессом (см. SHTORM_ENGINE.md: кодировка канала в Windows).
PROBE = 'Привет, Иван! Ёжик — «зам+ок» йод'

_VOWELS = 'аеёиоуыэюяАЕЁИОУЫЭЮЯ'
_WORD = re.compile(r'[А-Яа-яЁё+]+(?:-[А-Яа-яЁё+]+)*')


def model_dir():
    return Path(model_dirs.VOXCPM_DIR)


def missing_files():
    d = model_dir()
    return [n for n in REQUIRED_FILES if not (d / n).is_file()]


def installed():
    return not missing_files()


def not_installed_message():
    miss = missing_files()
    return (f'Файлы Shtorm-VoxCPM2-RU не найдены в {model_dir()}'
            + (f' (нет: {", ".join(miss)})' if miss else '') + '.\n'
            'Скачай их: ⚙ → «Модели…» (нужен интернет), затем снова выбери Shtorm-VoxCPM2-RU.')


def prepare_text(text):
    """Подготовить текст BookVoice для модели.

    Метки «+» перед ударной гласной модель понимает как есть (в этом её отличие от PocketTTS, которому
    нужен акут). Но автор предупреждает: на односложных словах метка читается как выделение слова и речь
    растягивается, а «ё» всегда ударная и метки не требует. Такие метки снимаются. Маркеры «*» нужны
    только Silero и удаляются, как и любой «+», стоящий не перед гласной.
    """
    text = text.replace('*', '')

    def part(piece):
        if '+' not in piece:
            return piece
        if sum(ch in _VOWELS for ch in piece) < 2:        # односложное слово (в том числе часть «кто-то»)
            return piece.replace('+', '')
        return re.sub(r'\+(?=[Ёё])', '', piece)

    def word(m):
        return '-'.join(part(p) for p in m.group(0).split('-'))

    text = _WORD.sub(word, text)
    return re.sub(r'\+(?![' + _VOWELS + '])', '', text)


def prompt_for_model(text):
    """Дословный текст образца подаётся без меток («+», «*»)."""
    return re.sub(r'\s+', ' ', (text or '').replace('+', '').replace('*', '')).strip()


def _start_worker():
    global _proc, _log_handle
    if _proc is not None and _proc.poll() is None:
        return
    if _proc is not None:                   # прежний процесс умер: его каналы закрываем
        for pipe in (_proc.stdin, _proc.stdout):
            try:
                pipe.close()
            except Exception:
                pass
    if not PYTHON.is_file():
        raise RuntimeError('Изолированная среда Shtorm-VoxCPM2-RU не установлена. '
                           'Создай её: ⚙ → «Модели…» → Shtorm-VoxCPM2-RU.')
    if not WORKER.is_file():
        raise RuntimeError(f'Не найден файл движка: {WORKER.name}')
    log_path = model_dir() / 'bookvoice_worker.log'
    log_path.parent.mkdir(parents=True, exist_ok=True)
    if _log_handle is not None:
        try:
            _log_handle.close()
        except Exception:
            pass
    _log_handle = open(log_path, 'a', encoding='utf-8', buffering=1)
    env = os.environ.copy()
    env['HF_HUB_OFFLINE'] = '1'
    env['TRANSFORMERS_OFFLINE'] = '1'
    env['PYTHONUTF8'] = '1'
    env['PYTHONIOENCODING'] = 'utf-8'
    _proc = subprocess.Popen(
        [str(PYTHON), '-u', str(WORKER)], cwd=str(BASE), env=env,
        stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=_log_handle,
        text=True, encoding='utf-8', errors='replace', bufsize=1,
        creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))


def _request(payload):
    global _loaded
    _start_worker()
    try:
        # ensure_ascii: кириллица уходит как \uXXXX, так что кодировка канала не важна
        _proc.stdin.write(json.dumps(payload) + '\n')
        _proc.stdin.flush()
        line = _proc.stdout.readline()
    except (OSError, BrokenPipeError) as e:
        _loaded = False
        raise RuntimeError(f'Процесс VoxCPM2 остановился. Журнал: {model_dir() / "bookvoice_worker.log"}') from e
    if not line:
        _loaded = False
        try:
            code = _proc.wait(timeout=2)
        except Exception:
            code = _proc.poll()
        raise RuntimeError(f'Процесс VoxCPM2 завершился (код {code}). Журнал: '
                           f'{model_dir() / "bookvoice_worker.log"}')
    try:
        response = json.loads(line)
    except json.JSONDecodeError as e:
        raise RuntimeError('Процесс VoxCPM2 вернул некорректный ответ. Проверь bookvoice_worker.log.') from e
    if not response.get('ok'):
        raise RuntimeError(response.get('error') or 'Неизвестная ошибка VoxCPM2')
    return response


def is_loaded(voice_ref=None, prompt_text=None):
    with _lock:
        if not (_proc is not None and _proc.poll() is None and _loaded):
            return False
        if voice_ref is not None and str(Path(voice_ref).expanduser().resolve()) != _voice_ref:
            return False
        return prompt_text is None or prompt_for_model(prompt_text) == _prompt_text


def load(voice_ref=None, prompt_text=''):
    """Загрузить модель (один раз) и задать образец голоса. prompt_text - дословный текст образца: с ним
    клонирование точнее (режим Hi-Fi), без него модель берёт только тембр."""
    global _voice_ref, _prompt_text, _sample_rate, SAMPLE_RATE, _loaded
    if not voice_ref:
        raise RuntimeError('Для Shtorm-VoxCPM2-RU выбери WAV-файл с образцом голоса '
                           '(5–15 секунд чистой речи).')
    ref = Path(voice_ref).expanduser().resolve()
    if not ref.is_file():
        raise RuntimeError(f'Файл образца голоса не найден: {ref}')
    if ref.suffix.lower() != '.wav':
        raise RuntimeError('Образец голоса должен быть WAV-файлом.')
    if not installed():
        raise RuntimeError(not_installed_message())
    prompt = prompt_for_model(prompt_text)
    with _lock:
        if is_loaded(str(ref), prompt):
            return
        response = _request({'cmd': 'load', 'model_dir': str(model_dir()), 'voice_ref': str(ref),
                             'prompt_text': prompt, 'probe': PROBE})
        if response.get('probe', PROBE) != PROBE:
            shutdown()
            raise RuntimeError('Процесс VoxCPM2 искажает русский текст при обмене данными '
                               f'(получено {response.get("probe")!r}). Озвучка остановлена.')
        rate = int(response.get('sample_rate', SAMPLE_RATE))
        if rate <= 0:
            raise RuntimeError(f'Некорректная частота дискретизации VoxCPM2: {rate}')
        _voice_ref, _prompt_text, _sample_rate, _loaded = str(ref), prompt, rate, True
        SAMPLE_RATE = rate


def synthesize(text):
    """Синтезировать текст в mono float32; модель постоянно живёт в отдельном процессе."""
    if not text or not text.strip():
        return np.zeros(0, dtype=np.float32)
    with _lock:
        if not is_loaded():
            raise RuntimeError('Shtorm-VoxCPM2-RU не загружен: выбери движок и образец голоса.')
        fd, out_path = tempfile.mkstemp(prefix='bookvoice_vox_', suffix='.npy')
        os.close(fd)
        try:
            response = _request({'cmd': 'synthesize', 'text': text, 'out_path': out_path,
                                 'cfg_value': float(CFG_VALUE), 'timesteps': int(TIMESTEPS)})
            actual = Path(response.get('out_path', out_path))
            arr = np.load(actual, allow_pickle=False).astype(np.float32, copy=False).reshape(-1)
            if not arr.size:
                raise RuntimeError('VoxCPM2 вернул пустой аудиофрагмент.')
            if not np.isfinite(arr).all():
                raise RuntimeError('VoxCPM2 вернул некорректные значения аудио (NaN/Inf).')
            return np.clip(arr, -1.0, 1.0)
        finally:
            try:
                Path(out_path).unlink(missing_ok=True)
            except OSError:
                pass


def shutdown():
    """Остановить процесс и освободить видеопамять."""
    global _proc, _log_handle, _loaded
    with _lock:
        _loaded = False
        if _proc is not None:
            try:
                if _proc.poll() is None:
                    _proc.stdin.write('{"cmd":"shutdown"}\n')
                    _proc.stdin.flush()
                    _proc.wait(timeout=5)
            except Exception:
                try:
                    _proc.terminate()
                    _proc.wait(timeout=5)
                except Exception:
                    pass
            for pipe in (_proc.stdin, _proc.stdout):
                try:
                    pipe.close()
                except Exception:
                    pass
            _proc = None
        if _log_handle is not None:
            try:
                _log_handle.close()
            except Exception:
                pass
            _log_handle = None


atexit.register(shutdown)
