"""Оформление книги поверх простого списка абзацев: пустые строки, «с новой страницы», стихи, центрированный курсив, нумерация глав.

Главы книги по-прежнему (название, [абзацы]). Всё оформление лежит ОТДЕЛЬНО и ссылается на номера абзацев:

    layout = [{'paragraph': p, 'kind': 'empty' | 'page' | 'verse'}, ...]    (для одной главы)

  empty, page - «перед абзацем p» (p == число абзацев: в самом конце главы); несколько записей подряд =
                несколько пустых строк;
  verse       - абзац p это строка стиха (курсив и сдвиг вправо); center - курсивный абзац по центру.

В окне редактора пустая строка и новая страница видны строками-метками MARK_EMPTY и MARK_PAGE, а стих помечен
тегом. Метки не абзацы: в озвучку, счётчики и акценты они не попадают. Модуль не зависит от Tk.
"""
import re

KIND_EMPTY, KIND_PAGE, KIND_VERSE, KIND_CENTER = 'empty', 'page', 'verse', 'center'
MARK_EMPTY = '[пустая строка]'
MARK_PAGE = '[новая страница]'
MARKS = {MARK_EMPTY: KIND_EMPTY, MARK_PAGE: KIND_PAGE}
MARK_TEXT = {v: k for k, v in MARKS.items()}

DEFAULT_NUMBER_FORMAT = 'Глава {n} - {title}'


def is_mark(line):
    """Строка окна редактора, которая является меткой оформления, а не текстом."""
    return line.strip() in MARKS


# ---------------------------------------------------------------- строки окна <-> абзацы + оформление
def compose_lines(paras, layout):
    """(абзацы, оформление) -> (строки окна, номер строки каждого абзаца, номера строк-стихов), всё с нуля."""
    before = {}
    verse = set()
    for e in clamp_layout(layout, len(paras)):
        if e['kind'] == KIND_VERSE:
            verse.add(e['paragraph'])
        else:
            before.setdefault(e['paragraph'], []).append(e['kind'])
    lines, para_line, verse_lines = [], [], set()
    for p in range(len(paras) + 1):
        for kind in before.get(p, []):
            lines.append(MARK_TEXT[kind])
        if p < len(paras):
            para_line.append(len(lines))
            if p in verse:
                verse_lines.add(len(lines))
            lines.append(paras[p])
    return lines, para_line, verse_lines


def parse_lines(lines, verse_lines=(), center_lines=()):
    """Строки окна (+ номера строк-стихов, с нуля) -> (абзацы, оформление).
    Абзац это непустая строка без меток, края обрезаются (как EditTab.get_paras). Обычные пустые строки,
    которые человек оставил в тексте, оформлением не считаются, как и раньше."""
    paras, layout = [], []
    verse_lines, center_lines = set(verse_lines), set(center_lines)
    for i, raw in enumerate(lines):
        s = raw.strip()
        if not s:
            continue
        if s in MARKS:
            layout.append({'paragraph': len(paras), 'kind': MARKS[s]})
            continue
        if i in verse_lines:
            layout.append({'paragraph': len(paras), 'kind': KIND_VERSE})
        if i in center_lines:
            layout.append({'paragraph': len(paras), 'kind': KIND_CENTER})
        paras.append(s)
    return paras, layout


def clamp_layout(layout, n_paras):
    """Оформление без мусора: известные виды, номера в пределах главы, verse только на существующем абзаце."""
    out = []
    for e in layout or []:
        try:
            kind, p = e['kind'], int(e['paragraph'])
        except (KeyError, TypeError, ValueError):
            continue
        if kind in (KIND_VERSE, KIND_CENTER):
            if 0 <= p < n_paras:
                out.append({'paragraph': p, 'kind': kind})
        elif kind in (KIND_EMPTY, KIND_PAGE):
            out.append({'paragraph': max(0, min(p, n_paras)), 'kind': kind})
    out.sort(key=lambda e: (e['paragraph'], e['kind'] == KIND_VERSE))     # перед абзацем: метки, потом признак стиха
    return out


def shift_layout(layout, delta):
    return [dict(e, paragraph=e['paragraph'] + delta) for e in layout]


def layout_key(layout):
    """Сравнимый вид оформления (для «есть ли несохранённые правки»)."""
    return tuple((e['paragraph'], e['kind']) for e in layout or [])


# ---------------------------------------------------------------- нумерация глав
def number_prefix(fmt, n):
    """Что стоит перед названием: «Глава 3 - » для формата «Глава {n} - {title}»."""
    return fmt.split('{title}')[0].replace('{n}', str(n))


def display_title(title, fmt, n):
    """Название главы для чтения и содержания: по формату, где {n} номер, {title} название."""
    try:
        return fmt.replace('{n}', str(n)).replace('{title}', title)
    except Exception:
        return title


def display_titles(titles, start, fmt=DEFAULT_NUMBER_FORMAT, excluded=()):
    """Названия всех глав. start: номер главы (с нуля), с которой начинается «Глава 1»; None: без нумерации.
    Главы до неё (вводные стихи, пролог) остаются как есть."""
    if start is None or not fmt or '{n}' not in fmt:
        return list(titles)
    excluded = set(excluded or ())
    number = 0
    result = []
    for i, title in enumerate(titles):
        if i < start or i in excluded:
            result.append(title)
        else:
            number += 1
            result.append(display_title(title, fmt, number))
    return result


def strip_number(title, fmt, n):
    """Обратное display_title: «Глава 1 - Дием» -> «Дием». Если название не по формату, оставляем как есть."""
    prefix = number_prefix(fmt, n)
    if prefix and title.startswith(prefix) and title[len(prefix):].strip():
        return title[len(prefix):].strip()
    return title


def valid_number_format(fmt):
    """Формат годится, если в нём есть и {n}, и {title}, и нет других фигурных скобок."""
    return (isinstance(fmt, str) and '{n}' in fmt and '{title}' in fmt
            and not re.search(r'\{(?!n\}|title\})', fmt))
