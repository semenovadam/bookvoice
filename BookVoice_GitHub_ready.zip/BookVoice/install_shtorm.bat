@echo off
setlocal
cd /d "%~dp0"
if not exist "venv\Scripts\python.exe" goto novenv
set "VIRTUAL_ENV=%~dp0venv"
set "PATH=%~dp0venv\Scripts;%PATH%"
set "PYTHONHOME="
set "HF_HUB_OFFLINE="
set "TRANSFORMERS_OFFLINE="
if exist "venv_shtorm\Scripts\python.exe" goto havevenv
echo === 1/3. Creating an isolated Python environment for Shtorm ===
"venv\Scripts\python.exe" -m venv venv_shtorm
if errorlevel 1 goto fail
:havevenv
echo.
echo === 2/3. Installing Pocket-TTS in its own environment ===
"venv_shtorm\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto fail
"venv_shtorm\Scripts\python.exe" -m pip install "pocket-tts==4.0.1"
if errorlevel 1 goto fail
echo.
echo === 3/3. Downloading Shtorm-PocketTTS-RU fast/slow weights (about 0.9 GB) ===
"venv_shtorm\Scripts\python.exe" install_shtorm.py
if errorlevel 1 goto fail
echo.
echo Shtorm installed. Existing Silero and Tera environments were not modified.
echo In BookVoice choose Shtorm-PocketTTS-RU and select a clean WAV voice sample.
pause
exit /b 0
:novenv
echo venv\Scripts\python.exe was not found. Run BookVoice setup first.
pause
exit /b 1
:fail
echo.
echo Installation failed. Read the error above, fix the issue and run this file again.
pause
exit /b 1
