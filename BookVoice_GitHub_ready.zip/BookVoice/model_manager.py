r"""Модели BookVoice: что установлено, скачивание из программы, ffmpeg, перенос на другое устройство.

Скачивание идёт отдельным процессом (python model_manager.py job <компонент>): сама программа
работает без сети (HF_HUB_OFFLINE), а процессу скачивания сеть нужна. Процесс печатает служебные
строки, по которым окно «Модели» показывает ход, а всё остальное попадает в его журнал как есть:
  @@stage текст     что делается сейчас
  @@total байты     сколько всего нужно скачать (если известно)
  @@watch путь      файл или папка, размер которых растёт при скачивании
Компоненты: silero, ruaccent, tera, shtorm, voxcpm, ffmpeg (и silero_update: обновить репозиторий Silero).
"""
import contextlib
import fnmatch
import importlib.util
import inspect
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import threading
import urllib.request
import zipfile
from collections import namedtuple
from pathlib import Path

import model_dirs

COMPONENTS = ['silero', 'ruaccent', 'tera', 'shtorm', 'voxcpm', 'ffmpeg']
REQUIRED = ('silero', 'ruaccent')            # без них программа не запустится
TITLES = {'silero': 'Silero (основной движок, голоса)',
          'ruaccent': 'RUAccent (расстановка ударений)',
          'tera': 'TeraTTS v2 (голоса ru_f1, ru_m5 и другие)',
          'shtorm': 'Shtorm-PocketTTS-RU (голос по образцу WAV)',
          'voxcpm': 'Shtorm-VoxCPM2-RU (ударения по меткам, голос по образцу; нужна видеокарта)',
          'ffmpeg': 'ffmpeg (сохранение mp3)'}
APPROX = {'silero': 'около 0,2 ГБ', 'ruaccent': 'несколько сотен МБ', 'tera': 'около 1,2 ГБ',
          'shtorm': 'около 0,9 ГБ + своя среда около 1 ГБ',
          'voxcpm': 'около 5 ГБ + своя среда около 6 ГБ', 'ffmpeg': 'около 0,2 ГБ'}
APPROX_BYTES = {'silero': 200 << 20, 'ruaccent': 500 << 20, 'tera': 1200 << 20,
                'shtorm': 1900 << 20, 'voxcpm': 11000 << 20, 'ffmpeg': 200 << 20}      # для проверки свободного места
NOTES = {'silero': 'нужен всегда', 'ruaccent': 'нужен всегда',
         'tera': 'по желанию', 'shtorm': 'по желанию, ставит отдельную среду venv_shtorm',
         'voxcpm': 'по желанию, ставит отдельную среду venv_voxcpm (Python 3.10–3.12, видеокарта NVIDIA)',
         'ffmpeg': 'нужен для mp3; если ffmpeg уже есть в системе, качать не надо'}

RUACCENT_SIZE = 'turbo'                      # модель по умолчанию (так программа работала раньше)
RUACCENT_REPO = 'ruaccent/accentuator'       # там лежат словари и все модели ударений
RUACCENT_PKG = 'ruaccent'                    # имя пакета в pip
# Модели омографов, о которых известно заранее (на случай, когда сервер недоступен): от новых к старым.
# Настоящий список программа берёт с сервера кнопкой «Проверить обновления» в окне RUAccent.
RUACCENT_MODELS = {
    'turbo3.1': 'самая новая из основных; лучший кандидат на точность',
    'turbo3': 'основная, прошлое поколение',
    'turbo2': 'основная, прошлое поколение',
    'turbo': 'с ней программа работала раньше',
    'tiny2.1': 'самая новая из лёгких: быстрая, мало памяти (для слабых компьютеров)',
    'tiny2': 'лёгкая, прошлое поколение',
    'tiny': 'лёгкая, самая первая',
    'big_poetry': 'старое поколение «poetry», тяжёлая',
    'medium_poetry': 'старое поколение «poetry»',
    'small_poetry': 'старое поколение «poetry», лёгкая',
}
RUACCENT_RECORDS = '.bookvoice_ruaccent.json'   # в папке моделей ударений: когда какая модель скачана
RUACCENT_SETTING_KEYS = ('ruaccent_model', 'ruaccent_dictionary', 'ruaccent_tiny')   # ключи settings.json
TERA_REPO = 'TeraSpace/TeraTTSv2'
SHTORM_REPO = 'ArtShtorm/Shtorm-PocketTTS-RU'
SHTORM_REFS = ('model_fast.safetensors', 'model_slow.safetensors', 'tokenizer.model')
SHTORM_FILES = ['config.yaml', 'config_fast.yaml', 'config_slow.yaml', *SHTORM_REFS]
POCKET_TTS_SPEC = 'pocket-tts==4.0.1'
VOXCPM_REPO = 'ArtShtorm/Shtorm-VoxCPM2-RU'
VOXCPM_FILES = ['config.json', 'model.safetensors', 'audiovae.pth', 'tokenizer.json',
                'tokenizer_config.json', 'special_tokens_map.json', 'tokenization_voxcpm2.py']
VOXCPM_PY_RANGE = ((3, 10), (3, 12))         # VoxCPM2 не поддерживает Python 3.13
VOXCPM_MIN_TORCH = (2, 5)                    # требование пакета voxcpm
VOXCPM_TORCH_INDEX = 'https://download.pytorch.org/whl/'
VOXCPM_TORCH_FALLBACK = 'cu124'              # если по основной среде не удалось понять, какой CUDA нужен
FFMPEG_URLS = {'amd64': 'https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/'
                        'ffmpeg-master-latest-win64-gpl.zip',
               'arm64': 'https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/'
                        'ffmpeg-master-latest-winarm64-gpl.zip'}
NO_WINDOW = getattr(subprocess, 'CREATE_NO_WINDOW', 0)

Status = namedtuple('Status', 'ok size where note')


# ---------------------------------------------------------------- что установлено
def dir_size(path):
    """Размер файла или папки в байтах (ссылки не считаются, ошибки чтения пропускаются)."""
    p = Path(path)
    try:
        if p.is_file():
            return p.stat().st_size
    except OSError:
        return 0
    total = 0
    for root, _dirs, files in os.walk(p):
        for name in files:
            f = os.path.join(root, name)
            try:
                if not os.path.islink(f):
                    total += os.path.getsize(f)
            except OSError:
                pass
    return total


def fmt_size(n):
    return model_dirs._fmt(n)


def _has_files(path):
    try:
        return any(f for _r, _d, fs in os.walk(path) for f in fs)
    except OSError:
        return False


FLAG = '.bookvoice_downloading'
PARTIAL_NOTE = 'скачано не до конца, нажми «Скачать выбранные» ещё раз'


def partial(path):
    """В папке неполные файлы: скачивание оборвали (кнопка «Остановить», обрыв сети, выключили питание).
    Признак: флажок нашего скачивания или недокачанные файлы huggingface_hub (.incomplete)."""
    p = Path(path)
    try:
        if (p / FLAG).is_file():
            return True
        return any(f.name.endswith('.incomplete') for f in (p / '.cache' / 'huggingface' / 'download').rglob('*'))
    except OSError:
        return False


@contextlib.contextmanager
def in_progress(path):
    """Пока идёт скачивание, в папке лежит флажок. Закончилось успешно - флажок убирается; оборвали или
    случилась ошибка - остаётся, и окно «Модели» не считает такую папку готовой."""
    flag = Path(path) / FLAG
    flag.parent.mkdir(parents=True, exist_ok=True)
    flag.write_text('Скачивание в эту папку не закончено. Удали файл, только если всё скачано.\n', encoding='utf-8')
    yield
    flag.unlink(missing_ok=True)


def ruaccent_module_dir():
    """Папка пакета ruaccent в текущем Python (сам пакет при этом не импортируется)."""
    try:
        spec = importlib.util.find_spec('ruaccent')
        return Path(spec.origin).parent if spec and spec.origin else None
    except Exception:
        return None


def ruaccent_places():
    """Где могут лежать модели ударений: (папка в папке моделей, папка внутри пакета ruaccent)."""
    return Path(model_dirs.RUACCENT_DIR), ruaccent_module_dir()


def ruaccent_workdir():
    """Папка моделей ударений для RUAccent.load(workdir=...); None, если модели лежат по-старому,
    внутри пакета ruaccent (так у компьютеров, где программа работала раньше)."""
    own, _pkg = ruaccent_places()
    return str(own) if _has_files(own / 'nn' / 'nn_omograph') and not partial(own) else None


def _read_settings():
    try:
        d = json.loads(Path(model_dirs.SETTINGS_FILE).read_text(encoding='utf-8-sig'))
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def valid_ruaccent_name(name):
    """Имя папки модели: буквы, цифры, точка, дефис, подчёркивание (без путей и «..»)."""
    return (isinstance(name, str) and re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]{0,39}', name) is not None
            and '..' not in name)


def ruaccent_chosen():
    """Модель омографов, выбранная в окне RUAccent (settings.json); по умолчанию прежняя turbo."""
    v = _read_settings().get('ruaccent_model')
    return v if valid_ruaccent_name(v) else RUACCENT_SIZE


def ruaccent_use_dictionary():
    """Словарь ударений целиком (лучше качество, больше памяти). По умолчанию включён, как раньше."""
    v = _read_settings().get('ruaccent_dictionary', True)
    return v if isinstance(v, bool) else True


def ruaccent_tiny_mode():
    """Лёгкий режим tiny_mode (без правил и словаря, ради памяти). По умолчанию выключен."""
    v = _read_settings().get('ruaccent_tiny', False)
    return v if isinstance(v, bool) else False


def ruaccent_installed_models():
    """{модель: папка, где лежит}: что уже есть на диске (в папке моделей или внутри пакета ruaccent)."""
    own, pkg = ruaccent_places()
    found = {}
    for base in (own, pkg):
        if base is None or (base == own and partial(own)):
            continue
        root = Path(base) / 'nn' / 'nn_omograph'
        try:
            names = sorted(p.name for p in root.iterdir() if p.is_dir() and _has_files(p))
        except OSError:
            continue
        for name in names:
            found.setdefault(name, Path(base))
    return found


def ruaccent_effective():
    """Что на самом деле загрузить: (модель, workdir или None, заметка).
    Выбранная модель не скачана, а другая есть - работаем на имеющейся (прежняя turbo, иначе любая),
    чтобы программа запускалась; заметка говорит об этом."""
    own, _pkg = ruaccent_places()
    chosen, installed, note = ruaccent_chosen(), ruaccent_installed_models(), ''
    name = chosen
    if installed and chosen not in installed:
        name = RUACCENT_SIZE if RUACCENT_SIZE in installed else next(iter(installed))
        note = (f'выбранная модель ударений «{chosen}» не скачана, работает «{name}» '
                f'(⚙ → «Модели ударений RUAccent…»)')
    where = installed.get(name)
    workdir = str(own) if where is not None and Path(where) == Path(own) else None
    return name, workdir, note


def ruaccent_load_kwargs(accentizer=None):
    """Параметры для RUAccent.load: выбранная модель, словарь, при необходимости tiny_mode и workdir
    (если модели лежат в папке моделей). По умолчанию те же, что раньше: turbo и словарь целиком."""
    name, wd, _note = ruaccent_effective()
    kw = {'omograph_model_size': name, 'use_dictionary': ruaccent_use_dictionary()}
    if wd and (accentizer is None or _accepts(accentizer.load, 'workdir')):
        kw['workdir'] = wd
    if ruaccent_tiny_mode() and (accentizer is None or _accepts(accentizer.load, 'tiny_mode')):
        kw['tiny_mode'] = True
    return kw


def ruaccent_records():
    """{модель: {'remote_updated': дата на сервере при скачивании, 'downloaded': когда}}."""
    try:
        d = json.loads((Path(model_dirs.RUACCENT_DIR) / RUACCENT_RECORDS).read_text(encoding='utf-8'))
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def ruaccent_record(name, remote_updated):
    """Запомнить, что модель скачана (и какой датой помечена на сервере): по этому потом видно «есть обновление»."""
    import datetime
    d = ruaccent_records()
    d[name] = {'remote_updated': remote_updated or '',
               'downloaded': datetime.datetime.now().isoformat(timespec='seconds')}
    path = Path(model_dirs.RUACCENT_DIR) / RUACCENT_RECORDS
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding='utf-8')


def ruaccent_pkg_version():
    """Версия установленного пакета ruaccent или None."""
    try:
        import importlib.metadata as md
        importlib.invalidate_caches()
        return md.version(RUACCENT_PKG)
    except Exception:
        return None


def _http_json(url, timeout, opener=None):
    req = urllib.request.Request(url, headers={'User-Agent': 'BookVoice', 'Accept': 'application/json'})
    with (opener or urllib.request.urlopen)(req, timeout=timeout) as r:
        data = json.loads(r.read().decode('utf-8'))
        link = r.headers.get('Link') or ''
    m = re.search(r'<([^>]+)>\s*;\s*rel="next"', link)
    return data, (m.group(1) if m else None)


def ruaccent_sort_key(name):
    """Новые первыми: неизвестные заранее имена (возможно, новые модели) в самом верху, дальше по списку RUACCENT_MODELS."""
    order = list(RUACCENT_MODELS)
    return (1, order.index(name)) if name in order else (0, name)


def fetch_ruaccent_models(timeout=20, opener=None):
    """Какие модели омографов лежат на сервере: {имя: {'size': байт, 'updated': 'ГГГГ-ММ-ДД...'}}.
    Один небольшой запрос к huggingface.co (только чтение). Ошибка сети -> OSError, неожиданный ответ -> ValueError."""
    url = (f'https://huggingface.co/api/models/{RUACCENT_REPO}/tree/main/nn/nn_omograph'
           '?recursive=true&expand=true')
    models, pages = {}, 0
    while url and pages < 30:
        data, url = _http_json(url, timeout, opener)
        pages += 1
        if not isinstance(data, list):
            raise ValueError('сервер вернул не список файлов')
        for e in data:
            if not isinstance(e, dict) or e.get('type') != 'file':
                continue
            parts = str(e.get('path', '')).split('/')
            if len(parts) < 4 or parts[:2] != ['nn', 'nn_omograph'] or not valid_ruaccent_name(parts[2]):
                continue
            m = models.setdefault(parts[2], {'size': 0, 'updated': ''})
            m['size'] += int(e.get('size') or 0)
            date = str((e.get('lastCommit') or {}).get('date') or '')
            if date > m['updated']:
                m['updated'] = date
    if not models:
        raise ValueError('на сервере не нашлось ни одной модели омографов')
    return models


def fetch_ruaccent_pkg_latest(timeout=15, opener=None):
    """Последняя версия пакета ruaccent на PyPI или None, если узнать не удалось."""
    try:
        data, _ = _http_json(f'https://pypi.org/pypi/{RUACCENT_PKG}/json', timeout, opener)
        v = data['info']['version']
        return v if isinstance(v, str) and v else None
    except Exception:
        return None


def ruaccent_model_state(name, installed, remote=None, records=None):
    """missing - не скачана; installed - есть (сверить не с чем); current - актуальна; update - на сервере
    новее, чем при скачивании; unknown - есть, но дата скачивания не записана (скачана раньше)."""
    if name not in installed:
        return 'missing'
    cur = ((remote or {}).get(name) or {}).get('updated')
    if not cur:
        return 'installed'
    rec = ((records or {}).get(name) or {}).get('remote_updated')
    if not rec:
        return 'unknown'
    return 'update' if cur > rec else 'current'


def ruaccent_summary(remote, installed, records, chosen):
    """Итог проверки обновлений: (текст для человека, [модели, у которых есть обновление])."""
    updates = [n for n in installed if ruaccent_model_state(n, installed, remote, records) == 'update']
    fresh = [n for n in remote if n not in installed]
    unknown = [n for n in installed if ruaccent_model_state(n, installed, remote, records) == 'unknown']
    parts = []
    if updates:
        parts.append('Есть обновление у скачанных моделей: ' + ', '.join(sorted(updates, key=ruaccent_sort_key)) + '.')
    else:
        parts.append('Все скачанные модели актуальны.' if installed else 'Ни одна модель ещё не скачана.')
    if unknown:
        parts.append('Для ' + ', '.join(sorted(unknown, key=ruaccent_sort_key)) + ' дата скачивания не записана '
                     '(скачаны раньше): скачай заново, если хочешь быть уверен, что версия свежая.')
    if fresh:
        parts.append(f'Ещё не скачаны ({len(fresh)}): ' + ', '.join(sorted(fresh, key=ruaccent_sort_key)) + '.')
    if chosen not in remote:
        parts.append(f'Выбранной «{chosen}» нет на сервере.')
    return ' '.join(parts), sorted(updates, key=ruaccent_sort_key)


def _accepts(func, name):
    try:
        return name in inspect.signature(func).parameters
    except (TypeError, ValueError):
        return False


def console_python():
    """Python для дочерних процессов с выводом в канал: pythonw.exe (запуск без окна) заменяется на python.exe,
    у него есть настоящие stdout/stderr."""
    exe = Path(sys.executable)
    if exe.name.lower() == 'pythonw.exe':
        cand = exe.with_name('python.exe')
        if cand.is_file():
            return str(cand)
    return str(exe)


def shtorm_python():
    return Path(model_dirs.BASE) / 'venv_shtorm' / 'Scripts' / 'python.exe'


def voxcpm_python():
    return Path(model_dirs.BASE) / 'venv_voxcpm' / 'Scripts' / 'python.exe'


def voxcpm_package_dir():
    """Где лежит установленный пакет voxcpm (проверяем наличие папки, не запуская Python)."""
    return voxcpm_python().parent.parent / 'Lib' / 'site-packages' / 'voxcpm'


def local_ffmpeg():
    exe = Path(model_dirs.FFMPEG_DIR) / ('ffmpeg.exe' if os.name == 'nt' else 'ffmpeg')
    return exe if exe.is_file() else None


def ensure_ffmpeg_on_path():
    """ffmpeg из папки моделей добавляется в PATH процесса: программа вызывает просто «ffmpeg»."""
    if shutil.which('ffmpeg'):
        return True
    exe = local_ffmpeg()
    if exe:
        os.environ['PATH'] = str(exe.parent) + os.pathsep + os.environ.get('PATH', '')
        return True
    return False


def _status_silero():
    where = Path(model_dirs.SILERO_DIR)
    primary, fallback = model_dirs._model_file(), model_dirs._model_file(model_dirs.SILERO_FALLBACK)
    try:
        if primary.is_file() and primary.stat().st_size > 0:
            return Status(True, dir_size(where), str(where), f'модель {model_dirs.SILERO_MODEL}')
        if fallback.is_file() and fallback.stat().st_size > 0:
            return Status(False, dir_size(where), str(where),
                          f'есть только запасная {model_dirs.SILERO_FALLBACK}, {model_dirs.SILERO_MODEL} не скачана')
    except OSError:
        pass
    return Status(False, 0, str(where), 'не скачана')


def _status_ruaccent():
    own, pkg = ruaccent_places()
    name, _wd, note = ruaccent_effective()
    tail = f': {name}' if name != RUACCENT_SIZE or note else ''
    own_has = _has_files(own / 'nn' / 'nn_omograph' / name)
    if own_has and not partial(own):
        return Status(True, dir_size(own), str(own), 'в папке моделей' + tail + (f'; {note}' if note else ''))
    if pkg and _has_files(pkg / 'nn' / 'nn_omograph' / name):
        return Status(True, dir_size(pkg), str(pkg), 'в пакете ruaccent' + tail + (f'; {note}' if note else ''))
    if own_has or partial(own):
        return Status(False, dir_size(own), str(own), PARTIAL_NOTE)
    return Status(False, 0, str(own), 'не скачаны')


def _status_tera():
    d = Path(model_dirs.TERA_DIR)
    if partial(d):
        return Status(False, dir_size(d), str(d), PARTIAL_NOTE)
    if (d / 'config.json').is_file() and (d / 'styles').is_dir():
        return Status(True, dir_size(d), str(d), 'голоса на месте')
    return Status(False, dir_size(d) if d.is_dir() else 0, str(d), 'не скачана')


def _shtorm_variants(d):
    out = []
    for v in ('fast', 'slow'):
        if all((d / n).is_file() for n in (f'config_{v}.yaml', f'model_{v}.safetensors', 'tokenizer.model')):
            out.append(v)
    return out


def _status_shtorm():
    d = Path(model_dirs.SHTORM_DIR)
    variants, env = _shtorm_variants(d), shtorm_python().is_file()
    size = dir_size(d) if d.is_dir() else 0
    if partial(d):
        return Status(False, size, str(d), PARTIAL_NOTE)
    if variants and env:
        try:
            patched = all('hf://ArtShtorm/' not in (d / f'config_{v}.yaml').read_text(encoding='utf-8')
                          for v in variants)
        except OSError:
            patched = False
        if patched:
            return Status(True, size, str(d), 'варианты: ' + ', '.join(variants) + '; среда на месте')
        return Status(False, size, str(d), 'конфигурации не настроены на локальные файлы: скачай ещё раз')
    parts = []
    if not variants:
        parts.append('нет весов')
    if not env:
        parts.append('нет среды venv_shtorm')
    return Status(False, size, str(d), ', '.join(parts))


def _status_voxcpm():
    d = Path(model_dirs.VOXCPM_DIR)
    size = dir_size(d) if d.is_dir() else 0
    if partial(d):
        return Status(False, size, str(d), PARTIAL_NOTE)
    missing = [n for n in VOXCPM_FILES if not (d / n).is_file()]
    py = voxcpm_python()
    env = py.is_file() and voxcpm_package_dir().is_dir()
    if not missing and env:
        return Status(True, size, str(d), 'веса и среда на месте')
    parts = []
    if missing:
        parts.append('нет весов' if len(missing) == len(VOXCPM_FILES)
                     else 'не хватает файлов: ' + ', '.join(missing))
    if not env:
        parts.append('нет среды venv_voxcpm' if not py.is_file()
                     else 'в venv_voxcpm не установлен пакет voxcpm')
    return Status(False, size, str(d), ', '.join(parts))


def _status_ffmpeg():
    exe = local_ffmpeg()
    if exe:
        return Status(True, dir_size(exe), str(exe.parent), 'в папке моделей')
    found = shutil.which('ffmpeg')
    if found:
        return Status(True, 0, str(Path(found).parent), 'найден в системе (PATH)')
    return Status(False, 0, str(model_dirs.FFMPEG_DIR), 'не найден')


_STATUS = {'silero': _status_silero, 'ruaccent': _status_ruaccent, 'tera': _status_tera,
           'shtorm': _status_shtorm, 'voxcpm': _status_voxcpm, 'ffmpeg': _status_ffmpeg}


def status(cid):
    return _STATUS[cid]()


def statuses():
    return {cid: status(cid) for cid in COMPONENTS}


def missing_required():
    return [cid for cid in REQUIRED if not status(cid).ok]


def free_space(path):
    """Свободно байт на диске, где лежит (или будет лежать) путь; None, если узнать не удалось."""
    p = Path(path)
    while not p.exists() and p.parent != p:
        p = p.parent
    try:
        return shutil.disk_usage(p).free
    except OSError:
        return None


# ---------------------------------------------------------------- пакеты для переноса на другое устройство
def freeze_lines(text):
    """Строки pip freeze, пригодные для установки на другом компьютере: без путей и редактируемых
    установок, без локальной приставки версии (torch==2.5.1+cpu -> torch==2.5.1)."""
    out = []
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith(('#', '-')) or ' @ ' in line:
            continue
        out.append(re.sub(r'(==[^+\s;]+)\+[^\s;]+', r'\1', line))
    return out


def write_lockfile(path=None):
    """Точные версии пакетов этой среды -> requirements.lock.txt: start.bat на другом устройстве
    ставит именно их. Возвращает (путь, число пакетов)."""
    path = Path(path) if path else Path(model_dirs.BASE) / 'requirements.lock.txt'
    r = subprocess.run([console_python(), '-m', 'pip', 'freeze', '--disable-pip-version-check'],
                       capture_output=True, text=True, encoding='utf-8', errors='replace',
                       creationflags=NO_WINDOW)
    if r.returncode != 0:
        raise RuntimeError('pip freeze не сработал: ' + (r.stderr or r.stdout).strip()[:300])
    lines = freeze_lines(r.stdout)
    if not lines:
        raise RuntimeError('pip freeze вернул пустой список пакетов')
    path.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    return path, len(lines)


# ---------------------------------------------------------------- папка для другого компьютера
# Рабочая копия программы: только то, без чего она не запускается, и ничего лишнего (тесты, документация,
# старые bat-файлы и инструменты разработки остаются в основном проекте).
PORTABLE_CODE = ['app.py', 'bookio.py', 'bookexport.py', 'book.py', 'edit_tab.py', 'emphasis.py', 'homographs.py',
                 'punctuation_pauses.py', 'textmenu.py', 'speak.py', 'tera.py', 'shtorm.py', 'shtorm_worker.py',
                 'shtorm_vox.py', 'shtorm_vox_worker.py',
                 'model_dirs.py', 'model_manager.py', 'models_ui.py', 'ruaccent_ui.py', 'accent_pipeline.py', 'layoutmarks.py', 'audio_seams.py']
PORTABLE_EXTRA = ['start.bat', 'requirements.txt', 'README_ПЕРЕНОС.txt']
PORTABLE_DATA = ['словарь.txt', 'омографы.json']            # данные пользователя: копируются как есть, если есть


def portable_files():
    """Что кладётся в папку для другого компьютера: (обязательные, необязательные)."""
    return PORTABLE_CODE + PORTABLE_EXTRA, PORTABLE_DATA


def build_portable(target, lock=True, base=None):
    """Собрать папку для другого компьютера (на флешке, в сети): нужные файлы программы, ваш словарь,
    start.bat и точные версии пакетов (requirements.lock.txt) с этого компьютера. Модели не копируются:
    на новом месте их скачивает ⚙ → «Модели…». Возвращает (скопированные файлы, примечания)."""
    base = Path(base) if base else Path(model_dirs.BASE)
    target = Path(target)
    if model_dirs._nested(target, base):
        raise RuntimeError('Выбери папку вне папки программы (например, на флешке).')
    required, optional = portable_files()
    missing = [f for f in required if not (base / f).is_file()]
    if missing:
        raise RuntimeError('В папке программы не хватает файлов: ' + ', '.join(missing))
    target.mkdir(parents=True, exist_ok=True)
    copied, notes = [], []
    for name in required + optional:
        src = base / name
        if src.is_file():
            shutil.copy2(src, target / name)
            copied.append(name)
    (target / 'PYTHON_VERSION.txt').write_text(f'{sys.version_info[0]}.{sys.version_info[1]}\n', encoding='ascii')
    copied.append('PYTHON_VERSION.txt')
    if lock:
        try:
            path, n = write_lockfile(target / 'requirements.lock.txt')
            copied.append(path.name)
            notes.append(f'версии пакетов сохранены ({n} шт.), start.bat поставит именно их')
        except Exception as e:
            notes.append(f'версии пакетов сохранить не удалось ({e}); start.bat возьмёт requirements.txt')
    return copied, notes


# ---------------------------------------------------------------- запуск скачивания (в программе)
def job_command(cid):
    return [console_python(), '-u', str(Path(__file__).resolve()), 'job', cid]


def child_env(models_dir=None):
    """Окружение процесса скачивания: сеть разрешена, вывод в UTF-8 (иначе Windows читает канал
    в cp1251 и русский текст портится), та же папка моделей, что у программы."""
    env = os.environ.copy()
    for k in ('HF_HUB_OFFLINE', 'TRANSFORMERS_OFFLINE'):
        env.pop(k, None)
    env.update({'PYTHONUTF8': '1', 'PYTHONIOENCODING': 'utf-8', 'PYTHONUNBUFFERED': '1',
                'HF_HUB_DISABLE_PROGRESS_BARS': '1', 'PIP_DISABLE_PIP_VERSION_CHECK': '1',
                'PIP_PROGRESS_BAR': 'off', 'BOOKVOICE_MODELS_DIR': str(models_dir or model_dirs.MODELS_DIR)})
    return env


def parse_line(line):
    """Строка вывода процесса -> ('stage'|'total'|'watch'|'log', значение)."""
    line = line.rstrip('\r\n')
    if line.startswith('@@'):
        key, _, rest = line[2:].partition(' ')
        if key == 'total':
            try:
                return 'total', int(rest.strip())
            except ValueError:
                return 'log', line
        if key in ('stage', 'watch'):
            return key, rest.strip()
    return 'log', line


def kill_tree(proc):
    """Остановить процесс вместе с его дочерними (pip, git и т.п.)."""
    try:
        if os.name == 'nt':
            subprocess.run(['taskkill', '/PID', str(proc.pid), '/T', '/F'],
                           capture_output=True, creationflags=NO_WINDOW)
        else:
            proc.terminate()
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass


class Runner:
    """Скачивает компоненты по очереди в фоновом потоке и сообщает о ходе через on_event(событие):
      ('start', cid) ('stage', cid, текст) ('total', cid, байт) ('progress', cid, скачано, всего|None)
      ('log', cid, строка) ('end', cid, успех, сообщение) ('finished', [успешные], [неудачные], отменено)"""

    def __init__(self, on_event, command=None, env_factory=None, poll=1.0):
        self.on_event = on_event
        self.command = command or job_command
        self.env_factory = env_factory or child_env
        self.poll = poll
        self._thread = None
        self._proc = None
        self._cancel = threading.Event()
        self._lock = threading.Lock()

    def running(self):
        return self._thread is not None and self._thread.is_alive()

    def start(self, ids):
        with self._lock:
            if self.running():
                return False
            self._cancel.clear()
            self._thread = threading.Thread(target=self._run, args=(list(ids),), daemon=True)
            self._thread.start()
            return True

    def cancel(self):
        self._cancel.set()
        proc = self._proc
        if proc is not None and proc.poll() is None:
            kill_tree(proc)

    def join(self, timeout=None):
        if self._thread is not None:
            self._thread.join(timeout)

    def _emit(self, *event):
        try:
            self.on_event(event)
        except Exception:
            pass

    def _run(self, ids):
        done, failed = [], []
        for cid in ids:
            if self._cancel.is_set():
                break
            self._emit('start', cid)
            ok, message = self._run_one(cid)
            self._emit('end', cid, ok, message)
            (done if ok else failed).append(cid)
            if self._cancel.is_set():
                break
        self._emit('finished', done, failed, self._cancel.is_set())

    def _run_one(self, cid):
        try:
            proc = subprocess.Popen(self.command(cid), cwd=str(model_dirs.BASE), env=self.env_factory(),
                                    stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                    stderr=subprocess.STDOUT, text=True, encoding='utf-8',
                                    errors='replace', bufsize=1, creationflags=NO_WINDOW)
        except OSError as e:
            return False, f'не удалось запустить процесс скачивания: {e}'
        self._proc = proc
        if self._cancel.is_set():                 # «Остановить» нажали, пока процесс запускался
            kill_tree(proc)
        state = {'watch': None, 'total': None}
        stop = threading.Event()

        def poller():
            while not stop.wait(self.poll):
                if state['watch']:
                    self._emit('progress', cid, dir_size(state['watch']), state['total'])
        threading.Thread(target=poller, daemon=True).start()
        tail = []
        try:
            for line in proc.stdout:
                kind, value = parse_line(line)
                if kind == 'stage':
                    self._emit('stage', cid, value)
                elif kind == 'total':
                    state['total'] = value
                    self._emit('total', cid, value)
                elif kind == 'watch':
                    state['watch'] = value
                else:
                    if value.strip():
                        tail = (tail + [value.strip()])[-3:]
                    self._emit('log', cid, value)
            proc.wait()
        finally:
            stop.set()
            try:
                proc.stdout.close()
            except Exception:
                pass
            self._proc = None
        if self._cancel.is_set():
            return False, 'остановлено'
        if proc.returncode == 0:
            if state['watch'] and state['total']:
                self._emit('progress', cid, state['total'], state['total'])
            return True, 'готово'
        return False, (tail[-1] if tail else f'процесс завершился с кодом {proc.returncode}')


# ---------------------------------------------------------------- сами скачивания (в отдельном процессе)
def _stage(text):
    print('@@stage ' + text, flush=True)


def _watch(path):
    print('@@watch ' + str(path), flush=True)


def _total(n):
    if n and n > 0:
        print('@@total %d' % n, flush=True)


def _run(cmd):
    """Внешняя команда: её вывод идёт в журнал; ненулевой код -> ошибка."""
    print('> ' + ' '.join(str(c) for c in cmd), flush=True)
    r = subprocess.run([str(c) for c in cmd], stdin=subprocess.DEVNULL, creationflags=NO_WINDOW)
    if r.returncode != 0:
        raise RuntimeError(f'команда завершилась с кодом {r.returncode}: {" ".join(str(c) for c in cmd[:5])}')


def _old_hub():
    """huggingface_hub старше 0.23 при скачивании в папку оставляет большие файлы в общем кэше
    на диске C: (в папке лежат лишь ссылки на них); таким версиям ссылки запрещаем."""
    import huggingface_hub
    try:
        major, minor = (int(x) for x in huggingface_hub.__version__.split('.')[:2])
    except ValueError:
        return False
    return (major, minor) < (0, 23)


def _hf_total(repo, patterns=None):
    """Сколько всего байт в репозитории (по списку файлов на сервере); 0, если узнать не удалось."""
    try:
        from huggingface_hub import HfApi
        info = HfApi().model_info(repo, files_metadata=True)
        return sum((s.size or 0) for s in (info.siblings or [])
                   if patterns is None or any(fnmatch.fnmatch(s.rfilename, pat) for pat in patterns))
    except Exception as e:
        print(f'Объём заранее узнать не удалось ({type(e).__name__}), ход будет без процентов.', flush=True)
        return 0


def _hf_download(repo, target, patterns=None):
    from huggingface_hub import snapshot_download
    target = Path(target)
    target.mkdir(parents=True, exist_ok=True)
    _total(_hf_total(repo, patterns))
    _watch(target)
    kw = {'local_dir_use_symlinks': False} if _old_hub() else {}
    if patterns:
        kw['allow_patterns'] = patterns
    return snapshot_download(repo, local_dir=str(target), **kw)


def job_silero(update=False):
    problems = model_dirs.apply()
    for p in problems:
        print('ВНИМАНИЕ:', p, flush=True)
    _watch(model_dirs.SILERO_DIR)
    import torch
    names = [model_dirs.SILERO_MODEL]
    if model_dirs.SILERO_FALLBACK not in names:
        names.append(model_dirs.SILERO_FALLBACK)
    last = None
    for i, name in enumerate(names):
        _stage(f'Silero {name}: ' + ('обновляю репозиторий и скачиваю модель' if update else 'скачиваю репозиторий и модель'))
        try:
            torch.hub.load(repo_or_dir='snakers4/silero-models', model='silero_tts', language='ru',
                           speaker=name, force_reload=bool(update and i == 0))
            print(f'Готово: Silero {name}', flush=True)
            return
        except Exception as e:
            last = e
            print(f'Silero {name} не скачалась: {type(e).__name__}: {str(e)[:200]}', flush=True)
    raise last


def _ruaccent_drop_incomplete(wd):
    """RUAccent считает папки dictionary и nn готовыми, как только они появились. После оборванной загрузки
    в них не хватает файлов, а докачивать он не станет и потом не запустится, поэтому неполные папки
    (только в нашей папке моделей) убираем: скачаются заново."""
    if not partial(wd):
        return False
    for name in ('dictionary', 'nn'):
        shutil.rmtree(wd / name, ignore_errors=True)
    print('Прошлая загрузка ударений оборвалась: убираю неполные файлы и качаю заново.', flush=True)
    return True


def _ruaccent_fetch_model(wd, name):
    """Скачать общие файлы RUAccent (словари, вспомогательные сети) и ОДНУ модель омографов, а не весь
    репозиторий со всеми моделями. True - сделано; False - список файлов получить не удалось, дальше
    скачает сам RUAccent. Нет такой модели на сервере - исключение."""
    try:
        from huggingface_hub import HfApi
        files = HfApi().list_repo_files(RUACCENT_REPO)
    except Exception as e:
        print(f'Список файлов получить не удалось ({type(e).__name__}); скачает сам RUAccent.', flush=True)
        return False
    prefix = 'nn/nn_omograph/'
    mine = f'{prefix}{name}/'
    if not any(f.startswith(mine) for f in files):
        known = sorted({f[len(prefix):].split('/')[0] for f in files if f.startswith(prefix) and f.count('/') >= 3},
                       key=ruaccent_sort_key)
        raise RuntimeError(f'на сервере нет модели «{name}». Есть: {", ".join(known) or "список пуст"}')
    patterns = [f for f in files if not f.startswith(prefix) and not f.endswith(('.md', '.gitattributes'))]
    patterns.append(mine + '*')
    _stage(f'RUAccent: скачиваю модель «{name}» и общие файлы (одну модель, не весь репозиторий)')
    with in_progress(wd):
        _hf_download(RUACCENT_REPO, wd, patterns)
    return True


def job_ruaccent(model=None):
    """Скачать модель ударений (по умолчанию выбранную в окне RUAccent) и проверить, что она загружается."""
    model_dirs.apply()
    from ruaccent import RUAccent
    name = model or ruaccent_chosen()
    if not valid_ruaccent_name(name):
        raise RuntimeError(f'недопустимое имя модели: {name!r}')
    acc = RUAccent()
    kw = {'omograph_model_size': name, 'use_dictionary': ruaccent_use_dictionary()}
    wd = None
    if _accepts(acc.load, 'workdir'):
        wd = Path(model_dirs.RUACCENT_DIR)
        wd.mkdir(parents=True, exist_ok=True)
        kw['workdir'] = str(wd)
        _watch(wd)
        _ruaccent_drop_incomplete(wd)
        _ruaccent_fetch_model(wd, name)
    else:
        print('Эта версия RUAccent не умеет скачивать в выбранную папку: модели лягут в пакет ruaccent.',
              flush=True)
        pkg = ruaccent_module_dir()
        if pkg:
            _watch(pkg)
    _stage(f'RUAccent: проверяю загрузку модели «{name}» (первый раз это несколько минут)')
    if wd is None:
        acc.load(**kw)
    else:
        with in_progress(wd):
            acc.load(**kw)
    try:
        print('Проба:', acc.process_all('на двери висит замок.'), flush=True)
    except Exception as e:
        raise RuntimeError(f'модель «{name}» загрузилась, но не работает: {type(e).__name__}: {e}. '
                           'Возможно, пакет ruaccent староват для неё: нажми «Обновить пакет ruaccent».')
    if wd is not None:
        try:
            remote = fetch_ruaccent_models(timeout=15)
            ruaccent_record(name, (remote.get(name) or {}).get('updated'))
        except Exception as e:
            print(f'Дату версии записать не удалось ({type(e).__name__}): это не мешает работе.', flush=True)
            ruaccent_record(name, '')
    print(f'Готово: RUAccent, модель {name}', flush=True)


def job_ruaccent_pkg():
    """Обновить пакет ruaccent через pip (новые модели часто требуют свежий код)."""
    before = ruaccent_pkg_version()
    _stage('RUAccent: обновляю пакет ruaccent (pip)')
    _run([sys.executable, '-m', 'pip', 'install', '--upgrade', '--disable-pip-version-check',
          '--progress-bar', 'off', RUACCENT_PKG])
    after = ruaccent_pkg_version()
    if before == after:
        print(f'Пакет ruaccent уже последней версии: {after}', flush=True)
    else:
        print(f'Пакет ruaccent: {before or "не было"} -> {after or "?"}. Перезапусти программу, чтобы он заработал.',
              flush=True)


TERA_PACKAGES = (('transformers', 'transformers>=4.40'), ('onnxruntime', 'onnxruntime'))


def job_tera():
    model_dirs.apply()
    need = [spec for mod, spec in TERA_PACKAGES if importlib.util.find_spec(mod) is None]
    if need:
        _stage('TeraTTS v2: ставлю пакеты ' + ', '.join(need))
        _run([sys.executable, '-m', 'pip', 'install', '--disable-pip-version-check', '--progress-bar', 'off', *need])
    _stage('TeraTTS v2: скачиваю модель (около 1,2 ГБ; если оборвётся, запусти ещё раз: докачает)')
    d = Path(model_dirs.TERA_DIR)
    with in_progress(d):
        path = _hf_download(TERA_REPO, d)
        if not ((d / 'config.json').is_file() and (d / 'styles').is_dir()):
            raise RuntimeError(f'в {d} после скачивания нет config.json или папки styles')
    print('Скачано в', path, flush=True)


# Строка конфигурации вида «ключ: путь/к/model_fast.safetensors» с абсолютным путём (после прошлой настройки
# или после копирования папки моделей с другого компьютера): путь переписывается на нынешнюю папку.
# Ссылки hf:// на чужие репозитории (например, hf://kyutai/...) не трогаем.
_SHTORM_LOCAL_REF = re.compile(
    r'(?P<head>:[ \t]+)(?P<q>["\']?)'
    r'(?P<dir>(?:[A-Za-z]:[\\/]|[\\/])(?:[^"\'\r\n]*?[\\/])?)'
    r'(?P<name>model_fast\.safetensors|model_slow\.safetensors|tokenizer\.model)(?P=q)[ \t]*$', re.M)


def patch_shtorm_configs(target, strict=True):
    """Конфигурации репозитория указывают на hf:// URL; переписываем их на локальные файлы, иначе запуск
    без сети попробует обратиться к серверу. Повторный вызов безопасен и чинит пути, которые остались от
    другой папки (модели скопировали с другого компьютера или поменяли папку моделей).
    Возвращает список изменённых файлов; strict=False не ругается на неготовые конфигурации."""
    target = Path(target)
    prefix = target.resolve().as_posix().rstrip('/') + '/'
    changed = []
    for name in ('config.yaml', 'config_fast.yaml', 'config_slow.yaml'):
        cfg = target / name
        if not cfg.is_file():
            continue
        content = old = cfg.read_text(encoding='utf-8')
        for f in SHTORM_REFS:
            content = content.replace(f'hf://{SHTORM_REPO}/{f}', prefix + f)
        content = _SHTORM_LOCAL_REF.sub(
            lambda m: m.group('head') + m.group('q') + prefix + m.group('name') + m.group('q'), content)
        if content != old:
            cfg.write_text(content, encoding='utf-8')
            changed.append(name)
    if strict:
        for name in ('config_fast.yaml', 'config_slow.yaml'):
            if f'hf://{SHTORM_REPO}/' in (target / name).read_text(encoding='utf-8'):
                raise RuntimeError(f'не удалось перевести {name} в локальный режим')
    return changed


def job_shtorm():
    model_dirs.apply()
    py = shtorm_python()
    with in_progress(model_dirs.SHTORM_DIR):
        if not py.is_file():
            _stage('Shtorm: создаю отдельную среду Python (venv_shtorm)')
            _run([sys.executable, '-m', 'venv', py.parent.parent])
        _stage('Shtorm: ставлю Pocket-TTS в отдельную среду (несколько минут, нужен интернет)')
        _run([py, '-m', 'pip', 'install', '--disable-pip-version-check', '--progress-bar', 'off', POCKET_TTS_SPEC])
        _stage('Shtorm: скачиваю веса fast и slow')
        _hf_download(SHTORM_REPO, model_dirs.SHTORM_DIR, SHTORM_FILES)
        patch_shtorm_configs(model_dirs.SHTORM_DIR)
        missing = [n for n in ('config_fast.yaml', 'config_slow.yaml', *SHTORM_REFS)
                   if not (Path(model_dirs.SHTORM_DIR) / n).is_file()]
        if missing:
            raise RuntimeError('после скачивания не хватает файлов: ' + ', '.join(missing))
    print('Готово: Shtorm. Дальше выбери Shtorm в программе и укажи WAV-образец голоса.', flush=True)

def voxcpm_base_python(version=None):
    """Python, которым создаётся venv_voxcpm. VoxCPM2 работает на Python 3.10–3.12 (3.13 пока не поддержан):
    если основная среда новее, ищем подходящий через «py -3.12 / -3.11 / -3.10»."""
    version = tuple(version or sys.version_info[:2])
    lo, hi = VOXCPM_PY_RANGE
    if lo <= version <= hi:
        return console_python()
    if _is_windows():
        for ver in ('3.12', '3.11', '3.10'):
            try:
                r = subprocess.run(['py', f'-{ver}', '-c', 'import sys; print(sys.executable)'],
                                   capture_output=True, text=True, encoding='utf-8', errors='replace',
                                   creationflags=NO_WINDOW)
            except OSError:
                break
            if r.returncode == 0 and r.stdout.strip():
                return r.stdout.strip().splitlines()[-1]
    raise RuntimeError('Для Shtorm-VoxCPM2-RU нужен Python 3.10, 3.11 или 3.12, а у BookVoice '
                       f'Python {version[0]}.{version[1]}. Установи Python 3.12 '
                       '(python.org, галочка «py launcher») и повтори скачивание.')


def voxcpm_torch_args():
    """Аргументы pip для установки torch с поддержкой видеокарты. Берём ту же версию и тот же CUDA, что в
    основной среде BookVoice (если там torch с CUDA и не старше 2.5); иначе свежий torch с CUDA 12.4.
    Обычный «pip install torch» на Windows ставит версию без видеокарты: модель на процессоре непригодна."""
    tag, version = VOXCPM_TORCH_FALLBACK, None
    try:
        import torch
        m = re.match(r'^(\d+)\.(\d+)\.(\d+)\+(cu\d+)$', str(torch.__version__))
        if m and (int(m.group(1)), int(m.group(2))) >= VOXCPM_MIN_TORCH:
            version, tag = f'{m.group(1)}.{m.group(2)}.{m.group(3)}', m.group(4)
    except Exception:
        pass
    pins = [f'torch=={version}', f'torchaudio=={version}'] if version else ['torch', 'torchaudio']
    return pins + ['--index-url', VOXCPM_TORCH_INDEX + tag]


def job_voxcpm():
    model_dirs.apply()
    py = voxcpm_python()
    with in_progress(model_dirs.VOXCPM_DIR):
        if not py.is_file():
            base = voxcpm_base_python()
            _stage('Shtorm-VoxCPM2-RU: создаю отдельную среду Python (venv_voxcpm)')
            _run([base, '-m', 'venv', py.parent.parent])
        pip = [py, '-m', 'pip', 'install', '--disable-pip-version-check', '--progress-bar', 'off']
        _stage('Shtorm-VoxCPM2-RU: ставлю torch с поддержкой видеокарты (несколько ГБ, нужен интернет)')
        _run(pip + voxcpm_torch_args())
        _stage('Shtorm-VoxCPM2-RU: ставлю пакет voxcpm (несколько минут)')
        _run(pip + ['voxcpm'])
        _stage('Shtorm-VoxCPM2-RU: проверяю среду')
        r = subprocess.run([str(py), '-c', 'import torch, voxcpm; '
                            'print("torch", torch.__version__, "CUDA:", torch.cuda.is_available())'],
                           capture_output=True, text=True, encoding='utf-8', errors='replace',
                           cwd=str(py.parent), creationflags=NO_WINDOW)
        print((r.stdout or '').strip(), flush=True)
        if r.returncode != 0:
            raise RuntimeError('пакет voxcpm не импортируется: ' + (r.stderr or '').strip()[-500:])
        if 'CUDA: True' not in (r.stdout or ''):
            print('ВНИМАНИЕ: torch в venv_voxcpm не видит видеокарту. Установи драйвер NVIDIA (CUDA 12+) и '
                  'запусти скачивание ещё раз; на процессоре модель слишком медленная.', flush=True)
        _stage('Shtorm-VoxCPM2-RU: скачиваю веса (около 5 ГБ; если оборвётся, запусти ещё раз: докачает)')
        _hf_download(VOXCPM_REPO, model_dirs.VOXCPM_DIR, VOXCPM_FILES)
        missing = [n for n in VOXCPM_FILES if not (Path(model_dirs.VOXCPM_DIR) / n).is_file()]
        if missing:
            raise RuntimeError('после скачивания не хватает файлов: ' + ', '.join(missing))
    print('Готово: Shtorm-VoxCPM2-RU. Дальше выбери его в программе и укажи WAV-образец голоса.', flush=True)


def _verify_ffmpeg(exe):
    """ffmpeg запускается и умеет кодировать mp3 (libmp3lame)."""
    r = subprocess.run([str(exe), '-hide_banner', '-encoders'], capture_output=True, text=True,
                       encoding='utf-8', errors='replace', creationflags=NO_WINDOW)
    if r.returncode != 0 or 'libmp3lame' not in r.stdout:
        raise RuntimeError('скачанный ffmpeg не запускается или не умеет кодировать mp3')


def _is_windows():
    return os.name == 'nt'


def job_ffmpeg():
    if not _is_windows():
        raise RuntimeError('Автоматическая установка ffmpeg есть только для Windows: '
                           'поставь ffmpeg средствами системы.')
    dst = Path(model_dirs.FFMPEG_DIR)
    dst.mkdir(parents=True, exist_ok=True)
    arch = 'arm64' if platform.machine().lower() in ('arm64', 'aarch64') else 'amd64'
    part = dst / 'ffmpeg.zip.part'
    _stage('ffmpeg: скачиваю (около 150-200 МБ)')
    _watch(part)
    req = urllib.request.Request(FFMPEG_URLS[arch], headers={'User-Agent': 'BookVoice'})
    with urllib.request.urlopen(req, timeout=60) as r, open(part, 'wb') as f:
        try:
            _total(int(r.headers.get('Content-Length') or 0))
        except (TypeError, ValueError):
            pass
        shutil.copyfileobj(r, f, 1 << 20)
    _stage('ffmpeg: распаковываю')
    exe = dst / 'ffmpeg.exe'
    tmp = dst / 'ffmpeg.exe.new'
    with zipfile.ZipFile(part) as z:
        member = next((n for n in z.namelist() if n.replace('\\', '/').lower().endswith('/bin/ffmpeg.exe')), None)
        if member is None:
            raise RuntimeError('в архиве нет bin/ffmpeg.exe')
        with z.open(member) as src, open(tmp, 'wb') as out:
            shutil.copyfileobj(src, out, 1 << 20)
    os.replace(tmp, exe)
    part.unlink()
    _verify_ffmpeg(exe)
    print('Готово: ffmpeg', exe, flush=True)


JOBS = {'silero': job_silero, 'ruaccent': job_ruaccent, 'tera': job_tera, 'shtorm': job_shtorm,
        'voxcpm': job_voxcpm,
        'ffmpeg': job_ffmpeg, 'silero_update': lambda: job_silero(update=True),
        'ruaccent_pkg': job_ruaccent_pkg}


def job_title(cid):
    """Подпись задачи для окон: компоненты, «ruaccent:<модель>» и «ruaccent_pkg»."""
    if cid in TITLES:
        return TITLES[cid]
    if cid == 'ruaccent_pkg':
        return 'RUAccent: обновление пакета (pip)'
    if cid == 'silero_update':
        return 'Silero: обновление репозитория'
    if isinstance(cid, str) and cid.startswith('ruaccent:'):
        return f'RUAccent: модель {cid.split(":", 1)[1]}'
    return str(cid)


def run_job(cid):
    """Выполнить скачивание в этом процессе. 0 - успех."""
    import traceback
    model = cid.split(':', 1)[1] if cid.startswith('ruaccent:') else None
    if cid not in JOBS and not (model and valid_ruaccent_name(model)):
        print(f'Неизвестный компонент: {cid}', flush=True)
        return 2
    try:
        if model:
            job_ruaccent(model)
        else:
            JOBS[cid]()
        return 0
    except Exception as e:
        traceback.print_exc(file=sys.stdout)
        print(f'ОШИБКА: {type(e).__name__}: {e}', flush=True)
        return 1


def main(argv):
    cmd = argv[1] if len(argv) > 1 else 'status'
    if cmd == 'job' and len(argv) > 2:
        return run_job(argv[2])
    if cmd == 'status':
        for cid, st in statuses().items():
            print(f'{TITLES[cid]:<48} {"есть" if st.ok else "нет "}  {st.note}  [{st.where}]')
        return 0
    if cmd == 'portable' and len(argv) > 2:
        copied, notes = build_portable(argv[2])
        print('Скопировано:', ', '.join(copied))
        for n in notes:
            print(n)
        return 0
    print('Команды: status (по умолчанию), job <silero|ruaccent|ruaccent:<модель>|ruaccent_pkg|tera|shtorm|voxcpm|ffmpeg|silero_update>, '
          'portable <папка>')
    return 2


if __name__ == '__main__':
    sys.exit(main(sys.argv))
