"""Экспорт книги в EPUB 3 и MOBI 6, а также работа с изображениями внутри глав.

Модель книги (bookio.Book) дополнена полем images: [{'slot': k, 'data': bytes, 'name': str}].
slot = k значит «перед главой с номером k»; slot = len(chapters) - после последней главы.
Несколько картинок в одном слоте идут в порядке списка.

Зависимости: только стандартная библиотека. Pillow (он уже в requirements.txt) нужен для MOBI:
Kindle не умеет полупрозрачный PNG, поэтому там PNG переводится в GIF с прозрачностью.
В EPUB PNG кладётся как есть, полная альфа-прозрачность сохраняется.
"""
import datetime
import os
import random
import re
import struct
import tempfile
import time
import uuid
import zipfile
from io import BytesIO
from pathlib import Path
from xml.sax.saxutils import escape, quoteattr

_CTRL = re.compile(r'[\x00-\x08\x0b\x0c\x0e-\x1f]')
IMAGE_EXTS = ('.png', '.jpg', '.jpeg', '.gif')
MAX_IMAGE_BYTES = 25 * 1024 * 1024
MOBI_MAX_SIDE = 1600                  # длинная сторона картинки в MOBI, больше Kindle всё равно не нужно


def _x(s):
    return escape(_CTRL.sub('', s or ''))


# ---------------------------------------------------------------- картинки
def sniff_image(data):
    """('png'|'jpg'|'gif', mime) по первым байтам; ValueError, если это не png/jpeg/gif."""
    if data[:8] == b'\x89PNG\r\n\x1a\n':
        return 'png', 'image/png'
    if data[:3] == b'\xff\xd8\xff':
        return 'jpg', 'image/jpeg'
    if data[:6] in (b'GIF87a', b'GIF89a'):
        return 'gif', 'image/gif'
    raise ValueError('Поддерживаются картинки PNG, JPEG и GIF.')


def check_image(data, name='картинка'):
    """Проверить картинку целиком и вернуть сведения о ней: {'ext','mime','width','height','alpha'}.
    ValueError с понятным текстом, если файл пуст, слишком велик, это не картинка или он повреждён."""
    if not data:
        raise ValueError(f'«{name}»: файл пуст.')
    if len(data) > MAX_IMAGE_BYTES:
        raise ValueError(f'«{name}»: файл больше {MAX_IMAGE_BYTES // 1024 // 1024} МБ.')
    try:
        ext, mime = sniff_image(data)
    except ValueError:
        raise ValueError(f'«{name}»: это не PNG, JPEG или GIF.') from None
    try:
        from PIL import Image
        with Image.open(BytesIO(data)) as im:
            im.load()                                    # verify() ловит не всё, load() декодирует пиксели
            alpha = im.mode in ('RGBA', 'LA', 'PA') or 'transparency' in im.info
            return {'ext': ext, 'mime': mime, 'width': im.width, 'height': im.height, 'alpha': bool(alpha)}
    except ImportError:
        return {'ext': ext, 'mime': mime, 'width': 0, 'height': 0, 'alpha': ext == 'png'}
    except Exception as e:
        raise ValueError(f'«{name}»: файл повреждён ({type(e).__name__}).') from None


def _mobi_image(data, max_side=MOBI_MAX_SIDE):
    """Картинка в вид, который понимает Kindle: JPEG или GIF.
    PNG без прозрачности -> JPEG; PNG и GIF с прозрачностью -> GIF (прозрачность 1-битная: пиксели с альфой
    меньше половины становятся прозрачными, остальные заливаются на белый). Слишком большие уменьшаются."""
    ext, _ = sniff_image(data)
    from PIL import Image
    with Image.open(BytesIO(data)) as src:
        src.load()
        animated = getattr(src, 'n_frames', 1) > 1
        has_alpha = src.mode in ('RGBA', 'LA', 'PA') or 'transparency' in src.info
        big = max(src.size) > max_side
        im = src.convert('RGBA')
    out = BytesIO()
    if not has_alpha and not big and (ext == 'jpg' or (ext == 'gif' and not animated)):
        return data, ext                                  # уже подходит, не перекодируем
    if big:
        im.thumbnail((max_side, max_side), Image.LANCZOS)
    alpha = im.getchannel('A')
    if has_alpha and alpha.getextrema()[0] < 255:
        flat = Image.alpha_composite(Image.new('RGBA', im.size, (255, 255, 255, 255)), im).convert('RGB')
        pal = flat.quantize(colors=255, method=getattr(getattr(Image, 'Quantize', Image), 'MEDIANCUT'),
                            dither=getattr(getattr(Image, 'Dither', Image), 'NONE'))   # имена зависят от версии Pillow
        pal.paste(255, mask=alpha.point(lambda a: 255 if a < 128 else 0))
        pal.save(out, 'GIF', transparency=255)
        return out.getvalue(), 'gif'
    im.convert('RGB').save(out, 'JPEG', quality=90, optimize=True)
    return out.getvalue(), 'jpg'


def _thumbnail(data, side=330):
    from PIL import Image
    with Image.open(BytesIO(data)) as src:
        im = src.convert('RGB')
    im.thumbnail((side, side), Image.LANCZOS)
    out = BytesIO()
    im.save(out, 'JPEG', quality=85)
    return out.getvalue()


def images_by_slot(book):
    """{индекс главы: [изображения]} с учётом границ; slot == число глав — хвост книги."""
    n = len(book.chapters)
    out = {}
    for img in getattr(book, 'images', None) or []:
        slot = min(max(int(img.get('slot', n)), 0), n)
        out.setdefault(slot, []).append(img)
    return out


def _sequence(book):
    """Последовательность для экспорта: изображения главы перед её блоком (экспорт вкладывает их в главу)."""
    slots = images_by_slot(book)
    seq = []
    for i, (title, paras) in enumerate(book.chapters):
        seq += [('image', im) for im in slots.get(i, [])]
        seq.append(('chapter', i, title, paras))
    seq += [('image', im) for im in slots.get(len(book.chapters), [])]
    return seq


def _alt(img, n):
    name = re.sub(r'\.[A-Za-z0-9]{2,4}$', '', (img.get('name') or '').strip())
    return name or f'Иллюстрация {n}'


def _lang(book):
    lang = (getattr(book, 'lang', '') or 'ru').strip()
    return lang if re.fullmatch(r'[A-Za-z]{2,3}(-[A-Za-z0-9]{1,8})*', lang) else 'ru'


def _atomic_write(path, data, check=None):
    """Записать файл целиком или не трогать прежний: временный файл рядом, проверка, замена."""
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=target.name + '.', suffix='.tmp', dir=str(target.parent))
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        if check:
            check(tmp)
        os.replace(tmp, target)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


# ---------------------------------------------------------------- EPUB
_CSS = """body { font-family: serif; line-height: 1.4; margin: 0 4%; }
h1, h2 { text-align: center; font-weight: bold; page-break-after: avoid; }
h1 { font-size: 1.6em; margin: 2em 0 1em; }
h2 { font-size: 1.3em; margin: 1.5em 0 1em; }
p { margin: 0; text-indent: 1.4em; text-align: justify; }
p.author, p.plain { text-indent: 0; text-align: center; }
div.pic { text-align: center; margin: 0; padding: 0; page-break-before: always; page-break-after: always; }
div.pic img { max-width: 100%; max-height: 95vh; height: auto; }
div.cover { text-align: center; }
div.cover img { max-width: 100%; max-height: 80vh; height: auto; }
nav ol { list-style-type: none; padding-left: 0; }
nav li { margin: 0.4em 0; }
"""


def _xhtml(lang, title, body, extra_head=''):
    return ('<?xml version="1.0" encoding="utf-8"?>\n<!DOCTYPE html>\n'
            f'<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops" '
            f'lang="{_x(lang)}" xml:lang="{_x(lang)}">\n<head><meta charset="utf-8"/>'
            f'<title>{_x(title)}</title><link rel="stylesheet" type="text/css" href="style.css"/>{extra_head}'
            f'</head>\n<body>\n{body}\n</body>\n</html>\n')


def build_epub(book, titlepage=True, toc=True):
    """EPUB 3 (с toc.ncx для старых читалок) целиком в памяти, bytes."""
    lang = _lang(book)
    title = (book.title or '').strip() or 'Без названия'
    author = (book.author or '').strip()
    uid = f'urn:uuid:{uuid.uuid4()}'
    files = {}                     # путь внутри OEBPS -> bytes
    manifest = []                  # (id, href, mime, properties)
    spine = []                     # (idref, linear)
    toc_entries = []               # (название, href)

    files['style.css'] = _CSS.encode('utf-8')
    manifest.append(('css', 'style.css', 'text/css', ''))

    cover_href = None
    if book.cover:
        ext, mime = sniff_image(book.cover)
        cover_href = f'images/cover.{ext}'
        files[cover_href] = book.cover
        manifest.append(('cover-image', cover_href, mime, 'cover-image'))

    if titlepage and (book.cover or title or author):
        body = '<div class="cover">'
        if cover_href:
            body += f'<img src="{cover_href}" alt="Обложка"/>'
        body += '</div>\n'
        if book.title:
            body += f'<h1>{_x(title)}</h1>\n'
        if author:
            body += f'<p class="author">{_x(author)}</p>'
        files['title.xhtml'] = _xhtml(lang, title, body).encode('utf-8')
        manifest.append(('titlepage', 'title.xhtml', 'application/xhtml+xml', ''))
        spine.append(('titlepage', True))

    chapter_no = img_no = 0
    pending_images = []
    for block in _sequence(book):
        if block[0] == 'image':
            pending_images.append(block[1])
            continue
        _, _i, ctitle, paras = block
        chapter_no += 1
        page = f'ch{chapter_no:03d}.xhtml'
        image_html = []
        for img in pending_images:
            img_no += 1
            ext, mime = sniff_image(img['data'])
            href = f'images/img{img_no:03d}.{ext}'
            files[href] = img['data']
            image_html.append(f'<div class="chapter-image"><img src="{href}" alt={quoteattr(_alt(img, img_no))}/></div>')
            manifest.append((f'img{img_no:03d}', href, mime, ''))
        pending_images = []
        body = f'<h2>{_x(ctitle)}</h2>\n' + '\n'.join(image_html + [f'<p>{_x(p)}</p>' for p in paras])
        files[page] = _xhtml(lang, ctitle, body).encode('utf-8')
        manifest.append((f'ch{chapter_no:03d}', page, 'application/xhtml+xml', ''))
        spine.append((f'ch{chapter_no:03d}', True))
        toc_entries.append((ctitle, page))
    # Изображения в конце книги (не привязанные к главе) сохраняем отдельными страницами.
    for img in pending_images:
        img_no += 1
        ext, mime = sniff_image(img['data'])
        href = f'images/img{img_no:03d}.{ext}'
        page = f'pic{img_no:03d}.xhtml'
        files[href] = img['data']
        body = f'<div class="pic"><img src="{href}" alt={quoteattr(_alt(img, img_no))}/></div>'
        files[page] = _xhtml(lang, _alt(img, img_no), body).encode('utf-8')
        manifest.append((f'img{img_no:03d}', href, mime, ''))
        manifest.append((f'pic{img_no:03d}', page, 'application/xhtml+xml', ''))
        spine.append((f'pic{img_no:03d}', True))

    # навигация: nav.xhtml обязателен в EPUB 3; в порядок чтения он попадает, только если нужно «Содержание»
    items = ''.join(f'<li><a href="{_x(h)}">{_x(t)}</a></li>\n' for t, h in toc_entries)
    nav_body = (f'<nav epub:type="toc" id="toc"><h1>Содержание</h1>\n<ol>\n{items}</ol></nav>')
    files['nav.xhtml'] = _xhtml(lang, 'Содержание', nav_body).encode('utf-8')
    manifest.append(('nav', 'nav.xhtml', 'application/xhtml+xml', 'nav'))
    if toc and toc_entries:
        spine.insert(1 if spine and spine[0][0] == 'titlepage' else 0, ('nav', True))

    points = ''.join(
        f'<navPoint id="np{n}" playOrder="{n}"><navLabel><text>{_x(t)}</text></navLabel>'
        f'<content src="{_x(h)}"/></navPoint>\n' for n, (t, h) in enumerate(toc_entries, 1))
    files['toc.ncx'] = ('<?xml version="1.0" encoding="utf-8"?>\n'
                        '<ncx xmlns="http://www.daisy.org/z3986/2005/ncx/" version="2005-1">\n'
                        f'<head><meta name="dtb:uid" content="{uid}"/><meta name="dtb:depth" content="1"/>'
                        '<meta name="dtb:totalPageCount" content="0"/><meta name="dtb:maxPageNumber" content="0"/></head>\n'
                        f'<docTitle><text>{_x(title)}</text></docTitle>\n<navMap>\n{points}</navMap>\n</ncx>\n'
                        ).encode('utf-8')
    manifest.append(('ncx', 'toc.ncx', 'application/x-dtbncx+xml', ''))

    modified = datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
    meta = [f'<dc:identifier id="bookid">{uid}</dc:identifier>',
            f'<dc:title>{_x(title)}</dc:title>',
            f'<dc:language>{_x(lang)}</dc:language>']
    if author:
        meta.append(f'<dc:creator>{_x(author)}</dc:creator>')
    meta.append(f'<meta property="dcterms:modified">{modified}</meta>')
    if cover_href:
        meta.append('<meta name="cover" content="cover-image"/>')
    man = '\n'.join(
        f'<item id="{i}" href="{_x(h)}" media-type="{m}"' + (f' properties="{p}"' if p else '') + '/>'
        for i, h, m, p in manifest)
    sp = '\n'.join(f'<itemref idref="{i}"/>' for i, _ in spine)
    files['content.opf'] = ('<?xml version="1.0" encoding="utf-8"?>\n'
                            f'<package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="bookid" '
                            f'xml:lang="{_x(lang)}">\n'
                            f'<metadata xmlns:dc="http://purl.org/dc/elements/1.1/">\n' + '\n'.join(meta) +
                            f'\n</metadata>\n<manifest>\n{man}\n</manifest>\n<spine toc="ncx">\n{sp}\n</spine>\n'
                            '</package>\n').encode('utf-8')

    out = BytesIO()
    with zipfile.ZipFile(out, 'w') as z:
        z.writestr(zipfile.ZipInfo('mimetype', (1980, 1, 1, 0, 0, 0)), b'application/epub+zip',
                   compress_type=zipfile.ZIP_STORED)                 # первым и без сжатия, как требует стандарт
        z.writestr('META-INF/container.xml',
                   '<?xml version="1.0" encoding="utf-8"?>\n'
                   '<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container">\n'
                   '<rootfiles><rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/>'
                   '</rootfiles>\n</container>\n', compress_type=zipfile.ZIP_DEFLATED)
        for name, data in files.items():
            comp = zipfile.ZIP_STORED if name.rsplit('.', 1)[-1] in ('png', 'jpg', 'gif') else zipfile.ZIP_DEFLATED
            z.writestr('OEBPS/' + name, data, compress_type=comp)
    return out.getvalue()


def _check_zip(path):
    with zipfile.ZipFile(path) as z:
        if z.testzip() is not None:
            raise ValueError('EPUB собрался с ошибкой архива.')


def write_epub(book, path, titlepage=True, toc=True, **_):
    _atomic_write(path, build_epub(book, titlepage=titlepage, toc=toc), check=_check_zip)


# ---------------------------------------------------------------- MOBI 6
_TRANSLIT = dict(zip('абвгдеёжзийклмнопрстуфхцчшщъыьэюя',
                     ['a', 'b', 'v', 'g', 'd', 'e', 'e', 'zh', 'z', 'i', 'y', 'k', 'l', 'm', 'n', 'o', 'p', 'r', 's',
                      't', 'u', 'f', 'h', 'ts', 'ch', 'sh', 'sch', '', 'y', '', 'e', 'yu', 'ya']))
_LOCALE = {'ru': 25, 'en': 9, 'uk': 34, 'de': 7, 'fr': 12, 'es': 10, 'it': 16, 'pl': 21, 'be': 35, 'cs': 5}
TEXT_RECORD = 4096
_EPOCH_1904 = 2082844800


def _palm_name(title):
    s = ''.join(_TRANSLIT.get(c.lower(), c) for c in title)
    s = re.sub(r'[^A-Za-z0-9._-]+', '_', s).strip('_')
    return (s or 'Book')[:31]


def _split_utf8(data, size=TEXT_RECORD):
    """Режем текст на записи по size байт, но не посреди многобайтного символа UTF-8."""
    parts, i = [], 0
    while i < len(data):
        j = min(i + size, len(data))
        while j < len(data) and (data[j] & 0xC0) == 0x80:
            j -= 1
        parts.append(data[i:j])
        i = j
    return parts


def _mobi_html(book, titlepage, toc, offsets, cover_rec, img_recs):
    """HTML-текст MOBI. offsets: номер главы -> байтовое смещение (для ссылок filepos); возвращает
    (bytes, новые offsets). Ссылки имеют фиксированную ширину (10 цифр), поэтому за два прохода всё сходится."""
    title = (book.title or '').strip() or 'Без названия'
    author = (book.author or '').strip()
    chapters = _sequence(book)
    parts, pos, found = [], 0, {}

    def add(s, mark=None):
        nonlocal pos
        if mark is not None:
            found[mark] = pos
        b = s.encode('utf-8')
        parts.append(b)
        pos += len(b)

    def fp(key):
        return f'{offsets.get(key, 0):010d}'

    guide = ''
    first_ch = next((b[1] for b in chapters if b[0] == 'chapter'), None)
    if toc and first_ch is not None:
        guide += f'<reference type="toc" title="Содержание" filepos={fp("toc")} />'
    if first_ch is not None:
        guide += f'<reference type="text" title="Начало" filepos={fp(("ch", first_ch))} />'
    add('<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>'
        f'<title>{_x(title)}</title>' + (f'<guide>{guide}</guide>' if guide else '') + '</head><body>\n')

    if titlepage and (cover_rec or book.title or author):
        add('<div align="center">')
        if cover_rec:
            add(f'<img recindex="{cover_rec:05d}" alt="Обложка"/>')
        if book.title:
            add(f'<h1>{_x(title)}</h1>')
        if author:
            add(f'<p align="center">{_x(author)}</p>')
        add('</div>\n<mbp:pagebreak/>\n')
    if toc and first_ch is not None:
        add('<h2 align="center">Содержание</h2>\n', mark='toc')
        for b in chapters:
            if b[0] == 'chapter':
                add(f'<p><a filepos={fp(("ch", b[1]))}>{_x(b[2])}</a></p>\n')
        add('<mbp:pagebreak/>\n')
    img_n = 0
    pending_images = []
    for b in chapters:
        if b[0] == 'image':
            img_n += 1
            pending_images.append((b[1], img_recs[img_n - 1], img_n))
        else:
            _, i, ctitle, paras = b
            add(f'<h2 align="center">{_x(ctitle)}</h2>\n', mark=('ch', i))
            for img, rec, number in pending_images:
                add(f'<div align="center"><img recindex="{rec:05d}" alt={quoteattr(_alt(img, number))}/>'
                    '</div>\n')
            pending_images = []
            add(''.join(f'<p>{_x(p)}</p>\n' for p in paras))
            add('<mbp:pagebreak/>\n')
    # Картинки после последней главы не имеют владельца и остаются в конце книги.
    for img, rec, number in pending_images:
        add(f'<div align="center"><img recindex="{rec:05d}" alt={quoteattr(_alt(img, number))}/>'
            '</div>\n<mbp:pagebreak/>\n')
    add('</body></html>')
    return b''.join(parts), found


def _exth(records):
    body = b''.join(struct.pack('>II', t, len(d) + 8) + d for t, d in records)
    raw = b'EXTH' + struct.pack('>II', 12 + len(body), len(records)) + body
    return raw + b'\0' * (-len(raw) % 4)


def build_mobi(book, titlepage=True, toc=True):
    """MOBI 6 (классический формат Kindle/Mobipocket), bytes. Текст без сжатия, UTF-8, оглавление ссылками."""
    title = (book.title or '').strip() or 'Без названия'
    author = (book.author or '').strip()
    lang = _lang(book)

    # картинки: [обложка, миниатюра] + изображения глав, каждая в JPEG или GIF
    image_recs, cover_rec = [], 0
    if book.cover:
        data, _ = _mobi_image(book.cover)
        image_recs += [data, _thumbnail(data)]
        cover_rec = 1
    content_recs = []                                   # номер записи (1-based среди картинок) для каждой картинки
    for block in _sequence(book):
        if block[0] == 'image':
            data, _ = _mobi_image(block[1]['data'])
            image_recs.append(data)
            content_recs.append(len(image_recs))

    offsets = {}
    for _ in range(2):                                  # проход 1 считает смещения, проход 2 вписывает их
        html, offsets_new = _mobi_html(book, titlepage, toc, offsets, cover_rec, content_recs)
        if offsets_new == offsets:
            break
        offsets = offsets_new
    else:
        raise RuntimeError('MOBI: не сошлись смещения глав.')
    text_records = _split_utf8(html)

    n_text = len(text_records)
    first_image = n_text + 1 if image_recs else 0xFFFFFFFF
    last_content = n_text + len(image_recs)
    flis_rec, fcis_rec = last_content + 1, last_content + 2
    first_non_book = n_text + 1

    exth_records = [(501, b'PDOC'), (503, title.encode('utf-8')), (524, lang.encode('ascii')),
                   (204, struct.pack('>I', 201)), (205, struct.pack('>I', 2)), (206, struct.pack('>I', 9)),
                   (207, struct.pack('>I', 0))]
    if author:
        exth_records.append((100, author.encode('utf-8')))
    if cover_rec:
        exth_records += [(201, struct.pack('>I', 0)), (202, struct.pack('>I', 1))]
    exth = _exth(sorted(exth_records))

    name = title.encode('utf-8')
    name_off = 16 + 232 + len(exth)
    h = bytearray(b'\xff' * 232)                        # заголовок MOBI с 0x10 до 0xF8, по умолчанию «нет»
    put = lambda off, fmt, *v: struct.pack_into('>' + fmt, h, off - 16, *v)
    put(0x10, '4s', b'MOBI'); put(0x14, 'I', 232); put(0x18, 'I', 2); put(0x1C, 'I', 65001)
    put(0x20, 'I', random.getrandbits(32)); put(0x24, 'I', 6)
    put(0x50, 'I', first_non_book); put(0x54, 'I', name_off); put(0x58, 'I', len(name))
    put(0x5C, 'I', _LOCALE.get(lang.split('-')[0].lower(), 0)); put(0x60, 'I', 0); put(0x64, 'I', 0)
    put(0x68, 'I', 6); put(0x6C, 'I', first_image)
    put(0x70, 'IIII', 0, 0, 0, 0); put(0x80, 'I', 0x50)
    h[0x84 - 16:0xA4 - 16] = b'\0' * 32
    put(0xA8, 'I', 0xFFFFFFFF); put(0xAC, 'III', 0, 0, 0)
    h[0xB8 - 16:0xC0 - 16] = b'\0' * 8
    put(0xC0, 'HH', 1, last_content); put(0xC4, 'I', 1)
    put(0xC8, 'IIII', fcis_rec, 1, flis_rec, 1)
    h[0xD8 - 16:0xE0 - 16] = b'\0' * 8
    put(0xE0, 'I', 0xFFFFFFFF); put(0xE4, 'I', 0); put(0xE8, 'I', 0xFFFFFFFF); put(0xEC, 'I', 0xFFFFFFFF)
    put(0xF0, 'I', 0); put(0xF4, 'I', 0xFFFFFFFF)       # без дополнительных данных в записях текста и без INDX
    palmdoc = struct.pack('>HHIHHHH', 1, 0, len(html), n_text, TEXT_RECORD, 0, 0)
    record0 = palmdoc + bytes(h) + exth + name + b'\0\0'
    record0 += b'\0' * (-len(record0) % 4)

    flis = b'FLIS\0\0\0\x08\0\x41\0\0\0\0\0\0\xff\xff\xff\xff\0\x01\0\x03\0\0\0\x03\0\0\0\x01\xff\xff\xff\xff'
    fcis = (b'FCIS\x00\x00\x00\x14\x00\x00\x00\x10\x00\x00\x00\x01\x00\x00\x00\x00' + struct.pack('>I', len(html)) +
            b'\x00\x00\x00\x00\x00\x00\x00\x20\x00\x00\x00\x08\x00\x01\x00\x01\x00\x00\x00\x00')
    records = [record0] + text_records + image_recs + [flis, fcis, b'\xe9\x8e\r\n']

    now = int(time.time()) + _EPOCH_1904
    header = struct.pack('>32sHH6I4s4sIIH', _palm_name(title).encode('ascii'), 0, 0, now, now, 0, 0, 0, 0,
                         b'BOOK', b'MOBI', 2 * len(records) - 1, 0, len(records))
    offset = len(header) + 8 * len(records) + 2
    lst = b''
    for i, rec in enumerate(records):
        lst += struct.pack('>I', offset) + bytes([0]) + struct.pack('>I', 2 * i)[1:]
        offset += len(rec)
    return header + lst + b'\0\0' + b''.join(records)


def _check_mobi(path):
    data = Path(path).read_bytes()
    n = struct.unpack('>H', data[76:78])[0]
    offs = [struct.unpack('>I', data[78 + 8 * i:82 + 8 * i])[0] for i in range(n)]
    if data[60:68] != b'BOOKMOBI' or offs != sorted(offs) or offs[-1] > len(data) or data[offs[0] + 16:offs[0] + 20] != b'MOBI':
        raise ValueError('MOBI собрался с ошибкой структуры.')


def write_mobi(book, path, titlepage=True, toc=True, **_):
    _atomic_write(path, build_mobi(book, titlepage=titlepage, toc=toc), check=_check_mobi)
