"""Меню ⚙ и окно «Модели»: папка моделей, скачивание Silero / ударений / TeraTTS / Shtorm / Shtorm-VoxCPM2 / ffmpeg,
отчёт, очистка старого кэша, список пакетов для переноса на другое устройство.

Сама логика лежит в model_manager.py и model_dirs.py; здесь только окна и вызовы. Скачивание идёт
отдельным процессом, окно показывает ход и умеет остановить его."""
import contextlib
import io
import os
import subprocess
import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

import model_dirs
import model_manager
from model_manager import COMPONENTS, REQUIRED, TITLES, APPROX, NOTES, job_title

TITLES = dict(TITLES, silero_update='Silero: обновление репозитория')


# ---------------------------------------------------------------- меню ⚙
def build_settings_menu(app, parent):
    """Кнопка ⚙ с выпадающим списком (ставится правее переключателя движков)."""
    btn = ttk.Menubutton(parent, text='⚙', width=3)
    menu = tk.Menu(btn, tearoff=0, bg=app.colors['PANEL'], fg=app.colors['FG'],
                   activebackground='#33364a', activeforeground=app.colors['ACCENT'],
                   font=('Segoe UI', 11), bd=0)
    menu.add_command(label='Модели: скачать и проверить…', command=app.open_models)
    menu.add_command(label='Модели ударений RUAccent…', command=app.open_ruaccent)
    menu.add_command(label='Папка моделей…', command=app.choose_models_dir)
    menu.add_command(label='Открыть папку моделей', command=lambda: open_path(model_dirs.MODELS_DIR))
    menu.add_command(label='Открыть папку программы', command=lambda: open_path(model_dirs.BASE))
    menu.add_separator()
    menu.add_command(label='Обновить Silero (новые версии модели)', command=app.update_silero)
    menu.add_command(label='Что где лежит (отчёт)', command=app.show_report)
    menu.add_command(label='Очистить старый кэш на диске C:…', command=app.clean_old_cache)
    menu.add_separator()
    menu.add_command(label='Собрать папку для другого компьютера…', command=app.build_portable)
    menu.add_command(label='Сохранить версии пакетов (requirements.lock.txt)', command=app.save_lockfile)
    btn['menu'] = menu
    return btn, menu


def open_path(path):
    """Открыть папку в Проводнике (создаёт её, если папки моделей ещё нет)."""
    p = str(path)
    try:
        Path(p).mkdir(parents=True, exist_ok=True)
    except OSError:
        pass
    try:
        if os.name == 'nt':
            os.startfile(p)
        elif sys.platform == 'darwin':
            subprocess.Popen(['open', p])
        else:
            subprocess.Popen(['xdg-open', p])
    except Exception as e:
        messagebox.showerror('Папка', f'Не удалось открыть {p}:\n{e}')


def choose_models_dir(app):
    """Выбрать папку моделей и запомнить её. True, если папка поменялась."""
    cur = model_dirs.MODELS_DIR
    path = filedialog.askdirectory(
        title='Папка для моделей (Silero, ударения, TeraTTS, Shtorm, Shtorm-VoxCPM2, ffmpeg)',
        initialdir=cur if Path(cur).is_dir() else str(Path(cur).parent if Path(cur).parent.is_dir() else Path.home()),
        mustexist=False, parent=app.root)
    if not path:
        return False
    path = str(Path(path))
    try:
        Path(path).mkdir(parents=True, exist_ok=True)
    except OSError as e:
        messagebox.showerror('Папка моделей', f'Не могу создать или открыть папку:\n{path}\n\n{e}')
        return False
    if os.path.normcase(path) == os.path.normcase(str(cur)):
        return False
    model_dirs.configure(path)
    app.models_dir_cfg = path
    app.save_cfg()
    note = ('\n\nSilero и ударения новая папка подхватит после перезапуска программы.'
            if app.models_loaded() else '')
    app.log(f'Папка моделей: {path}')
    messagebox.showinfo('Папка моделей',
                        f'Папка моделей: {path}\n\nМодели из прежней папки не переносятся: '
                        f'скачай их здесь («Модели…») или скопируй вручную.{note}')
    app.refresh_models_window()
    return True


def _text_window(app, title, text, geometry='900x640'):
    win = tk.Toplevel(app.root)
    win.title(title)
    win.geometry(geometry)
    win.configure(bg=app.colors['BG'])
    win.transient(app.root)
    win.bind('<Escape>', lambda e: win.destroy())
    box = ttk.Frame(win, padding=12)
    box.pack(fill='both', expand=True)
    txt = app.textbox(box, 10)
    sc = ttk.Scrollbar(box, command=txt.yview)
    txt.configure(yscrollcommand=sc.set)
    sc.pack(side='right', fill='y')
    txt.pack(side='left', fill='both', expand=True)
    txt.insert('end', text)
    txt.configure(state='disabled')
    return win


def show_report(app):
    """Отчёт «что где лежит» (то же, что python model_dirs.py)."""
    app.log('Считаю размеры папок моделей, это может занять несколько секунд…')

    def work():
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            model_dirs.report()
            print('\nСостояние моделей:')
            for cid, st in model_manager.statuses().items():
                print(f'  {TITLES[cid]}: {"есть" if st.ok else "нет"} ({st.note})')
        app.ui(lambda: _text_window(app, 'Что где лежит', buf.getvalue()))
    threading.Thread(target=work, daemon=True).start()


def clean_old_cache(app):
    """Старые копии Silero/TeraTTS на диске C: (прежний кэш Python): показать и удалить после согласия."""
    def plan():
        try:
            todo, keep = model_dirs.clean_plan()
        except RuntimeError:
            todo, keep = [], []
        app.ui(lambda: confirm(todo, keep))

    def confirm(todo, keep):
        if not todo and not keep:
            messagebox.showinfo('Очистка', 'На диске C: старых копий не найдено, удалять нечего.')
            return
        lines = []
        if todo:
            lines.append('Можно удалить (на новом месте всё есть, это просто старые копии):')
            lines += [f'  {lab}: {path}  ({model_dirs._fmt(size)})' for lab, path, size, _w in todo]
        for lab, path, size, why in keep:
            lines.append(f'Оставляю {lab}: {path} ({model_dirs._fmt(size)})\n  причина: {why}')
        lines.append('\nRUAccent и чужие модели не трогаю.')
        if not todo:
            messagebox.showinfo('Очистка', '\n'.join(lines))
            return
        total = sum(item[2] for item in todo)
        if messagebox.askyesno('Очистка старого кэша',
                               '\n'.join(lines) + f'\n\nУдалить то, что в списке «Можно удалить» '
                               f'(освободится {model_dirs._fmt(total)})?'):
            threading.Thread(target=run, args=(todo,), daemon=True).start()

    def run(todo):
        freed, errors = model_dirs.clean_run(todo)
        msg = f'Освобождено {model_dirs._fmt(freed)}.'
        if errors:
            msg += '\nНе удалось удалить (закрой программы, которые их держат, и повтори):\n' + \
                   '\n'.join(f'  {p}: {e}' for p, e in errors)
        app.log(msg.replace('\n', ' '))
        app.ui(lambda: messagebox.showinfo('Очистка', msg))
    threading.Thread(target=plan, daemon=True).start()


def save_lockfile(app):
    """Точные версии установленных пакетов -> requirements.lock.txt для start.bat на другом устройстве."""
    def work():
        try:
            path, n = model_manager.write_lockfile()
            msg = (f'Сохранено пакетов: {n}\n{path}\n\nСкопируй этот файл вместе с папкой программы: '
                   'start.bat на другом устройстве поставит именно эти версии (так программа работает так же, '
                   'как здесь).')
            app.ui(lambda: messagebox.showinfo('Версии пакетов', msg))
        except Exception as e:
            app.ui(lambda: messagebox.showerror('Версии пакетов', str(e)))
    threading.Thread(target=work, daemon=True).start()


def build_portable(app):
    """Собрать папку для другого компьютера: нужные файлы, ваш словарь, start.bat и версии пакетов."""
    dest = filedialog.askdirectory(title='Куда положить папку BookVoice для другого компьютера (например, флешка)',
                                   mustexist=True, parent=app.root)
    if not dest:
        return
    target = Path(dest) / 'BookVoice'
    if target.exists() and any(target.iterdir()):
        if not messagebox.askyesno('Папка для другого компьютера',
                                   f'Папка уже есть и не пуста:\n{target}\n\nФайлы программы в ней будут '
                                   'заменены (модели и venv не затрагиваются). Продолжить?'):
            return
    app.log(f'Собираю папку для другого компьютера: {target} (сохраняю версии пакетов, пара секунд)…')

    def work():
        try:
            copied, notes = model_manager.build_portable(target)
            msg = (f'Готово: {target}\n\nФайлов: {len(copied)}\n' + '\n'.join(notes) +
                   '\n\nНа другом компьютере: поставь Python той же версии (см. PYTHON_VERSION.txt), '
                   'запусти start.bat (первый запуск ставит пакеты, нужен интернет), затем в программе '
                   '⚙ → «Модели…» скачай модели.')
            app.ui(lambda: messagebox.showinfo('Папка для другого компьютера', msg))
        except Exception as e:
            err = str(e)
            app.ui(lambda: messagebox.showerror('Папка для другого компьютера', err))
    threading.Thread(target=work, daemon=True).start()


# ---------------------------------------------------------------- окно «Модели»
class ModelsWindow:
    """Окно «Модели»: папка моделей, что установлено, скачивание выбранного с ходом и остановкой."""

    def __init__(self, app, banner='', runner_factory=model_manager.Runner):
        self.app = app
        self.colors = app.colors
        self.win = tk.Toplevel(app.root)
        self.win.title('Модели BookVoice')
        sw, sh = app.root.winfo_screenwidth(), app.root.winfo_screenheight()
        self.win.geometry(f'{min(880, sw - 40)}x{min(760, sh - 80)}')
        self.win.configure(bg=self.colors['BG'])
        self.win.transient(app.root)
        self.win.bind('<Escape>', lambda e: self.close())
        self.win.protocol('WM_DELETE_WINDOW', self.close)
        self.rows = {}
        self.totals = {}
        self.current = None
        self.touched = False
        self.runner = runner_factory(self._on_event_thread)
        self._build(banner)
        self.refresh()

    # ---- построение окна
    def _build(self, banner):
        box = ttk.Frame(self.win, padding=14)
        box.pack(fill='both', expand=True)
        self.banner = ttk.Label(box, text=banner, wraplength=820, foreground=self.colors['ACCENT'])
        self.banner.pack(anchor='w', pady=(0, 8) if banner else 0)

        top = ttk.Frame(box)
        top.pack(fill='x')
        ttk.Label(top, text='Папка моделей:').pack(side='left')
        self.dir_lbl = ttk.Label(top, text='', style='M.TLabel')
        self.dir_lbl.pack(side='left', padx=8, fill='x', expand=True)
        ttk.Button(top, text='Выбрать…', command=self._choose_dir).pack(side='right')
        ttk.Button(top, text='Открыть', command=lambda: open_path(model_dirs.MODELS_DIR)).pack(
            side='right', padx=6)
        self.free_lbl = ttk.Label(box, text='', style='M.TLabel')
        self.free_lbl.pack(anchor='w', pady=(2, 10))

        for cid in COMPONENTS:
            row = ttk.Frame(box)
            row.pack(fill='x', pady=3)
            var = tk.BooleanVar(value=False)
            chk = ttk.Checkbutton(row, text=TITLES[cid], variable=var,
                                  command=lambda: setattr(self, 'touched', True))
            chk.pack(side='left')
            state = ttk.Label(row, text='')
            state.pack(side='right')
            sub = ttk.Label(box, text=f'{NOTES[cid]}; скачать: {APPROX[cid]}', style='M.TLabel')
            sub.pack(anchor='w', padx=26)
            self.rows[cid] = {'var': var, 'chk': chk, 'state': state, 'sub': sub}

        bar = ttk.Frame(box)
        bar.pack(fill='x', pady=(12, 6))
        self.b_start = ttk.Button(bar, text='Скачать выбранные', style='Accent.TButton', command=self.start)
        self.b_start.pack(side='left')
        self.b_stop = ttk.Button(bar, text='Остановить', command=self.stop, state='disabled')
        self.b_stop.pack(side='left', padx=6)
        self.b_refresh = ttk.Button(bar, text='Обновить список', command=self.refresh)
        self.b_refresh.pack(side='left')
        ttk.Button(bar, text='Закрыть', command=self.close).pack(side='right')

        self.pb = ttk.Progressbar(box, mode='determinate', maximum=100)
        self.pb.pack(fill='x')
        self.stage_lbl = ttk.Label(box, text='', style='M.TLabel')
        self.stage_lbl.pack(anchor='w', pady=(4, 6))
        logbox = ttk.Frame(box)
        logbox.pack(fill='both', expand=True)
        self.log_txt = self.app.textbox(logbox, 8)
        sc = ttk.Scrollbar(logbox, command=self.log_txt.yview)
        self.log_txt.configure(yscrollcommand=sc.set, state='disabled')
        sc.pack(side='right', fill='y')
        self.log_txt.pack(side='left', fill='both', expand=True)

    # ---- состояние
    def alive(self):
        try:
            return bool(self.win.winfo_exists())
        except tk.TclError:
            return False

    def show_banner(self, text):
        self.banner.configure(text=text)
        self.banner.pack(anchor='w', pady=(0, 8))

    def refresh(self):
        model_manager.ensure_ffmpeg_on_path()
        self.dir_lbl.configure(text=str(model_dirs.MODELS_DIR))
        free = model_manager.free_space(model_dirs.MODELS_DIR)
        self.free_lbl.configure(text='' if free is None else f'Свободно на этом диске: {model_manager.fmt_size(free)}')
        for cid, st in model_manager.statuses().items():
            row = self.rows[cid]
            size = f' · {model_manager.fmt_size(st.size)}' if st.ok and st.size else ''
            row['state'].configure(text=(f'✓ есть{size}' if st.ok else f'✗ нет: {st.note}'))
            row['sub'].configure(text=f'{NOTES[cid]}; скачать: {APPROX[cid]}' if not st.ok
                                 else f'{st.note}  ·  {st.where}')
            if st.ok:
                row['var'].set(False)
            elif not self.touched:
                row['var'].set(cid in REQUIRED)           # по умолчанию отмечено то, без чего программа не запустится

    def selected(self):
        return [cid for cid in COMPONENTS if self.rows[cid]['var'].get()]

    def running(self):
        return self.runner.running()

    # ---- запуск и остановка
    def start(self, ids=None):
        ids = list(ids) if ids is not None else self.selected()
        if not ids:
            messagebox.showinfo('Модели', 'Отметь, что скачать.', parent=self.win)
            return False
        need = sum(model_manager.APPROX_BYTES.get(cid, 0) for cid in ids)
        free = model_manager.free_space(model_dirs.MODELS_DIR)
        if free is not None and need and free < need * 1.1:
            if not messagebox.askyesno('Мало места',
                                       f'Свободно {model_manager.fmt_size(free)}, а нужно примерно '
                                       f'{model_manager.fmt_size(need)}. Всё равно начать?', parent=self.win):
                return False
        if not self.runner.start(ids):
            messagebox.showinfo('Модели', 'Скачивание уже идёт.', parent=self.win)
            return False
        self._set_running(True)
        self._log(f'--- Начинаю: {", ".join(job_title(c) for c in ids)}')
        return True

    def stop(self):
        self.stage_lbl.configure(text='Останавливаю…')
        self.runner.cancel()

    def _set_running(self, running):
        self.b_start.configure(state='disabled' if running else 'normal')
        self.b_refresh.configure(state='disabled' if running else 'normal')
        self.b_stop.configure(state='normal' if running else 'disabled')
        if not running:
            self._pb_idle()

    def close(self):
        if self.running():
            if not messagebox.askyesno('Модели', 'Скачивание идёт. Остановить и закрыть окно?', parent=self.win):
                return
            self.runner.cancel()
        self.app.models_win = None
        try:
            self.win.destroy()
        except tk.TclError:
            pass

    def _choose_dir(self):
        if self.running():
            messagebox.showinfo('Модели', 'Сначала дождись конца скачивания или останови его.', parent=self.win)
            return
        self.app.choose_models_dir()

    # ---- ход скачивания
    def _on_event_thread(self, event):
        """Вызывается из потока скачивания: переносим обработку в поток окна."""
        self.app.ui(lambda: self.alive() and self.on_event(event))

    def _pb_idle(self):
        self.pb.stop()
        self.pb.configure(mode='determinate', value=0)

    def _pb_busy(self):
        self.pb.configure(mode='indeterminate')
        self.pb.start(60)

    def _log(self, line):
        self.log_txt.configure(state='normal')
        self.log_txt.insert('end', line + '\n')
        n = int(float(self.log_txt.index('end-1c').split('.')[0]))
        if n > 600:
            self.log_txt.delete('1.0', f'{n - 600}.0')
        self.log_txt.see('end')
        self.log_txt.configure(state='disabled')

    def on_event(self, event):
        kind, cid = event[0], event[1] if len(event) > 1 else None
        if kind == 'start':
            self.current = cid
            self.totals.pop(cid, None)
            self.stage_lbl.configure(text=f'{job_title(cid)}: начинаю…')
            self._pb_busy()
        elif kind == 'stage':
            self.stage_lbl.configure(text=event[2])
            self._log('# ' + event[2])
        elif kind == 'total':
            self.totals[cid] = event[2]
        elif kind == 'progress':
            done, total = event[2], event[3] or self.totals.get(cid)
            if total:
                self.pb.stop()
                self.pb.configure(mode='determinate', value=min(100.0, 100.0 * done / total))
                self.stage_lbl.configure(
                    text=f'{job_title(cid)}: {model_manager.fmt_size(done)} из {model_manager.fmt_size(total)}'
                         f' ({min(100, int(100 * done / total))}%)')
            else:
                self.stage_lbl.configure(text=f'{job_title(cid)}: скачано {model_manager.fmt_size(done)}')
        elif kind == 'log':
            self._log(event[2])
        elif kind == 'end':
            ok, message = event[2], event[3]
            self._log(('✓ ' if ok else '✗ ') + f'{job_title(cid)}: {message}')
            self.refresh()
        elif kind == 'finished':
            done, failed, cancelled = event[1], event[2], event[3]
            self._set_running(False)
            if cancelled:
                text = 'Остановлено.'
            elif failed:
                text = 'Не удалось: ' + ', '.join(job_title(c) for c in failed) + '. Подробности в журнале ниже.'
            else:
                text = 'Готово.'
            self.stage_lbl.configure(text=text)
            self.refresh()
            self.app.models_changed(done)
