"""Скачивание моделей из программы (⚙ → «Модели…») и папка для другого компьютера.

Сети и настоящих моделей здесь нет: скачивание проверяется на подставных процессах и подставных
пакетах (torch, ruaccent, huggingface_hub), окна и меню - на упрощённом tkinter."""
import atexit
import contextlib
import io
import os
import shutil
import sys
import tempfile

if not os.environ.get('BOOKVOICE_MODELS_DIR'):             # тесты не должны создавать папку models в проекте
    _MODELS_FOR_TESTS = tempfile.mkdtemp(prefix='bookvoice_models_')
    os.environ['BOOKVOICE_MODELS_DIR'] = _MODELS_FOR_TESTS
    atexit.register(shutil.rmtree, _MODELS_FOR_TESTS, True)

import ast
import re
import textwrap
import threading
import time
import unittest
import zipfile
from pathlib import Path
from types import ModuleType, SimpleNamespace
from unittest import mock

import model_dirs
import model_manager as mm

ROOT = Path(__file__).resolve().parent.parent
MD_NAMES = ('MODELS_DIR', 'SILERO_DIR', 'RUACCENT_DIR', 'TERA_DIR', 'SHTORM_DIR', 'VOXCPM_DIR', 'FFMPEG_DIR')


class IsolatedModels(unittest.TestCase):
    """Каждому тесту своя временная папка моделей; model_dirs и окружение после теста возвращаются."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(ignore_cleanup_errors=True)
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        saved = {n: getattr(model_dirs, n) for n in MD_NAMES}
        self.addCleanup(lambda: [setattr(model_dirs, n, v) for n, v in saved.items()])
        env = mock.patch.dict(os.environ)
        env.start()
        self.addCleanup(env.stop)
        for patcher in (mock.patch.object(mm.shutil, 'which', return_value=None),       # ffmpeg из системы не мешает
                        mock.patch.object(mm, 'ruaccent_module_dir', return_value=None),   # и ударения из пакета тоже
                        # тесты не ходят в сеть: список моделей RUAccent и версия пакета «недоступны»
                        mock.patch.object(mm, 'fetch_ruaccent_models', side_effect=OSError('в тестах нет сети')),
                        mock.patch.object(mm, 'fetch_ruaccent_pkg_latest', return_value=None)):
            patcher.start()
            self.addCleanup(patcher.stop)
        self.models = self.root / 'models'
        self.use(self.models)

    def use(self, base):
        base = Path(base)
        model_dirs.MODELS_DIR = str(base)
        for name, key in (('SILERO_DIR', 'silero'), ('RUACCENT_DIR', 'ruaccent'), ('TERA_DIR', 'tera'),
                          ('SHTORM_DIR', 'shtorm'), ('VOXCPM_DIR', 'voxcpm'), ('FFMPEG_DIR', 'ffmpeg')):
            setattr(model_dirs, name, str(base / model_dirs.SUBDIRS[key]))

    def touch(self, path, data=b'x'):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        return path

    def run_quiet(self, func, *a, **k):
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            result = func(*a, **k)
        return result, buf.getvalue()


# ---------------------------------------------------------------- разбор вывода и список пакетов
class ParseAndFreezeTests(unittest.TestCase):
    def test_service_lines(self):
        self.assertEqual(mm.parse_line('@@stage Скачиваю модель\r\n'), ('stage', 'Скачиваю модель'))
        self.assertEqual(mm.parse_line('@@total 1234'), ('total', 1234))
        self.assertEqual(mm.parse_line(r'@@watch D:\AI\models\my dir'), ('watch', r'D:\AI\models\my dir'))

    def test_everything_else_goes_to_the_log(self):
        self.assertEqual(mm.parse_line('Downloading: 10%\n'), ('log', 'Downloading: 10%'))
        self.assertEqual(mm.parse_line('@@total много'), ('log', '@@total много'))
        self.assertEqual(mm.parse_line('@@неизвестно x'), ('log', '@@неизвестно x'))
        self.assertEqual(mm.parse_line(''), ('log', ''))

    def test_freeze_lines_are_installable_elsewhere(self):
        raw = ('# комментарий\n-e git+https://github.com/x/y#egg=y\nnumpy==1.26.4\ntorch==2.5.1+cpu\n'
               'mypkg @ file:///C:/build/mypkg\n\n  Pillow==10.4.0  \nonnxruntime-gpu==1.19.2+cu12x\n'
               '--extra-index-url https://example.org\n')
        self.assertEqual(mm.freeze_lines(raw), ['numpy==1.26.4', 'torch==2.5.1', 'Pillow==10.4.0',
                                                'onnxruntime-gpu==1.19.2'])

    def test_write_lockfile_uses_pip_freeze(self):
        tmp = tempfile.TemporaryDirectory(ignore_cleanup_errors=True)
        self.addCleanup(tmp.cleanup)
        out = Path(tmp.name) / 'requirements.lock.txt'
        done = SimpleNamespace(returncode=0, stdout='numpy==1.26.4\ntorch==2.5.1+cpu\n', stderr='')
        with mock.patch.object(mm.subprocess, 'run', return_value=done) as run:
            path, n = mm.write_lockfile(out)
        self.assertEqual((path, n), (out, 2))
        self.assertEqual(out.read_text(encoding='utf-8'), 'numpy==1.26.4\ntorch==2.5.1\n')
        self.assertEqual(run.call_args[0][0][1:], ['-m', 'pip', 'freeze', '--disable-pip-version-check'])

    def test_write_lockfile_reports_pip_failures(self):
        out = Path(tempfile.gettempdir()) / 'bookvoice_never_written.lock.txt'
        bad = SimpleNamespace(returncode=1, stdout='', stderr='pip сломался')
        with mock.patch.object(mm.subprocess, 'run', return_value=bad):
            with self.assertRaisesRegex(RuntimeError, 'pip сломался'):
                mm.write_lockfile(out)
        empty = SimpleNamespace(returncode=0, stdout='# ничего\n', stderr='')
        with mock.patch.object(mm.subprocess, 'run', return_value=empty):
            with self.assertRaisesRegex(RuntimeError, 'пустой'):
                mm.write_lockfile(out)
        self.assertFalse(out.exists())

    def test_child_processes_use_console_python(self):
        with mock.patch.object(mm.sys, 'executable', r'C:\py\pythonw.exe'):
            self.assertTrue(mm.console_python().endswith('pythonw.exe'))     # python.exe рядом нет: остаётся как есть
        tmp = tempfile.TemporaryDirectory(ignore_cleanup_errors=True)
        self.addCleanup(tmp.cleanup)
        (Path(tmp.name) / 'python.exe').write_bytes(b'')
        pyw = Path(tmp.name) / 'pythonw.exe'
        with mock.patch.object(mm.sys, 'executable', str(pyw)):
            self.assertEqual(Path(mm.console_python()).name, 'python.exe')
            self.assertEqual(mm.job_command('tera')[1:], ['-u', str(Path(mm.__file__).resolve()), 'job', 'tera'])


# ---------------------------------------------------------------- какая папка моделей действует
class ModelsDirChoiceTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(ignore_cleanup_errors=True)
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.settings = self.root / 'settings.json'
        for patcher in (mock.patch.object(model_dirs, 'SETTINGS_FILE', self.settings),
                        mock.patch.object(model_dirs, 'LEGACY_BASE', str(self.root / 'legacy')),
                        mock.patch.object(model_dirs, 'BASE', self.root / 'app'),
                        mock.patch.dict(os.environ)):
            patcher.start()
            self.addCleanup(patcher.stop)
        os.environ.pop('BOOKVOICE_MODELS_DIR', None)

    def test_order_env_settings_legacy_program_folder(self):
        self.assertEqual(model_dirs.default_base(), str(self.root / 'app' / 'models'))
        (self.root / 'legacy').mkdir()
        self.assertEqual(model_dirs.default_base(), str(self.root / 'legacy'))       # так было у основного компьютера
        self.settings.write_text('{"models_dir": "E:\\\\Модели"}', encoding='utf-8')
        self.assertEqual(model_dirs.default_base(), 'E:\\Модели')
        os.environ['BOOKVOICE_MODELS_DIR'] = 'F:\\env'
        self.assertEqual(model_dirs.default_base(), 'F:\\env')

    def test_broken_settings_are_ignored(self):
        for text in ('не json', '[]', '{"models_dir": 5}', '{"models_dir": "   "}'):
            self.settings.write_text(text, encoding='utf-8')
            self.assertEqual(model_dirs.default_base(), str(self.root / 'app' / 'models'), text)

    def test_settings_with_bom_are_read(self):
        self.settings.write_bytes('\ufeff{"models_dir": "G:\\\\m"}'.encode('utf-8'))
        self.assertEqual(model_dirs.default_base(), 'G:\\m')


class ConfigureTests(IsolatedModels):
    def test_configure_moves_every_subfolder(self):
        new = self.root / 'новая'
        with mock.patch.object(model_dirs, '_problems', None):
            model_dirs.configure(new)
        self.assertEqual(model_dirs.MODELS_DIR, str(new))
        self.assertEqual(model_dirs.SILERO_DIR, str(new / 'silero'))
        self.assertEqual(model_dirs.RUACCENT_DIR, str(new / 'ruaccent'))
        self.assertEqual(model_dirs.TERA_DIR, str(new / 'ttsv2'))
        self.assertEqual(model_dirs.SHTORM_DIR, str(new / 'shtorm-pockettts-ru'))
        self.assertEqual(model_dirs.VOXCPM_DIR, str(new / 'shtorm-voxcpm2-ru'))
        self.assertEqual(model_dirs.FFMPEG_DIR, str(new / 'ffmpeg'))

    def test_configure_reapplies_caches_only_when_they_were_applied_before(self):
        with mock.patch.object(model_dirs, 'apply') as apply:
            with mock.patch.object(model_dirs, '_problems', None):
                model_dirs.configure(self.root / 'a')
            apply.assert_not_called()
            with mock.patch.object(model_dirs, '_problems', []):
                model_dirs.configure(self.root / 'b')
            apply.assert_called_once()


# ---------------------------------------------------------------- что установлено
class StatusTests(IsolatedModels):
    def test_empty_folder_nothing_is_installed(self):
        st = mm.statuses()
        self.assertEqual(set(st), set(mm.COMPONENTS))
        self.assertFalse(any(s.ok for s in st.values()), st)
        self.assertEqual(mm.missing_required(), ['silero', 'ruaccent'])

    def test_silero_current_model_and_fallback(self):
        self.touch(model_dirs._model_file(model_dirs.SILERO_FALLBACK))
        st = mm.status('silero')
        self.assertFalse(st.ok)
        self.assertIn('запасная', st.note)
        self.touch(model_dirs._model_file())
        st = mm.status('silero')
        self.assertTrue(st.ok)
        self.assertIn(model_dirs.SILERO_MODEL, st.note)
        model_dirs._model_file().write_bytes(b'')           # пустой файл (оборванная загрузка) не считается
        self.assertFalse(mm.status('silero').ok)

    def test_ruaccent_in_models_folder_or_in_package(self):
        self.assertFalse(mm.status('ruaccent').ok)
        pkg = self.root / 'site-packages' / 'ruaccent'
        self.touch(pkg / 'nn' / 'nn_omograph' / 'turbo' / 'model.onnx')
        with mock.patch.object(mm, 'ruaccent_module_dir', return_value=pkg):
            st = mm.status('ruaccent')
            self.assertTrue(st.ok)
            self.assertIn('пакете', st.note)
            self.assertIsNone(mm.ruaccent_workdir())          # старое место: программа грузит как раньше
        self.touch(Path(model_dirs.RUACCENT_DIR) / 'nn' / 'nn_omograph' / 'turbo' / 'model.onnx')
        st = mm.status('ruaccent')
        self.assertTrue(st.ok)
        self.assertEqual(st.where, model_dirs.RUACCENT_DIR)

    def test_ruaccent_load_kwargs(self):
        class New:
            def load(self, omograph_model_size='turbo', use_dictionary=True, workdir=None):
                pass

        class Old:
            def load(self, omograph_model_size='turbo', use_dictionary=True):
                pass
        base = {'omograph_model_size': 'turbo', 'use_dictionary': True}
        self.assertEqual(mm.ruaccent_load_kwargs(New()), base)            # в папке моделей пусто: как раньше
        self.touch(Path(model_dirs.RUACCENT_DIR) / 'nn' / 'nn_omograph' / 'turbo' / 'model.onnx')
        self.assertEqual(mm.ruaccent_load_kwargs(New()), dict(base, workdir=model_dirs.RUACCENT_DIR))
        self.assertEqual(mm.ruaccent_load_kwargs(Old()), base)            # старая версия пакета workdir не знает

    def test_tera(self):
        self.touch(Path(model_dirs.TERA_DIR) / 'config.json')
        self.assertFalse(mm.status('tera').ok)
        (Path(model_dirs.TERA_DIR) / 'styles').mkdir()
        self.assertTrue(mm.status('tera').ok)

    def test_shtorm_needs_weights_environment_and_local_configs(self):
        d = Path(model_dirs.SHTORM_DIR)
        py = self.root / 'venv_shtorm' / 'Scripts' / 'python.exe'
        with mock.patch.object(mm, 'shtorm_python', return_value=py):
            self.assertIn('нет весов', mm.status('shtorm').note)
            for name in ('config_fast.yaml', 'config_slow.yaml'):
                self.touch(d / name, b'weights_path: hf://ArtShtorm/Shtorm-PocketTTS-RU/model_x.safetensors\n')
            for name in ('model_fast.safetensors', 'model_slow.safetensors', 'tokenizer.model'):
                self.touch(d / name)
            st = mm.status('shtorm')
            self.assertFalse(st.ok)
            self.assertIn('venv_shtorm', st.note)
            self.touch(py)
            st = mm.status('shtorm')
            self.assertFalse(st.ok)
            self.assertIn('не настроены', st.note)                         # конфигурации ещё смотрят в интернет
            for name in ('config_fast.yaml', 'config_slow.yaml'):
                (d / name).write_text('weights_path: /models/model_x.safetensors\n', encoding='utf-8')
            st = mm.status('shtorm')
            self.assertTrue(st.ok, st)
            self.assertIn('fast, slow', st.note)

    def test_flag_of_an_interrupted_download_means_not_ready(self):
        # Файлы лежат, но скачивание не закончено (кнопка «Остановить», обрыв сети): готовой папку считать нельзя.
        tera = Path(model_dirs.TERA_DIR)
        self.touch(tera / 'config.json')
        (tera / 'styles').mkdir()
        self.assertTrue(mm.status('tera').ok)
        self.touch(tera / mm.FLAG)
        st = mm.status('tera')
        self.assertFalse(st.ok)
        self.assertEqual(st.note, mm.PARTIAL_NOTE)
        self.assertGreater(st.size, 0)
        self.assertIn('tera', [c for c in mm.COMPONENTS if not mm.status(c).ok])
        (tera / mm.FLAG).unlink()
        self.assertTrue(mm.status('tera').ok)

    def test_unfinished_huggingface_files_mean_interrupted_too(self):
        tera = Path(model_dirs.TERA_DIR)
        self.touch(tera / 'config.json')
        (tera / 'styles').mkdir()
        part = self.touch(tera / '.cache' / 'huggingface' / 'download' / 'model.onnx.0a1b2c.incomplete')
        self.assertTrue(mm.partial(tera))
        self.assertEqual(mm.status('tera').note, mm.PARTIAL_NOTE)
        part.unlink()
        self.assertFalse(mm.partial(tera))
        self.assertTrue(mm.status('tera').ok)
        self.assertFalse(mm.partial(self.root / 'нет такой папки'))

    def test_ruaccent_interrupted_download_is_not_used_and_not_ready(self):
        own = Path(model_dirs.RUACCENT_DIR)
        self.touch(own / 'nn' / 'nn_omograph' / 'turbo' / 'model.onnx')
        self.touch(own / mm.FLAG)
        st = mm.status('ruaccent')
        self.assertFalse(st.ok)
        self.assertEqual(st.note, mm.PARTIAL_NOTE)
        self.assertIsNone(mm.ruaccent_workdir())               # недокачанные модели RUAccent не получает
        self.assertEqual(mm.missing_required(), ['silero', 'ruaccent'])
        pkg = self.root / 'site-packages' / 'ruaccent'
        self.touch(pkg / 'nn' / 'nn_omograph' / 'turbo' / 'model.onnx')
        with mock.patch.object(mm, 'ruaccent_module_dir', return_value=pkg):
            st = mm.status('ruaccent')                         # а исправные модели в пакете остаются в силе
            self.assertTrue(st.ok)
            self.assertIn('пакете', st.note)

    def test_shtorm_interrupted_download_is_not_ready_even_with_all_files(self):
        d = Path(model_dirs.SHTORM_DIR)
        py = self.root / 'venv_shtorm' / 'Scripts' / 'python.exe'
        self.touch(py)
        for name in ('config_fast.yaml', 'config_slow.yaml'):
            self.touch(d / name, b'weights_path: /models/model_x.safetensors\n')
        for name in ('model_fast.safetensors', 'model_slow.safetensors', 'tokenizer.model'):
            self.touch(d / name)
        with mock.patch.object(mm, 'shtorm_python', return_value=py):
            self.assertTrue(mm.status('shtorm').ok)
            self.touch(d / mm.FLAG)
            self.assertEqual(mm.status('shtorm').note, mm.PARTIAL_NOTE)
            self.assertFalse(mm.status('shtorm').ok)

    def test_ffmpeg_local_and_path(self):
        self.assertFalse(mm.status('ffmpeg').ok)
        exe = Path(model_dirs.FFMPEG_DIR) / ('ffmpeg.exe' if os.name == 'nt' else 'ffmpeg')
        self.touch(exe)
        self.assertTrue(mm.status('ffmpeg').ok)
        os.environ['PATH'] = os.pathsep.join(['/usr/bin'])
        self.assertTrue(mm.ensure_ffmpeg_on_path())
        self.assertTrue(os.environ['PATH'].startswith(str(exe.parent)))     # программа зовёт просто «ffmpeg»
        exe.unlink()
        with mock.patch.object(mm.shutil, 'which', return_value='/usr/bin/ffmpeg'):
            st = mm.status('ffmpeg')
            self.assertTrue(st.ok)
            self.assertIn('PATH', st.note)

    def test_ffmpeg_is_not_added_twice_when_system_has_one(self):
        self.touch(Path(model_dirs.FFMPEG_DIR) / ('ffmpeg.exe' if os.name == 'nt' else 'ffmpeg'))
        before = os.environ.get('PATH', '')
        with mock.patch.object(mm.shutil, 'which', return_value='/usr/bin/ffmpeg'):
            self.assertTrue(mm.ensure_ffmpeg_on_path())
        self.assertEqual(os.environ.get('PATH', ''), before)

    def test_free_space_of_a_folder_that_does_not_exist_yet(self):
        free = mm.free_space(self.root / 'нет' / 'такой' / 'папки')
        self.assertIsNotNone(free)
        self.assertGreater(free, 0)

    def test_dir_size_counts_files_in_subfolders(self):
        self.touch(self.root / 'd' / 'a.bin', b'12345')
        self.touch(self.root / 'd' / 'x' / 'b.bin', b'123')
        self.assertEqual(mm.dir_size(self.root / 'd'), 8)
        self.assertEqual(mm.dir_size(self.root / 'd' / 'a.bin'), 5)
        self.assertEqual(mm.dir_size(self.root / 'нет'), 0)


# ---------------------------------------------------------------- процесс скачивания (Runner)
FAKE_JOB = '''
import pathlib, sys, time
mode = sys.argv[1]
if mode == 'ok':
    print('@@stage Первый этап', flush=True)
    print('Привет, Иван! Ёжик — «съе\\u0301л» йод', flush=True)
elif mode == 'fail':
    print('перед ошибкой', flush=True)
    print('ОШИБКА: нет сети', flush=True)
    sys.exit(3)
elif mode == 'watch':
    target = pathlib.Path(sys.argv[2])
    print('@@total 1000', flush=True)
    print('@@watch ' + str(target), flush=True)
    with open(target, 'wb') as f:
        for _ in range(8):
            f.write(b'x' * 100)
            f.flush()
            time.sleep(0.1)
elif mode == 'slow':
    print('начали', flush=True)
    time.sleep(60)
'''
PROBE_TEXT = 'Привет, Иван! Ёжик — «съе\u0301л» йод'


class Collector:
    def __init__(self):
        self.events, self.lock = [], threading.Lock()

    def __call__(self, event):
        with self.lock:
            self.events.append(tuple(event))

    def of(self, kind):
        with self.lock:
            return [e for e in self.events if e[0] == kind]

    def wait(self, pred, timeout=30.0):
        end = time.time() + timeout
        while time.time() < end:
            if pred(self):
                return True
            time.sleep(0.02)
        return False


class RunnerTests(IsolatedModels):
    def setUp(self):
        super().setUp()
        self.script = self.touch(self.root / 'job.py', FAKE_JOB.encode('utf-8'))
        self.events = Collector()
        self.runners = []
        self.addCleanup(lambda: [r.cancel() for r in self.runners])

    def runner(self, extra=(), **kw):
        r = mm.Runner(self.events, command=lambda cid: [sys.executable, '-u', str(self.script), cid, *extra],
                      poll=0.05, **kw)
        self.runners.append(r)
        return r

    def test_successful_job_reports_stage_log_and_end(self):
        r = self.runner()
        self.assertTrue(r.start(['ok']))
        r.join(60)
        self.assertEqual(self.events.of('start'), [('start', 'ok')])
        self.assertEqual(self.events.of('stage'), [('stage', 'ok', 'Первый этап')])
        self.assertIn(PROBE_TEXT, [e[2] for e in self.events.of('log')])
        self.assertEqual(self.events.of('end'), [('end', 'ok', True, 'готово')])
        self.assertEqual(self.events.of('finished'), [('finished', ['ok'], [], False)])
        self.assertFalse(r.running())

    def test_russian_text_survives_a_parent_with_the_ansi_code_page(self):
        # На Windows процесс с выводом в канал по умолчанию пишет в cp1251/cp866 и русский текст портится.
        os.environ['PYTHONIOENCODING'] = 'cp1251'
        os.environ['PYTHONUTF8'] = '0'
        r = self.runner()
        r.start(['ok'])
        r.join(60)
        self.assertIn(PROBE_TEXT, [e[2] for e in self.events.of('log')])

    def test_failed_job_does_not_stop_the_next_one(self):
        r = self.runner()
        r.start(['fail', 'ok'])
        r.join(60)
        self.assertEqual(self.events.of('end'), [('end', 'fail', False, 'ОШИБКА: нет сети'),
                                                 ('end', 'ok', True, 'готово')])
        self.assertEqual(self.events.of('finished'), [('finished', ['ok'], ['fail'], False)])

    def test_progress_follows_the_growing_file(self):
        target = self.root / 'grow.bin'
        r = self.runner(extra=[str(target)])
        r.start(['watch'])
        r.join(60)
        self.assertEqual(self.events.of('total'), [('total', 'watch', 1000)])
        progress = self.events.of('progress')
        self.assertTrue(any(0 < e[2] < 1000 and e[3] == 1000 for e in progress), progress)
        self.assertEqual(progress[-1], ('progress', 'watch', 1000, 1000))

    def test_cancel_stops_the_process_and_the_queue(self):
        r = self.runner()
        r.start(['slow', 'ok'])
        self.assertTrue(self.events.wait(lambda c: any(e[2] == 'начали' for e in c.of('log'))))
        t0 = time.time()
        r.cancel()
        r.join(30)
        self.assertLess(time.time() - t0, 20)
        self.assertEqual(self.events.of('end'), [('end', 'slow', False, 'остановлено')])
        self.assertEqual([e[1] for e in self.events.of('start')], ['slow'])
        self.assertEqual(self.events.of('finished'), [('finished', [], ['slow'], True)])
        self.assertFalse(r.running())

    def test_cancel_pressed_while_the_process_is_starting(self):
        # «Остановить» нажали после запуска процесса, но до того, как Runner его запомнил: процесс всё равно убирается.
        r = self.runner()
        real_popen = mm.subprocess.Popen

        def popen_then_cancel(*a, **k):
            proc = real_popen(*a, **k)
            r.cancel()                                        # в этот момент r._proc ещё пуст
            return proc
        with mock.patch.object(mm.subprocess, 'Popen', popen_then_cancel):
            t0 = time.time()
            r.start(['slow'])
            r.join(30)
        self.assertLess(time.time() - t0, 20)                 # без исправления «slow» спал бы 60 секунд
        self.assertEqual(self.events.of('end'), [('end', 'slow', False, 'остановлено')])
        self.assertEqual(self.events.of('finished'), [('finished', [], ['slow'], True)])

    def test_second_start_while_running_is_refused(self):
        r = self.runner()
        self.assertTrue(r.start(['slow']))
        self.assertTrue(self.events.wait(lambda c: any(e[2] == 'начали' for e in c.of('log'))))
        self.assertFalse(r.start(['ok']))
        self.assertTrue(r.running())
        r.cancel()
        r.join(30)
        self.assertTrue(r.start(['ok']))                    # после остановки можно начать заново
        r.join(60)
        self.assertEqual(self.events.of('end')[-1], ('end', 'ok', True, 'готово'))

    def test_process_that_cannot_start_is_reported(self):
        r = mm.Runner(self.events, command=lambda cid: [str(self.root / 'нет такой программы')], poll=0.05)
        r.start(['x'])
        r.join(30)
        end = self.events.of('end')[0]
        self.assertFalse(end[2])
        self.assertTrue(end[3].startswith('не удалось запустить процесс скачивания'), end)
        self.assertEqual(self.events.of('finished'), [('finished', [], ['x'], False)])

    def test_broken_listener_does_not_break_the_download(self):
        def bad(event):
            raise ValueError('окно закрыто')
        r = mm.Runner(bad, command=lambda cid: [sys.executable, '-u', str(self.script), cid], poll=0.05)
        r.start(['ok'])
        r.join(60)
        self.assertFalse(r.running())

    def test_child_environment(self):
        os.environ.update({'HF_HUB_OFFLINE': '1', 'TRANSFORMERS_OFFLINE': '1'})
        env = mm.child_env()
        self.assertNotIn('HF_HUB_OFFLINE', env)                # программа работает без сети, скачивание с сетью
        self.assertNotIn('TRANSFORMERS_OFFLINE', env)
        self.assertEqual((env['PYTHONUTF8'], env['PYTHONIOENCODING']), ('1', 'utf-8'))
        self.assertEqual(env['BOOKVOICE_MODELS_DIR'], model_dirs.MODELS_DIR)
        self.assertEqual(mm.child_env(self.root / 'x')['BOOKVOICE_MODELS_DIR'], str(self.root / 'x'))
        self.assertEqual(os.environ['HF_HUB_OFFLINE'], '1')    # сама программа остаётся без сети


# ---------------------------------------------------------------- конфигурации Shtorm
SHTORM_YAML = ('weights_path: hf://ArtShtorm/Shtorm-PocketTTS-RU/model_fast.safetensors\n'
               'flow_lm:\n  lookup_table:\n    tokenizer_path: hf://ArtShtorm/Shtorm-PocketTTS-RU/tokenizer.model\n'
               'mimi:\n  weights_path: hf://kyutai/pocket-tts/tokenizer.model\n')


class ShtormConfigTests(IsolatedModels):
    def make(self, name, text=SHTORM_YAML):
        d = self.root / name
        for cfg in ('config.yaml', 'config_fast.yaml', 'config_slow.yaml'):
            self.touch(d / cfg, text.encode('utf-8'))
        return d

    def test_hf_links_become_local_paths_and_foreign_links_stay(self):
        d = self.make('a b')                                      # пробел в пути тоже допустим
        self.assertEqual(mm.patch_shtorm_configs(d), ['config.yaml', 'config_fast.yaml', 'config_slow.yaml'])
        text = (d / 'config_fast.yaml').read_text(encoding='utf-8')
        prefix = d.resolve().as_posix() + '/'
        self.assertIn(f'weights_path: {prefix}model_fast.safetensors', text)
        self.assertIn(f'tokenizer_path: {prefix}tokenizer.model', text)
        self.assertIn('hf://kyutai/pocket-tts/tokenizer.model', text)       # чужой репозиторий не трогаем
        self.assertNotIn('hf://ArtShtorm', text)

    def test_second_run_changes_nothing(self):
        d = self.make('m')
        mm.patch_shtorm_configs(d)
        stamp = (d / 'config_fast.yaml').stat().st_mtime_ns
        self.assertEqual(mm.patch_shtorm_configs(d), [])
        self.assertEqual((d / 'config_fast.yaml').stat().st_mtime_ns, stamp)

    def test_paths_left_from_another_folder_are_repaired(self):
        # Модели скопировали с другого компьютера или поменяли папку моделей: в конфигурациях старый путь.
        old = ('weights_path: D:/AI/models/shtorm-pockettts-ru/model_fast.safetensors\n'
               'quoted: "E:\\\\Модели\\\\shtorm\\\\model_slow.safetensors"\n'
               'unix: /home/u/models/shtorm/tokenizer.model\n'
               'foreign: hf://kyutai/pocket-tts/tokenizer.model\n'
               'note: слово model_fast.safetensors в тексте\n')
        d = self.make('new', old)
        mm.patch_shtorm_configs(d)
        text = (d / 'config_slow.yaml').read_text(encoding='utf-8')
        prefix = d.resolve().as_posix() + '/'
        self.assertIn(f'weights_path: {prefix}model_fast.safetensors', text)
        self.assertIn(f'quoted: "{prefix}model_slow.safetensors"', text)
        self.assertIn(f'unix: {prefix}tokenizer.model', text)
        self.assertIn('foreign: hf://kyutai/pocket-tts/tokenizer.model', text)
        self.assertIn('note: слово model_fast.safetensors в тексте', text)
        self.assertNotIn('D:/AI', text)

    def test_leftover_hf_link_is_an_error_only_in_strict_mode(self):
        d = self.make('s', 'extra: hf://ArtShtorm/Shtorm-PocketTTS-RU/other.bin\n')
        with self.assertRaisesRegex(RuntimeError, 'config_fast.yaml'):
            mm.patch_shtorm_configs(d)
        self.assertEqual(mm.patch_shtorm_configs(d, strict=False), [])

    def test_loading_shtorm_repairs_the_paths_first(self):
        try:
            import shtorm
        except Exception as e:                       # нет numpy и т.п.
            self.skipTest(f'shtorm не импортируется здесь: {e!r}')
        d = self.make('loaded', 'weights_path: C:/старый/путь/model_fast.safetensors\n')
        for name in ('model_fast.safetensors', 'model_slow.safetensors', 'tokenizer.model'):
            self.touch(d / name)
        wav = self.touch(self.root / 'voice.wav', b'RIFF')
        model_dirs.SHTORM_DIR = str(d)
        seen = []

        def request(payload):
            seen.append((d / 'config_fast.yaml').read_text(encoding='utf-8'))     # воркер читает уже исправленный файл
            return {'ok': True, 'sample_rate': 24000, 'probe': shtorm.PROBE}
        saved = (shtorm._model_variant, shtorm._voice_ref, shtorm._sample_rate, shtorm.SAMPLE_RATE)
        self.addCleanup(lambda: setattr(shtorm, '_model_variant', saved[0]))
        self.addCleanup(lambda: setattr(shtorm, '_voice_ref', saved[1]))
        self.addCleanup(lambda: setattr(shtorm, '_sample_rate', saved[2]))
        self.addCleanup(lambda: setattr(shtorm, 'SAMPLE_RATE', saved[3]))
        with mock.patch.object(shtorm, '_request', request), mock.patch.object(shtorm, 'is_loaded', return_value=False):
            shtorm.load('fast', str(wav))
        self.assertEqual(len(seen), 1)
        self.assertIn(d.resolve().as_posix() + '/model_fast.safetensors', seen[0])
        self.assertNotIn('старый', seen[0])


# ---------------------------------------------------------------- сами скачивания (в процессе скачивания, но без сети)
class JobTests(IsolatedModels):
    def setUp(self):
        super().setUp()
        apply = mock.patch.object(model_dirs, 'apply', return_value=[])      # без переноса кэшей и смены окружения
        apply.start()
        self.addCleanup(apply.stop)

    def fake_torch(self, fail=()):
        calls = []

        def load(**kw):
            calls.append(kw)
            if kw['speaker'] in fail:
                raise RuntimeError('нет сети для ' + kw['speaker'])
            return 'модель', 'пример'
        mod = ModuleType('torch')
        mod.hub = SimpleNamespace(load=load)
        return mod, calls

    def test_silero_loads_the_current_model(self):
        torch, calls = self.fake_torch()
        with mock.patch.dict(sys.modules, {'torch': torch}):
            _r, out = self.run_quiet(mm.job_silero)
        self.assertEqual(calls, [dict(repo_or_dir='snakers4/silero-models', model='silero_tts', language='ru',
                                      speaker=model_dirs.SILERO_MODEL, force_reload=False)])
        self.assertIn('@@watch ' + model_dirs.SILERO_DIR, out)
        self.assertIn('Готово: Silero ' + model_dirs.SILERO_MODEL, out)

    def test_silero_falls_back_and_reports_the_last_error(self):
        torch, calls = self.fake_torch(fail=(model_dirs.SILERO_MODEL,))
        with mock.patch.dict(sys.modules, {'torch': torch}):
            _r, out = self.run_quiet(mm.job_silero)
        self.assertEqual([c['speaker'] for c in calls], [model_dirs.SILERO_MODEL, model_dirs.SILERO_FALLBACK])
        self.assertIn('не скачалась', out)
        torch, calls = self.fake_torch(fail=(model_dirs.SILERO_MODEL, model_dirs.SILERO_FALLBACK))
        with mock.patch.dict(sys.modules, {'torch': torch}):
            with self.assertRaisesRegex(RuntimeError, model_dirs.SILERO_FALLBACK):
                self.run_quiet(mm.job_silero)

    def test_silero_update_forces_reload_of_the_repository_once(self):
        torch, calls = self.fake_torch(fail=(model_dirs.SILERO_MODEL,))
        with mock.patch.dict(sys.modules, {'torch': torch}):
            self.run_quiet(mm.job_silero, update=True)
        self.assertEqual([c['force_reload'] for c in calls], [True, False])
        self.assertIn('silero_update', mm.JOBS)

    def fake_ruaccent(self, with_workdir):
        loads = []
        if with_workdir:
            class RUAccent:
                def load(self, omograph_model_size='turbo', use_dictionary=True, workdir=None):
                    loads.append(dict(omograph_model_size=omograph_model_size, use_dictionary=use_dictionary,
                                      workdir=workdir))

                def process_all(self, text):            # проба после загрузки (job_ruaccent)
                    return text
        else:
            class RUAccent:
                def load(self, omograph_model_size='turbo', use_dictionary=True):
                    loads.append(dict(omograph_model_size=omograph_model_size, use_dictionary=use_dictionary))

                def process_all(self, text):
                    return text
        mod = ModuleType('ruaccent')
        mod.RUAccent = RUAccent
        return mod, loads

    def test_ruaccent_goes_into_the_models_folder(self):
        mod, loads = self.fake_ruaccent(True)
        with mock.patch.dict(sys.modules, {'ruaccent': mod}):
            _r, out = self.run_quiet(mm.job_ruaccent)
        self.assertEqual(loads, [dict(omograph_model_size='turbo', use_dictionary=True,
                                      workdir=model_dirs.RUACCENT_DIR)])
        self.assertIn('@@watch ' + model_dirs.RUACCENT_DIR, out)
        self.assertTrue(Path(model_dirs.RUACCENT_DIR).is_dir())

    def test_old_ruaccent_package_keeps_its_own_folder(self):
        mod, loads = self.fake_ruaccent(False)
        pkg = self.root / 'site-packages' / 'ruaccent'
        pkg.mkdir(parents=True)
        with mock.patch.dict(sys.modules, {'ruaccent': mod}), \
                mock.patch.object(mm, 'ruaccent_module_dir', return_value=pkg):
            _r, out = self.run_quiet(mm.job_ruaccent)
        self.assertEqual(loads, [dict(omograph_model_size='turbo', use_dictionary=True)])
        self.assertIn('не умеет скачивать в выбранную папку', out)
        self.assertIn('@@watch ' + str(pkg), out)

    def test_in_progress_flag_lives_exactly_as_long_as_the_download(self):
        d = self.root / 'папка'
        with mm.in_progress(d):
            self.assertTrue((d / mm.FLAG).is_file())
            self.assertTrue(mm.partial(d))
        self.assertFalse((d / mm.FLAG).exists())
        with self.assertRaisesRegex(ValueError, 'обрыв'):
            with mm.in_progress(d):
                raise ValueError('обрыв')
        self.assertTrue((d / mm.FLAG).is_file())              # ошибка или остановка: флажок остаётся
        (d / mm.FLAG).unlink()
        with mm.in_progress(d):                               # файл флажка исчез сам: это не ошибка
            (d / mm.FLAG).unlink()
        self.assertFalse(mm.partial(d))

    def test_ruaccent_download_is_marked_and_unmarked(self):
        seen = []
        mod, loads = self.fake_ruaccent(True)
        real = mod.RUAccent.load

        def load(self_, omograph_model_size='turbo', use_dictionary=True, workdir=None):
            seen.append((Path(model_dirs.RUACCENT_DIR) / mm.FLAG).is_file())
            real(self_, omograph_model_size, use_dictionary, workdir)
        mod.RUAccent.load = load
        with mock.patch.dict(sys.modules, {'ruaccent': mod}):
            self.run_quiet(mm.job_ruaccent)
        self.assertEqual(seen, [True])
        self.assertFalse((Path(model_dirs.RUACCENT_DIR) / mm.FLAG).exists())

    def test_ruaccent_interrupted_earlier_is_wiped_and_downloaded_again(self):
        # RUAccent считает dictionary и nn готовыми, как только они появились; после обрыва в них пусто
        # или не хватает файлов, поэтому неполные папки убираются, а чужие файлы рядом остаются.
        own = Path(model_dirs.RUACCENT_DIR)
        self.touch(own / 'dictionary' / 'half.json')
        self.touch(own / 'nn' / 'nn_omograph' / 'turbo' / 'half.onnx')
        self.touch(own / 'other.txt')
        self.touch(own / mm.FLAG)
        mod, loads = self.fake_ruaccent(True)
        with mock.patch.dict(sys.modules, {'ruaccent': mod}):
            _r, out = self.run_quiet(mm.job_ruaccent)
        self.assertFalse((own / 'dictionary').exists())
        self.assertFalse((own / 'nn').exists())
        self.assertTrue((own / 'other.txt').is_file())
        self.assertIn('оборвалась', out)
        self.assertEqual(len(loads), 1)
        self.assertFalse((own / mm.FLAG).exists())

    def test_ruaccent_healthy_folder_is_not_wiped(self):
        own = Path(model_dirs.RUACCENT_DIR)
        keep = self.touch(own / 'nn' / 'nn_omograph' / 'turbo' / 'model.onnx')
        mod, loads = self.fake_ruaccent(True)
        with mock.patch.dict(sys.modules, {'ruaccent': mod}):
            _r, out = self.run_quiet(mm.job_ruaccent)
        self.assertTrue(keep.is_file())
        self.assertNotIn('оборвалась', out)

    def test_ruaccent_failed_download_leaves_the_flag(self):
        mod, _loads = self.fake_ruaccent(True)

        def broken(self_, omograph_model_size='turbo', use_dictionary=True, workdir=None):
            raise RuntimeError('нет сети')
        mod.RUAccent.load = broken
        with mock.patch.dict(sys.modules, {'ruaccent': mod}):
            with self.assertRaisesRegex(RuntimeError, 'нет сети'):
                self.run_quiet(mm.job_ruaccent)
        self.assertTrue((Path(model_dirs.RUACCENT_DIR) / mm.FLAG).is_file())
        self.assertEqual(mm.status('ruaccent').note, mm.PARTIAL_NOTE)

    def tera_fakes(self, create_styles=True, missing_packages=()):
        ran = []

        def download(repo, target, patterns=None):
            self.touch(Path(target) / 'config.json')
            if create_styles:
                (Path(target) / 'styles').mkdir(parents=True, exist_ok=True)
            ran.append(('download', repo, str(target), patterns))
            return str(target)

        def find_spec(name, *a):
            return None if name in missing_packages else object()
        return ran, [mock.patch.object(mm, '_hf_download', download),
                     mock.patch.object(mm, '_run', lambda cmd: ran.append(('run', [str(c) for c in cmd]))),
                     mock.patch.object(mm.importlib.util, 'find_spec', find_spec)]

    def test_tera_installs_missing_packages_then_downloads(self):
        ran, patches = self.tera_fakes(missing_packages=('transformers',))
        with contextlib.ExitStack() as stack:
            for p in patches:
                stack.enter_context(p)
            self.run_quiet(mm.job_tera)
        self.assertEqual(ran[0][0], 'run')
        self.assertEqual(ran[0][1][1:], ['-m', 'pip', 'install', '--disable-pip-version-check', '--progress-bar',
                                         'off', 'transformers>=4.40'])
        self.assertEqual(ran[1], ('download', mm.TERA_REPO, model_dirs.TERA_DIR, None))
        self.assertTrue(mm.status('tera').ok)

    def test_tera_without_missing_packages_runs_no_pip(self):
        ran, patches = self.tera_fakes()
        with contextlib.ExitStack() as stack:
            for p in patches:
                stack.enter_context(p)
            self.run_quiet(mm.job_tera)
        self.assertEqual([r[0] for r in ran], ['download'])

    def test_tera_incomplete_download_is_an_error(self):
        ran, patches = self.tera_fakes(create_styles=False)
        with contextlib.ExitStack() as stack:
            for p in patches:
                stack.enter_context(p)
            with self.assertRaisesRegex(RuntimeError, 'styles'):
                self.run_quiet(mm.job_tera)
        self.assertEqual(mm.status('tera').note, mm.PARTIAL_NOTE)      # и папка не считается готовой

    def test_tera_download_is_marked_while_it_runs_and_unmarked_after(self):
        flag = Path(model_dirs.TERA_DIR) / mm.FLAG
        seen = []

        def download(repo, target, patterns=None):
            seen.append(flag.is_file())
            self.touch(Path(target) / 'config.json')
            (Path(target) / 'styles').mkdir(parents=True, exist_ok=True)
            return str(target)
        with mock.patch.object(mm, '_hf_download', download), \
                mock.patch.object(mm.importlib.util, 'find_spec', lambda name, *a: object()):
            self.run_quiet(mm.job_tera)
        self.assertEqual(seen, [True])
        self.assertFalse(flag.exists())
        self.assertTrue(mm.status('tera').ok)

    def test_tera_stopped_download_is_not_ready_and_is_downloaded_again(self):
        flag = Path(model_dirs.TERA_DIR) / mm.FLAG

        def dying_download(repo, target, patterns=None):
            self.touch(Path(target) / 'config.json')           # часть файлов успела скачаться
            raise KeyboardInterrupt
        with mock.patch.object(mm, '_hf_download', dying_download), \
                mock.patch.object(mm.importlib.util, 'find_spec', lambda name, *a: object()):
            with self.assertRaises(KeyboardInterrupt):
                self.run_quiet(mm.job_tera)
        self.assertTrue(flag.is_file())
        self.assertFalse(mm.status('tera').ok)
        ran, patches = self.tera_fakes()
        with contextlib.ExitStack() as stack:
            for p in patches:
                stack.enter_context(p)
            self.run_quiet(mm.job_tera)                         # «Скачать» ещё раз: докачивает и снимает флажок
        self.assertFalse(flag.exists())
        self.assertTrue(mm.status('tera').ok)

    def shtorm_fakes(self, env_exists):
        py = self.root / 'venv_shtorm' / 'Scripts' / 'python.exe'
        if env_exists:
            self.touch(py)
        ran = []

        def run(cmd):
            ran.append([str(c) for c in cmd])
            if len(cmd) > 2 and cmd[1:3] == ['-m', 'venv']:
                self.touch(py)

        def download(repo, target, patterns=None):
            ran.append(['download', repo, str(target), list(patterns or [])])
            for name in ('config.yaml', 'config_fast.yaml', 'config_slow.yaml'):
                self.touch(Path(target) / name, SHTORM_YAML.encode('utf-8'))
            for name in ('model_fast.safetensors', 'model_slow.safetensors', 'tokenizer.model'):
                self.touch(Path(target) / name)
        return py, ran, [mock.patch.object(mm, 'shtorm_python', return_value=py),
                         mock.patch.object(mm, '_run', run), mock.patch.object(mm, '_hf_download', download)]

    def test_shtorm_creates_its_environment_installs_pocket_tts_and_downloads(self):
        py, ran, patches = self.shtorm_fakes(env_exists=False)
        with contextlib.ExitStack() as stack:
            for p in patches:
                stack.enter_context(p)
            self.run_quiet(mm.job_shtorm)
            self.assertEqual(ran[0][1:3], ['-m', 'venv'])
            self.assertEqual(ran[0][3], str(py.parent.parent))
            self.assertEqual(ran[1], [str(py), '-m', 'pip', 'install', '--disable-pip-version-check',
                                      '--progress-bar', 'off', 'pocket-tts==4.0.1'])
            self.assertEqual(ran[2][:3], ['download', mm.SHTORM_REPO, model_dirs.SHTORM_DIR])
            self.assertEqual(ran[2][3], mm.SHTORM_FILES)
            text = (Path(model_dirs.SHTORM_DIR) / 'config_fast.yaml').read_text(encoding='utf-8')
            self.assertNotIn('hf://ArtShtorm', text)
            self.assertTrue(mm.status('shtorm').ok, mm.status('shtorm'))

    def test_shtorm_flag_stays_when_pip_fails_and_goes_after_a_good_run(self):
        py, ran, patches = self.shtorm_fakes(env_exists=True)
        flag = Path(model_dirs.SHTORM_DIR) / mm.FLAG

        def failing_run(cmd):
            raise RuntimeError('pip: нет сети')
        with mock.patch.object(mm, 'shtorm_python', return_value=py), \
                mock.patch.object(mm, '_run', failing_run):
            with self.assertRaisesRegex(RuntimeError, 'нет сети'):
                self.run_quiet(mm.job_shtorm)
            self.assertTrue(flag.is_file())
            self.assertEqual(mm.status('shtorm').note, mm.PARTIAL_NOTE)
        with contextlib.ExitStack() as stack:
            for p in patches:
                stack.enter_context(p)
            self.run_quiet(mm.job_shtorm)
            self.assertFalse(flag.exists())
            self.assertTrue(mm.status('shtorm').ok, mm.status('shtorm'))

    def test_shtorm_existing_environment_is_reused(self):
        py, ran, patches = self.shtorm_fakes(env_exists=True)
        with contextlib.ExitStack() as stack:
            for p in patches:
                stack.enter_context(p)
            self.run_quiet(mm.job_shtorm)
        self.assertFalse(any(len(c) > 2 and c[1:3] == ['-m', 'venv'] for c in ran))
        self.assertEqual(ran[0][0], str(py))

    @staticmethod
    def zip_bytes(member='ffmpeg-master-latest-win64-gpl/bin/ffmpeg.exe'):
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, 'w') as z:
            z.writestr(member, b'MZ-fake-exe')
            z.writestr('ffmpeg-master-latest-win64-gpl/LICENSE.txt', b'license')
        return buf.getvalue()

    class Response(io.BytesIO):
        def __init__(self, data):
            super().__init__(data)
            self.headers = {'Content-Length': str(len(data))}

    def test_ffmpeg_download_unpacks_and_verifies(self):
        data = self.zip_bytes()
        with mock.patch.object(mm, '_is_windows', return_value=True), \
                mock.patch.object(mm.platform, 'machine', return_value='AMD64'), \
                mock.patch.object(mm.urllib.request, 'urlopen', return_value=self.Response(data)) as urlopen, \
                mock.patch.object(mm, '_verify_ffmpeg') as verify:
            _r, out = self.run_quiet(mm.job_ffmpeg)
        exe = Path(model_dirs.FFMPEG_DIR) / 'ffmpeg.exe'
        self.assertEqual(exe.read_bytes(), b'MZ-fake-exe')
        self.assertEqual(sorted(p.name for p in Path(model_dirs.FFMPEG_DIR).iterdir()), ['ffmpeg.exe'])   # без остатков
        self.assertEqual(urlopen.call_args[0][0].full_url, mm.FFMPEG_URLS['amd64'])
        verify.assert_called_once_with(exe)
        self.assertIn('@@total %d' % len(data), out)
        self.assertIn('@@watch ' + str(Path(model_dirs.FFMPEG_DIR) / 'ffmpeg.zip.part'), out)

    def test_ffmpeg_arm_windows_takes_the_arm_build(self):
        with mock.patch.object(mm, '_is_windows', return_value=True), \
                mock.patch.object(mm.platform, 'machine', return_value='ARM64'), \
                mock.patch.object(mm.urllib.request, 'urlopen', return_value=self.Response(self.zip_bytes())) as urlopen, \
                mock.patch.object(mm, '_verify_ffmpeg'):
            self.run_quiet(mm.job_ffmpeg)
        self.assertEqual(urlopen.call_args[0][0].full_url, mm.FFMPEG_URLS['arm64'])

    def test_ffmpeg_archive_without_binary_is_an_error(self):
        with mock.patch.object(mm, '_is_windows', return_value=True), \
                mock.patch.object(mm.urllib.request, 'urlopen',
                                  return_value=self.Response(self.zip_bytes('x/readme.txt'))), \
                mock.patch.object(mm, '_verify_ffmpeg'):
            with self.assertRaisesRegex(RuntimeError, 'bin/ffmpeg.exe'):
                self.run_quiet(mm.job_ffmpeg)
        self.assertFalse((Path(model_dirs.FFMPEG_DIR) / 'ffmpeg.exe').exists())

    def test_ffmpeg_automatic_install_is_for_windows_only(self):
        with mock.patch.object(mm, '_is_windows', return_value=False):
            with self.assertRaisesRegex(RuntimeError, 'Windows'):
                self.run_quiet(mm.job_ffmpeg)

    def test_run_job_exit_codes(self):
        _r, out = self.run_quiet(mm.run_job, 'такого-нет')
        self.assertEqual(_r, 2)
        with mock.patch.dict(mm.JOBS, {'good': lambda: print('сделано')}):
            self.assertEqual(self.run_quiet(mm.run_job, 'good')[0], 0)
        def broken():
            raise RuntimeError('диск полон')
        with mock.patch.dict(mm.JOBS, {'bad': broken}):
            code, out = self.run_quiet(mm.run_job, 'bad')
        self.assertEqual(code, 1)
        self.assertIn('ОШИБКА: RuntimeError: диск полон', out)

    def test_every_component_has_a_job_a_status_and_texts(self):
        for cid in mm.COMPONENTS:
            self.assertIn(cid, mm.JOBS)
            self.assertIn(cid, mm.TITLES)
            self.assertIn(cid, mm.APPROX)
            self.assertIn(cid, mm.APPROX_BYTES)
            self.assertIn(cid, mm.NOTES)
        self.assertTrue(set(mm.REQUIRED) <= set(mm.COMPONENTS))

    def test_command_line(self):
        code, out = self.run_quiet(mm.main, ['model_manager.py', 'status'])
        self.assertEqual(code, 0)
        self.assertEqual(len(out.strip().splitlines()), len(mm.COMPONENTS))
        self.assertEqual(self.run_quiet(mm.main, ['model_manager.py', 'bogus'])[0], 2)
        self.assertEqual(self.run_quiet(mm.main, ['model_manager.py', 'job', 'такого-нет'])[0], 2)


class VoxcpmComponentTests(IsolatedModels):
    """Shtorm-VoxCPM2-RU в окне «Модели»: статус, установка отдельной среды с CUDA-torch и скачивание весов."""

    def setUp(self):
        super().setUp()
        self.py = self.root / 'venv_voxcpm' / 'Scripts' / 'python.exe'
        patcher = mock.patch.object(mm, 'voxcpm_python', return_value=self.py)
        patcher.start()
        self.addCleanup(patcher.stop)
        self.pkg = self.py.parent.parent / 'Lib' / 'site-packages' / 'voxcpm'

    def put_weights(self):
        for name in mm.VOXCPM_FILES:
            self.touch(Path(model_dirs.VOXCPM_DIR) / name)

    def test_status_walks_from_nothing_to_ready(self):
        st = mm.status('voxcpm')
        self.assertFalse(st.ok)
        self.assertIn('нет весов', st.note)
        self.assertIn('нет среды venv_voxcpm', st.note)
        self.put_weights()
        self.assertIn('нет среды venv_voxcpm', mm.status('voxcpm').note)
        self.touch(self.py)
        st = mm.status('voxcpm')
        self.assertFalse(st.ok)
        self.assertIn('не установлен пакет voxcpm', st.note)
        self.touch(self.pkg / '__init__.py')
        st = mm.status('voxcpm')
        self.assertTrue(st.ok, st)

    def test_missing_weight_file_is_named(self):
        self.put_weights()
        self.touch(self.py)
        self.touch(self.pkg / '__init__.py')
        (Path(model_dirs.VOXCPM_DIR) / 'audiovae.pth').unlink()
        st = mm.status('voxcpm')
        self.assertFalse(st.ok)
        self.assertIn('audiovae.pth', st.note)

    def test_interrupted_download_is_not_ready_even_with_all_files(self):
        self.put_weights()
        self.touch(self.py)
        self.touch(self.pkg / '__init__.py')
        self.assertTrue(mm.status('voxcpm').ok)
        self.touch(Path(model_dirs.VOXCPM_DIR) / mm.FLAG)
        self.assertEqual(mm.status('voxcpm').note, mm.PARTIAL_NOTE)

    def test_file_list_matches_the_client(self):
        import shtorm_vox
        self.assertEqual(sorted(mm.VOXCPM_FILES), sorted(shtorm_vox.REQUIRED_FILES))

    def fake_torch(self, version):
        mod = ModuleType('torch')
        mod.__version__ = version
        return mock.patch.dict(sys.modules, {'torch': mod})

    def test_torch_follows_the_main_environment_cuda(self):
        with self.fake_torch('2.5.1+cu121'):
            self.assertEqual(mm.voxcpm_torch_args(), ['torch==2.5.1', 'torchaudio==2.5.1', '--index-url',
                                                      'https://download.pytorch.org/whl/cu121'])

    def test_torch_falls_back_when_the_main_one_is_unsuitable(self):
        tail = ['--index-url', 'https://download.pytorch.org/whl/' + mm.VOXCPM_TORCH_FALLBACK]
        for version in ('2.8.0+cpu', '2.4.0+cu121', '2.6.0', 'странная'):
            with self.fake_torch(version):
                self.assertEqual(mm.voxcpm_torch_args(), ['torch', 'torchaudio'] + tail, version)
        with mock.patch.dict(sys.modules, {'torch': None}):           # torch в основной среде не импортируется
            self.assertEqual(mm.voxcpm_torch_args(), ['torch', 'torchaudio'] + tail)

    def test_base_python_uses_the_current_one_when_it_fits(self):
        with mock.patch.object(mm, 'console_python', return_value='C:/venv/python.exe'):
            for v in ((3, 10), (3, 11), (3, 12)):
                self.assertEqual(mm.voxcpm_base_python(v), 'C:/venv/python.exe')

    def test_base_python_finds_an_older_one_for_python_313(self):
        calls = []

        def run(cmd, **kw):
            calls.append(cmd[:2])
            ok = cmd[1] == '-3.11'
            return SimpleNamespace(returncode=0 if ok else 1, stdout='C:\\Py311\\python.exe\n' if ok else '', stderr='')
        with mock.patch.object(mm, '_is_windows', return_value=True), mock.patch.object(mm.subprocess, 'run', run):
            self.assertEqual(mm.voxcpm_base_python((3, 13)), 'C:\\Py311\\python.exe')
        self.assertEqual(calls, [['py', '-3.12'], ['py', '-3.11']])

    def test_base_python_explains_when_nothing_fits(self):
        def run(cmd, **kw):
            return SimpleNamespace(returncode=1, stdout='', stderr='')
        with mock.patch.object(mm, '_is_windows', return_value=True), mock.patch.object(mm.subprocess, 'run', run):
            with self.assertRaisesRegex(RuntimeError, 'Python 3.10, 3.11 или 3.12.*3.13'):
                mm.voxcpm_base_python((3, 13))

    def job_fakes(self, env_exists=False, import_ok=True, cuda=True):
        if env_exists:
            self.touch(self.py)
        ran = []

        def run(cmd):
            ran.append([str(c) for c in cmd])
            if len(cmd) > 2 and cmd[1:3] == ['-m', 'venv']:
                self.touch(self.py)
            if cmd[-1] == 'voxcpm':
                self.touch(self.pkg / '__init__.py')

        def download(repo, target, patterns=None):
            ran.append(['download', repo, str(target), list(patterns or [])])
            for name in (patterns or []):
                self.touch(Path(target) / name)

        def check(cmd, **kw):
            ran.append(['check'] + [str(c) for c in cmd[:1]])
            return SimpleNamespace(returncode=0 if import_ok else 1,
                                   stdout=f'torch 2.5.1+cu121 CUDA: {cuda}\n' if import_ok else '',
                                   stderr='' if import_ok else 'ModuleNotFoundError: No module named x')
        return ran, [mock.patch.object(mm, '_run', run), mock.patch.object(mm, '_hf_download', download),
                     mock.patch.object(mm.subprocess, 'run', check),
                     mock.patch.object(mm, 'voxcpm_base_python', return_value='C:/Py312/python.exe'),
                     self.fake_torch('2.5.1+cu121')]

    def run_job(self, patches):
        with contextlib.ExitStack() as stack:
            for p in patches:
                stack.enter_context(p)
            return self.run_quiet(mm.job_voxcpm)

    def test_job_creates_environment_then_torch_then_package_then_weights(self):
        ran, patches = self.job_fakes()
        _code, out = self.run_job(patches)
        self.assertEqual(ran[0], ['C:/Py312/python.exe', '-m', 'venv', str(self.py.parent.parent)])
        pip = [str(self.py), '-m', 'pip', 'install', '--disable-pip-version-check', '--progress-bar', 'off']
        self.assertEqual(ran[1], pip + ['torch==2.5.1', 'torchaudio==2.5.1', '--index-url',
                                        'https://download.pytorch.org/whl/cu121'])
        self.assertEqual(ran[2], pip + ['voxcpm'])
        self.assertEqual(ran[3], ['check', str(self.py)])
        self.assertEqual(ran[4], ['download', mm.VOXCPM_REPO, model_dirs.VOXCPM_DIR, mm.VOXCPM_FILES])
        self.assertFalse((Path(model_dirs.VOXCPM_DIR) / mm.FLAG).exists())
        self.assertTrue(mm.status('voxcpm').ok, mm.status('voxcpm'))
        self.assertNotIn('ВНИМАНИЕ', out)

    def test_job_reuses_an_existing_environment(self):
        ran, patches = self.job_fakes(env_exists=True)
        self.run_job(patches)
        self.assertFalse(any(len(c) > 2 and c[1:3] == ['-m', 'venv'] for c in ran))

    def test_job_warns_when_torch_has_no_cuda_but_still_finishes(self):
        _ran, patches = self.job_fakes(cuda=False)
        _code, out = self.run_job(patches)
        self.assertIn('не видит видеокарту', out)
        self.assertTrue(mm.status('voxcpm').ok)

    def test_job_fails_clearly_when_the_package_does_not_import(self):
        _ran, patches = self.job_fakes(import_ok=False)
        with self.assertRaisesRegex(RuntimeError, 'voxcpm не импортируется'):
            self.run_job(patches)
        self.assertTrue((Path(model_dirs.VOXCPM_DIR) / mm.FLAG).is_file())      # флажок: загрузка не закончена
        self.assertEqual(mm.status('voxcpm').note, mm.PARTIAL_NOTE)

    def test_job_is_registered_for_the_command_line(self):
        self.assertIs(mm.JOBS['voxcpm'], mm.job_voxcpm)
        self.assertIn('voxcpm', mm.COMPONENTS)



# ---------------------------------------------------------------- папка для другого компьютера
PIP_NAMES = {'PIL': 'Pillow', 'numpy': 'numpy', 'soundfile': 'soundfile', 'sounddevice': 'sounddevice',
             'torch': 'torch', 'num2words': 'num2words', 'ruaccent': 'ruaccent', 'pymorphy3': 'pymorphy3',
             'transformers': 'transformers', 'huggingface_hub': 'huggingface_hub',
             'tkinterdnd2': 'tkinterdnd2'}
SEPARATE_ENVIRONMENT = {'pocket_tts', 'voxcpm'}          # ставятся в venv_shtorm / venv_voxcpm, а не в основную среду


def _imports(path):
    tree = ast.parse(Path(path).read_text(encoding='utf-8'))
    names = set()
    for node in ast.walk(tree):                # и ленивые импорты внутри функций тоже
        if isinstance(node, ast.Import):
            names |= {a.name.split('.')[0] for a in node.names}
        elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
            names.add(node.module.split('.')[0])
    return names


class PortableTests(IsolatedModels):
    def setUp(self):
        super().setUp()
        self.target = self.root / 'флешка' / 'BookVoice'

    def listing(self, folder):
        return sorted(p.relative_to(folder).as_posix() for p in Path(folder).rglob('*') if p.is_file())

    def test_every_manifest_file_exists_in_the_project(self):
        required, optional = mm.portable_files()
        self.assertEqual([f for f in required if not (ROOT / f).is_file()], [])
        self.assertEqual(len(required), len(set(required)))
        self.assertTrue(set(optional).isdisjoint(required))

    def test_manifest_is_exactly_the_runtime_import_closure(self):
        # Программа запускается из этих файлов; ни одного лишнего и ни одного недостающего.
        # shtorm_worker, shtorm_vox_worker и model_manager стартуют как отдельные процессы
        entry = ['app', 'shtorm_worker', 'shtorm_vox_worker', 'model_manager']
        seen, todo = set(), list(entry)
        while todo:
            name = todo.pop()
            if name in seen:
                continue
            seen.add(name)
            todo += [n for n in _imports(ROOT / f'{name}.py') if (ROOT / f'{n}.py').is_file()]
        self.assertEqual({f'{n}.py' for n in seen}, set(mm.PORTABLE_CODE))

    def test_requirements_cover_every_third_party_import(self):
        std = sys.stdlib_module_names
        local = {Path(f).stem for f in mm.PORTABLE_CODE}
        third = set()
        for f in mm.PORTABLE_CODE:
            third |= {n for n in _imports(ROOT / f) if n not in std and n not in local}
        third -= SEPARATE_ENVIRONMENT
        unknown = sorted(third - set(PIP_NAMES))
        self.assertEqual(unknown, [], 'добавь пакет в PIP_NAMES теста и в requirements.txt')
        listed = set()
        for line in (ROOT / 'requirements.txt').read_text(encoding='utf-8').splitlines():
            line = line.split('#')[0].strip()
            if line:
                listed.add(re.split(r'[<>=!~\[; ]', line)[0].lower().replace('_', '-'))
        for name in sorted(third):
            self.assertIn(PIP_NAMES[name].lower().replace('_', '-'), listed, name)
        self.assertIn('onnxruntime', listed)                       # его требует TeraTTS, прямого import в коде нет

    def test_build_copies_only_what_is_needed(self):
        copied, notes = mm.build_portable(self.target, lock=False)
        required, optional = mm.portable_files()
        expected = set(required) | {f for f in optional if (ROOT / f).is_file()} | {'PYTHON_VERSION.txt'}
        self.assertEqual(set(copied), expected)
        self.assertEqual(set(self.listing(self.target)), expected)
        for name in required:
            self.assertEqual((self.target / name).read_bytes(), (ROOT / name).read_bytes(), name)
        self.assertEqual((self.target / 'PYTHON_VERSION.txt').read_text(encoding='ascii'),
                         f'{sys.version_info[0]}.{sys.version_info[1]}\n')
        for junk in ('settings.json', 'bookvoice.bat', 'install_tera.bat', 'app_silero.py', 'speak_silero.py',
                     'test.py', 'rename_folder.bat', 'move_app.py'):
            self.assertFalse((self.target / junk).exists(), junk)
        self.assertFalse((self.target / 'tests').exists())
        self.assertEqual(notes, [])

    def test_build_adds_exact_package_versions(self):
        def fake_lock(path):
            Path(path).write_text('numpy==1.26.4\n', encoding='utf-8')
            return Path(path), 1
        with mock.patch.object(mm, 'write_lockfile', fake_lock):
            copied, notes = mm.build_portable(self.target)
        self.assertIn('requirements.lock.txt', copied)
        self.assertEqual((self.target / 'requirements.lock.txt').read_text(encoding='utf-8'), 'numpy==1.26.4\n')
        self.assertTrue(any('версии пакетов сохранены (1 шт.)' in n for n in notes), notes)

    def test_build_survives_a_failing_pip_freeze(self):
        with mock.patch.object(mm, 'write_lockfile', side_effect=RuntimeError('pip сломался')):
            copied, notes = mm.build_portable(self.target)
        self.assertNotIn('requirements.lock.txt', copied)
        self.assertFalse((self.target / 'requirements.lock.txt').exists())
        self.assertTrue(any('pip сломался' in n and 'requirements.txt' in n for n in notes), notes)
        self.assertTrue((self.target / 'start.bat').is_file())

    def test_build_refuses_a_target_inside_the_program_folder_or_the_folder_itself(self):
        inside = ROOT / 'bookvoice_test_must_not_appear'
        for bad in (inside, ROOT, ROOT.parent):
            with self.assertRaisesRegex(RuntimeError, 'вне папки программы'):
                mm.build_portable(bad, lock=False)
        self.assertFalse(inside.exists())

    def test_build_reports_missing_program_files(self):
        base = self.root / 'неполная'
        self.touch(base / 'app.py')
        with self.assertRaisesRegex(RuntimeError, r'не хватает файлов: .*bookio\.py'):
            mm.build_portable(self.target, lock=False, base=base)
        self.assertFalse(self.target.exists())

    def test_rebuild_updates_files_and_keeps_everything_else(self):
        mm.build_portable(self.target, lock=False)
        (self.target / 'app.py').write_text('старая версия', encoding='utf-8')
        for keep in ('venv/Scripts/python.exe', 'models/silero/v5_6_ru.pt', 'settings.json', 'out/1.mp3'):
            self.touch(self.target / keep, b'user data')
        mm.build_portable(self.target, lock=False)
        self.assertEqual((self.target / 'app.py').read_bytes(), (ROOT / 'app.py').read_bytes())
        for keep in ('venv/Scripts/python.exe', 'models/silero/v5_6_ru.pt', 'settings.json', 'out/1.mp3'):
            self.assertEqual((self.target / keep).read_bytes(), b'user data')

    def test_dictionary_files_are_optional(self):
        base = self.root / 'копия'
        base.mkdir()
        required, optional = mm.portable_files()
        for name in required:
            self.touch(base / name)
        copied, _notes = mm.build_portable(self.target, lock=False, base=base)
        self.assertFalse(any(f in copied for f in optional))
        self.touch(base / 'словарь.txt', 'слово=слово\n'.encode('utf-8'))
        copied, _notes = mm.build_portable(self.target, lock=False, base=base)
        self.assertIn('словарь.txt', copied)

    def test_command_line_builds_the_folder(self):
        with mock.patch.object(mm, 'write_lockfile', side_effect=RuntimeError('нет pip')):
            code, out = self.run_quiet(mm.main, ['model_manager.py', 'portable', str(self.target)])
        self.assertEqual(code, 0)
        self.assertIn('app.py', out)
        self.assertTrue((self.target / 'start.bat').is_file())


class StartBatTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw = (ROOT / 'start.bat').read_bytes()
        cls.text = cls.raw.decode('ascii')                      # только ASCII: кодовая страница cmd не помешает
        cls.lines = cls.text.split('\r\n')

    def test_crlf_only(self):
        self.assertTrue(self.raw.endswith(b'\r\n'))
        stripped = self.raw.replace(b'\r\n', b'')
        self.assertNotIn(b'\n', stripped)
        self.assertNotIn(b'\r', stripped)

    def test_no_multiline_parenthesis_blocks_and_no_activate(self):
        for n, line in enumerate(self.lines, 1):
            s = line.strip()
            self.assertFalse(s.endswith('('), f'строка {n}: многострочный блок')
            self.assertFalse(s.startswith(')'), f'строка {n}: многострочный блок')
        commands = [l for l in self.lines if not l.lower().startswith('rem ')]
        self.assertFalse(any('activate' in l.lower() for l in commands), 'venv не активируется: его python.exe зовётся напрямую')

    def test_every_goto_has_its_label(self):
        labels = {l[1:].strip().lower() for l in self.lines if l.startswith(':') and not l.startswith('::')}
        targets = {t.lower() for t in re.findall(r'goto\s+:?(\w+)', self.text, re.I)} - {'eof'}
        self.assertEqual(sorted(targets - labels), [])
        self.assertEqual(len(labels), len([l for l in self.lines if l.startswith(':') and not l.startswith('::')]))

    def test_python_of_the_venv_is_started_directly(self):
        self.assertIn('"venv\\Scripts\\python.exe" app.py', self.text)
        self.assertIn('cd /d "%~dp0"', self.text)
        self.assertNotIn('pythonw', self.text.lower())

    def test_install_flow(self):
        t = self.text
        for needle in ('PYTHON_VERSION.txt', 'requirements.lock.txt', 'requirements.txt', 'bookvoice_ready.txt',
                       'import tkinter', 'struct.calcsize'):
            self.assertIn(needle, t)
        # выбор Python: сначала версия с основного компьютера, потом остальные
        self.assertLess(t.index('py -%PYVER%'), t.index('for %%v in (3.12 3.11 3.13 3.10)'))
        # пакеты ставятся до того, как поставлена отметка «готово», а отметку проверяет каждый запуск
        self.assertLess(t.index('-r requirements.lock.txt'), t.index('echo ok> "venv\\bookvoice_ready.txt"'))
        self.assertLess(t.index('-r requirements.txt'), t.index('echo ok> "venv\\bookvoice_ready.txt"'))
        self.assertLess(t.index('if not exist "venv\\bookvoice_ready.txt" goto install'), t.index(':findpython'))
        # проверка импортов перед отметкой
        self.assertLess(t.index('import numpy, soundfile'), t.index('echo ok>'))

    def test_only_the_new_venv_is_ever_deleted(self):
        for line in self.lines:
            if 'rmdir' in line.lower() or ' del ' in f' {line.lower()} ':
                self.assertEqual(line.strip(), 'rmdir /s /q "venv"')

    def test_messages_are_ascii_english(self):
        self.assertNotRegex(self.text, r'[^\x20-\x7e\r\n]')


class ReadmeTests(unittest.TestCase):
    def test_readme_for_the_other_computer(self):
        raw = (ROOT / 'README_ПЕРЕНОС.txt').read_bytes()
        text = raw.decode('utf-8-sig')
        for needle in ('start.bat', 'PYTHON_VERSION.txt', 'requirements.lock.txt', '⚙', 'Модели', 'Python'):
            self.assertIn(needle, text)
        self.assertIn(b'\r\n', raw)                                 # блокнот Windows


class RequirementsFileTests(unittest.TestCase):
    def test_plain_ascii_and_installable_lines(self):
        data = (ROOT / 'requirements.txt').read_bytes().decode('ascii')
        for line in data.splitlines():
            line = line.strip()
            if line and not line.startswith('#'):
                self.assertRegex(line, r'^[A-Za-z0-9][A-Za-z0-9._-]*([<>=!~]=?[0-9A-Za-z.*]+)?$', line)


# ---------------------------------------------------------------- окна и меню (упрощённый tkinter)
class FakeVar:
    def __init__(self, master=None, value=None, **kw):
        self.v = value

    def get(self):
        return self.v

    def set(self, v):
        self.v = v


class TclError(Exception):
    pass


class W:
    """Любой виджет: помнит параметры, остальные вызовы (pack, bind, ...) пропускает."""

    def __init__(self, *a, **kw):
        self.opts, self.calls, self.destroyed = dict(kw), [], False

    def configure(self, cnf=None, **kw):
        self.opts.update(cnf or {})
        self.opts.update(kw)

    config = configure

    def __getitem__(self, key):
        return self.opts.get(key)

    def __setitem__(self, key, value):
        self.opts[key] = value

    def winfo_exists(self):
        return 0 if self.destroyed else 1

    def destroy(self):
        self.destroyed = True

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(name)
        return lambda *a, **k: self.calls.append((name, a, k))


class TextW(W):
    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.content = ''

    def insert(self, index, text, *tags):
        if self.opts.get('state') != 'disabled':
            self.content += text

    def index(self, index):
        return f'{self.content.count(chr(10)) + 1}.0'          # как в Tk: «строка конца текста»

    def delete(self, first, last=None):
        self.content = '\n'.join(self.content.split('\n')[int(last.split('.')[0]) - 1:])


class FakeRunner:
    def __init__(self, on_event):
        self.on_event, self.started, self.cancelled, self.busy = on_event, [], 0, False

    def start(self, ids):
        if self.busy:
            return False
        self.started.append(list(ids))
        self.busy = True
        return True

    def running(self):
        return self.busy

    def cancel(self):
        self.cancelled += 1


class ImmediateThread:
    """Поток, который выполняется сразу: окна не ждут настоящих потоков."""

    def __init__(self, target=None, args=(), kwargs=None, daemon=None):
        self.target, self.args, self.kwargs = target, args, kwargs or {}

    def start(self):
        self.target(*self.args, **self.kwargs)


FAKE_TK = SimpleNamespace(Toplevel=W, BooleanVar=FakeVar, TclError=TclError, Menu=W)
FAKE_TTK = SimpleNamespace(Frame=W, Label=W, Button=W, Checkbutton=W, Progressbar=W, Scrollbar=W, Menubutton=W)


class UiCase(IsolatedModels):
    """Окна models_ui на упрощённом tkinter, диалоги записываются вместо показа."""

    def setUp(self):
        super().setUp()
        try:
            import models_ui
        except Exception as e:
            self.skipTest(f'models_ui не импортируется здесь: {e!r}')
        self.ui = models_ui
        self.dialogs, self.answer = [], True
        for target, name, value in ((models_ui, 'tk', FAKE_TK), (models_ui, 'ttk', FAKE_TTK),
                                    (models_ui.threading, 'Thread', ImmediateThread)):
            patcher = mock.patch.object(target, name, value)
            patcher.start()
            self.addCleanup(patcher.stop)
        for kind in ('showinfo', 'showerror', 'showwarning'):
            patcher = mock.patch.object(models_ui.messagebox, kind,
                                        lambda title=None, message=None, _k=kind, **kw: self.dialogs.append((_k, title, message)))
            patcher.start()
            self.addCleanup(patcher.stop)
        patcher = mock.patch.object(models_ui.messagebox, 'askyesno',
                                    lambda title=None, message=None, **kw: self.dialogs.append(('askyesno', title, message)) or self.answer)
        patcher.start()
        self.addCleanup(patcher.stop)
        patcher = mock.patch.object(mm, 'free_space', return_value=10 ** 12)
        patcher.start()
        self.addCleanup(patcher.stop)
        self.logs, self.changed, self.saved = [], [], []
        self.app = SimpleNamespace(
            root=SimpleNamespace(winfo_screenwidth=lambda: 1920, winfo_screenheight=lambda: 1080),
            colors=dict(BG='#1b1c23', PANEL='#252733', FG='#ece8e1', MUTED='#8d8f9c', ACCENT='#d2ad6b'),
            textbox=lambda parent, height: TextW(), ui=lambda fn: fn(), log=self.logs.append,
            models_win=None, models_changed=lambda done: self.changed.append(list(done)),
            choose_models_dir=lambda: self.logs.append('choose_models_dir'), models_dir_cfg=None,
            save_cfg=lambda: self.saved.append(self.app.models_dir_cfg), refresh_models_window=lambda: None,
            models_loaded=lambda: False)

    def kinds(self):
        return [d[0] for d in self.dialogs]


class ModelsWindowTests(UiCase):
    def window(self, banner=''):
        self.win = self.ui.ModelsWindow(self.app, banner=banner, runner_factory=FakeRunner)
        self.app.models_win = self.win
        return self.win

    def required_present(self):
        self.touch(model_dirs._model_file())
        self.touch(Path(model_dirs.RUACCENT_DIR) / 'nn' / 'nn_omograph' / 'turbo' / 'model.onnx')

    def test_lists_every_component_and_preselects_what_is_required(self):
        win = self.window()
        self.assertEqual(list(win.rows), mm.COMPONENTS)
        self.assertEqual(win.selected(), ['silero', 'ruaccent'])
        self.assertTrue(all(r['state'].opts['text'].startswith('✗ нет') for r in win.rows.values()))
        self.assertEqual(win.dir_lbl.opts['text'], model_dirs.MODELS_DIR)
        self.assertIn('Свободно', win.free_lbl.opts['text'])

    def test_installed_components_are_marked_and_not_selected(self):
        self.touch(model_dirs._model_file(), b'x' * 2048)
        win = self.window()
        self.assertTrue(win.rows['silero']['state'].opts['text'].startswith('✓ есть'))
        self.assertEqual(win.selected(), ['ruaccent'])

    def test_manual_choice_survives_refresh(self):
        win = self.window()
        win.rows['tera']['var'].set(True)
        win.rows['silero']['var'].set(False)
        win.touched = True
        win.refresh()
        self.assertEqual(win.selected(), ['ruaccent', 'tera'])

    def test_banner(self):
        win = self.window(banner='Не хватает моделей')
        self.assertEqual(win.banner.opts['text'], 'Не хватает моделей')
        win.show_banner('другое')
        self.assertEqual(win.banner.opts['text'], 'другое')

    def test_start_runs_the_selection_and_locks_the_buttons(self):
        win = self.window()
        self.assertTrue(win.start())
        self.assertEqual(win.runner.started, [['silero', 'ruaccent']])
        self.assertEqual((win.b_start.opts['state'], win.b_stop.opts['state']), ('disabled', 'normal'))
        self.assertIn('Начинаю', win.log_txt.content)
        self.assertFalse(win.start())                                  # второй запуск при идущем
        self.assertIn('showinfo', self.kinds())

    def test_start_with_nothing_ticked_says_so(self):
        win = self.window()
        for row in win.rows.values():
            row['var'].set(False)
        self.assertFalse(win.start())
        self.assertEqual(win.runner.started, [])
        self.assertIn('Отметь', self.dialogs[-1][2])

    def test_low_disk_space_asks_first(self):
        win = self.window()
        with mock.patch.object(mm, 'free_space', return_value=50 << 20):
            self.answer = False
            self.assertFalse(win.start())
            self.assertEqual(win.runner.started, [])
            self.assertEqual(self.dialogs[-1][1], 'Мало места')
            self.answer = True
            self.assertTrue(win.start())
        self.assertEqual(len(win.runner.started), 1)

    def test_start_with_explicit_components(self):
        win = self.window()
        self.assertTrue(win.start(['silero_update']))
        self.assertEqual(win.runner.started, [['silero_update']])
        self.assertIn('Silero: обновление репозитория', win.log_txt.content)

    def test_progress_and_log_events(self):
        win = self.window()
        win.on_event(('start', 'tera'))
        self.assertIn('TeraTTS v2', win.stage_lbl.opts['text'])
        self.assertIn('начинаю', win.stage_lbl.opts['text'])
        win.on_event(('stage', 'tera', 'Скачиваю модель'))
        self.assertEqual(win.stage_lbl.opts['text'], 'Скачиваю модель')
        self.assertIn('# Скачиваю модель', win.log_txt.content)
        win.on_event(('total', 'tera', 2000))
        win.on_event(('progress', 'tera', 500, None))                  # всего узнали заранее
        self.assertEqual(win.pb.opts['value'], 25.0)
        self.assertEqual(win.pb.opts['mode'], 'determinate')
        self.assertIn('25%', win.stage_lbl.opts['text'])
        win.on_event(('progress', 'tera', 5000, 2000))                 # больше «всего» не бывает
        self.assertEqual(win.pb.opts['value'], 100.0)
        win.on_event(('progress', 'ruaccent', 123 << 20, None))        # размер заранее неизвестен
        self.assertIn('скачано 123 МБ', win.stage_lbl.opts['text'])
        win.on_event(('log', 'tera', 'Downloading shard 1'))
        self.assertIn('Downloading shard 1', win.log_txt.content)

    def test_end_and_finished_events(self):
        win = self.window()
        win.start()
        win.on_event(('end', 'silero', True, 'готово'))
        win.on_event(('end', 'ruaccent', False, 'нет сети'))
        self.assertIn('✓ Silero (основной движок, голоса): готово', win.log_txt.content)
        self.assertIn('✗ RUAccent (расстановка ударений): нет сети', win.log_txt.content)
        win.runner.busy = False
        win.on_event(('finished', ['silero'], ['ruaccent'], False))
        self.assertEqual(win.stage_lbl.opts['text'],
                         'Не удалось: RUAccent (расстановка ударений). Подробности в журнале ниже.')
        self.assertEqual((win.b_start.opts['state'], win.b_stop.opts['state']), ('normal', 'disabled'))
        self.assertEqual(self.changed, [['silero']])                   # программа узнаёт, что скачано
        win.on_event(('finished', [], [], True))
        self.assertEqual(win.stage_lbl.opts['text'], 'Остановлено.')
        win.on_event(('finished', ['tera'], [], False))
        self.assertEqual(win.stage_lbl.opts['text'], 'Готово.')
        self.assertEqual(self.changed[-1], ['tera'])

    def test_status_is_rechecked_after_each_component(self):
        win = self.window()
        self.assertTrue(win.rows['silero']['state'].opts['text'].startswith('✗'))
        self.touch(model_dirs._model_file())
        win.on_event(('end', 'silero', True, 'готово'))
        self.assertTrue(win.rows['silero']['state'].opts['text'].startswith('✓'))

    def test_closing_while_downloading_asks_and_cancels(self):
        win = self.window()
        win.start()
        self.answer = False
        win.close()
        self.assertEqual(win.runner.cancelled, 0)
        self.assertFalse(win.win.destroyed)
        self.assertIs(self.app.models_win, win)
        self.answer = True
        win.close()
        self.assertEqual(win.runner.cancelled, 1)
        self.assertTrue(win.win.destroyed)
        self.assertIsNone(self.app.models_win)

    def test_closing_an_idle_window_does_not_ask(self):
        win = self.window()
        win.close()
        self.assertEqual(self.dialogs, [])
        self.assertTrue(win.win.destroyed)
        self.assertFalse(win.alive())

    def test_stop_button(self):
        win = self.window()
        win.start()
        win.stop()
        self.assertEqual(win.runner.cancelled, 1)
        self.assertEqual(win.stage_lbl.opts['text'], 'Останавливаю…')

    def test_changing_the_folder_is_blocked_while_downloading(self):
        win = self.window()
        win._choose_dir()
        self.assertEqual(self.logs, ['choose_models_dir'])
        win.start()
        self.logs.clear()
        win._choose_dir()
        self.assertEqual(self.logs, [])
        self.assertEqual(self.dialogs[-1][0], 'showinfo')

    def test_events_come_through_the_interface_thread(self):
        handed = []
        self.app.ui = lambda fn: handed.append(fn)
        win = self.window()
        win._on_event_thread(('log', 'tera', 'строка'))
        self.assertEqual(len(handed), 1)                                # само окно не трогаем из чужого потока
        self.assertNotIn('строка', win.log_txt.content)
        handed[0]()
        self.assertIn('строка', win.log_txt.content)
        win.win.destroy()
        win._on_event_thread(('log', 'tera', 'после закрытия'))
        handed[1]()
        self.assertNotIn('после закрытия', win.log_txt.content)

    def test_log_keeps_the_last_600_lines(self):
        win = self.window()
        for i in range(700):
            win.on_event(('log', 'tera', f'строка {i}'))
        lines = win.log_txt.content.splitlines()
        self.assertEqual((len(lines), lines[0], lines[-1]), (600, 'строка 100', 'строка 699'))


class SettingsMenuTests(UiCase):
    def test_menu_entries_and_what_they_call(self):
        called = []
        entries = []

        class Menu(W):
            def add_command(self, **kw):
                entries.append(kw)

            def add_separator(self):
                entries.append(None)
        app = SimpleNamespace(colors=self.app.colors, **{name: (lambda n=name: called.append(n)) for name in (
            'open_models', 'open_ruaccent', 'choose_models_dir', 'update_silero', 'show_report',
            'clean_old_cache', 'build_portable', 'save_lockfile')})
        with mock.patch.object(self.ui.tk, 'Menu', Menu), \
                mock.patch.object(self.ui, 'open_path', lambda p: called.append(('open', str(p)))):
            btn, menu = self.ui.build_settings_menu(app, parent=W())
            self.assertEqual(btn.opts['text'], '⚙')
            self.assertIs(btn.opts['menu'], menu)
            labels = [e['label'] if e else '---' for e in entries]
            self.assertEqual(labels, [
                'Модели: скачать и проверить…', 'Модели ударений RUAccent…', 'Папка моделей…',
                'Открыть папку моделей', 'Открыть папку программы',
                '---', 'Обновить Silero (новые версии модели)', 'Что где лежит (отчёт)',
                'Очистить старый кэш на диске C:…', '---', 'Собрать папку для другого компьютера…',
                'Сохранить версии пакетов (requirements.lock.txt)'])
            for e in entries:                       # команды зовутся, пока open_path подменён: проводник не открывается
                if e:
                    e['command']()
        self.assertEqual(called, ['open_models', 'open_ruaccent', 'choose_models_dir', ('open', model_dirs.MODELS_DIR),
                                  ('open', str(model_dirs.BASE)), 'update_silero', 'show_report',
                                  'clean_old_cache', 'build_portable', 'save_lockfile'])

    def test_open_path_creates_the_folder_and_opens_it(self):
        target = self.root / 'новая' / 'папка'
        with mock.patch.object(os, 'startfile', create=True) as startfile, \
                mock.patch.object(self.ui.subprocess, 'Popen') as popen:
            self.ui.open_path(target)
        self.assertTrue(target.is_dir())
        opened = startfile.call_args_list or popen.call_args_list
        self.assertEqual(len(opened), 1)
        self.assertIn(str(target), str(opened[0]))


class MenuActionTests(UiCase):
    def test_choose_models_dir(self):
        configured = []
        new = self.root / 'диск' / 'модели'
        with mock.patch.object(model_dirs, 'configure', configured.append), \
                mock.patch.object(self.ui.filedialog, 'askdirectory', return_value=''):
            self.assertFalse(self.ui.choose_models_dir(self.app))              # отмена
        self.assertEqual((configured, self.dialogs), ([], []))
        with mock.patch.object(model_dirs, 'configure', configured.append), \
                mock.patch.object(self.ui.filedialog, 'askdirectory', return_value=model_dirs.MODELS_DIR):
            self.assertFalse(self.ui.choose_models_dir(self.app))              # та же папка
        self.assertEqual(configured, [])
        self.app.models_loaded = lambda: True
        with mock.patch.object(model_dirs, 'configure', configured.append), \
                mock.patch.object(self.ui.filedialog, 'askdirectory', return_value=str(new)):
            self.assertTrue(self.ui.choose_models_dir(self.app))
        self.assertEqual(configured, [str(new)])
        self.assertTrue(new.is_dir())
        self.assertEqual((self.app.models_dir_cfg, self.saved), (str(new), [str(new)]))     # запомнилась в настройках
        self.assertIn('после перезапуска', self.dialogs[-1][2])
        self.assertIn(f'Папка моделей: {new}', self.logs)

    def test_choose_models_dir_that_cannot_be_created(self):
        blocker = self.touch(self.root / 'файл.txt')
        with mock.patch.object(model_dirs, 'configure') as configure, \
                mock.patch.object(self.ui.filedialog, 'askdirectory', return_value=str(blocker / 'внутри')):
            self.assertFalse(self.ui.choose_models_dir(self.app))
        configure.assert_not_called()
        self.assertEqual(self.dialogs[-1][0], 'showerror')
        self.assertIsNone(self.app.models_dir_cfg)

    def test_build_portable_folder(self):
        dest = self.root / 'флешка'
        dest.mkdir()
        built = []

        def fake_build(target):
            built.append(Path(target))
            return ['app.py', 'start.bat'], ['версии пакетов сохранены (3 шт.), start.bat поставит именно их']
        with mock.patch.object(self.ui.filedialog, 'askdirectory', return_value=''):
            self.ui.build_portable(self.app)                                   # отмена
        self.assertEqual(built, [])
        with mock.patch.object(self.ui.filedialog, 'askdirectory', return_value=str(dest)), \
                mock.patch.object(mm, 'build_portable', fake_build):
            self.ui.build_portable(self.app)
        self.assertEqual(built, [dest / 'BookVoice'])
        kind, title, message = self.dialogs[-1]
        self.assertEqual(kind, 'showinfo')
        for needle in (str(dest / 'BookVoice'), 'Файлов: 2', 'версии пакетов сохранены', 'start.bat', 'Модели'):
            self.assertIn(needle, message)

    def test_build_portable_asks_before_touching_a_non_empty_folder(self):
        dest = self.root / 'флешка'
        self.touch(dest / 'BookVoice' / 'old.txt')
        built = []
        with mock.patch.object(self.ui.filedialog, 'askdirectory', return_value=str(dest)), \
                mock.patch.object(mm, 'build_portable', lambda t: built.append(t) or ([], [])):
            self.answer = False
            self.ui.build_portable(self.app)
            self.assertEqual(built, [])
            self.assertEqual(self.dialogs[-1][0], 'askyesno')
            self.answer = True
            self.ui.build_portable(self.app)
        self.assertEqual(len(built), 1)

    def test_build_portable_error_is_shown(self):
        with mock.patch.object(self.ui.filedialog, 'askdirectory', return_value=str(self.root)), \
                mock.patch.object(mm, 'build_portable', side_effect=RuntimeError('Выбери папку вне папки программы')):
            self.ui.build_portable(self.app)
        self.assertEqual(self.dialogs[-1][0], 'showerror')
        self.assertIn('вне папки программы', self.dialogs[-1][2])

    def test_save_lockfile(self):
        with mock.patch.object(mm, 'write_lockfile', return_value=(self.root / 'requirements.lock.txt', 42)):
            self.ui.save_lockfile(self.app)
        self.assertEqual(self.dialogs[-1][0], 'showinfo')
        self.assertIn('Сохранено пакетов: 42', self.dialogs[-1][2])
        with mock.patch.object(mm, 'write_lockfile', side_effect=RuntimeError('pip сломался')):
            self.ui.save_lockfile(self.app)
        self.assertEqual(self.dialogs[-1][:1] + self.dialogs[-1][2:], ('showerror', 'pip сломался'))

    def test_report_shows_folders_and_component_states(self):
        shown = []
        with mock.patch.object(self.ui, '_text_window', lambda app, title, text, **kw: shown.append((title, text))), \
                mock.patch.object(model_dirs, 'report', lambda: print('ОТЧЁТ О ПАПКАХ')):
            self.ui.show_report(self.app)
        title, text = shown[0]
        self.assertEqual(title, 'Что где лежит')
        self.assertIn('ОТЧЁТ О ПАПКАХ', text)
        self.assertIn('Состояние моделей:', text)
        for cid in mm.COMPONENTS:
            self.assertIn(self.ui.TITLES[cid], text)

    def test_clean_old_cache_nothing_to_clean(self):
        with mock.patch.object(model_dirs, 'clean_plan', return_value=([], [])):
            self.ui.clean_old_cache(self.app)
        self.assertEqual(self.dialogs[-1][:1], ('showinfo',))
        self.assertIn('удалять нечего', self.dialogs[-1][2])
        with mock.patch.object(model_dirs, 'clean_plan', side_effect=RuntimeError('нет домашней папки')):
            self.ui.clean_old_cache(self.app)
        self.assertIn('удалять нечего', self.dialogs[-1][2])

    def test_clean_old_cache_deletes_only_after_consent(self):
        old = self.root / 'C' / 'torch' / 'hub' / 'snakers4_silero-models_master'
        todo = [('Silero', old, 5 << 20, '')]
        ran = []
        with mock.patch.object(model_dirs, 'clean_plan', return_value=(todo, [])), \
                mock.patch.object(model_dirs, 'clean_run', lambda t: ran.append(t) or (5 << 20, [])):
            self.answer = False
            self.ui.clean_old_cache(self.app)
            self.assertEqual(ran, [])
            asked = [d for d in self.dialogs if d[0] == 'askyesno'][-1]
            self.assertIn(str(old), asked[2])
            self.assertIn('RUAccent и чужие модели не трогаю', asked[2])
            self.answer = True
            self.ui.clean_old_cache(self.app)
        self.assertEqual(ran, [todo])
        self.assertIn('Освобождено 5 МБ', self.dialogs[-1][2])

    def test_clean_old_cache_reports_what_it_could_not_delete(self):
        old = self.root / 'C' / 'old'
        with mock.patch.object(model_dirs, 'clean_plan', return_value=([('TeraTTS', old, 1 << 20, '')], [])), \
                mock.patch.object(model_dirs, 'clean_run', return_value=(0, [(old, OSError('занято'))])):
            self.ui.clean_old_cache(self.app)
        self.assertIn('Не удалось удалить', self.dialogs[-1][2])
        self.assertIn('занято', self.dialogs[-1][2])

    def test_clean_old_cache_only_keep_items_just_explains(self):
        old = self.root / 'C' / 'old'
        with mock.patch.object(model_dirs, 'clean_plan',
                               return_value=([], [('Silero', old, 1 << 20, 'на новом месте нет целой копии')])):
            self.ui.clean_old_cache(self.app)
        self.assertEqual([d[0] for d in self.dialogs], ['showinfo'])
        self.assertIn('на новом месте нет целой копии', self.dialogs[-1][2])


# ---------------------------------------------------------------- связка с программой (app.py)
class AppGlueTests(IsolatedModels):
    def setUp(self):
        super().setUp()
        try:
            import app
        except Exception as e:
            self.skipTest(f'app не импортируется здесь: {e!r}')
        self.app = app

    def required_present(self):
        self.touch(model_dirs._model_file())
        self.touch(Path(model_dirs.RUACCENT_DIR) / 'nn' / 'nn_omograph' / 'turbo' / 'model.onnx')

    def test_models_hint_opens_the_window_with_what_is_missing(self):
        calls = []
        fake = SimpleNamespace(log=lambda m: calls.append(('log', m)), open_models=lambda **kw: calls.append(('open', kw)))
        self.app.App.models_hint(fake)
        opened = [c for c in calls if c[0] == 'open']
        self.assertEqual(len(opened), 1)
        self.assertIn('Silero', opened[0][1]['banner'])
        self.assertIn('RUAccent', opened[0][1]['banner'])
        self.assertTrue(any('⚙' in c[1] for c in calls if c[0] == 'log'))
        # модели на месте, а загрузка всё равно не удалась: причина другая, окно моделей не нужно
        self.required_present()
        calls.clear()
        self.app.App.models_hint(fake)
        self.assertEqual([c[0] for c in calls], ['log'])
        self.assertIn('на месте', calls[0][1])

    def test_failed_start_up_load_opens_the_models_window(self):
        hints, logs = [], []
        fake = SimpleNamespace(log=logs.append, ui=lambda fn: fn(), models_hint=lambda: hints.append(1))
        with mock.patch.dict(sys.modules, {'speak': None}), mock.patch.object(self.app, 'speak', None):
            self.app.App._load(fake)                       # import speak падает: нет моделей, нет сети
        self.assertEqual(hints, [1])
        self.assertTrue(any(m.startswith('Ошибка загрузки') for m in logs), logs)

    def test_downloaded_models_start_loading_without_restart(self):
        reloads = []
        fake = SimpleNamespace(reload_models=lambda: reloads.append(1))
        self.required_present()
        with mock.patch.object(self.app, 'speak', None):
            self.app.App.models_changed(fake, ['silero'])
            self.assertEqual(reloads, [1])
            self.app.App.models_changed(fake, [])                    # ничего не скачано
            self.assertEqual(reloads, [1])
        with mock.patch.object(self.app, 'speak', object()):         # модели уже загружены
            self.app.App.models_changed(fake, ['tera'])
        self.assertEqual(reloads, [1])

    def test_no_loading_while_required_models_are_still_missing(self):
        reloads = []
        fake = SimpleNamespace(reload_models=lambda: reloads.append(1))
        with mock.patch.object(self.app, 'speak', None):
            self.app.App.models_changed(fake, ['tera'])             # скачали только TeraTTS: Silero ещё нет
        self.assertEqual(reloads, [])

    def test_downloaded_ffmpeg_is_found_right_away(self):
        exe = self.touch(Path(model_dirs.FFMPEG_DIR) / ('ffmpeg.exe' if os.name == 'nt' else 'ffmpeg'))
        os.environ['PATH'] = '/nowhere'
        fake = SimpleNamespace(reload_models=lambda: None)
        with mock.patch.object(self.app, 'speak', object()):
            self.app.App.models_changed(fake, ['ffmpeg'])
        self.assertTrue(os.environ['PATH'].startswith(str(exe.parent)))

    def close_fake(self, win, calls):
        return SimpleNamespace(
            models_win=win, tab_edit=SimpleNamespace(is_dirty=lambda: False),
            save_dict=lambda: calls.append('save_dict'), save_cfg=lambda: calls.append('save_cfg'),
            stop_flag=SimpleNamespace(set=lambda: calls.append('stop')),
            player=SimpleNamespace(close=lambda: calls.append('player')),
            root=SimpleNamespace(destroy=lambda: calls.append('destroy')))

    def test_closing_the_program_stops_a_running_download(self):
        calls = []
        win = SimpleNamespace(alive=lambda: True, running=lambda: True,
                              runner=SimpleNamespace(cancel=lambda: calls.append('cancel')))
        fake = self.close_fake(win, calls)
        with mock.patch.object(self.app.messagebox, 'askyesno', return_value=False) as ask:
            self.app.App.on_close(fake)
        self.assertEqual(calls, [])                                   # передумал: программа остаётся
        self.assertIn('скачивание', ask.call_args[0][1].lower())
        with mock.patch.object(self.app.messagebox, 'askyesno', return_value=True):
            self.app.App.on_close(fake)
        self.assertLess(calls.index('cancel'), calls.index('destroy'))

    def test_closing_with_an_idle_models_window_does_not_ask(self):
        calls = []
        win = SimpleNamespace(alive=lambda: True, running=lambda: False,
                              runner=SimpleNamespace(cancel=lambda: calls.append('cancel')))
        with mock.patch.object(self.app.messagebox, 'askyesno', side_effect=AssertionError('не должна спрашивать')):
            self.app.App.on_close(self.close_fake(win, calls))
        self.assertIn('destroy', calls)

    def test_chosen_models_folder_is_remembered_for_the_next_start(self):
        settings = self.root / 'settings.json'
        fake = SimpleNamespace(
            remember_voice=lambda: None, engine=FakeVar(value='silero'), cfg={}, voice_by_engine={'silero': 'xenia'},
            tera_speed=FakeVar(value=1.0), tera_g=FakeVar(value=False), shtorm_variant=FakeVar(value='fast'),
            shtorm_voice_ref=FakeVar(value=''), voxcpm_voice_ref=FakeVar(value=''), voxcpm_prompt=FakeVar(value=''),
            voxcpm_cfg=FakeVar(value='2.0'), voxcpm_steps=FakeVar(value='10'),
            pause_level=FakeVar(value=3), models_dir_cfg='E:\\Модели')
        with mock.patch.object(self.app, 'SETTINGS', settings), mock.patch.object(model_dirs, 'SETTINGS_FILE', settings), \
                mock.patch.object(self.app, 'speak', None):
            self.app.App.save_cfg(fake)
            self.assertEqual(model_dirs._saved_base(), 'E:\\Модели')   # то же читает model_dirs при следующем запуске
            fake.models_dir_cfg = None
            self.app.App.save_cfg(fake)
            self.assertIsNone(model_dirs._saved_base())

    def test_help_text_describes_the_gear_menu_and_has_no_stale_commands(self):
        help_text = self.app.HELP_TEXT
        for needle in ('⚙', 'Собрать папку для другого компьютера', 'start.bat', 'Папка моделей'):
            self.assertIn(needle, help_text)
        for stale in ('командой install_shtorm.bat', 'check_updates.bat', 'where_models.bat'):
            self.assertNotIn(stale, help_text)


if __name__ == '__main__':
    unittest.main()
