"""Shtorm от начала до конца без настоящей модели: клиент shtorm.py + shtorm_worker.py
в отдельном процессе с поддельным pocket_tts (проверяются протокол, передача звука и перезапуск)."""
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import model_dirs
import shtorm

FAKE_POCKET_TTS = '''
import numpy as np


class _Tensor:
    def __init__(self, a):
        self.a = a

    def detach(self):
        return self

    def cpu(self):
        return self

    def numpy(self):
        return self.a


class TTSModel:
    sample_rate = 24000

    @classmethod
    def load_model(cls, config=None, **kw):
        if 'crash' in str(config):
            raise RuntimeError('boom')
        m = cls()
        m.config = str(config)
        return m

    def get_state_for_audio_prompt(self, path):
        return {'ref': str(path)}

    def generate_audio(self, state, text):
        import os
        if text == 'КРАХ':
            os._exit(3)
        if os.environ.get('FAKE_TEXT_LOG'):         # что именно дошло до модели
            with open(os.environ['FAKE_TEXT_LOG'], 'a', encoding='utf-8') as f:
                f.write(text + '\\n')
        return _Tensor((np.sin(np.linspace(0, 50, 1200 + 10 * len(text))) * 0.5).astype(np.float32))
'''


class ShtormProtocolTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        root = Path(self.tmp.name)
        self.model = root / 'model'
        self.model.mkdir()
        for name in ('config_fast.yaml', 'config_slow.yaml', 'model_fast.safetensors',
                     'model_slow.safetensors', 'tokenizer.model'):
            (self.model / name).write_bytes(b'x')
        self.fake = root / 'fake'
        self.fake.mkdir()
        (self.fake / 'pocket_tts.py').write_text(FAKE_POCKET_TTS, encoding='utf-8')
        self.wav = root / 'voice.wav'
        self.wav.write_bytes(b'RIFF')
        self.textlog = root / 'received.txt'
        self.textlog.write_text('', encoding='utf-8')
        self.saved = (model_dirs.SHTORM_DIR, shtorm.PYTHON, shtorm.WORKER)
        model_dirs.SHTORM_DIR = str(self.model)
        shtorm.PYTHON = Path(sys.executable)             # вместо venv_shtorm\Scripts\python.exe
        self.env = mock.patch.dict(os.environ, {'PYTHONPATH': str(self.fake),
                                                'FAKE_TEXT_LOG': str(self.textlog)})
        self.env.start()
        shtorm.shutdown()

    def tearDown(self):
        shtorm.shutdown()
        model_dirs.SHTORM_DIR, shtorm.PYTHON, shtorm.WORKER = self.saved
        self.env.stop()
        self.tmp.cleanup()

    def received(self):
        return self.textlog.read_text(encoding='utf-8').splitlines()

    def stub_worker(self, source):
        path = Path(self.tmp.name) / 'stub_worker.py'
        path.write_text(source, encoding='utf-8')
        shtorm.WORKER = path

    def test_load_and_synthesize(self):
        shtorm.load('fast', str(self.wav))
        self.assertTrue(shtorm.is_loaded('fast', str(self.wav)))
        self.assertEqual(shtorm.SAMPLE_RATE, 24000)
        audio = shtorm.synthesize('Привет, мир.')
        self.assertEqual(audio.dtype.name, 'float32')
        self.assertEqual(audio.ndim, 1)
        self.assertGreater(audio.size, 1000)
        self.assertLessEqual(float(abs(audio).max()), 1.0)
        shtorm.load('fast', str(self.wav))               # повторная загрузка того же ничего не делает
        self.assertTrue(shtorm.is_loaded())

    def test_slow_variant_uses_its_config(self):
        shtorm.load('slow', str(self.wav))
        self.assertTrue(shtorm.is_loaded('slow'))
        self.assertFalse(shtorm.is_loaded('fast'))

    def test_worker_error_comes_back_as_runtime_error(self):
        (self.model / 'config_fast.yaml').unlink()
        with self.assertRaises(RuntimeError):
            shtorm.load('fast', str(self.wav))           # установка неполная: понятная ошибка, не зависание
        (self.model / 'config_fast.yaml').write_bytes(b'x')
        crash_dir = Path(self.tmp.name) / 'crash_model'  # поддельная модель падает при загрузке, если в пути «crash»
        crash_dir.mkdir()
        for name in ('config_fast.yaml', 'model_fast.safetensors', 'tokenizer.model'):
            (crash_dir / name).write_bytes(b'x')
        model_dirs.SHTORM_DIR = str(crash_dir)
        with self.assertRaises(RuntimeError) as ctx:
            shtorm.load('fast', str(self.wav))
        self.assertIn('boom', str(ctx.exception))
        model_dirs.SHTORM_DIR = str(self.model)
        shtorm.load('fast', str(self.wav))               # после ошибки движок снова работает
        self.assertTrue(shtorm.is_loaded())

    def test_dead_worker_is_restarted_on_next_load(self):
        shtorm.load('fast', str(self.wav))
        with self.assertRaises(RuntimeError):
            shtorm.synthesize('КРАХ')                    # процесс умирает посреди работы
        self.assertFalse(shtorm.is_loaded())
        shtorm.load('fast', str(self.wav))               # переключение движка запускает его заново
        self.assertGreater(shtorm.synthesize('Снова работает.').size, 0)

    # ---- кодировка канала. Windows читает stdin процесса, подключённого к каналу, в cp1251 (а клиент
    # пишет UTF-8): модель получала «РџСЂРѕ…» и озвучивала книгу по буквам, а заглавная «И» (байт 0x98,
    # которого нет в cp1251) роняла процесс. На Linux по умолчанию UTF-8, поэтому ошибку воспроизводит
    # только явная имитация: PYTHONIOENCODING=cp1251.
    TEXT = 'Проло\u0301г: Иван озву\u0301чиваю. Броса\u0301й! Чтоб тебя\u0301!'

    def test_russian_text_reaches_the_model_through_a_cp1251_pipe(self):
        os.environ['PYTHONIOENCODING'] = 'cp1251'
        shtorm.load('fast', str(self.wav))
        self.assertGreater(shtorm.synthesize(self.TEXT).size, 0)
        self.assertEqual(self.received(), [self.TEXT])

    def test_client_exchange_is_pure_ascii(self):
        self.stub_worker(
            "import json, sys\n"
            "raw = sys.stdin.buffer.readline()\n"
            "sys.stdout.write(json.dumps({'ok': True, 'ascii': all(b < 128 for b in raw)}) + '\\n')\n"
            "sys.stdout.flush()\n")
        self.assertTrue(shtorm._request({'cmd': 'x', 'text': self.TEXT})['ascii'])

    def test_worker_alone_survives_a_cp1251_stdin(self):
        env = dict(os.environ, PYTHONIOENCODING='cp1251')
        env.pop('PYTHONUTF8', None)
        proc = subprocess.Popen([sys.executable, '-u', str(shtorm.WORKER)], env=env, text=True,
                                encoding='utf-8', stdin=subprocess.PIPE, stdout=subprocess.PIPE)
        out = Path(self.tmp.name) / 'o.npy'

        def ask(data):
            proc.stdin.write(json.dumps(data, ensure_ascii=False) + '\n')   # как писал прежний клиент
            proc.stdin.flush()
            return json.loads(proc.stdout.readline())
        try:
            self.assertTrue(ask({'cmd': 'load', 'variant': 'fast', 'voice_ref': str(self.wav),
                                 'model_dir': str(self.model), 'probe': self.TEXT})['probe'] == self.TEXT)
            self.assertTrue(ask({'cmd': 'synthesize', 'text': self.TEXT, 'out_path': str(out)})['ok'])
        finally:
            proc.stdin.write('{"cmd":"shutdown"}\n')
            proc.stdin.flush()
            proc.wait(timeout=10)
            proc.stdin.close()
            proc.stdout.close()
        self.assertEqual(self.received(), [self.TEXT])

    def test_corrupted_channel_is_detected_at_load(self):
        self.stub_worker(
            "import json, sys\n"
            "for line in sys.stdin:\n"
            "    sys.stdout.write(json.dumps({'ok': True, 'sample_rate': 24000, "
            "'probe': 'РџСЂРёРІРµС‚'}) + '\\n')\n"
            "    sys.stdout.flush()\n")
        with self.assertRaises(RuntimeError) as ctx:
            shtorm.load('fast', str(self.wav))
        self.assertIn('искажает', str(ctx.exception))
        self.assertFalse(shtorm.is_loaded())


if __name__ == '__main__':
    unittest.main()
