"""Стыки между фрагментами озвучки: измерения, исправление краёв, повторный синтез, отчёт; параметры
генерации Shtorm; режущий по союзам split_long. Настоящие модели не нужны: речь подменена тоном."""
import re
import sys
import tempfile
import unittest
from pathlib import Path
from types import ModuleType, SimpleNamespace
from unittest import mock

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import accent_pipeline as ap
import audio_seams as seams

try:
    from test_ruaccent_models import function_source
except ImportError:
    from tests.test_ruaccent_models import function_source

SR = 24000


def speech(dur=1.5, lead=0.05, tail=0.1, amp=0.3, soft_edges=True, f=173, dc=0.0):
    """Подставная «речь»: тон с огибающей, тишина до и после. soft_edges=False даёт обрыв на полной громкости."""
    n, ln, lt = int(SR * dur), int(SR * lead), int(SR * tail)
    t = np.arange(n) / SR
    tone = amp * np.sin(2 * np.pi * f * t + 0.7) * (0.6 + 0.4 * np.sin(2 * np.pi * 3 * t))
    if soft_edges:
        ramp = min(int(0.03 * SR), n // 4)
        tone[:ramp] *= np.linspace(0, 1, ramp)
        tone[-ramp:] *= np.linspace(1, 0, ramp)
    return np.concatenate([np.zeros(ln), tone, np.zeros(lt)]).astype(np.float32) + np.float32(dc)


TEXT = 'Он долго шёл по тёмной дороге.'            # 24 буквы


def tracker(rate_letters=24, dur=1.5, count=10):
    tr = seams.Tracker()
    for _ in range(count):
        tr.add(seams.analyze(speech(dur=dur), SR), 'а' * rate_letters)
    return tr


class AnalyzeTests(unittest.TestCase):
    def test_lead_tail_and_speech_length(self):
        m = seams.analyze(speech(dur=1.5, lead=0.2, tail=0.3), SR)
        self.assertFalse(m['silent'])
        self.assertAlmostEqual(m['lead_ms'], 200, delta=15)
        self.assertAlmostEqual(m['tail_ms'], 300, delta=15)
        self.assertAlmostEqual(m['speech_s'], 1.5, delta=0.05)
        self.assertLess(m['tail_db'], -40)
        self.assertLess(m['head_db'], -40)

    def test_silence_is_detected(self):
        self.assertTrue(seams.analyze(np.zeros(SR, dtype=np.float32), SR)['silent'])
        self.assertTrue(seams.analyze(np.zeros(0, dtype=np.float32), SR)['silent'])
        sev, _ = seams.reasons(seams.analyze(np.zeros(SR, dtype=np.float32), SR), TEXT, seams.Tracker(), seams.config_from(None))
        self.assertEqual(sev, ['silent'])

    def test_inner_silence(self):
        a, b = speech(dur=0.6, lead=0, tail=0), speech(dur=0.6, lead=0, tail=0)
        x = np.concatenate([a, np.zeros(int(0.9 * SR), dtype=np.float32), b])
        self.assertAlmostEqual(seams.analyze(x, SR)['inner_silence_ms'], 900, delta=40)


class ReasonsTests(unittest.TestCase):
    cfg = seams.config_from(None)

    def why(self, audio, text=TEXT, tr=None):
        return seams.reasons(seams.analyze(audio, SR), text, tr or tracker(), self.cfg)

    def test_a_clean_fragment_has_no_reasons(self):
        self.assertEqual(self.why(speech()), ([], []))

    def test_speech_cut_off_at_the_end_is_severe_and_clicks(self):
        severe, minor = self.why(speech(soft_edges=False, tail=0.0))
        self.assertIn('tail_cut', severe)
        self.assertIn('click_end', minor)

    def test_speech_starting_abruptly(self):
        severe, minor = self.why(speech(soft_edges=False, lead=0.0))
        self.assertIn('head_cut', severe)
        self.assertIn('click_start', minor)

    def test_clipping(self):
        x = speech()
        x[SR // 2:SR // 2 + 40] = 1.0
        self.assertIn('clip', self.why(x)[0])

    def test_duration_anomalies_need_history_and_enough_text(self):
        self.assertIn('rate', self.why(speech(dur=0.35))[0])                       # пропущены слова
        self.assertIn('rate', self.why(speech(dur=4.0))[0])                        # бормотание
        self.assertNotIn('rate', self.why(speech(dur=0.35), 'Да.')[0])             # короткий текст не судим
        self.assertNotIn('rate', self.why(speech(dur=0.35), tr=seams.Tracker())[0])  # нет истории

    def test_inner_gap_unless_it_is_an_ellipsis(self):
        x = np.concatenate([speech(dur=0.7, lead=0, tail=0), np.zeros(int(0.9 * SR), dtype=np.float32),
                            speech(dur=0.7, lead=0.0, tail=0.1)])
        tr = tracker(dur=1.5)
        self.assertIn('inner_gap', seams.reasons(seams.analyze(x, SR), 'Он вошёл и ушёл прочь.', tr, self.cfg)[0])
        self.assertNotIn('inner_gap', seams.reasons(seams.analyze(x, SR), 'Он вошёл… и ушёл прочь.', tr, self.cfg)[0])

    def test_long_edges_and_level_jump_are_minor(self):
        severe, minor = self.why(speech(lead=0.4, tail=0.6))
        self.assertEqual(severe, [])
        self.assertTrue({'long_lead', 'long_tail'} <= set(minor))
        loud = seams.reasons(seams.analyze(speech(amp=0.9), SR), TEXT, tracker(), self.cfg)[1]
        self.assertIn('level_jump', loud)


class ConditionTests(unittest.TestCase):
    cfg = seams.config_from(None)

    def test_long_silence_is_capped_not_removed(self):
        x = speech(lead=0.5, tail=0.8)
        m = seams.analyze(x, SR)
        y = seams.condition(x, SR, self.cfg, m)
        m2 = seams.analyze(y, SR)
        self.assertAlmostEqual(m2['lead_ms'], self.cfg['max_lead_ms'], delta=12)
        self.assertAlmostEqual(m2['tail_ms'], self.cfg['max_tail_ms'], delta=12)
        self.assertAlmostEqual(m2['speech_s'], m['speech_s'], delta=0.03)          # речь не тронута

    def test_short_natural_silence_is_kept(self):
        x = speech(lead=0.03, tail=0.05)
        self.assertEqual(len(seams.condition(x, SR, self.cfg)), len(x))

    def test_edges_fade_to_zero_and_the_click_is_gone(self):
        x = speech(soft_edges=False, lead=0.0, tail=0.0)
        y = seams.condition(x, SR, self.cfg)
        self.assertLess(abs(float(y[0])), 1e-3)
        self.assertLess(abs(float(y[-1])), 1e-3)
        m = seams.analyze(y, SR)
        self.assertLess(m['end_jump'], self.cfg['click_level'])
        self.assertLess(m['start_jump'], self.cfg['click_level'])
        mid = slice(int(0.1 * SR), int(0.9 * SR))
        np.testing.assert_allclose(y[mid], x[mid] - x.mean(), atol=1e-5)           # середина без изменений

    def test_dc_offset_and_peak_guard(self):
        y = seams.condition(speech(dc=0.05), SR, self.cfg)
        self.assertLess(abs(float(y.mean())), 1e-3)
        self.assertLessEqual(float(np.abs(seams.condition(speech(amp=1.4), SR, self.cfg)).max()), 0.99 + 1e-6)

    def test_input_is_not_modified(self):
        x = speech(soft_edges=False, lead=0.0)
        before = x.copy()
        seams.condition(x, SR, self.cfg)
        np.testing.assert_array_equal(x, before)

    def test_empty_input(self):
        self.assertEqual(len(seams.condition(np.zeros(0, dtype=np.float32), SR, self.cfg)), 0)


class SessionTests(unittest.TestCase):
    def session(self, engine='shtorm', **over):
        cfg = seams.config_from(over or None)
        s = seams.Session(engine, SR, cfg, chapter='003')
        for _ in range(10):
            s.tracker.add(seams.analyze(speech(), SR), 'а' * 24)
        return s

    def test_bad_fragment_is_synthesized_again_and_the_good_one_is_used(self):
        takes = iter([speech(soft_edges=False, tail=0.0), speech()])
        logged = []
        s = self.session()
        out = s.fragment(lambda: next(takes), TEXT, t=75.0, log=logged.append)
        self.assertEqual(s.report.counts['retried'], 1)
        self.assertEqual(s.report.counts['suspicious'], 0)
        self.assertLess(seams.analyze(out, SR)['tail_db'], -40)
        self.assertTrue(any('повтор синтеза' in l and 'оборвана' in l for l in logged))
        rec = s.report.records[0]
        self.assertEqual((rec['chapter'], rec['t'], rec['tries'], rec['severe']), ('003', 75.0, 1, []))

    def test_exception_is_retried_then_raised_when_it_persists(self):
        calls = []

        def flaky():
            calls.append(1)
            if len(calls) == 1:
                raise RuntimeError('процесс остановился')
            return speech()
        s = self.session()
        s.fragment(flaky, TEXT)
        self.assertEqual(len(calls), 2)

        def always():
            raise RuntimeError('нет')
        with self.assertRaises(RuntimeError):
            self.session().fragment(always, TEXT)

    def test_when_every_take_is_bad_the_least_bad_stays_and_is_reported(self):
        bad = speech(soft_edges=False, tail=0.0, lead=0.0)                 # две причины: начало и конец
        worse_than_bad = [bad, speech(soft_edges=False, tail=0.0), bad]
        takes = iter(worse_than_bad)
        s = self.session()
        s.fragment(lambda: next(takes), TEXT)
        self.assertEqual(s.report.counts['retried'], 2)
        self.assertEqual(s.report.counts['suspicious'], 1)
        self.assertEqual(s.report.records[0]['severe'], ['tail_cut'])      # осталась версия с одной причиной

    def test_retries_can_be_switched_off(self):
        n = []
        s = self.session(retries=0)
        s.fragment(lambda: n.append(1) or speech(soft_edges=False, tail=0.0), TEXT)
        self.assertEqual(len(n), 1)

    def test_silero_is_passed_through_untouched_by_default(self):
        s = self.session('silero')
        x = speech(soft_edges=False, lead=0.9, tail=0.0)
        out = s.fragment(lambda: x, TEXT)
        self.assertIs(out, x)
        self.assertEqual(s.pause_ms(0), 0)
        self.assertEqual(s.report.counts['processed'], 0)

    def test_silero_can_be_enabled(self):
        s = self.session('silero', engines={'silero': True})
        self.assertTrue(s.on)

    def test_forced_pause_only_where_the_table_gave_zero(self):
        s = self.session()
        self.assertEqual(s.pause_ms(0), 60)
        self.assertEqual(s.pause_ms(400), 400)
        self.assertEqual(self.session(forced_pause_ms=0).pause_ms(0), 0)

    def test_level_match_is_off_by_default_and_limited_when_on(self):
        loud = speech(amp=0.9)
        base = self.session().fragment(lambda: loud, TEXT)
        self.assertAlmostEqual(float(np.abs(base).max()), 0.9, delta=0.02)
        s = self.session(level_match_db=3)
        out = s.fragment(lambda: loud, TEXT)
        drop = 20 * np.log10(0.9 / float(np.abs(out).max()))
        self.assertAlmostEqual(drop, 3.0, delta=0.4)                       # не больше заданного предела

    def test_tracker_only_learns_from_good_fragments(self):
        s = self.session()
        before = len(s.tracker.rates)
        takes = iter([speech(soft_edges=False, tail=0.0)] * 3)
        s.fragment(lambda: next(takes), TEXT)
        self.assertEqual(len(s.tracker.rates), before)


class ConfigAndReportTests(unittest.TestCase):
    def test_config_ignores_garbage_and_merges_engines(self):
        cfg = seams.config_from({'retries': 99, 'fade_out_ms': 'много', 'max_tail_ms': 200, 'engines': {'silero': True, 'x': 1},
                                 'forced_pause_ms': True, 'неизвестно': 5})
        self.assertEqual(cfg['retries'], 5)
        self.assertEqual(cfg['fade_out_ms'], seams.DEFAULTS['fade_out_ms'])
        self.assertEqual(cfg['max_tail_ms'], 200)
        self.assertEqual(cfg['forced_pause_ms'], seams.DEFAULTS['forced_pause_ms'])
        self.assertTrue(cfg['engines']['silero'] and cfg['engines']['shtorm'])
        self.assertEqual(seams.config_from(None), seams.config_from('мусор'))

    def test_defaults_are_not_shared_between_configs(self):
        a = seams.config_from(None)
        a['engines']['shtorm'] = False
        self.assertTrue(seams.config_from(None)['engines']['shtorm'])
        self.assertTrue(seams.DEFAULTS['engines']['shtorm'])

    def test_clock(self):
        self.assertEqual((seams.clock(75), seams.clock(5), seams.clock(3725)), ('1:15', '0:05', '1:02:05'))

    def test_report_lists_places_with_chapter_and_time(self):
        s = seams.Session('shtorm', SR, seams.config_from(None), chapter='007')
        for _ in range(10):
            s.tracker.add(seams.analyze(speech(), SR), 'а' * 24)
        takes = iter([speech(soft_edges=False, tail=0.0)] * 3)
        s.fragment(lambda: next(takes), TEXT, t=761.0)
        s.fragment(lambda: speech(), 'Всё хорошо.', t=770.0)
        s.note_forced('Он долго шёл по тёмной', 800.0)
        text = s.report.text()
        self.assertIn('007 · 12:41 · речь оборвана в конце', text)
        self.assertIn('(осталось)', text)
        self.assertIn('007 · 13:20 · оборван без знака', text)
        self.assertIn('Стыки: фрагментов 2', text)
        self.assertNotIn('Всё хорошо', text)
        self.assertIn('Подозрительных стыков не найдено', seams.Report().text())


# ---------------------------------------------------------------- render в app.py
class RenderTests(unittest.TestCase):
    def render_ns(self, engine='shtorm'):
        from punctuation_pauses import pause_ms
        made = []

        def say(s, pairs):
            made.append(s)
            return speech(dur=0.5, lead=0.02, tail=0.02)
        fake_speak = SimpleNamespace(SAMPLE_RATE=SR, ENGINE=engine, say_sentence=say)
        ns = {'np': np, 'seams': seams, 'speak': fake_speak, 'pause_ms': pause_ms}
        exec(function_source('app.py', 'render', 'App'), ns)
        me = SimpleNamespace(cfg={}, logs=[], stop_flag=SimpleNamespace(is_set=lambda: False))
        me.log = me.logs.append
        return ns['render'], me, made

    def test_pauses_forced_cut_timeline_and_report(self):
        render, me, made = self.render_ns()
        units = [('Первый кусок,', None), ('второй без знака', None), ('Конец.', 'par1')]
        audio = render(me, units, [], lambda: None, label='005')
        sr = SR
        frag = len(speech(dur=0.5, lead=0.02, tail=0.02))
        self.assertEqual(made, ['Первый кусок,', 'второй без знака', 'Конец.'])
        self.assertGreater(len(audio), 3 * frag * 0.9)
        rep = me.seam_report
        self.assertEqual(rep.counts['fragments'], 3)
        self.assertEqual(rep.counts['forced'], 1)
        forced = [r for r in rep.records if r['kind'] == 'forced']
        self.assertEqual([r['text'] for r in forced], ['второй без знака'])
        self.assertGreater(forced[0]['t'], 0.5)                           # время от начала главы растёт
        self.assertEqual(forced[0]['chapter'], '005')

    def test_silero_keeps_the_old_hard_concatenation(self):
        render, me, _ = self.render_ns('silero')
        audio = render(me, [('без знака', None), ('ещё без знака', None)], [], lambda: None)
        one = len(speech(dur=0.5, lead=0.02, tail=0.02))
        self.assertEqual(len(audio), 2 * one)                              # ни пауз, ни обрезки, как раньше

    def test_stop_flag_returns_none(self):
        render, me, _ = self.render_ns()
        me.stop_flag = SimpleNamespace(is_set=lambda: True)
        self.assertIsNone(render(me, [('а', None)], [], lambda: None))

    def test_a_failing_fragment_is_skipped_with_a_log_line(self):
        render, me, _ = self.render_ns()
        calls = []

        def boom(s, pairs):
            calls.append(s)
            if s == 'плохой':
                raise RuntimeError('нет')
            return speech(dur=0.3)
        render.__globals__['speak'].say_sentence = boom
        audio = render(me, [('плохой', None), ('хороший.', None)], [], lambda: None)
        self.assertIsNotNone(audio)
        self.assertTrue(any('пропуск' in l for l in me.logs))
        self.assertEqual(calls.count('плохой'), 3)                         # 1 + 2 повтора, потом пропуск


# ---------------------------------------------------------------- параметры генерации Shtorm
class ShtormGenTests(unittest.TestCase):
    def test_clean_gen_keeps_only_valid_known_values(self):
        import shtorm
        got = shtorm.clean_gen({'temp': 0.5, 'lsd_decode_steps': 3.0, 'eos_threshold': -3, 'noise_clamp': 99,
                                'frames_after_eos': 2, 'x': 1, 'temp2': 1})
        self.assertEqual(got, {'temp': 0.5, 'lsd_decode_steps': 3, 'eos_threshold': -3.0, 'frames_after_eos': 2})
        self.assertEqual(shtorm.clean_gen({'temp': 'много', 'frames_after_eos': True, 'lsd_decode_steps': 0}), {})
        self.assertEqual(shtorm.clean_gen(None), {})

    def test_reload_only_when_parameters_change(self):
        import shtorm
        sent = []
        resp = {'ok': True, 'sample_rate': 24000, 'probe': shtorm.PROBE, 'gen_applied': {'temp': 0.5}}
        tmp = Path(tempfile.mkdtemp())
        ref = tmp / 'r.wav'
        ref.write_bytes(b'x')
        state = dict(_proc=None)
        with mock.patch.object(shtorm, '_request', lambda p: sent.append(p) or dict(resp)), \
                mock.patch.object(shtorm, 'installed', return_value=True), \
                mock.patch.object(shtorm, '_relocalize_configs'), \
                mock.patch.object(shtorm, 'is_loaded', lambda variant=None, voice_ref=None: bool(sent)), \
                mock.patch.object(shtorm, '_gen', {}), mock.patch.object(shtorm, '_loaded_gen', {}):
            shtorm.configure({'temp': 0.5})
            shtorm.load('fast', str(ref))
            shtorm.load('fast', str(ref))                                   # те же параметры: заново не грузим
            self.assertEqual(len(sent), 1)
            self.assertEqual(sent[0]['gen'], {'temp': 0.5})
            shtorm.configure({'temp': 0.4})
            shtorm.load('fast', str(ref))                                   # параметры другие: перезагрузка
            self.assertEqual(len(sent), 2)
            self.assertEqual(shtorm.last_gen_applied, {'temp': 0.5})
            shtorm.configure(None)

    def test_without_settings_the_load_request_is_what_it_always_was(self):
        import shtorm
        sent = []
        resp = {'ok': True, 'sample_rate': 24000, 'probe': shtorm.PROBE}
        tmp = Path(tempfile.mkdtemp())
        ref = tmp / 'r.wav'
        ref.write_bytes(b'x')
        with mock.patch.object(shtorm, '_request', lambda p: sent.append(p) or dict(resp)), \
                mock.patch.object(shtorm, 'installed', return_value=True), \
                mock.patch.object(shtorm, '_relocalize_configs'), \
                mock.patch.object(shtorm, 'is_loaded', lambda variant=None, voice_ref=None: False), \
                mock.patch.object(shtorm, '_gen', {}), mock.patch.object(shtorm, '_loaded_gen', {}):
            shtorm.load('fast', str(ref))
        self.assertEqual(sent[0]['gen'], {})


class WorkerGenTests(unittest.TestCase):
    def worker(self, accepts_frames=True, accepts_temp=True):
        calls = {'load': [], 'gen': []}

        class TTSModel:
            sample_rate = 24000

            @classmethod
            def load_model(cls, config=None, **kw):
                calls['load'].append(kw)
                return cls()

            def get_state_for_audio_prompt(self, ref):
                return 'state'

            if accepts_frames:
                def generate_audio(self, state, text, frames_after_eos=None):
                    calls['gen'].append({'frames_after_eos': frames_after_eos})
                    return np.zeros(100, dtype=np.float32) + 0.1
            else:
                def generate_audio(self, state, text):
                    calls['gen'].append({})
                    return np.zeros(100, dtype=np.float32) + 0.1
        if not accepts_temp:
            def strict(cls, config=None):
                calls['load'].append({})
                return cls()
            TTSModel.load_model = classmethod(strict)
        mod = ModuleType('pocket_tts')
        mod.TTSModel = TTSModel
        sys.modules['pocket_tts'] = mod
        self.addCleanup(sys.modules.pop, 'pocket_tts', None)
        import importlib
        import shtorm_worker
        importlib.reload(shtorm_worker)
        d = Path(tempfile.mkdtemp())
        (d / 'config_fast.yaml').write_text('x')
        (d / 'ref.wav').write_bytes(b'x')
        base = {'cmd': 'load', 'variant': 'fast', 'model_dir': str(d), 'voice_ref': str(d / 'ref.wav')}
        return shtorm_worker, calls, base, d

    def test_parameters_reach_the_model_and_are_reported(self):
        w, calls, base, d = self.worker()
        r = w.handle(dict(base, gen={'temp': 0.5, 'eos_threshold': -3.0, 'frames_after_eos': 2}))
        self.assertEqual(calls['load'], [{'temp': 0.5, 'eos_threshold': -3.0}])
        self.assertEqual(r['gen_applied'], {'temp': 0.5, 'eos_threshold': -3.0, 'frames_after_eos': 2})
        w.handle({'cmd': 'synthesize', 'text': 'Привет.', 'out_path': str(d / 'o.npy')})
        self.assertEqual(calls['gen'], [{'frames_after_eos': 2}])

    def test_no_parameters_means_the_old_calls(self):
        w, calls, base, d = self.worker()
        r = w.handle(base)
        self.assertEqual(calls['load'], [{}])
        self.assertEqual(r['gen_applied'], {})
        w.handle({'cmd': 'synthesize', 'text': 'Привет.', 'out_path': str(d / 'o.npy')})
        self.assertEqual(calls['gen'], [{'frames_after_eos': None}])        # аргумент по умолчанию, то есть без изменений

    def test_model_is_rebuilt_only_when_load_parameters_change(self):
        w, calls, base, d = self.worker()
        w.handle(dict(base, gen={'temp': 0.5}))
        w.handle(dict(base, gen={'temp': 0.5, 'frames_after_eos': 3}))      # frames_after_eos не требует новой модели
        self.assertEqual(len(calls['load']), 1)
        w.handle(dict(base, gen={'temp': 0.6}))
        self.assertEqual(len(calls['load']), 2)

    def test_parameters_the_build_does_not_know_are_dropped_not_fatal(self):
        w, calls, base, d = self.worker(accepts_frames=False, accepts_temp=False)
        r = w.handle(dict(base, gen={'temp': 0.5, 'frames_after_eos': 2}))
        self.assertEqual(r['gen_applied'], {})
        w.handle({'cmd': 'synthesize', 'text': 'Привет.', 'out_path': str(d / 'o.npy')})
        self.assertEqual(calls['gen'], [{}])


# ---------------------------------------------------------------- нарезка длинных фраз
class SplitLongTests(unittest.TestCase):
    TEXT = ('Он долго шёл по тёмной дороге мимо старых заброшенных домов и думал о том что скажет ей когда наконец '
            'доберётся до места которое так давно хотел увидеть и ничего не мог придумать')

    def test_cuts_before_conjunctions_and_loses_nothing(self):
        chunks = ap.split_long(self.TEXT, 90)
        self.assertEqual(' '.join(chunks), self.TEXT)
        self.assertTrue(all(ap.visible_len(c) <= 90 for c in chunks))
        self.assertTrue(all(c.split()[0] in ap.BREAK_BEFORE for c in chunks[1:]), chunks)

    def test_without_a_good_place_it_still_cuts_by_length(self):
        text = ' '.join(['слово'] * 40)
        chunks = ap.split_long(text, 50)
        self.assertTrue(all(ap.visible_len(c) <= 50 for c in chunks))
        self.assertEqual(' '.join(chunks), text)

    def test_stress_marks_do_not_hide_the_conjunction(self):
        text = ('Мы шли ' * 8 + 'довольно долго п+ока не устали и сели ' + 'отдыхать ' * 6).strip()
        chunks = ap.split_long(text, 70)
        self.assertEqual(' '.join(chunks), text)

    def test_short_sentences_and_comma_splitting_are_unchanged(self):
        self.assertEqual(ap.split_long('Он ушёл.', 160), ['Он ушёл.'])
        text = 'Первая часть длинной фразы, вторая часть длинной фразы, третья часть длинной фразы'
        self.assertEqual(ap.split_long(text, 45), ['Первая часть длинной фразы,', 'вторая часть длинной фразы,',
                                                    'третья часть длинной фразы'])


class WiringTests(unittest.TestCase):
    def test_app_saves_and_uses_the_new_settings(self):
        src = (Path(__file__).resolve().parent.parent / 'app.py').read_text(encoding='utf-8')
        self.assertIn("'seams', 'shtorm_gen'", src)
        self.assertIn("shtorm.configure(self.cfg.get('shtorm_gen'))", src)
        self.assertIn("(Path(outdir) / 'стыки_отчёт.txt')", src)

    def test_portable_copy_has_the_new_module(self):
        import model_manager
        self.assertIn('audio_seams.py', model_manager.PORTABLE_CODE)


if __name__ == '__main__':
    unittest.main()
