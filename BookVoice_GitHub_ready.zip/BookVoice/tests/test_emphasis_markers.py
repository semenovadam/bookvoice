import unittest
from emphasis import (extract_emphasis, restore_emphasis,
                      inject_emphasis_ranges, inject_absolute_emphasis_ranges)


class EmphasisMarkerTests(unittest.TestCase):
    def test_strong_marker_survives_stress_plus(self):
        plain, marks = extract_emphasis('Они одержали **победу** в битве.')
        transformed = 'Они одерж+али поб+еду в битве.'
        self.assertEqual(restore_emphasis(transformed, marks),
                         'Они одерж+али **поб+еду** в битве.')

    def test_light_marker_survives(self):
        plain, marks = extract_emphasis('Это *важно* сейчас.')
        self.assertEqual(restore_emphasis('Это в+ажно сейчас.', marks), 'Это *в+ажно* сейчас.')

    def test_phrase_and_repeated_word(self):
        _, marks = extract_emphasis('Слово было, а потом **слово было** снова.')
        self.assertEqual(restore_emphasis('Слово было, а потом слово б+ыло снова.', marks),
                         'Слово было, а потом **слово б+ыло** снова.')

    def test_scene_break_is_not_emphasis(self):
        plain, marks = extract_emphasis('Конец главы. * * * Следующая глава.')
        self.assertEqual(plain, 'Конец главы. * * * Следующая глава.')
        self.assertEqual(marks, [])

    def test_no_guess_when_target_missing(self):
        _, marks = extract_emphasis('Это **победу**.')
        self.assertEqual(restore_emphasis('Это торжество.', marks), 'Это торжество.')

    def test_editor_tag_range_becomes_strong_marker(self):
        text = 'С тех пор как они прибыли и одержали победу.'
        start = text.index('они')
        marked = inject_emphasis_ranges(text, [(start, start + len('они'), 2)])
        self.assertEqual(marked, 'С тех пор как **они** прибыли и одержали победу.')
        plain, marks = extract_emphasis(marked)
        self.assertEqual(plain, text)
        self.assertEqual(marks[0]['words'], ['они'])
        self.assertEqual(marks[0]['level'], 2)

    def test_editor_absolute_tag_range_clips_to_sentence(self):
        text = 'Первая фраза. Они прибыли и победили. Третья.'
        start = text.index('Они')
        end = start + len('Они прибыли')
        marked = inject_absolute_emphasis_ranges(text, start, text.index('.', start),
                                                  [(start, end, 2)])
        self.assertEqual(marked, '**Они прибыли** и победили')


if __name__ == '__main__':
    unittest.main()
