"""Нумерация глав («Глава 1 - Дием»), пустые строки, «с новой страницы» и стихи (курсив, сдвиг вправо) в FB2 и в
редакторе. Tk здесь нет: окно текста подменено упрощённым FakeText (индексы, теги, вставка, удаление)."""
import re
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock
from xml.etree import ElementTree as ET

import bookio
import edit_tab
import layoutmarks as lm

NS = '{http://www.gribuser.ru/xml/fictionbook/2.0}'


def fb2_text(book, **kw):
    path = Path(tempfile.mkdtemp()) / 'k.fb2'
    bookio.write_fb2(book, path, **kw)
    return path.read_text(encoding='utf-8'), path


def entries(chapter, *items):
    """entries(0, ('empty', 0), ('verse', 1)) -> [{'chapter': 0, 'paragraph': 0, 'kind': 'empty'}, ...]"""
    return [{'chapter': chapter, 'paragraph': p, 'kind': k} for k, p in items]


POEM = ['Я помню чудное мгновенье,', 'Передо мной явилась ты,', 'Как мимолётное виденье,', 'Как гений чистой красоты.']


class LayoutMarksTests(unittest.TestCase):
    def test_compose_and_parse_are_inverse(self):
        paras = ['а', 'б', 'в', 'г']
        layout = [{'paragraph': 0, 'kind': 'empty'}, {'paragraph': 0, 'kind': 'verse'},
                  {'paragraph': 1, 'kind': 'verse'}, {'paragraph': 2, 'kind': 'empty'},
                  {'paragraph': 2, 'kind': 'page'}, {'paragraph': 4, 'kind': 'empty'}]
        lines, para_line, verse = lm.compose_lines(paras, layout)
        self.assertEqual(lines, [lm.MARK_EMPTY, 'а', 'б', lm.MARK_EMPTY, lm.MARK_PAGE, 'в', 'г', lm.MARK_EMPTY])
        self.assertEqual(para_line, [1, 2, 5, 6])
        self.assertEqual(verse, {1, 2})
        self.assertEqual(lm.parse_lines(lines, verse), (paras, layout))

    def test_center_italic_layout_round_trips(self):
        paras = ['обычный абзац', 'выделенный абзац', 'ещё один']
        layout = [{'paragraph': 1, 'kind': lm.KIND_CENTER}]
        lines, para_line, _verse = lm.compose_lines(paras, [])
        center_lines = {para_line[1]}
        self.assertEqual(lm.parse_lines(lines, (), center_lines), (paras, layout))

    def test_plain_blank_lines_and_indents_are_still_ignored(self):
        self.assertEqual(lm.parse_lines(['  а', '', '   ', 'б  ']), (['а', 'б'], []))

    def test_marks_are_never_paragraphs(self):
        paras, layout = lm.parse_lines(['а', '  ' + lm.MARK_PAGE + ' ', 'б'])
        self.assertEqual((paras, layout), (['а', 'б'], [{'paragraph': 1, 'kind': 'page'}]))
        self.assertTrue(lm.is_mark(lm.MARK_EMPTY + '  '))
        self.assertFalse(lm.is_mark('пустая строка'))

    def test_clamp_drops_garbage(self):
        raw = [{'paragraph': 9, 'kind': 'empty'}, {'paragraph': 9, 'kind': 'verse'}, {'kind': 'empty'},
               {'paragraph': 'x', 'kind': 'page'}, {'paragraph': 0, 'kind': 'magic'}, {'paragraph': -3, 'kind': 'empty'},
               {'paragraph': 1, 'kind': 'verse'}]
        self.assertEqual(lm.clamp_layout(raw, 2), [{'paragraph': 0, 'kind': 'empty'}, {'paragraph': 1, 'kind': 'verse'},
                                                   {'paragraph': 2, 'kind': 'empty'}])     # порядок канонический

    def test_shift(self):
        self.assertEqual(lm.shift_layout([{'paragraph': 1, 'kind': 'empty'}], 3), [{'paragraph': 4, 'kind': 'empty'}])

    def test_numbering_titles(self):
        titles = ['Введение', 'Пролог', 'Дием', 'Второй']
        self.assertEqual(lm.display_titles(titles, 2), ['Введение', 'Пролог', 'Глава 1 - Дием', 'Глава 2 - Второй'])
        self.assertEqual(lm.display_titles(titles, None), titles)
        self.assertEqual(lm.display_titles(titles, 0, 'Часть {n}. {title}')[:2], ['Часть 1. Введение', 'Часть 2. Пролог'])
        self.assertEqual(lm.display_titles(titles, 0, 'без номера'), titles)       # негодный формат ничего не портит

    def test_strip_number_is_the_inverse(self):
        for fmt in (lm.DEFAULT_NUMBER_FORMAT, 'Глава {n}. {title}', '{n}) {title}'):
            shown = lm.display_title('Дием', fmt, 7)
            self.assertEqual(lm.strip_number(shown, fmt, 7), 'Дием')
        self.assertEqual(lm.strip_number('Дием', lm.DEFAULT_NUMBER_FORMAT, 1), 'Дием')
        self.assertEqual(lm.strip_number('Глава 1 - ', lm.DEFAULT_NUMBER_FORMAT, 1), 'Глава 1 - ')    # пустое название не стираем

    def test_format_validation(self):
        self.assertTrue(lm.valid_number_format('Глава {n} - {title}'))
        for bad in ('Глава {n}', '{title}', 'Глава {n} {x} {title}', '', None, 5):
            self.assertFalse(lm.valid_number_format(bad), repr(bad))


class Fb2WriteReadTests(unittest.TestCase):
    def book(self):
        b = bookio.Book(title='Т', author='Иван Петров')
        b.chapters = [('Введение', POEM + ['Текст введения.']), ('Дием', ['Первый абзац.', 'Второй абзац.'])]
        return b

    def test_no_layout_no_numbering_is_the_old_output(self):
        text, path = fb2_text(self.book())
        self.assertIn('<section id="ch1"><title><p>Введение</p></title>', text)
        self.assertIn('<p>Текст введения.</p>', text)
        self.assertNotIn('epigraph', text)
        self.assertNotIn('cite', text)
        self.assertNotIn('numbering', text)
        self.assertNotIn('bv-page', text)
        r = bookio.read_fb2(path)
        self.assertEqual(r.chapters, self.book().chapters)
        self.assertEqual((r.layout, r.number_from), ([], None))

    def test_numbering_is_written_into_titles_and_toc_but_stored_without_numbers(self):
        b = self.book()
        b.number_from = 1
        text, path = fb2_text(b)
        self.assertIn('<title><p>Глава 1 - Дием</p></title>', text)
        self.assertIn('<a l:href="#ch2">Глава 1 - Дием</a>', text)
        self.assertIn('<title><p>Введение</p></title>', text)                 # вводная глава без номера
        r = bookio.read_fb2(path)
        self.assertEqual([t for t, _ in r.chapters], ['Введение', 'Дием'])   # при открытии номер снимается
        self.assertEqual((r.number_from, r.number_format), (1, lm.DEFAULT_NUMBER_FORMAT))
        again, path2 = fb2_text(r)                                           # и при повторном сохранении не удваивается
        self.assertIn('<title><p>Глава 1 - Дием</p></title>', again)
        self.assertNotIn('Глава 1 - Глава 1', again)

    def test_center_italic_and_chapter_exclusion_round_trip(self):
        b = self.book()
        b.chapters.append(('Эпилог', ['Конец.']))
        b.number_from = 1
        b.number_excluded = [2]
        b.layout = [{'chapter': 1, 'paragraph': 1, 'kind': lm.KIND_CENTER}]
        text, path = fb2_text(b)
        self.assertIn('<p style="text-align: center"><emphasis>Второй абзац.</emphasis></p>', text)
        self.assertIn('<title><p>Глава 1 - Дием</p></title>', text)
        self.assertIn('<title><p>Эпилог</p></title>', text)
        r = bookio.read_fb2(path)
        self.assertEqual(r.number_excluded, [2])
        self.assertEqual(r.layout, [{'paragraph': 1, 'kind': lm.KIND_CENTER, 'chapter': 1}])
        self.assertEqual(bookio.display_titles(r), ['Введение', 'Глава 1 - Дием', 'Эпилог'])

    def test_custom_number_format(self):
        b = self.book()
        b.number_from, b.number_format = 0, 'Часть {n}. {title}'
        text, path = fb2_text(b)
        self.assertIn('<title><p>Часть 2. Дием</p></title>', text)
        r = bookio.read_fb2(path)
        self.assertEqual(([t for t, _ in r.chapters], r.number_format), (['Введение', 'Дием'], 'Часть {n}. {title}'))

    def test_numbering_follows_the_chapter_even_if_empty_ones_are_skipped_on_read(self):
        b = bookio.Book(title='Т', author='А')
        b.chapters = [('Пустая', []), ('Введение', ['а']), ('Дием', ['б'])]
        b.number_from = 2
        text, path = fb2_text(b)
        r = bookio.read_fb2(path)                                            # пустая глава при чтении пропадает
        self.assertEqual([t for t, _ in r.chapters], ['Введение', 'Дием'])
        self.assertEqual(r.number_from, 1)                                   # а нумерация осталась на «Дием»

    def test_verse_right_after_the_title_is_an_epigraph_with_italic_and_stanzas(self):
        b = self.book()
        b.layout = entries(0, ('verse', 0), ('verse', 1), ('empty', 2), ('verse', 2), ('verse', 3), ('empty', 4))
        text, path = fb2_text(b)
        self.assertIn('<epigraph><poem><stanza><v><emphasis>Я помню чудное мгновенье,</emphasis></v>'
                      '<v><emphasis>Передо мной явилась ты,</emphasis></v></stanza><stanza>', text)
        self.assertEqual(text.count('<stanza>'), 2)                          # пустая строка между строками = новая строфа
        self.assertIn('</poem></epigraph>\n<empty-line/>\n<p>Текст введения.</p>', text)    # пустая строка после стиха
        r = bookio.read_fb2(path)
        self.assertEqual(r.chapters[0][1], POEM + ['Текст введения.'])       # текст не изменился
        self.assertEqual([(e['kind'], e['paragraph']) for e in r.layout if e['chapter'] == 0],
                         [('verse', 0), ('verse', 1), ('empty', 2), ('verse', 2), ('verse', 3), ('empty', 4)])

    def test_empty_line_before_the_verse_keeps_it_and_writes_a_citation(self):
        # как в примере: «Введение», пустая строка, стих, пустая строка, текст
        b = self.book()
        b.layout = entries(0, ('empty', 0), ('verse', 0), ('verse', 1), ('verse', 2), ('verse', 3), ('empty', 4))
        text, path = fb2_text(b)
        self.assertIn('<title><p>Введение</p></title>\n<empty-line/>\n<cite><poem>', text)
        self.assertNotIn('<epigraph>', text)                                 # эпиграф обязан идти первым: пустую строку не теряем
        self.assertIn('</poem></cite>\n<empty-line/>\n<p>Текст введения.</p>', text)
        r = bookio.read_fb2(path)
        self.assertEqual([(e['kind'], e['paragraph']) for e in r.layout],
                         [('empty', 0), ('verse', 0), ('verse', 1), ('verse', 2), ('verse', 3), ('empty', 4)])

    def test_verse_in_the_middle_is_a_citation_not_an_epigraph(self):
        b = self.book()
        b.layout = entries(0, ('verse', 2), ('verse', 3))
        text, _ = fb2_text(b)
        self.assertIn('<p>Я помню чудное мгновенье,</p>', text)
        self.assertIn('<cite><poem><stanza><v><emphasis>Как мимолётное виденье,</emphasis></v>', text)
        self.assertNotIn('<epigraph>', text)

    def test_chapter_made_only_of_verse_still_has_content_for_strict_readers(self):
        b = bookio.Book(title='Т', author='А')
        b.chapters = [('Эпиграф', ['Строка раз,', 'строка два.']), ('Дальше', ['Текст.'])]
        b.layout = entries(0, ('verse', 0), ('verse', 1))
        text, path = fb2_text(b)
        self.assertRegex(text, r'</epigraph>\n<empty-line/>\n</section>')
        self.assertEqual(bookio.read_fb2(path).chapters[0][1], ['Строка раз,', 'строка два.'])

    def test_empty_lines_in_ordinary_text(self):
        b = self.book()
        b.layout = entries(1, ('empty', 1), ('empty', 1), ('empty', 2))
        text, path = fb2_text(b)
        self.assertIn('<p>Первый абзац.</p>\n<empty-line/>\n<empty-line/>\n<p>Второй абзац.</p>\n<empty-line/>', text)
        r = bookio.read_fb2(path)
        self.assertEqual([(e['kind'], e['paragraph']) for e in r.layout], [('empty', 1), ('empty', 1), ('empty', 2)])

    def test_new_page_starts_a_new_section_that_reads_back_as_the_same_chapter(self):
        b = self.book()
        b.layout = entries(1, ('page', 1))
        b.annotations = [{'chapter': 1, 'paragraph': 1, 'start': 0, 'end': 6, 'level': 1, 'quote': 'Второй',
                          'context': 'Второй абзац.'}]
        text, path = fb2_text(b)
        self.assertIn('</section>\n<section id="bv-page-2-1">\n<p>Второй абзац.</p>\n</section>', text)
        r = bookio.read_fb2(path)
        self.assertEqual(len(r.chapters), 2)                                 # страница не стала новой главой
        self.assertEqual(r.chapters[1], ('Дием', ['Первый абзац.', 'Второй абзац.']))
        self.assertEqual(r.layout, [{'chapter': 1, 'paragraph': 1, 'kind': 'page'}])
        self.assertEqual([(a['chapter'], a['paragraph'], a['quote']) for a in r.annotations], [(1, 1, 'Второй')])

    def test_page_marker_at_the_end_gives_the_following_picture_its_own_page(self):
        b = self.book()
        b.images = [{'slot': 2, 'data': _tiny_png(), 'name': 'конец.png'}]
        b.layout = entries(1, ('page', 2))
        text, path = fb2_text(b)
        self.assertRegex(text, r'<section id="bv-page-2-1">\s*<image l:href="#bvimg1" id="bv-img-1"[^>]*/>\s*</section>')
        r = bookio.read_fb2(path)
        self.assertEqual([im['slot'] for im in r.images], [2])               # картинка осталась после последней главы
        self.assertEqual(r.layout, [{'chapter': 1, 'paragraph': 2, 'kind': 'page'}])
        self.assertEqual(len(r.chapters), 2)

    def test_pictures_without_layout_stay_where_they_were(self):
        b = self.book()
        b.images = [{'slot': 0, 'data': _tiny_png(), 'name': 'а.png'}, {'slot': 1, 'data': _tiny_png(), 'name': 'б.png'}]
        text, path = fb2_text(b)
        self.assertRegex(text, r'<section id="ch1"><title><p>Введение</p></title>\s*<image l:href="#bvimg1" id="bv-chapter-img-1"')
        r = bookio.read_fb2(path)
        self.assertEqual(sorted(im['slot'] for im in r.images), [0, 1])

    def test_picture_after_epigraph_keeps_the_schema_order(self):
        b = self.book()
        b.images = [{'slot': 0, 'data': _tiny_png(), 'name': 'а.png'}]
        b.layout = entries(0, ('verse', 0), ('verse', 1))
        text, _ = fb2_text(b)
        self.assertLess(text.index('</epigraph>'), text.index('id="bv-chapter-img-1"'))   # title, epigraph, image, текст

    def test_output_is_well_formed_and_sections_follow_the_schema(self):
        b = self.book()
        b.number_from = 1
        b.layout = (entries(0, ('verse', 0), ('verse', 1), ('empty', 2), ('page', 4)) +
                    entries(1, ('empty', 0), ('page', 1), ('empty', 2)))
        _, path = fb2_text(b)
        root = ET.parse(path).getroot()
        for sec in root.iter(NS + 'section'):
            names = [c.tag.replace(NS, '') for c in sec]
            if 'epigraph' in names:                                            # эпиграф сразу после названия
                self.assertEqual(names.index('epigraph'), 1 if 'title' in names else 0)
            if 'title' in names:
                self.assertEqual(names[0], 'title')
            self.assertTrue([n for n in names if n not in ('title', 'epigraph')], 'у секции нет содержания')

    def test_foreign_fb2_with_poems_and_empty_lines_is_read_with_layout(self):
        xml = ('<?xml version="1.0" encoding="utf-8"?><FictionBook xmlns="http://www.gribuser.ru/xml/fictionbook/2.0">'
               '<description><title-info><book-title>Ч</book-title></title-info></description><body>'
               '<section><title><p>Пролог</p></title><epigraph><poem><stanza><v>Строка раз,</v><v>строка два.</v></stanza>'
               '<stanza><v>Строка три.</v></stanza></poem><text-author>Автор</text-author></epigraph>'
               '<empty-line/><p>Текст.</p><cite><p>Цитата.</p></cite></section></body></FictionBook>')
        path = Path(tempfile.mkdtemp()) / 'x.fb2'
        path.write_text(xml, encoding='utf-8')
        r = bookio.read_fb2(path)
        self.assertEqual(r.chapters, [('Пролог', ['Строка раз,', 'строка два.', 'Строка три.', 'Текст.', 'Цитата.'])])
        self.assertEqual([(e['kind'], e['paragraph']) for e in r.layout],
                         [('verse', 0), ('verse', 1), ('empty', 2), ('verse', 2), ('empty', 3)])

    def test_other_formats_get_numbered_titles_and_no_layout(self):
        b = self.book()
        b.number_from = 1
        b.layout = entries(0, ('verse', 0), ('empty', 2))
        d = Path(tempfile.mkdtemp())
        bookio.write_any(b, d / 'k.txt')
        txt = (d / 'k.txt').read_text(encoding='utf-8')
        self.assertIn('Глава 1 - Дием', txt)
        self.assertIn('\nВведение\n', txt)
        bookio.write_any(b, d / 'k.md')
        self.assertIn('## Глава 1 - Дием', (d / 'k.md').read_text(encoding='utf-8'))
        self.assertEqual([t for t, _ in b.chapters], ['Введение', 'Дием'])      # исходная книга не изменилась
        bookio.write_any(b, d / 'k.epub')
        import zipfile
        with zipfile.ZipFile(d / 'k.epub') as z:
            self.assertTrue(any('Глава 1 - Дием' in z.read(n).decode('utf-8', 'ignore') for n in z.namelist()
                                if n.endswith(('.xhtml', '.ncx', '.opf'))))

    def test_merge_files_carries_the_layout_with_the_chapters(self):
        d = Path(tempfile.mkdtemp())
        a = self.book()
        a.layout = entries(0, ('verse', 0), ('empty', 4)) + entries(1, ('page', 1))
        bookio.write_fb2(a, d / 'a.fb2')
        (d / 'b.txt').write_text('Глава\n\nТекст.', encoding='utf-8')
        m = bookio.merge_files([d / 'a.fb2', d / 'b.txt'])
        self.assertEqual(len(m.book.chapters), 3)
        self.assertEqual([(e['chapter'], e['kind'], e['paragraph']) for e in m.book.layout],
                         [(0, 'verse', 0), (0, 'empty', 4), (1, 'page', 1)])


def _tiny_png():
    from tests.test_export_formats import make_png
    return make_png(20, 20)


# ---------------------------------------------------------------- редактор
class FakeText:
    """Окно текста без Tk: строки, индексы «строка.столбец», теги, вставка и удаление (без наследования тегов)."""

    def __init__(self, *a, **kw):
        self.t, self.tags, self.ins, self.selection = '\n', {}, 0, None

    def _starts(self):
        pos, out = 0, []
        for line in self.t.split('\n'):
            out.append(pos)
            pos += len(line) + 1
        return out

    def _off(self, index):
        index = str(index)
        if index == 'insert':
            return self.ins
        if index == 'end':
            return len(self.t)
        if index == 'end-1c':
            return len(self.t) - 1
        if index == 'sel.first':
            return self.selection[0]
        if index == 'sel.last':
            return self.selection[1]
        line, col = index.split('.')
        lines, starts = self.t.split('\n'), self._starts()
        if int(line) > len(lines) - 1:
            return len(self.t)
        base = starts[int(line) - 1]
        width = len(lines[int(line) - 1])
        return base + (width if col == 'end' else min(int(col), width))

    def _idx(self, off):
        starts = self._starts()
        line = max(i for i, s in enumerate(starts) if s <= off)
        return f'{line + 1}.{off - starts[line]}'

    def index(self, i):
        return self._idx(self._off(i))

    def get(self, a, b=None):
        oa = self._off(a)
        return self.t[oa:self._off(b)] if b is not None else self.t[oa:oa + 1]

    def insert(self, index, text, *tags):
        off = self._off(index)
        self.t = self.t[:off] + text + self.t[off:]
        for name in self.tags:
            self.tags[name] = {o + len(text) if o >= off else o for o in self.tags[name]}
        if off <= self.ins:
            self.ins += len(text)

    def delete(self, a, b=None):
        oa = self._off(a)
        ob = min(self._off(b) if b is not None else oa + 1, len(self.t) - 1)      # последний перевод строки Tk не удаляет
        self.t = self.t[:oa] + self.t[ob:]
        for name in self.tags:
            self.tags[name] = {o - (ob - oa) if o >= ob else o for o in self.tags[name] if not oa <= o < ob}
        self.ins = min(self.ins, len(self.t) - 1)

    def tag_add(self, tag, a, b=None):
        oa = self._off(a)
        ob = self._off(b) if b is not None else oa + 1
        self.tags.setdefault(tag, set()).update(range(oa, min(ob, len(self.t))))

    def tag_remove(self, tag, a, b=None):
        oa = self._off(a)
        ob = self._off(b) if b is not None else oa + 1
        self.tags.setdefault(tag, set()).difference_update(range(oa, ob))

    def tag_ranges(self, tag):
        offs = self.selection and set(range(*self.selection)) if tag == 'sel' else self.tags.get(tag, set())
        if tag == 'sel' and not self.selection:
            return ()
        out, run = [], []
        for o in sorted(offs) + [None]:
            if run and (o is None or o != run[-1] + 1):
                out += [self._idx(run[0]), self._idx(run[-1] + 1)]
                run = []
            if o is not None:
                run.append(o)
        return tuple(out)

    def tag_names(self, index):
        off = self._off(index)
        return tuple(t for t, offs in self.tags.items() if off in offs)

    def mark_set(self, name, index):
        if name == 'insert':
            self.ins = self._off(index)

    def select(self, a, b):
        self.selection = (self._off(a), self._off(b))

    def edit_separator(self): ...
    def edit_reset(self): ...
    def focus_set(self): ...
    def pack_forget(self): ...
    def pack(self, *a, **k): ...
    def destroy(self): ...


class FakeTree:
    def __init__(self):
        self.rows = {}

    def delete(self, *items):
        for i in items:
            self.rows.pop(i, None)

    def get_children(self):
        return tuple(self.rows)

    def insert(self, parent, index, iid=None, values=()):
        self.rows[iid] = list(values)

    def exists(self, iid):
        return iid in self.rows

    def set(self, iid, col, value):
        self.rows[iid][{'n': 0, 'title': 1, 'chars': 2}[col]] = value

    def selection_set(self, iid): ...
    def see(self, iid): ...


class Var:
    def __init__(self, v=''):
        self.v = v

    def get(self):
        return self.v

    def set(self, v):
        self.v = v


def make_tab(chapters):
    """chapters: [(название, абзацы, оформление [(вид, номер абзаца)])]."""
    tab = edit_tab.EditTab.__new__(edit_tab.EditTab)
    tab.items, tab.cur, tab.next_id = [], None, 1
    tab.tail_images, tab.next_img_id, tab.sel_img = [], 1, None
    tab.title_var, tab.author_var, tab.lang_var, tab.status = Var('К'), Var('А'), Var('ru'), Var()
    tab.number_fmt, tab.number_start_id = Var(lm.DEFAULT_NUMBER_FORMAT), None
    tab.cover, tab.snapshot, tab.accent_dirty = None, None, False
    tab.tree = FakeTree()
    tab.make_text = lambda: FakeText()
    tab.select_item = lambda it: setattr(tab, 'cur', it)
    for title, paras, lay in chapters:
        it = tab.new_item(title, paras)
        it['layout'] = [{'paragraph': p, 'kind': k} for k, p in lay]
        tab.items.append(it)
    tab.cur = tab.items[0] if tab.items else None
    return tab


def layout_of(tab, i):
    return [(e['kind'], e['paragraph']) for e in tab.item_layout(tab.items[i])]


class EditorLayoutTests(unittest.TestCase):
    def test_widget_shows_marks_and_paragraphs_stay_clean(self):
        tab = make_tab([('Введение', ['а', 'б', 'в'], [('empty', 0), ('verse', 0), ('verse', 1), ('empty', 2), ('page', 3)])])
        w = tab.ensure_widget(tab.items[0])
        self.assertEqual(w.get('1.0', 'end-1c').split('\n'),
                         [lm.MARK_EMPTY, 'а', 'б', lm.MARK_EMPTY, 'в', lm.MARK_PAGE])
        self.assertEqual(tab.get_paras(tab.items[0]), ['а', 'б', 'в'])
        self.assertEqual(layout_of(tab, 0), [('empty', 0), ('verse', 0), ('verse', 1), ('empty', 2), ('page', 3)])
        self.assertIn('layoutmark', w.tag_names('1.0'))
        self.assertIn('verse', w.tag_names('2.0'))

    def test_unopened_and_opened_chapter_give_the_same_layout(self):
        tab = make_tab([('Г', ['а', 'б'], [('verse', 1), ('empty', 1), ('page', 2)])])
        before = layout_of(tab, 0)
        tab.ensure_widget(tab.items[0])
        self.assertEqual(layout_of(tab, 0), before)

    def test_accents_land_on_the_right_paragraph_when_marks_shift_the_lines(self):
        tab = make_tab([('Г', ['первый', 'второй'], [('empty', 0), ('empty', 1)])])
        tab.items[0]['annotations'] = [{'paragraph': 1, 'start': 0, 'end': 6, 'level': 1}]
        w = tab.ensure_widget(tab.items[0])
        self.assertEqual(w.get('1.0', 'end-1c').split('\n'), [lm.MARK_EMPTY, 'первый', lm.MARK_EMPTY, 'второй'])
        self.assertEqual(w.tag_ranges('accent1'), ('4.0', '4.6'))                  # а не в метке и не в первом абзаце
        recs = tab.accent_records(tab.items[0])
        self.assertEqual([(r['paragraph'], r['quote']) for r in recs], [(1, 'второй')])

    def test_set_paras_keeps_layout_and_accents(self):
        tab = make_tab([('Г', ['тут', 'там'], [('verse', 0), ('empty', 1)])])
        tab.items[0]['annotations'] = [{'paragraph': 1, 'start': 0, 'end': 3, 'level': 2}]
        w = tab.ensure_widget(tab.items[0])
        lost = tab.set_paras(tab.items[0], ['тут', 'там'])                           # как «типографика» без изменений
        self.assertEqual(lost, 0)
        self.assertEqual(layout_of(tab, 0), [('verse', 0), ('empty', 1)])
        self.assertEqual(w.get('1.0', 'end-1c').split('\n'), ['тут', lm.MARK_EMPTY, 'там'])
        self.assertEqual(w.tag_ranges('accent2'), ('3.0', '3.3'))

    def test_typography_and_replace_keep_marks(self):
        tab = make_tab([('Г', ['a - b', '"c"'], [('empty', 1), ('page', 2)])])
        tab.refresh_tree = lambda *a, **k: None
        tab.ensure_widget(tab.items[0])
        with mock.patch.object(edit_tab.messagebox, 'askyesno', return_value=True):
            tab.typography()
        self.assertEqual(tab.get_paras(tab.items[0]), ['a — b', '«c»'])
        self.assertEqual(layout_of(tab, 0), [('empty', 1), ('page', 2)])
        tab.find_var, tab.repl_var = Var('«c»'), Var('«d»')
        tab.replace_all()
        self.assertEqual(tab.get_paras(tab.items[0]), ['a — b', '«d»'])
        self.assertEqual(layout_of(tab, 0), [('empty', 1), ('page', 2)])

    def test_insert_empty_line_and_page_under_the_cursor(self):
        tab = make_tab([('Г', ['первый', 'второй'], [])])
        w = tab.ensure_widget(tab.items[0])
        w.mark_set('insert', '1.3')
        tab.insert_mark('empty')
        tab.insert_mark('empty')                                                    # два нажатия = две пустые строки
        tab.insert_mark('page')
        self.assertEqual(w.get('1.0', 'end-1c').split('\n'),
                         ['первый', lm.MARK_EMPTY, lm.MARK_EMPTY, lm.MARK_PAGE, 'второй'])
        self.assertEqual(layout_of(tab, 0), [('empty', 1), ('empty', 1), ('page', 1)])
        self.assertEqual(tab.get_paras(tab.items[0]), ['первый', 'второй'])

    def test_insert_on_a_blank_line_replaces_it_and_never_inherits_verse(self):
        tab = make_tab([('Г', ['стих', 'проза'], [('verse', 0)])])
        w = tab.ensure_widget(tab.items[0])
        w.mark_set('insert', '1.4')
        tab.insert_mark('empty')                                                    # под строкой стиха
        self.assertNotIn('verse', w.tag_names('2.0'))
        self.assertEqual(layout_of(tab, 0), [('verse', 0), ('empty', 1)])
        w.insert('end-1c', '\n')
        w.mark_set('insert', 'end-1c')
        tab.insert_mark('page')                                                     # курсор на пустой строке в конце
        self.assertEqual(w.get('1.0', 'end-1c').split('\n')[-1], lm.MARK_PAGE)

    def test_inserted_mark_does_not_inherit_accent_or_verse_tags(self):
        tab = make_tab([('Г', ['слово'], [('verse', 0)])])
        w = tab.ensure_widget(tab.items[0])
        w.tag_add('accent1', '1.0', '1.5')
        w.mark_set('insert', '1.2')
        real_insert = w.insert

        def inheriting_insert(index, text, *tags):                                  # как Tk: вставка наследует теги слева
            real_insert(index, text)
            off = w._off(index)
            for name in ('accent1', 'verse'):
                w.tags[name].update(range(off, off + len(text)))
        w.insert = inheriting_insert
        tab.insert_mark('empty')
        self.assertEqual(w.tag_names('2.0'), ('layoutmark',))
        self.assertEqual(layout_of(tab, 0), [('verse', 0), ('empty', 1)])

    def test_toggle_verse_on_cursor_line_selection_and_back(self):
        tab = make_tab([('Г', ['раз', 'два', 'три', 'проза'], [('empty', 3)])])
        w = tab.ensure_widget(tab.items[0])
        w.mark_set('insert', '1.1')
        tab.toggle_verse()
        self.assertEqual(layout_of(tab, 0), [('verse', 0), ('empty', 3)])
        w.select('2.0', '3.3')                                                      # две строки сразу
        tab.toggle_verse()
        self.assertEqual(layout_of(tab, 0), [('verse', 0), ('verse', 1), ('verse', 2), ('empty', 3)])
        w.select('1.0', '3.3')                                                      # все уже стих: пометка снимается
        tab.toggle_verse()
        self.assertEqual(layout_of(tab, 0), [('empty', 3)])

    def test_toggle_verse_ignores_marks_and_blank_lines(self):
        tab = make_tab([('Г', ['раз'], [('empty', 0)])])
        w = tab.ensure_widget(tab.items[0])
        w.mark_set('insert', '1.2')                                                 # курсор на метке
        tab.toggle_verse()
        self.assertEqual(layout_of(tab, 0), [('empty', 0)])
        self.assertIn('Поставь курсор', tab.status.get())

    def test_selection_ending_at_line_start_does_not_take_the_next_line(self):
        tab = make_tab([('Г', ['раз', 'два'], [])])
        w = tab.ensure_widget(tab.items[0])
        w.select('1.0', '2.0')
        tab.toggle_verse()
        self.assertEqual(layout_of(tab, 0), [('verse', 0)])

    def test_merge_chapters_shifts_the_second_layout(self):
        tab = make_tab([('А', ['а1', 'а2'], [('verse', 0)]), ('Б', ['б1'], [('empty', 0), ('page', 1)])])
        tab.refresh_tree = lambda *a, **k: None
        tab.ensure_widget(tab.items[0])
        tab.merge_next()
        self.assertEqual(len(tab.items), 1)
        self.assertEqual(tab.get_paras(tab.items[0]), ['а1', 'а2', 'б1'])
        self.assertEqual(layout_of(tab, 0), [('verse', 0), ('empty', 2), ('page', 3)])

    def test_merge_of_unopened_chapters_keeps_layout_too(self):
        tab = make_tab([('А', ['а1'], [('verse', 0)]), ('Б', ['б1'], [('verse', 0)])])
        tab.refresh_tree = lambda *a, **k: None
        tab.merge_next()
        self.assertEqual(tab.item_layout(tab.items[0]), [{'paragraph': 0, 'kind': 'verse'}, {'paragraph': 1, 'kind': 'verse'}])

    def test_split_chapter_divides_layout_at_the_cursor(self):
        tab = make_tab([('А', ['один', 'два', 'три', 'четыре'],
                         [('verse', 0), ('empty', 2), ('verse', 2), ('verse', 3), ('page', 4)])])
        tab.refresh_tree = lambda *a, **k: None
        w = tab.ensure_widget(tab.items[0])
        w.mark_set('insert', '4.0')                                                  # перед «три» (после метки пустой строки)
        with mock.patch.object(edit_tab.simpledialog, 'askstring', return_value='Новая'):
            tab.split_here()
        head, tail = tab.items
        self.assertEqual(tab.get_paras(head), ['один', 'два'])
        self.assertEqual(layout_of(tab, 0), [('verse', 0), ('empty', 2)])
        self.assertEqual(tail['paras'], ['три', 'четыре'])
        self.assertEqual(tail['layout'], [{'paragraph': 0, 'kind': 'verse'}, {'paragraph': 1, 'kind': 'verse'},
                                          {'paragraph': 2, 'kind': 'page'}])

    def test_split_in_the_middle_of_a_verse_line_keeps_verse_on_both_halves(self):
        tab = make_tab([('А', ['раз два', 'три'], [('verse', 0)])])
        tab.refresh_tree = lambda *a, **k: None
        w = tab.ensure_widget(tab.items[0])
        w.mark_set('insert', '1.3')
        with mock.patch.object(edit_tab.simpledialog, 'askstring', return_value='Н'):
            tab.split_here()
        self.assertEqual(tab.items[1]['paras'], ['два', 'три'])
        self.assertEqual(tab.items[1]['layout'], [{'paragraph': 0, 'kind': 'verse'}])

    def test_split_with_only_marks_after_the_cursor_is_refused(self):
        tab = make_tab([('А', ['раз'], [('empty', 1)])])
        w = tab.ensure_widget(tab.items[0])
        w.mark_set('insert', '1.3')
        with mock.patch.object(edit_tab.messagebox, 'showinfo') as info:
            tab.split_here()
        self.assertTrue(info.called)
        self.assertEqual(len(tab.items), 1)

    def test_collect_and_load_book_roundtrip_with_numbering(self):
        tab = make_tab([('Введение', ['а', 'б'], [('verse', 0), ('empty', 2)]), ('Дием', ['в'], [('page', 0)])])
        tab.number_start_id = tab.items[1]['id']
        tab.number_fmt.set('Часть {n}. {title}')
        book = tab.collect_book()
        self.assertEqual((book.number_from, book.number_format), (1, 'Часть {n}. {title}'))
        self.assertEqual([(e['chapter'], e['kind'], e['paragraph']) for e in book.layout],
                         [(0, 'verse', 0), (0, 'empty', 2), (1, 'page', 0)])
        other = make_tab([])
        other.hide_image_panel = lambda: None
        other.set_cover = lambda c: None
        other.refresh_tree = lambda *a, **k: None
        other.load_book(book)
        self.assertEqual(other.number_index(), 1)
        self.assertEqual(other.number_fmt.get(), 'Часть {n}. {title}')
        self.assertEqual(layout_of(other, 0), [('verse', 0), ('empty', 2)])
        self.assertEqual(layout_of(other, 1), [('page', 0)])

    def test_bad_number_format_falls_back_to_default_when_saving(self):
        tab = make_tab([('А', ['а'], [])])
        tab.number_start_id = tab.items[0]['id']
        tab.number_fmt.set('просто текст')
        self.assertEqual(tab.collect_book().number_format, lm.DEFAULT_NUMBER_FORMAT)

    def test_layout_and_numbering_make_the_editor_dirty(self):
        tab = make_tab([('А', ['раз', 'два'], [])])
        tab.ensure_widget(tab.items[0])
        tab.mark_clean()
        self.assertFalse(tab.is_dirty())
        w = tab.items[0]['w']
        w.mark_set('insert', '1.1')
        tab.insert_mark('empty')
        self.assertTrue(tab.is_dirty())
        tab.mark_clean()
        tab.number_start_id = tab.items[0]['id']
        self.assertTrue(tab.is_dirty())

    def test_tree_shows_chapter_numbers_after_the_marker(self):
        tab = make_tab([('Введение', ['а'], []), ('Пролог', ['б'], []), ('Дием', ['в'], []), ('Второй', ['г'], [])])
        tab.refresh_tree()
        self.assertEqual([r[0] for r in tab.tree.rows.values()], [1, 2, 3, 4])      # без нумерации как раньше
        tab.cur = tab.items[2]
        tab.toggle_number_start()
        self.assertEqual([r[0] for r in tab.tree.rows.values()], ['·', '·', 1, 2])
        self.assertIn('Глава 1 - Дием', tab.status.get())
        tab.toggle_number_start()                                                  # повторное нажатие снимает отметку
        self.assertEqual([r[0] for r in tab.tree.rows.values()], [1, 2, 3, 4])

    def test_number_marker_follows_its_chapter_and_survives_delete_and_merge(self):
        tab = make_tab([('А', ['а'], []), ('Б', ['б'], []), ('В', ['в'], [])])
        tab.refresh_tree = lambda *a, **k: None
        tab.number_start_id = tab.items[1]['id']
        tab.items[0], tab.items[1] = tab.items[1], tab.items[0]                    # «↑»: Б стала первой
        self.assertEqual(tab.number_index(), 0)
        tab.cur = tab.items[0]
        with mock.patch.object(edit_tab.messagebox, 'askyesno', return_value=True):
            tab.delete_chapter()                                                   # удалили отмеченную: отметка у следующей
        self.assertEqual(tab.items[tab.number_index()]['title'], 'А')
        tab2 = make_tab([('А', ['а'], []), ('Б', ['б'], [])])
        tab2.refresh_tree = lambda *a, **k: None
        tab2.number_start_id = tab2.items[1]['id']
        tab2.merge_next()
        self.assertEqual(tab2.number_index(), 0)

    def test_append_files_carries_layout(self):
        d = Path(tempfile.mkdtemp())
        book = bookio.Book(title='Т')
        book.chapters = [('Введение', ['а', 'б'])]
        book.layout = entries(0, ('verse', 0), ('empty', 2))
        bookio.write_fb2(book, d / 'a.fb2')
        tab = make_tab([('Старая', ['х'], [])])
        tab.refresh_tree = lambda *a, **k: None
        tab.set_cover = lambda c: None
        tab.append_paths([d / 'a.fb2'])
        self.assertEqual(len(tab.items), 2)
        self.assertEqual(layout_of(tab, 1), [('verse', 0), ('empty', 2)])

    def test_save_warns_that_other_formats_lose_the_layout(self):
        tab = make_tab([('А', ['а'], [('empty', 0)])])
        tab.save_path = str(Path(tempfile.mkdtemp()) / 'k.txt')
        tab.use_title = tab.use_toc = Var(False)
        tab.mark_clean = lambda: None
        asked = []
        with mock.patch.object(edit_tab.messagebox, 'askyesno', lambda t, m, **k: asked.append(t) or False):
            tab.save()
        self.assertEqual(asked, ['Оформление'])
        self.assertFalse(Path(tab.save_path).exists())

    def test_live_reading_skips_marks_and_empty_lines_strengthen_the_pause(self):
        calls = []

        class FakeTTS:
            def prepare_paragraph_ex(self, text, pairs=None):
                calls.append(text)
                return [(0, text)]
        subject = SimpleNamespace(app=SimpleNamespace(tts=FakeTTS()))
        text = 'Первая.\n' + lm.MARK_EMPTY + '\n' + lm.MARK_PAGE + '\nВторая.'
        units = list(edit_tab.EditTab.iter_live_units(subject, text, 0))
        self.assertEqual(calls, ['Первая.', 'Вторая.'])                             # метки не озвучиваются
        self.assertEqual([u['text'] for u in units], ['Первая.', 'Вторая.'])
        self.assertEqual(units[0]['paragraph_breaks'], 3)                          # 1 + две метки как пустые строки

    def test_character_count_ignores_marks(self):
        tab = make_tab([('Г', ['раз'], [('empty', 0), ('empty', 1)])])
        w = tab.ensure_widget(tab.items[0])
        tab.cur = tab.items[0]
        tab.tree.rows['1'] = [1, 'Г', 0]
        tab.update_counts()
        self.assertEqual(tab.tree.rows['1'][2], 3)


if __name__ == '__main__':
    unittest.main()
