import unittest

import shtorm


class ShtormAdapterTests(unittest.TestCase):
    def test_plus_to_acute(self):
        self.assertEqual(shtorm.plus_to_acute('С+ерое н+ебо'), 'Се\u0301рое не\u0301бо')

    def test_strips_silero_only_markers(self):
        self.assertEqual(shtorm.plus_to_acute('*слово*'), 'слово')

    def test_variant_config_names(self):
        self.assertEqual(shtorm.VARIANTS['fast'], 'config_fast.yaml')
        self.assertEqual(shtorm.VARIANTS['slow'], 'config_slow.yaml')

    def test_empty_text(self):
        self.assertEqual(shtorm.synthesize('').size, 0)


if __name__ == '__main__':
    unittest.main()
