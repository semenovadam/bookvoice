"""Тесты на ошибки, найденные при проверке проекта (FB2, акценты редактора, паузы, переключение движка)."""
import atexit
import os
import re
import shutil
import tempfile
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

if not os.environ.get('BOOKVOICE_MODELS_DIR'):             # import app создаёт папки моделей: пусть они будут временными
    _MODELS_FOR_TESTS = tempfile.mkdtemp(prefix='bookvoice_models_')
    os.environ['BOOKVOICE_MODELS_DIR'] = _MODELS_FOR_TESTS
    atexit.register(shutil.rmtree, _MODELS_FOR_TESTS, True)

import bookio
import edit_tab
from edit_tab import EditTab
from fake_text import FakeText
from punctuation_pauses import pause_ms

FB = '{http://www.gribuser.ru/xml/fictionbook/2.0}'

FB2_WITH_COMMENTS = '''<?xml version="1.0" encoding="utf-8"?>
<!-- сделано какой-то программой -->
<FictionBook xmlns="http://www.gribuser.ru/xml/fictionbook/2.0" xmlns:l="http://www.w3.org/1999/xlink">
<description><!-- описание -->
<title-info><genre>prose</genre><author><first-name>Иван</first-name><last-name>Петров</last-name></author><book-title>Книга</book-title><lang>ru</lang></title-info>
<document-info><author><nickname>x</nickname></author><date value="2020-01-01">2020</date><id>1</id><version>1.0</version></document-info>
</description>
<body>
<!-- начало -->
<section id="a"><title><p>Глава один</p></title><!-- внутри --><p>Первый <!-- середина -->абзац.</p><p>Второй абзац.</p></section>
<!-- между главами -->
<section><title><p>Глава два</p></title><p>Третий абзац.</p></section>
</body>
</FictionBook>
'''


def ann(chapter, paragraph, quote, text, level=1, start=None):
    start = text.index(quote) if start is None else start
    return {'chapter': chapter, 'paragraph': paragraph, 'start': start, 'end': start + len(quote),
            'level': level, 'quote': quote, 'context': text[max(0, start - 24):start + len(quote) + 24]}


class Fb2ReadWriteTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def test_fb2_with_ordinary_xml_comments_opens(self):
        # Раньше read_fb2 падал на любом комментарии (AttributeError: 'function' has no 'rsplit').
        path = self.dir / 'c.fb2'
        path.write_text(FB2_WITH_COMMENTS, encoding='utf-8')
        b = bookio.read_fb2(path)
        self.assertEqual(b.title, 'Книга')
        self.assertEqual(b.author, 'Иван Петров')
        self.assertEqual(b.chapters, [('Глава один', ['Первый абзац.', 'Второй абзац.']),
                                      ('Глава два', ['Третий абзац.'])])

    def test_custom_info_stands_in_description_per_fb2_schema(self):
        text = 'Что ты делаешь?'
        book = bookio.Book(title='T', author='A', chapters=[('Г', ['Привет.', text])],
                           annotations=[ann(0, 1, 'ты', text, 2)])
        path = self.dir / 'b.fb2'
        bookio.write_fb2(book, path)
        desc = ET.parse(path).getroot().find(FB + 'description')
        self.assertEqual([c.tag for c in desc if isinstance(c.tag, str)],
                         [FB + 'title-info', FB + 'document-info', FB + 'custom-info'])
        self.assertEqual(bookio.read_fb2(path).annotations[0]['quote'], 'ты')

    def test_old_placement_inside_document_info_still_reads(self):
        text = 'Что ты делаешь?'
        book = bookio.Book(title='T', author='A', chapters=[('Г', [text])],
                           annotations=[ann(0, 0, 'ты', text, 2)])
        path = self.dir / 'old.fb2'
        bookio.write_fb2(book, path)
        raw = path.read_text(encoding='utf-8')
        info = re.search(r'<custom-info .*?</custom-info>', raw, re.S).group(0)
        raw = raw.replace(info, '').replace('</document-info>', info + '</document-info>')
        raw = re.sub(r'<!--BOOKVOICE.*?-->', '', raw)
        path.write_text(raw, encoding='utf-8')
        self.assertEqual(bookio.read_fb2(path).annotations[0]['quote'], 'ты')

    def test_empty_chapter_does_not_shift_annotations(self):
        text = 'Что ты делаешь?'
        book = bookio.Book(title='T', author='A',
                           chapters=[('Один', ['Первый абзац.']), ('Пусто', []), ('Три', [text])],
                           annotations=[ann(2, 0, 'ты', text, 2)])
        path = self.dir / 'e.fb2'
        bookio.write_fb2(book, path)
        loaded = bookio.read_fb2(path)
        self.assertEqual([t for t, _ in loaded.chapters], ['Один', 'Три'])    # пустая глава при чтении пропускается
        self.assertEqual(bookio.annotations_as_markers(loaded)[1][1][0], 'Что **ты** делаешь?')

    def test_negative_numbers_are_not_python_indexes(self):
        chapters = [('Г', ['abc def'])]
        bad = [{'chapter': -1, 'paragraph': 0, 'start': 0, 'end': 3, 'level': 1, 'quote': 'abc'},
               {'chapter': 0, 'paragraph': -1, 'start': 0, 'end': 3, 'level': 1, 'quote': 'abc'}]
        self.assertEqual(bookio.normalize_annotations(bad, chapters), [])

    def test_markdown_underscores_are_removed_stars_stay(self):
        self.assertEqual(bookio._md_clean('Это _курсив_ и __жирный__, *акцент* и **сильный**.'),
                         'Это курсив и жирный, *акцент* и **сильный**.')
        self.assertEqual(bookio._md_clean('snake_case_name'), 'snake_case_name')


class Var:
    def __init__(self, value=''):
        self.value = value

    def get(self):
        return self.value

    def set(self, value):
        self.value = value


def make_tab(chapters):
    tab = EditTab.__new__(EditTab)          # без окна: проверяем только логику
    tab.items, tab.cur, tab.next_id = [], None, 1
    tab.title_var, tab.author_var, tab.lang_var = Var('Книга'), Var('Автор'), Var('ru')
    tab.cover, tab.snapshot, tab.accent_dirty = None, None, False
    tab.status = Var()
    tab.make_text = FakeText
    tab.refresh_tree = lambda *a, **k: None
    tab.select_item = lambda it: setattr(tab, 'cur', it)
    for title, paras in chapters:
        tab.items.append(tab.new_item(title, paras))
    tab.cur = tab.items[0]
    return tab


def mark(w, word, level, line=None):
    """Тег акцента на первом слове word (в строке line или в первой, где оно есть)."""
    for n, text in enumerate(w.get('1.0', 'end-1c').split('\n'), 1):
        if (line in (None, n)) and word in text:
            c = text.index(word)
            w.tag_add('accent2' if level == 2 else 'accent1', f'{n}.{c}', f'{n}.{c + len(word)}')
            return
    raise AssertionError(word)


def accents(tab, it):
    paras = tab.get_paras(it)
    return sorted((a['paragraph'], paras[a['paragraph']][a['start']:a['end']], a['level'])
                  for a in tab.item_accents(it))


class EditorAccentTests(unittest.TestCase):
    def test_blank_lines_and_indents_do_not_shift_saved_accents(self):
        tab = make_tab([('Гл', ['Первый абзац тут.', 'Второй абзац здесь.'])])
        w = tab.ensure_widget(tab.items[0])
        w.delete('1.0', 'end')
        w.insert('1.0', 'Первый абзац тут.\n\n    Второй абзац здесь.\n')       # пустая строка и отступ
        mark(w, 'абзац', 1, line=1)
        mark(w, 'здесь', 2, line=3)
        book = tab.collect_book()
        self.assertEqual(book.chapters[0][1], ['Первый абзац тут.', 'Второй абзац здесь.'])
        self.assertEqual({(a['paragraph'], a['quote'], a['level']) for a in book.annotations},
                         {(0, 'абзац', 1), (1, 'здесь', 2)})

    def test_selection_with_spaces_and_line_break_is_trimmed_and_split(self):
        tab = make_tab([('Гл', ['Конец первой строки', 'начало второй строки'])])
        w = tab.ensure_widget(tab.items[0])
        w.tag_add('accent2', '1.5', '2.7')                   # « первой строки» + перевод строки + «начало »
        got = sorted((a['paragraph'], a['quote'], a['level']) for a in tab.collect_book().annotations)
        self.assertEqual(got, [(0, 'первой строки', 2), (1, 'начало', 2)])

    def test_unopened_and_opened_chapter_give_the_same_annotations(self):
        text = 'Что ты делаешь здесь?'
        tab = make_tab([('Г1', ['Первая.', text]), ('Г2', ['Другая.'])])
        tab.items[0]['annotations'] = [ann(0, 1, 'ты', text, 2), ann(0, 1, 'здесь', text, 1)]
        before = tab.collect_book().annotations
        for it in tab.items:
            tab.ensure_widget(it)
        after = tab.collect_book().annotations
        self.assertEqual(before, after)
        self.assertEqual(len(after), 2)

    def test_only_accent_change_makes_editor_dirty(self):
        tab = make_tab([('Гл', ['Слово тут.'])])
        w = tab.ensure_widget(tab.items[0])
        tab.mark_clean()
        self.assertFalse(tab.is_dirty())
        tab.apply_text_accent(w, '1.0', '1.5', 2)
        self.assertTrue(tab.is_dirty())              # текст тот же, но правка не сохранена
        tab.mark_clean()
        self.assertFalse(tab.is_dirty())

    def test_typography_keeps_accents_on_their_words(self):
        tab = make_tab([('Гл', ['Он сказал "да" и ушёл.', 'Второй абзац.'])])
        it = tab.items[0]
        w = tab.ensure_widget(it)
        mark(w, 'ушёл', 1)
        mark(w, 'Второй', 2)
        lost = tab.set_paras(it, [edit_tab.typo_fix(p) for p in tab.get_paras(it)])
        self.assertEqual(w.get('1.0', 'end-1c').split('\n')[0], 'Он сказал «да» и ушёл.')
        self.assertEqual(lost, 0)
        self.assertEqual(accents(tab, it), [(0, 'ушёл', 1), (1, 'Второй', 2)])

    def test_replaced_word_loses_its_accent_and_is_counted(self):
        tab = make_tab([('Гл', ['Иван пришёл домой.'])])
        it = tab.items[0]
        w = tab.ensure_widget(it)
        mark(w, 'Иван', 2)
        mark(w, 'домой', 1)
        lost = tab.set_paras(it, ['Пётр пришёл домой.'])
        self.assertEqual(lost, 1)
        self.assertEqual(accents(tab, it), [(0, 'домой', 1)])

    def test_replace_in_unopened_chapter_moves_accents_too(self):
        text = 'Он сказал "да" и ушёл.'
        tab = make_tab([('Гл', [text])])
        it = tab.items[0]
        it['annotations'] = [ann(0, 0, 'ушёл', text, 1)]
        self.assertEqual(tab.set_paras(it, ['Он сказал «да» и ушёл.']), 0)
        w = tab.ensure_widget(it)
        self.assertEqual(accents(tab, it), [(0, 'ушёл', 1)])
        self.assertEqual(len(w.tag_ranges('accent1')), 2)

    def test_merge_chapters_keeps_accents_of_both(self):
        tab = make_tab([('А', ['Первый абзац.']), ('Б', ['Второй абзац.'])])
        a, b = tab.items
        mark(tab.ensure_widget(a), 'Первый', 1)
        mark(tab.ensure_widget(b), 'абзац', 2)
        tab.cur = a
        tab.merge_next()
        self.assertEqual(len(tab.items), 1)
        self.assertEqual(tab.get_paras(a), ['Первый абзац.', 'Второй абзац.'])
        self.assertEqual(accents(tab, a), [(0, 'Первый', 1), (1, 'абзац', 2)])

    def test_split_chapter_moves_accents_of_the_tail(self):
        tab = make_tab([('Гл', ['Первый абзац тут.', 'Второй абзац здесь.', 'Третий абзац.'])])
        it = tab.items[0]
        w = tab.ensure_widget(it)
        mark(w, 'тут', 1)
        mark(w, 'абзац', 2, line=2)
        mark(w, 'Третий', 1)
        w.mark_set('insert', '2.7')                          # «Второй |абзац здесь.»
        with mock.patch.object(edit_tab.simpledialog, 'askstring', return_value='Новая'):
            tab.split_here()
        head, tail = tab.items
        self.assertEqual(tab.get_paras(head), ['Первый абзац тут.', 'Второй'])
        self.assertEqual(accents(tab, head), [(0, 'тут', 1)])
        self.assertEqual(tab.get_paras(tail), ['абзац здесь.', 'Третий абзац.'])
        tab.ensure_widget(tail)
        self.assertEqual(accents(tab, tail), [(0, 'абзац', 2), (1, 'Третий', 1)])

    def test_fb2_roundtrip_of_edited_text_with_blank_lines(self):
        tab = make_tab([('Гл', ['Первый.', 'Что ты делаешь?'])])
        w = tab.ensure_widget(tab.items[0])
        w.delete('1.0', 'end')
        w.insert('1.0', 'Первый.\n\n  Что ты делаешь?')
        mark(w, 'ты', 2)
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / 'x.fb2'
            bookio.write_fb2(tab.collect_book(), path)
            loaded = bookio.read_fb2(path)
        self.assertEqual(bookio.annotations_as_markers(loaded)[0][1], ['Первый.', 'Что **ты** делаешь?'])


class PauseWithMarkersTests(unittest.TestCase):
    def test_markers_at_chunk_end_do_not_hide_the_punctuation(self):
        self.assertEqual(pause_ms('Он крикнул: **Стоять!**'), pause_ms('Он крикнул: Стоять!'))
        self.assertGreater(pause_ms('*слово*.'), 0)
        self.assertEqual(pause_ms('* * *'), 0)


class ShtormSwitchTests(unittest.TestCase):
    """Выбор Shtorm: образец голоса спрашивается сразу, кнопки не блокируются."""

    def setUp(self):
        try:
            import app
        except Exception as e:                       # нет звуковых библиотек и т.п.
            self.skipTest(f'app не импортируется здесь: {e!r}')
        self.app = app
        self.tmp = tempfile.TemporaryDirectory()
        self.wav = Path(self.tmp.name) / 'голос.wav'
        self.wav.write_bytes(b'RIFF')
        self.calls = []

    def tearDown(self):
        self.tmp.cleanup()

    def fake(self, ref='', accepts=False):
        calls = self.calls

        def choose():                                 # диалог выбора WAV: принят файл или отмена
            calls.append('dialog')
            return accepts
        return SimpleNamespace(
            shtorm_variant=Var('fast'), shtorm_voice_ref=Var(ref), engine=Var('silero'),
            cur_engine=lambda: 'silero', row_voice=object(),
            shtorm_row=SimpleNamespace(pack=lambda **k: calls.append('row')),
            shtorm_ref_lbl=SimpleNamespace(configure=lambda **k: calls.append('label')),
            log=lambda m: calls.append('log'),
            set_busy=lambda *a, **k: calls.append('busy'),
            remember_voice=lambda: None, tab_edit=SimpleNamespace(live=None),
            choose_shtorm_voice=choose, _switch=lambda *a: None)

    def test_no_sample_asks_for_it_and_keeps_the_buttons_enabled(self):
        fake = self.fake()
        self.app.App.switch_engine(fake, 'shtorm')
        self.assertIn('dialog', self.calls)           # образец спрашивают сразу, а не ждут, что человек найдёт кнопку
        self.assertNotIn('busy', self.calls)          # раньше кнопки блокировались и не включались обратно
        self.assertIn('row', self.calls)
        self.assertEqual(fake.engine.get(), 'silero')  # отмена: остаётся прежний движок

    def test_missing_sample_file_is_asked_again(self):
        self.app.App.switch_engine(self.fake(ref=str(self.wav.with_name('нет.wav'))), 'shtorm')
        self.assertIn('dialog', self.calls)
        self.assertNotIn('busy', self.calls)

    def test_start_up_with_saved_shtorm_only_hints(self):
        self.app.App.switch_engine(self.fake(), 'shtorm', quiet=True)
        self.assertNotIn('dialog', self.calls)        # при запуске программы окно с вопросом не открываем
        self.assertNotIn('busy', self.calls)

    def test_existing_sample_loads_without_a_dialog(self):
        started = []

        class FakeThread:
            def __init__(self, target=None, args=(), daemon=None):
                started.append(args)

            def start(self):
                pass
        with mock.patch.object(self.app.threading, 'Thread', FakeThread):
            fake = self.fake(ref=str(self.wav))
            self.app.App.switch_engine(fake, 'shtorm')
        self.assertNotIn('dialog', self.calls)
        self.assertIn('busy', self.calls)
        self.assertEqual(fake.engine.get(), 'shtorm')
        self.assertEqual(started, [('shtorm', False, 'fast', str(self.wav))])

    def test_chosen_sample_is_saved_and_switch_continues(self):
        saved, switched = [], []
        fake = SimpleNamespace(
            shtorm_voice_ref=Var(''), shtorm_ref_lbl=SimpleNamespace(configure=lambda **k: None),
            save_cfg=lambda: saved.append(True), switch_engine=lambda name: switched.append(name))
        with mock.patch.object(self.app.filedialog, 'askopenfilename', return_value=str(self.wav)), \
                mock.patch.object(self.app, 'speak', object()):
            self.assertTrue(self.app.App.choose_shtorm_voice(fake))
        self.assertEqual(fake.shtorm_voice_ref.get(), str(self.wav))
        self.assertEqual((saved, switched), ([True], ['shtorm']))

    def test_cancelled_or_wrong_file_is_not_accepted(self):
        for answer in ('', str(self.wav.with_suffix('.mp3')), str(self.wav.with_name('нет.wav'))):
            switched = []
            fake = SimpleNamespace(
                shtorm_voice_ref=Var(''), shtorm_ref_lbl=SimpleNamespace(configure=lambda **k: None),
                save_cfg=lambda: None, switch_engine=lambda name: switched.append(name))
            with mock.patch.object(self.app.filedialog, 'askopenfilename', return_value=answer), \
                    mock.patch.object(self.app.messagebox, 'showwarning'), \
                    mock.patch.object(self.app, 'speak', object()):
                self.assertFalse(self.app.App.choose_shtorm_voice(fake), answer)
            self.assertEqual((fake.shtorm_voice_ref.get(), switched), ('', []), answer)


# ---- словарь: граница слова и знак ударения «+» -------------------------------------------
import ast as _ast


def _load_apply_dictionary():
    """apply_dictionary из speak.py без импорта самого модуля (ему нужны модели)."""
    path = Path(__file__).resolve().parents[1] / 'speak.py'
    tree = _ast.parse(path.read_text(encoding='utf-8'))
    node = next(n for n in tree.body if isinstance(n, _ast.FunctionDef) and n.name == 'apply_dictionary')
    ns = {'re': re}
    exec(compile(_ast.Module(body=[node], type_ignores=[]), str(path), 'exec'), ns)
    return ns['apply_dictionary']


class DictionaryBoundaryTests(unittest.TestCase):
    def setUp(self):
        self.apply = _load_apply_dictionary()
        self.pairs = [('* А? = А+аа?', None)]

    def test_rule_does_not_match_inside_a_word_after_the_stress_mark(self):
        pairs = [('* А?', 'А+аа?'), ('* я...', '+яаа..'), ('* орочь*', '+орочь')]
        for text in ('Ты уж+е дом+а?', 'Где он+а?', 'Это был+а земл+я...', 'зам+орочь'):
            with self.subTest(text=text):
                self.assertEqual(self.apply(text, pairs), text)

    def test_rule_still_matches_whole_words(self):
        pairs = [('* А?', 'А+аа?'), ('* я...', '+яаа..'), ('* орочь*', '+орочь')]
        self.assertEqual(self.apply('— А? — спросил он.', pairs), '— А+аа? — спросил он.')
        self.assertEqual(self.apply('Я... не знаю.', pairs), '+Яаа.. не знаю.')
        self.assertEqual(self.apply('+орочь', pairs), '+орочь')          # слово с ударением на первой гласной
        self.assertEqual(self.apply('Тут орочьи земли.', pairs), 'Тут +орочьи земли.')

    def test_usual_rule_with_stress_inside_the_word(self):
        self.assertEqual(self.apply('Он вид+ел т+ени.', [('* тени', 'т+ени')]), 'Он вид+ел т+ени.')
        self.assertEqual(self.apply('Он вид+ел тен+и.', [('* тени', 'т+ени')]), 'Он вид+ел т+ени.')


class CloseWithUnsavedEditsTests(unittest.TestCase):
    def _app(self):
        try:
            import app
        except Exception as e:
            self.skipTest(f'app не импортируется здесь: {e!r}')
        return app

    def test_close_asks_when_editor_has_unsaved_changes(self):
        app = self._app()
        calls = []
        fake = SimpleNamespace(
            tab_edit=SimpleNamespace(is_dirty=lambda: True),
            save_dict=lambda: calls.append('save_dict'), save_cfg=lambda: calls.append('save_cfg'),
            stop_flag=SimpleNamespace(set=lambda: calls.append('stop')),
            player=SimpleNamespace(close=lambda: calls.append('player')),
            root=SimpleNamespace(destroy=lambda: calls.append('destroy')))
        with mock.patch.object(app.messagebox, 'askyesno', return_value=False):
            app.App.on_close(fake)
        self.assertEqual(calls, [])                       # осталась в программе
        with mock.patch.object(app.messagebox, 'askyesno', return_value=True):
            app.App.on_close(fake)
        self.assertIn('destroy', calls)

    def test_close_is_silent_when_nothing_is_unsaved(self):
        app = self._app()
        calls = []
        fake = SimpleNamespace(
            tab_edit=SimpleNamespace(is_dirty=lambda: False),
            save_dict=lambda: None, save_cfg=lambda: None, stop_flag=SimpleNamespace(set=lambda: None),
            player=SimpleNamespace(close=lambda: None), root=SimpleNamespace(destroy=lambda: calls.append('destroy')))
        with mock.patch.object(app.messagebox, 'askyesno', side_effect=AssertionError('не должна спрашивать')):
            app.App.on_close(fake)
        self.assertEqual(calls, ['destroy'])


if __name__ == '__main__':
    unittest.main()
