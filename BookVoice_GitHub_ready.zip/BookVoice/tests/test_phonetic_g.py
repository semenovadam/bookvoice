"""Regression tests for the optional Russian phonetic -ого/-его conversion."""
import ast
import re
import unittest
from pathlib import Path

SOURCE = Path(__file__).resolve().parents[1] / 'speak.py'
TREE = ast.parse(SOURCE.read_text(encoding='utf-8'))
NAMES = {'KEEP_G', 'phonetic_g'}
NODES = [n for n in TREE.body if isinstance(n, (ast.Assign, ast.FunctionDef)) and
         ((isinstance(n, ast.FunctionDef) and n.name in NAMES) or
          (isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id in NAMES for t in n.targets)))]
ns = {'re': re, 'WORD_RE': re.compile(r'[А-Яа-яЁё+] +'.replace(' ', ''))}
exec(compile(ast.Module(body=NODES, type_ignores=[]), str(SOURCE), 'exec'), ns)
phonetic_g = ns['phonetic_g']

class PhoneticGTests(unittest.TestCase):
    def test_preserves_words_ending_mnogo(self):
        for text in ('ненамного лучше', 'намного сильнее', 'немного позже', 'много книг'):
            with self.subTest(text=text):
                self.assertEqual(phonetic_g(text), text)

    def test_keeps_intended_phonetic_kovo(self):
        self.assertEqual(phonetic_g('Для кого это?'), 'Для ково это?')

    def test_keeps_general_adjective_conversion(self):
        self.assertEqual(phonetic_g('четв+ёртого дня'), 'четв+ёртово дня')

if __name__ == '__main__':
    unittest.main()
