"""Выбор модели RUAccent: настройки, список моделей с сервера, обновления, скачивание одной модели,
перезагрузка без перезапуска и окно «Модели ударений RUAccent».

Сети и настоящего RUAccent здесь нет: сервер, пакеты huggingface_hub и ruaccent подменены, окно работает
на упрощённом tkinter (как в test_model_manager.py)."""
import ast
import io
import json
import sys
import threading
import unittest
from pathlib import Path
from types import ModuleType, SimpleNamespace
from unittest import mock

try:
    from test_model_manager import (IsolatedModels, UiCase, W, TextW, FakeRunner, FakeVar, ImmediateThread,
                                    TclError, mm, model_dirs, ROOT)
except ImportError:                                             # запуск как tests.test_ruaccent_models
    from tests.test_model_manager import (IsolatedModels, UiCase, W, TextW, FakeRunner, FakeVar, ImmediateThread,
                                          TclError, mm, model_dirs, ROOT)


def put_settings(case, **values):
    """settings.json во временной папке; model_manager читает его через model_dirs.SETTINGS_FILE."""
    path = case.root / 'settings.json'
    path.write_text(json.dumps(values, ensure_ascii=False), encoding='utf-8')
    patcher = mock.patch.object(model_dirs, 'SETTINGS_FILE', path)
    patcher.start()
    case.addCleanup(patcher.stop)
    return path


def install_model(case, name, base=None):
    """Положить «модель» в папку ударений (или в base): достаточно одного файла в nn/nn_omograph/<имя>."""
    base = Path(base or model_dirs.RUACCENT_DIR)
    case.touch(base / 'nn' / 'nn_omograph' / name / 'model.onnx')
    case.touch(base / 'dictionary' / 'accents.json')
    return base


class SettingsAndKwargsTests(IsolatedModels):
    def setUp(self):
        super().setUp()
        patcher = mock.patch.object(model_dirs, 'SETTINGS_FILE', self.root / 'нет_такого_settings.json')
        patcher.start()
        self.addCleanup(patcher.stop)

    def test_default_is_exactly_what_the_program_did_before(self):
        self.assertEqual(mm.ruaccent_load_kwargs(), {'omograph_model_size': 'turbo', 'use_dictionary': True})
        self.assertEqual(mm.ruaccent_chosen(), 'turbo')
        self.assertTrue(mm.ruaccent_use_dictionary())
        self.assertFalse(mm.ruaccent_tiny_mode())

    def test_chosen_model_and_options_come_from_settings(self):
        put_settings(self, ruaccent_model='turbo3.1', ruaccent_dictionary=False, ruaccent_tiny=True)
        base = install_model(self, 'turbo3.1')

        class New:
            def load(self, omograph_model_size='turbo', use_dictionary=True, workdir=None, tiny_mode=False): ...

        kw = mm.ruaccent_load_kwargs(New())
        self.assertEqual(kw, {'omograph_model_size': 'turbo3.1', 'use_dictionary': False,
                              'workdir': str(base), 'tiny_mode': True})

    def test_tiny_mode_is_not_passed_to_a_package_that_does_not_know_it(self):
        put_settings(self, ruaccent_model='turbo', ruaccent_tiny=True)
        install_model(self, 'turbo')

        class Old:
            def load(self, omograph_model_size='turbo', use_dictionary=True, workdir=None): ...

        self.assertNotIn('tiny_mode', mm.ruaccent_load_kwargs(Old()))

    def test_garbage_in_settings_falls_back_to_defaults(self):
        for bad in ('../секрет', '', 5, None, 'a/b', 'x' * 80, '..'):
            put_settings(self, ruaccent_model=bad, ruaccent_dictionary='да', ruaccent_tiny='нет')
            self.assertEqual(mm.ruaccent_chosen(), 'turbo', repr(bad))
            self.assertTrue(mm.ruaccent_use_dictionary())
            self.assertFalse(mm.ruaccent_tiny_mode())

    def test_model_name_validation(self):
        for good in ('turbo', 'turbo3.1', 'tiny2.1', 'big_poetry', 'turbo4', 'v5-beta_1'):
            self.assertTrue(mm.valid_ruaccent_name(good), good)
        for bad in ('', '.', '..', 'a..b', 'a/b', 'a\\b', '-x', 'x y', None, 7):
            self.assertFalse(mm.valid_ruaccent_name(bad), repr(bad))

    def test_chosen_model_not_downloaded_falls_back_to_installed_turbo(self):
        put_settings(self, ruaccent_model='turbo3.1')
        install_model(self, 'turbo')
        name, workdir, note = mm.ruaccent_effective()
        self.assertEqual(name, 'turbo')
        self.assertEqual(workdir, model_dirs.RUACCENT_DIR)
        self.assertIn('turbo3.1', note)
        self.assertEqual(mm.ruaccent_load_kwargs()['omograph_model_size'], 'turbo')

    def test_fallback_to_any_installed_model_when_turbo_is_absent(self):
        put_settings(self, ruaccent_model='turbo3.1')
        install_model(self, 'tiny2')
        self.assertEqual(mm.ruaccent_effective()[0], 'tiny2')

    def test_nothing_installed_keeps_the_old_behaviour(self):
        put_settings(self, ruaccent_model='turbo3.1')
        name, workdir, note = mm.ruaccent_effective()
        self.assertEqual((name, workdir, note), ('turbo3.1', None, ''))       # скачает окно «Модели»/RUAccent

    def test_installed_listing_sees_own_folder_and_package_and_skips_partial(self):
        install_model(self, 'turbo3.1')
        install_model(self, 'tiny2.1')
        pkg = self.root / 'site-packages' / 'ruaccent'
        install_model(self, 'turbo', base=pkg)
        with mock.patch.object(mm, 'ruaccent_module_dir', return_value=pkg):
            found = mm.ruaccent_installed_models()
            self.assertEqual(set(found), {'turbo3.1', 'tiny2.1', 'turbo'})
            self.assertEqual(found['turbo'], pkg)
            # модель только в пакете: workdir не передаётся, RUAccent берёт папку пакета, как раньше
            put_settings(self, ruaccent_model='turbo')
            self.assertIsNone(mm.ruaccent_effective()[1])
            # оборванная загрузка в нашей папке: её модели не считаются
            self.touch(Path(model_dirs.RUACCENT_DIR) / mm.FLAG)
            self.assertEqual(set(mm.ruaccent_installed_models()), {'turbo'})

    def test_status_follows_the_chosen_model(self):
        put_settings(self, ruaccent_model='turbo3.1')
        self.assertFalse(mm.status('ruaccent').ok)
        install_model(self, 'turbo3.1')
        st = mm.status('ruaccent')
        self.assertTrue(st.ok)
        self.assertIn('turbo3.1', st.note)

    def test_status_with_old_default_is_unchanged(self):
        install_model(self, 'turbo')
        st = mm.status('ruaccent')
        self.assertTrue(st.ok)
        self.assertEqual(st.note, 'в папке моделей')

    def test_records_roundtrip(self):
        self.assertEqual(mm.ruaccent_records(), {})
        mm.ruaccent_record('turbo3.1', '2026-10-01T10:00:00.000Z')
        rec = mm.ruaccent_records()
        self.assertEqual(rec['turbo3.1']['remote_updated'], '2026-10-01T10:00:00.000Z')
        self.assertTrue(rec['turbo3.1']['downloaded'])
        self.assertFalse(mm.partial(model_dirs.RUACCENT_DIR))


class FakeResponse:
    def __init__(self, payload, link=''):
        self.body = json.dumps(payload).encode('utf-8')
        self.headers = {'Link': link} if link else {}

    def read(self):
        return self.body

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


def entry(path, size=10, date='2026-09-01T00:00:00.000Z', kind='file'):
    return {'type': kind, 'path': path, 'size': size, 'lastCommit': {'date': date}}


class RemoteListTests(unittest.TestCase):
    def test_collects_models_with_size_and_latest_date_over_pages(self):
        page1 = [entry('nn/nn_omograph/turbo3.1/model.onnx', 100, '2026-09-01T00:00:00.000Z'),
                 entry('nn/nn_omograph/turbo3.1', 0, kind='directory'),
                 entry('nn/nn_omograph/tiny2.1/model.onnx', 5, '2026-08-01T00:00:00.000Z')]
        page2 = [entry('nn/nn_omograph/turbo3.1/vocab.txt', 7, '2026-10-02T00:00:00.000Z'),
                 entry('nn/nn_accent/model.onnx', 999),                      # чужая папка
                 entry('nn/nn_omograph/../evil/x', 1),                       # недопустимое имя
                 entry('nn/nn_omograph/readme.md', 1)]                       # файл прямо в папке, не модель
        calls = []

        def opener(req, timeout):
            calls.append((req.full_url, timeout))
            if len(calls) == 1:
                return FakeResponse(page1, '<https://huggingface.co/api/next?cursor=abc>; rel="next"')
            return FakeResponse(page2)
        got = mm.fetch_ruaccent_models(timeout=7, opener=opener)
        self.assertEqual(got, {'turbo3.1': {'size': 107, 'updated': '2026-10-02T00:00:00.000Z'},
                               'tiny2.1': {'size': 5, 'updated': '2026-08-01T00:00:00.000Z'}})
        self.assertEqual(len(calls), 2)
        self.assertIn('ruaccent/accentuator', calls[0][0])
        self.assertIn('nn/nn_omograph', calls[0][0])
        self.assertEqual(calls[1][0], 'https://huggingface.co/api/next?cursor=abc')
        self.assertEqual(calls[0][1], 7)

    def test_unexpected_answers_are_errors(self):
        with self.assertRaises(ValueError):
            mm.fetch_ruaccent_models(opener=lambda req, timeout: FakeResponse({'error': 'нет'}))
        with self.assertRaises(ValueError):
            mm.fetch_ruaccent_models(opener=lambda req, timeout: FakeResponse([entry('nn/other/x')]))

    def test_network_errors_propagate_as_oserror(self):
        def boom(req, timeout):
            raise OSError('нет сети')
        with self.assertRaises(OSError):
            mm.fetch_ruaccent_models(opener=boom)

    def test_pkg_latest(self):
        ok = lambda req, timeout: FakeResponse({'info': {'version': '1.6.0'}})
        self.assertEqual(mm.fetch_ruaccent_pkg_latest(opener=ok), '1.6.0')
        self.assertIsNone(mm.fetch_ruaccent_pkg_latest(opener=lambda req, timeout: FakeResponse({'x': 1})))

        def boom(req, timeout):
            raise OSError('нет сети')
        self.assertIsNone(mm.fetch_ruaccent_pkg_latest(opener=boom))

    def test_unknown_names_go_first_then_known_newest_first(self):
        names = ['turbo', 'tiny2.1', 'turbo3.1', 'turbo4', 'big_poetry', 'tiny']
        self.assertEqual(sorted(names, key=mm.ruaccent_sort_key),
                         ['turbo4', 'turbo3.1', 'turbo', 'tiny2.1', 'tiny', 'big_poetry'])


class UpdateStateTests(unittest.TestCase):
    remote = {'turbo3.1': {'size': 1, 'updated': '2026-10-02T00:00:00.000Z'},
              'tiny2.1': {'size': 1, 'updated': '2026-08-01T00:00:00.000Z'},
              'turbo': {'size': 1, 'updated': '2026-01-01T00:00:00.000Z'}}

    def installed(self, *names):
        return {n: Path('x') for n in names}

    def test_states(self):
        inst = self.installed('turbo3.1', 'tiny2.1', 'turbo')
        rec = {'turbo3.1': {'remote_updated': '2026-09-01T00:00:00.000Z'},
               'tiny2.1': {'remote_updated': '2026-08-01T00:00:00.000Z'}}
        st = lambda n, r=self.remote: mm.ruaccent_model_state(n, inst, r, rec)
        self.assertEqual(st('turbo3.1'), 'update')
        self.assertEqual(st('tiny2.1'), 'current')
        self.assertEqual(st('turbo'), 'unknown')              # скачана раньше: даты нет
        self.assertEqual(st('turbo3.1', None), 'installed')   # проверку ещё не делали
        self.assertEqual(mm.ruaccent_model_state('turbo2', inst, self.remote, rec), 'missing')

    def test_summary_when_everything_is_fresh(self):
        inst = self.installed('turbo3.1')
        rec = {'turbo3.1': {'remote_updated': '2026-10-02T00:00:00.000Z'}}
        text, updates = mm.ruaccent_summary({'turbo3.1': self.remote['turbo3.1']}, inst, rec, 'turbo3.1')
        self.assertEqual(updates, [])
        self.assertIn('актуальны', text)

    def test_summary_lists_updates_and_new_models(self):
        inst = self.installed('turbo3.1')
        rec = {'turbo3.1': {'remote_updated': '2026-09-01T00:00:00.000Z'}}
        text, updates = mm.ruaccent_summary(self.remote, inst, rec, 'turbo3.1')
        self.assertEqual(updates, ['turbo3.1'])
        self.assertIn('обновление', text)
        self.assertIn('tiny2.1', text)                         # не скачана
        text, _ = mm.ruaccent_summary(self.remote, inst, rec, 'big_poetry')
        self.assertIn('big_poetry', text)                      # выбранной нет на сервере


class DownloadJobTests(IsolatedModels):
    FILES = ['README.md', '.gitattributes', 'dictionary/accents.json', 'nn/nn_accent/model.onnx',
             'nn/nn_omograph/turbo/model.onnx', 'nn/nn_omograph/turbo3.1/model.onnx',
             'nn/nn_omograph/turbo3.1/vocab.txt', 'nn/nn_omograph/tiny2.1/model.onnx']

    def hub(self, files=None, fail=False):
        mod = ModuleType('huggingface_hub')

        class HfApi:
            def list_repo_files(self, repo):
                if fail:
                    raise OSError('нет сети')
                return list(files if files is not None else DownloadJobTests.FILES)
        mod.HfApi = HfApi
        return mod

    def test_only_shared_files_and_the_one_model_are_downloaded(self):
        got = []
        with mock.patch.dict(sys.modules, {'huggingface_hub': self.hub()}), \
                mock.patch.object(mm, '_hf_download', lambda repo, target, patterns=None: got.append((repo, str(target), patterns))):
            done, out = self.run_quiet(mm._ruaccent_fetch_model, Path(model_dirs.RUACCENT_DIR), 'turbo3.1')
        self.assertTrue(done)
        repo, target, patterns = got[0]
        self.assertEqual(repo, mm.RUACCENT_REPO)
        self.assertEqual(target, model_dirs.RUACCENT_DIR)
        self.assertEqual(sorted(patterns), sorted(['dictionary/accents.json', 'nn/nn_accent/model.onnx',
                                                   'nn/nn_omograph/turbo3.1/*']))
        self.assertTrue(any(l.startswith('@@stage') and 'turbo3.1' in l for l in out.splitlines()))

    def test_unknown_model_lists_what_exists(self):
        with mock.patch.dict(sys.modules, {'huggingface_hub': self.hub()}):
            with self.assertRaisesRegex(RuntimeError, r'turbo4.*turbo3\.1.*turbo.*tiny2\.1'):
                self.run_quiet(mm._ruaccent_fetch_model, Path(model_dirs.RUACCENT_DIR), 'turbo4')

    def test_no_file_list_leaves_the_download_to_ruaccent_itself(self):
        with mock.patch.dict(sys.modules, {'huggingface_hub': self.hub(fail=True)}), \
                mock.patch.object(mm, '_hf_download', side_effect=AssertionError('не должно скачивать')):
            done, out = self.run_quiet(mm._ruaccent_fetch_model, Path(model_dirs.RUACCENT_DIR), 'turbo3.1')
        self.assertFalse(done)
        self.assertIn('скачает сам RUAccent', out)

    def fake_ruaccent(self, process_error=None):
        loads = []

        class RUAccent:
            def load(self, omograph_model_size='turbo', use_dictionary=True, workdir=None):
                loads.append(dict(omograph_model_size=omograph_model_size, use_dictionary=use_dictionary,
                                  workdir=workdir))

            def process_all(self, text):
                if process_error:
                    raise process_error
                return 'на двер+и вис+ит зам+ок.'
        mod = ModuleType('ruaccent')
        mod.RUAccent = RUAccent
        return mod, loads

    def test_job_loads_the_requested_model_and_records_the_server_date(self):
        mod, loads = self.fake_ruaccent()
        remote = {'turbo3.1': {'size': 1, 'updated': '2026-10-02T00:00:00.000Z'}}
        with mock.patch.dict(sys.modules, {'ruaccent': mod, 'huggingface_hub': self.hub()}), \
                mock.patch.object(mm, '_hf_download', lambda *a, **k: None), \
                mock.patch.object(mm, 'fetch_ruaccent_models', return_value=remote):
            _r, out = self.run_quiet(mm.job_ruaccent, 'turbo3.1')
        self.assertEqual(loads, [dict(omograph_model_size='turbo3.1', use_dictionary=True,
                                      workdir=model_dirs.RUACCENT_DIR)])
        self.assertIn('Проба: на двер+и', out)
        self.assertEqual(mm.ruaccent_records()['turbo3.1']['remote_updated'], '2026-10-02T00:00:00.000Z')
        self.assertFalse(mm.partial(model_dirs.RUACCENT_DIR))             # флажок снят

    def test_job_uses_the_chosen_model_and_dictionary_switch_from_settings(self):
        put_settings(self, ruaccent_model='tiny2.1', ruaccent_dictionary=False)
        mod, loads = self.fake_ruaccent()
        with mock.patch.dict(sys.modules, {'ruaccent': mod, 'huggingface_hub': self.hub()}), \
                mock.patch.object(mm, '_hf_download', lambda *a, **k: None):
            self.run_quiet(mm.job_ruaccent)
        self.assertEqual(loads[0]['omograph_model_size'], 'tiny2.1')
        self.assertFalse(loads[0]['use_dictionary'])

    def test_model_that_loads_but_does_not_work_points_to_the_package_update(self):
        mod, _loads = self.fake_ruaccent(process_error=ValueError('странный вход'))
        with mock.patch.dict(sys.modules, {'ruaccent': mod, 'huggingface_hub': self.hub()}), \
                mock.patch.object(mm, '_hf_download', lambda *a, **k: None):
            with self.assertRaisesRegex(RuntimeError, 'turbo3.1.*не работает.*Обновить пакет'):
                self.run_quiet(mm.job_ruaccent, 'turbo3.1')

    def test_bad_model_name_never_reaches_the_disk(self):
        mod, loads = self.fake_ruaccent()
        with mock.patch.dict(sys.modules, {'ruaccent': mod}):
            with self.assertRaisesRegex(RuntimeError, 'недопустимое имя'):
                self.run_quiet(mm.job_ruaccent, '../x')
        self.assertEqual(loads, [])

    def test_run_job_routes_model_names_and_rejects_bad_ones(self):
        seen = []
        fake = lambda model=None: seen.append(model)
        with mock.patch.object(mm, 'job_ruaccent', fake), mock.patch.dict(mm.JOBS, {'ruaccent': fake}):
            self.assertEqual(self.run_quiet(mm.run_job, 'ruaccent:turbo3.1')[0], 0)
            self.assertEqual(self.run_quiet(mm.run_job, 'ruaccent')[0], 0)
            self.assertEqual(self.run_quiet(mm.run_job, 'ruaccent:../x')[0], 2)
            self.assertEqual(self.run_quiet(mm.run_job, 'nonsense')[0], 2)
        self.assertEqual(seen, ['turbo3.1', None])

    def test_titles(self):
        self.assertEqual(mm.job_title('ruaccent:turbo3.1'), 'RUAccent: модель turbo3.1')
        self.assertIn('пакета', mm.job_title('ruaccent_pkg'))
        self.assertEqual(mm.job_title('ruaccent'), mm.TITLES['ruaccent'])
        self.assertEqual(mm.job_title('silero_update'), 'Silero: обновление репозитория')

    def test_package_update_reports_old_and_new_version(self):
        versions = iter(['1.5.8.3', '1.5.9'])
        ran = []
        with mock.patch.object(mm, 'ruaccent_pkg_version', lambda: next(versions)), \
                mock.patch.object(mm, '_run', lambda cmd: ran.append(list(cmd))):
            _r, out = self.run_quiet(mm.job_ruaccent_pkg)
        self.assertEqual(ran[0][1:5], ['-m', 'pip', 'install', '--upgrade'])
        self.assertEqual(ran[0][-1], 'ruaccent')
        self.assertIn('1.5.8.3 -> 1.5.9', out)
        self.assertIn('Перезапусти', out)

    def test_package_update_when_already_latest(self):
        with mock.patch.object(mm, 'ruaccent_pkg_version', lambda: '1.5.9'), mock.patch.object(mm, '_run', lambda c: None):
            _r, out = self.run_quiet(mm.job_ruaccent_pkg)
        self.assertIn('уже последней версии', out)

    def test_runner_command_carries_the_model_name(self):
        cmd = mm.job_command('ruaccent:turbo3.1')
        self.assertEqual(cmd[-2:], ['job', 'ruaccent:turbo3.1'])


# ---------------------------------------------------------------- перезагрузка в speak.py и app.py без графики
def function_source(path, name, class_name=None):
    tree = ast.parse((ROOT / path).read_text(encoding='utf-8'))
    nodes = tree.body
    if class_name:
        nodes = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == class_name).body
    node = next(n for n in nodes if isinstance(n, ast.FunctionDef) and n.name == name)
    return ast.get_source_segment((ROOT / path).read_text(encoding='utf-8'), node)


class ReloadAccentizerTests(unittest.TestCase):
    """reload_accentizer из speak.py (сам модуль тянет torch, поэтому функции берутся из исходника)."""

    def namespace(self, loads, fail_on=None):
        class RUAccent:
            def __init__(self):
                self.kw = None

            def load(self, **kw):
                if fail_on and kw.get('omograph_model_size') == fail_on:
                    raise RuntimeError('не грузится')
                self.kw = kw
                loads.append(kw)

        state = {'kw': {'omograph_model_size': 'turbo', 'use_dictionary': True}}
        mm_stub = SimpleNamespace(
            ruaccent_load_kwargs=lambda acc=None: dict(state['kw']),
            ruaccent_effective=lambda: (state['kw']['omograph_model_size'], None, 'заметка'))
        ns = {'RUAccent': RUAccent, 'model_manager': mm_stub, 'TTS_LOCK': threading.Lock()}
        exec(function_source('speak.py', '_load_accentizer'), ns)
        exec(function_source('speak.py', 'reload_accentizer'), ns)
        ns['accentizer'], ns['ACCENT_KW'], _ = ns['_load_accentizer']()
        return ns, state

    def test_reload_swaps_the_object_and_the_parameters(self):
        loads = []
        ns, state = self.namespace(loads)
        first = ns['accentizer']
        state['kw'] = {'omograph_model_size': 'turbo3.1', 'use_dictionary': True}
        kw = ns['reload_accentizer']()
        self.assertEqual(kw['omograph_model_size'], 'turbo3.1')
        self.assertIsNot(ns['accentizer'], first)
        self.assertEqual(ns['ACCENT_KW']['omograph_model_size'], 'turbo3.1')
        self.assertFalse(ns['TTS_LOCK'].locked())

    def test_failed_reload_restores_the_previous_configuration_and_releases_the_lock(self):
        loads = []
        ns, state = self.namespace(loads, fail_on='broken')
        state['kw'] = {'omograph_model_size': 'broken', 'use_dictionary': True}
        with self.assertRaisesRegex(RuntimeError, 'не грузится'):
            ns['reload_accentizer']()
        self.assertIsNotNone(ns['accentizer'])
        self.assertEqual(ns['ACCENT_KW']['omograph_model_size'], 'turbo')
        self.assertFalse(ns['TTS_LOCK'].locked())


class AppRuaccentMethodsTests(unittest.TestCase):
    """set_ruaccent / apply_ruaccent из app.py на подставном «self» (сам app.py тянет звук и torch)."""

    def methods(self, speak):
        ns = {'speak': speak, 'threading': SimpleNamespace(Thread=ImmediateThread)}
        for name in ('set_ruaccent', 'apply_ruaccent'):
            src = function_source('app.py', name, 'App')
            exec(src, ns)
        return ns

    def fake_self(self, busy=False):
        me = SimpleNamespace(cfg={}, logs=[], saved=0, busy_calls=[],
                             b_run={'state': 'disabled' if busy else 'normal'})
        me.save_cfg = lambda: setattr(me, 'saved', me.saved + 1)
        me.log = me.logs.append
        me.ui = lambda fn: fn()
        me.set_busy = lambda busy, loading=False: me.busy_calls.append((busy, loading))
        return me

    def test_set_ruaccent_remembers_only_what_was_given(self):
        ns = self.methods(None)
        me = self.fake_self()
        ns['set_ruaccent'](me, model='turbo3.1')
        self.assertEqual(me.cfg, {'ruaccent_model': 'turbo3.1'})
        ns['set_ruaccent'](me, dictionary=0, tiny=1)
        self.assertEqual(me.cfg, {'ruaccent_model': 'turbo3.1', 'ruaccent_dictionary': False, 'ruaccent_tiny': True})
        self.assertEqual(me.saved, 2)

    def test_apply_before_models_are_loaded_only_saves(self):
        ns = self.methods(None)
        me, answers = self.fake_self(), []
        ns['apply_ruaccent'](me, done=lambda ok, msg: answers.append((ok, msg)))
        self.assertEqual(answers[0][0], True)
        self.assertIn('применятся', answers[0][1])
        self.assertEqual(me.busy_calls, [])

    def test_apply_is_refused_while_the_book_is_being_voiced(self):
        reloads = []
        ns = self.methods(SimpleNamespace(reload_accentizer=lambda: reloads.append(1)))
        me, answers = self.fake_self(busy=True), []
        ns['apply_ruaccent'](me, done=lambda ok, msg: answers.append((ok, msg)))
        self.assertEqual(reloads, [])
        self.assertFalse(answers[0][0])
        self.assertIn('идёт озвучка', answers[0][1])

    def test_apply_reloads_and_reports(self):
        kw = {'omograph_model_size': 'turbo3.1', 'use_dictionary': True, 'tiny_mode': True}
        ns = self.methods(SimpleNamespace(reload_accentizer=lambda: kw))
        me, answers = self.fake_self(), []
        ns['apply_ruaccent'](me, done=lambda ok, msg: answers.append((ok, msg)))
        self.assertEqual(me.busy_calls, [(True, True), (False, False)])
        self.assertTrue(answers[0][0])
        self.assertIn('turbo3.1', answers[0][1])
        self.assertIn('tiny_mode', answers[0][1])

    def test_apply_failure_is_reported_and_the_buttons_come_back(self):
        def boom():
            raise RuntimeError('нет файлов')
        ns = self.methods(SimpleNamespace(reload_accentizer=boom))
        me, answers = self.fake_self(), []
        ns['apply_ruaccent'](me, done=lambda ok, msg: answers.append((ok, msg)))
        self.assertFalse(answers[0][0])
        self.assertIn('нет файлов', answers[0][1])
        self.assertEqual(me.busy_calls[-1], (False, False))

    def test_save_cfg_keeps_the_ruaccent_keys(self):
        src = function_source('app.py', 'save_cfg', 'App')
        self.assertIn('model_manager.RUACCENT_SETTING_KEYS', src)
        self.assertEqual(set(mm.RUACCENT_SETTING_KEYS), {'ruaccent_model', 'ruaccent_dictionary', 'ruaccent_tiny'})


# ---------------------------------------------------------------- окно
class FakeTree(W):
    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.rows, self.sel = {}, ()

    def insert(self, parent, index, iid=None, values=(), **kw):
        self.rows[iid] = tuple(values)
        return iid

    def delete(self, item):
        self.rows.pop(item, None)

    def get_children(self, item=''):
        return tuple(self.rows)

    def exists(self, item):
        return item in self.rows

    def selection(self):
        return self.sel

    def selection_set(self, item):
        self.sel = (item,)


class RuaccentWindowTests(UiCase):
    def setUp(self):
        super().setUp()
        try:
            import ruaccent_ui
        except Exception as e:
            self.skipTest(f'ruaccent_ui не импортируется здесь: {e!r}')
        self.rui = ruaccent_ui
        patcher = mock.patch.object(model_dirs, 'SETTINGS_FILE', self.root / 'нет_settings.json')
        patcher.start()
        self.addCleanup(patcher.stop)
        ttk = SimpleNamespace(Frame=W, Label=W, Button=W, Checkbutton=W, Progressbar=W, Scrollbar=W, Treeview=FakeTree)
        for target, name, value in ((ruaccent_ui, 'tk', SimpleNamespace(Toplevel=W, BooleanVar=FakeVar, TclError=TclError)),
                                    (ruaccent_ui, 'ttk', ttk), (ruaccent_ui.threading, 'Thread', ImmediateThread)):
            p = mock.patch.object(target, name, value)
            p.start()
            self.addCleanup(p.stop)
        for kind in ('showinfo', 'showerror', 'showwarning'):
            p = mock.patch.object(ruaccent_ui.messagebox, kind,
                                  lambda title=None, message=None, _k=kind, **kw: self.dialogs.append((_k, title, message)))
            p.start()
            self.addCleanup(p.stop)
        p = mock.patch.object(ruaccent_ui.messagebox, 'askyesno',
                              lambda title=None, message=None, **kw: self.dialogs.append(('askyesno', title, message)) or self.answer)
        p.start()
        self.addCleanup(p.stop)
        self.calls = []
        self.app.set_ruaccent = lambda **kw: self.calls.append(('set', kw))
        self.app.apply_ruaccent = lambda done=None: (self.calls.append(('apply',)), done and done(True, 'RUAccent готов'))
        self.app.ruaccent_win = None
        self.remote = {'turbo3.1': {'size': 3 << 20, 'updated': '2026-10-02T00:00:00.000Z'},
                       'turbo': {'size': 2 << 20, 'updated': '2026-01-01T00:00:00.000Z'}}

    def window(self, remote=None, error=None, latest='1.6.0'):
        def fetch():
            if error:
                raise OSError(error)
            return remote if remote is not None else self.remote
        self.win = self.rui.RuaccentWindow(self.app, runner_factory=FakeRunner, fetch=fetch,
                                           pkg_latest=lambda: latest)
        self.app.ruaccent_win = self.win
        return self.win

    def test_rows_before_any_check_show_known_models_and_the_active_one(self):
        install_model(self, 'turbo')
        w = self.window()
        self.assertEqual(list(w.tree.rows), sorted(mm.RUACCENT_MODELS, key=mm.ruaccent_sort_key))
        self.assertIn('◀ используется', w.tree.rows['turbo'][4])
        self.assertIn('✓', w.tree.rows['turbo'][4])
        self.assertEqual(w.tree.rows['turbo3.1'][4], 'не скачана')
        self.assertEqual(w.tree.rows['turbo3.1'][3], '—')

    def test_check_shows_sizes_dates_new_models_and_the_summary(self):
        install_model(self, 'turbo')
        mm.ruaccent_record('turbo', '2026-01-01T00:00:00.000Z')
        remote = dict(self.remote, turbo4={'size': 5 << 20, 'updated': '2026-10-20T00:00:00.000Z'})
        w = self.window(remote=remote)
        w.check()
        self.assertEqual(next(iter(w.tree.rows)), 'turbo4')                      # новая модель сверху
        self.assertIn('описания пока нет', w.tree.rows['turbo4'][1])
        self.assertEqual(w.tree.rows['turbo3.1'][2], mm.fmt_size(3 << 20))
        self.assertEqual(w.tree.rows['turbo3.1'][3], '2026-10-02')
        self.assertIn('актуальна', w.tree.rows['turbo'][4])
        self.assertIn('Все скачанные модели актуальны', w.summary_lbl.opts['text'])
        self.assertIn('Пакет ruaccent', w.pkg_lbl.opts['text'])
        self.assertIn('1.6.0', w.pkg_lbl.opts['text'])
        self.assertEqual(self.dialogs, [])

    def test_check_offers_to_update_the_model_in_use(self):
        install_model(self, 'turbo')
        mm.ruaccent_record('turbo', '2025-12-01T00:00:00.000Z')                    # на сервере новее
        w = self.window()
        w.check()
        self.assertEqual(self.kinds(), ['askyesno'])
        self.assertIn('turbo', self.dialogs[0][2])
        self.assertEqual(w.runner.started, [['ruaccent:turbo']])
        self.assertEqual(w.pending_use, 'turbo')                                  # после скачивания включится заново
        self.assertIn('обновление', w.tree.rows['turbo'][4])

    def test_check_without_the_update_decision_does_not_download(self):
        install_model(self, 'turbo')
        mm.ruaccent_record('turbo', '2025-12-01T00:00:00.000Z')
        self.answer = False
        w = self.window()
        w.check()
        self.assertEqual(w.runner.started, [])

    def test_check_failure_keeps_the_table_and_explains(self):
        w = self.window(error='нет сети')
        w.check()
        self.assertIn('Не удалось получить список', w.summary_lbl.opts['text'])
        self.assertIn('нет сети', w.summary_lbl.opts['text'])
        self.assertEqual(len(w.tree.rows), len(mm.RUACCENT_MODELS))

    def test_download_selected_needs_a_selection_then_starts_that_model(self):
        w = self.window()
        self.assertFalse(w.download_selected())
        self.assertEqual(self.kinds(), ['showinfo'])
        w.tree.selection_set('turbo3.1')
        self.assertTrue(w.download_selected())
        self.assertEqual(w.runner.started, [['ruaccent:turbo3.1']])
        self.assertEqual(w.b_download.opts['state'], 'disabled')
        self.assertEqual(w.b_stop.opts['state'], 'normal')

    def test_low_disk_space_asks_first(self):
        w = self.window()
        w.check()
        w.tree.selection_set('turbo3.1')
        self.answer = False
        with mock.patch.object(mm, 'free_space', return_value=1 << 20):
            self.assertFalse(w.download_selected())
        self.assertEqual(w.runner.started, [])
        self.assertIn('Мало места', [d[1] for d in self.dialogs])

    def test_use_installed_model_saves_and_reloads_at_once(self):
        install_model(self, 'tiny2.1')
        w = self.window()
        w.v_dict.set(False)
        w.v_tiny.set(True)
        w.tree.selection_set('tiny2.1')
        self.assertTrue(w.use_selected())
        self.assertEqual(self.calls[0], ('set', {'model': 'tiny2.1', 'dictionary': False, 'tiny': True}))
        self.assertEqual(self.calls[1], ('apply',))
        self.assertEqual(w.runner.started, [])
        self.assertIn('RUAccent готов', w.summary_lbl.opts['text'])

    def test_use_missing_model_downloads_then_switches_after_the_download(self):
        w = self.window()
        w.tree.selection_set('turbo3.1')
        self.assertTrue(w.use_selected())
        self.assertEqual(w.runner.started, [['ruaccent:turbo3.1']])
        self.assertEqual(self.calls, [])                                          # пока не скачано, ничего не включено
        install_model(self, 'turbo3.1')
        w.runner.busy = False
        w.on_event(('finished', ['ruaccent:turbo3.1'], [], False))
        self.assertEqual(self.calls[0][0:2], ('set', {'model': 'turbo3.1', 'dictionary': True, 'tiny': False}))
        self.assertEqual(self.calls[1], ('apply',))
        self.assertEqual(self.changed, [['ruaccent:turbo3.1']])

    def test_failed_download_never_switches_the_model(self):
        w = self.window()
        w.tree.selection_set('turbo3.1')
        w.use_selected()
        w.runner.busy = False
        w.on_event(('finished', [], ['ruaccent:turbo3.1'], False))
        self.assertEqual(self.calls, [])
        self.assertIn('Не удалось', w.stage_lbl.opts['text'])
        self.assertIn('RUAccent: модель turbo3.1', w.stage_lbl.opts['text'])

    def test_declining_the_download_does_nothing(self):
        w = self.window()
        w.tree.selection_set('turbo3.1')
        self.answer = False
        self.assertFalse(w.use_selected())
        self.assertEqual((w.runner.started, self.calls), ([], []))

    def test_apply_options_keeps_the_chosen_model(self):
        put_settings(self, ruaccent_model='turbo')
        install_model(self, 'turbo')
        w = self.window()
        w.v_dict.set(False)
        w.apply_options()
        self.assertEqual(self.calls[0], ('set', {'model': 'turbo', 'dictionary': False, 'tiny': False}))
        self.assertEqual(self.calls[1], ('apply',))

    def test_package_update_confirms_runs_and_asks_for_a_restart(self):
        w = self.window()
        self.assertTrue(w.update_pkg())
        self.assertEqual(w.runner.started, [['ruaccent_pkg']])
        w.runner.busy = False
        w.on_event(('finished', ['ruaccent_pkg'], [], False))
        self.assertIn('showinfo', self.kinds())
        self.assertIn('Перезапусти', self.dialogs[-1][2])

    def test_package_update_declined(self):
        w = self.window()
        self.answer = False
        self.assertFalse(w.update_pkg())
        self.assertEqual(w.runner.started, [])

    def test_progress_and_log_events(self):
        w = self.window()
        w.on_event(('start', 'ruaccent:turbo3.1'))
        self.assertIn('RUAccent: модель turbo3.1', w.stage_lbl.opts['text'])
        w.on_event(('total', 'ruaccent:turbo3.1', 100))
        w.on_event(('progress', 'ruaccent:turbo3.1', 50, None))
        self.assertIn('50%', w.stage_lbl.opts['text'])
        w.on_event(('log', 'ruaccent:turbo3.1', 'строка журнала'))
        self.assertIn('строка журнала', w.log_txt.content)

    def test_close_while_running_asks_and_cancels(self):
        w = self.window()
        w.runner.busy = True
        w.close()
        self.assertEqual(w.runner.cancelled, 1)
        self.assertIsNone(self.app.ruaccent_win)
        self.assertTrue(w.win.destroyed)

    def test_close_while_running_can_be_declined(self):
        w = self.window()
        w.runner.busy = True
        self.answer = False
        w.close()
        self.assertEqual(w.runner.cancelled, 0)
        self.assertFalse(w.win.destroyed)

    def test_build_rows_marks_unknown_versions_and_missing_on_server(self):
        installed = {'turbo': Path('x')}
        rows = {r[0]: r for r in self.rui.build_rows({'turbo3.1': {'size': 1, 'updated': ''}}, installed, {}, 'turbo')}
        self.assertEqual(rows['turbo'][4], '✓ скачана  ◀ используется')
        self.assertEqual(rows['tiny'][4], 'нет на сервере')


class FilesAndDocsTests(unittest.TestCase):
    def test_new_module_is_in_the_portable_copy(self):
        self.assertIn('ruaccent_ui.py', mm.PORTABLE_CODE)
        self.assertTrue((ROOT / 'ruaccent_ui.py').is_file())

    def test_app_has_the_button_and_the_menu_entry(self):
        app_src = (ROOT / 'app.py').read_text(encoding='utf-8')
        self.assertIn("text='RUAccent', command=self.open_ruaccent", app_src)
        self.assertIn('Модели ударений RUAccent…', (ROOT / 'models_ui.py').read_text(encoding='utf-8'))

    def test_speak_reads_the_model_from_settings_through_model_manager(self):
        src = (ROOT / 'speak.py').read_text(encoding='utf-8')
        self.assertIn('model_manager.ruaccent_load_kwargs(acc)', src)
        self.assertNotIn("omograph_model_size='turbo'", src)


if __name__ == '__main__':
    unittest.main()
