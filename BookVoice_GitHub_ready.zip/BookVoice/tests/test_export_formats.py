"""Сохранение в EPUB и MOBI, картинки между главами (PNG с прозрачностью), их хранение в FB2 и логика редактора.
Окон здесь нет: вкладка редактора создаётся без Tk, как в других тестах."""
import re
import shutil
import struct
import subprocess
import tempfile
import unittest
import zipfile
from io import BytesIO
from pathlib import Path
from unittest import mock
from xml.etree import ElementTree as ET

from PIL import Image, ImageDraw

import bookexport
import bookio
import edit_tab


def make_png(w=120, h=80, alpha=True):
    im = Image.new('RGBA' if alpha else 'RGB', (w, h), (0, 0, 0, 0) if alpha else (255, 255, 255))
    d = ImageDraw.Draw(im)
    d.ellipse((10, 10, w - 10, h - 10), fill=(200, 30, 30, 255) if alpha else (200, 30, 30))
    out = BytesIO()
    im.save(out, 'PNG')
    return out.getvalue()


def make_jpg(w=100, h=150):
    out = BytesIO()
    Image.new('RGB', (w, h), (90, 140, 200)).save(out, 'JPEG')
    return out.getvalue()


def sample_book(with_cover=True, long_text=False):
    body = ['Съешь ещё этих мягких французских булок, да выпей чаю. ' * (60 if long_text else 2)]
    b = bookio.Book(title='Тест & «книга»', author='Иван Петров', lang='ru',
                    cover=make_jpg() if with_cover else None)
    b.chapters = [('Глава 1', ['Первый <абзац>.'] + body), ('Глава 2', body), ('Глава 3', ['Финал.'])]
    b.images = [{'slot': 0, 'data': make_png(), 'name': 'начало.png'},
                {'slot': 1, 'data': make_png(alpha=False), 'name': 'между.png'},
                {'slot': 1, 'data': make_png(60, 60), 'name': 'вторая.png'},
                {'slot': 3, 'data': make_png(200, 100), 'name': 'конец.png'}]
    return b


class ImageCheckTests(unittest.TestCase):
    def test_png_alpha_is_detected(self):
        info = bookexport.check_image(make_png(), 'a.png')
        self.assertEqual((info['ext'], info['alpha'], info['width'], info['height']), ('png', True, 120, 80))
        self.assertFalse(bookexport.check_image(make_png(alpha=False), 'b.png')['alpha'])

    def test_garbage_empty_and_truncated_files_are_rejected_with_the_name(self):
        for data in (b'', b'not an image at all', make_png()[:60]):
            with self.assertRaises(ValueError) as cm:
                bookexport.check_image(data, 'файл.png')
            self.assertIn('файл.png', str(cm.exception))


class EpubTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / 'книга.epub'

    def build(self, book=None, **kw):
        book = book or sample_book()
        bookio.write_any(book, self.path, **kw)
        return book, zipfile.ZipFile(self.path)

    def test_mimetype_is_first_and_stored(self):
        _, z = self.build()
        first = z.infolist()[0]
        self.assertEqual((first.filename, first.compress_type), ('mimetype', zipfile.ZIP_STORED))
        self.assertEqual(z.read('mimetype'), b'application/epub+zip')

    def test_every_xml_part_is_well_formed(self):
        _, z = self.build()
        for name in z.namelist():
            if name.endswith(('.xhtml', '.opf', '.ncx', '.xml')):
                ET.fromstring(z.read(name))

    def test_chapter_images_are_embedded_in_their_chapter_pages(self):
        _, z = self.build()
        opf = z.read('OEBPS/content.opf').decode('utf-8')
        order = re.findall(r'<itemref idref="([^"]+)"', opf)
        self.assertEqual(order, ['titlepage', 'nav', 'ch001', 'ch002', 'ch003', 'pic004'])
        first = z.read('OEBPS/ch001.xhtml').decode('utf-8')
        second = z.read('OEBPS/ch002.xhtml').decode('utf-8')
        self.assertIn('chapter-image', first)
        self.assertIn('chapter-image', second)
        self.assertEqual(second.count('chapter-image'), 2)

    def test_png_is_stored_byte_for_byte_so_transparency_survives(self):
        book, z = self.build()
        self.assertEqual(z.read('OEBPS/images/img001.png'), book.images[0]['data'])
        im = Image.open(BytesIO(z.read('OEBPS/images/img001.png')))
        self.assertEqual(im.mode, 'RGBA')
        self.assertEqual(im.getpixel((0, 0))[3], 0)

    def test_titles_text_and_special_characters_are_escaped(self):
        _, z = self.build()
        ch = z.read('OEBPS/ch001.xhtml').decode('utf-8')
        self.assertIn('Первый &lt;абзац&gt;.', ch)
        self.assertIn('Тест &amp; «книга»', z.read('OEBPS/content.opf').decode('utf-8'))

    def test_toc_and_titlepage_options(self):
        _, z = self.build(titlepage=False, toc=False)
        order = re.findall(r'<itemref idref="([^"]+)"', z.read('OEBPS/content.opf').decode('utf-8'))
        self.assertNotIn('titlepage', order)
        self.assertNotIn('nav', order)
        self.assertIn('OEBPS/nav.xhtml', z.namelist())                  # навигация в EPUB 3 нужна всегда
        self.assertEqual(z.read('OEBPS/toc.ncx').decode('utf-8').count('<navPoint '), 3)

    def test_book_without_cover_author_or_images(self):
        b = bookio.Book(title='', chapters=[('Единственная', ['Текст.'])])
        _, z = self.build(b)
        opf = z.read('OEBPS/content.opf').decode('utf-8')
        self.assertIn('<dc:title>Без названия</dc:title>', opf)
        self.assertNotIn('dc:creator', opf)
        self.assertNotIn('cover-image', opf)

    def test_bad_language_code_falls_back_to_russian(self):
        b = sample_book()
        b.lang = 'русский!'
        _, z = self.build(b)
        self.assertIn('<dc:language>ru</dc:language>', z.read('OEBPS/content.opf').decode('utf-8'))

    @unittest.skipUnless(shutil.which('java'), 'нужна Java для epubcheck')
    def test_epubcheck_finds_no_problems(self):
        try:
            import epubcheck
        except ImportError:
            self.skipTest('пакет epubcheck не установлен')
        jar = Path(epubcheck.__file__).parent / 'epubcheck.jar'
        self.build()
        res = subprocess.run(['java', '-jar', str(jar), str(self.path)], capture_output=True, text=True)
        self.assertIn('0 fatals / 0 errors / 0 warnings', res.stdout + res.stderr)


def parse_mobi(data):
    """Минимальный разбор MOBI для проверок: записи, текст, заголовки."""
    n = struct.unpack('>H', data[76:78])[0]
    offs = [struct.unpack('>I', data[78 + 8 * i:82 + 8 * i])[0] for i in range(n)] + [len(data)]
    recs = [data[offs[i]:offs[i + 1]] for i in range(n)]
    r0 = recs[0]
    compression, _, text_len, n_text, rec_size = struct.unpack('>HHIHH', r0[:12])
    hdr_len = struct.unpack('>I', r0[20:24])[0]
    first_image = struct.unpack('>I', r0[0x6C:0x70])[0]
    return dict(data=data, recs=recs, r0=r0, compression=compression, text_len=text_len, n_text=n_text,
                rec_size=rec_size, hdr_len=hdr_len, first_image=first_image,
                text_recs=recs[1:1 + n_text], text=b''.join(recs[1:1 + n_text]))


def exth_records(info):
    r0 = info['r0']
    start = 16 + info['hdr_len']
    assert r0[start:start + 4] == b'EXTH'
    total, count = struct.unpack('>II', r0[start + 4:start + 12])
    pos, out = start + 12, {}
    for _ in range(count):
        t, ln = struct.unpack('>II', r0[pos:pos + 8])
        out.setdefault(t, []).append(r0[pos + 8:pos + ln])
        pos += ln
    return out


class MobiTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / 'книга.mobi'

    def build(self, book=None, **kw):
        book = book or sample_book()
        bookio.write_any(book, self.path, **kw)
        return book, parse_mobi(self.path.read_bytes())

    def test_palmdb_and_mobi_headers(self):
        _, m = self.build()
        d = m['data']
        self.assertEqual(d[60:68], b'BOOKMOBI')
        self.assertEqual(m['r0'][16:20], b'MOBI')
        self.assertEqual((m['hdr_len'], struct.unpack('>I', m['r0'][0x24:0x28])[0]), (232, 6))
        self.assertEqual(struct.unpack('>I', m['r0'][0x1C:0x20])[0], 65001)
        self.assertEqual(m['compression'], 1)

    def test_text_records_are_whole_utf8_and_add_up(self):
        _, m = self.build(sample_book(long_text=True))
        self.assertGreater(m['n_text'], 3)
        self.assertEqual(sum(len(r) for r in m['text_recs']), m['text_len'])
        for r in m['text_recs']:
            self.assertLessEqual(len(r), 4096)
            r.decode('utf-8')                                   # ни один символ не разрезан между записями

    def test_chapter_links_point_exactly_at_headings(self):
        _, m = self.build(sample_book(long_text=True))
        text = m['text']
        links = [int(x) for x in re.findall(rb'<a filepos=(\d{10})>', text)]
        self.assertEqual(len(links), 3)
        for off in links:
            self.assertEqual(text[off:off + 3], b'<h2')
        guide = re.findall(rb'<reference type="(\w+)"[^>]*filepos=(\d{10})', text)
        self.assertEqual({t for t, _ in guide}, {b'toc', b'text'})
        for _t, off in guide:
            self.assertEqual(text[int(off):int(off) + 3], b'<h2')

    def test_images_are_jpeg_or_gif_and_transparency_is_kept(self):
        book, m = self.build()
        first = m['first_image']
        imgs = m['recs'][first:first + 2 + len(book.images)]
        kinds = [bookexport.sniff_image(i)[0] for i in imgs]
        self.assertTrue(all(k in ('jpg', 'gif') for k in kinds))
        cover, thumb, first_png = imgs[0], imgs[1], imgs[2]
        self.assertEqual(bookexport.sniff_image(first_png)[0], 'gif')               # PNG с альфой -> GIF
        gif = Image.open(BytesIO(first_png)).convert('RGBA')
        self.assertEqual(gif.getpixel((0, 0))[3], 0)                                # углы прозрачны
        self.assertEqual(gif.getpixel((60, 40))[3], 255)                            # середина плотная
        self.assertEqual(bookexport.sniff_image(imgs[3])[0], 'jpg')                 # PNG без альфы -> JPEG
        self.assertLessEqual(max(Image.open(BytesIO(thumb)).size), 330)

    def test_chapter_images_are_inside_their_chapter_after_its_heading(self):
        _book, m = self.build()
        text = m['text'].decode('utf-8')
        heading = text.index('<h2 align="center">Глава 1</h2>')
        image = text.index('recindex="00003"')
        paragraph = text.index('Первый')
        self.assertLess(heading, image)
        self.assertLess(image, paragraph)

    def test_every_recindex_in_text_points_at_an_image_record(self):
        book, m = self.build()
        n_images = len(m['recs']) - m['first_image'] - 3                            # минус FLIS, FCIS, EOF
        refs = [int(x) for x in re.findall(rb'recindex="(\d{5})"', m['text'])]
        self.assertEqual(len(refs), len(book.images) + 1)                           # картинки + обложка на титуле
        self.assertTrue(all(1 <= r <= n_images for r in refs))

    def test_exth_has_author_title_and_cover(self):
        _, m = self.build()
        e = exth_records(m)
        self.assertEqual(e[100][0].decode('utf-8'), 'Иван Петров')
        self.assertEqual(e[503][0].decode('utf-8'), 'Тест & «книга»')
        self.assertEqual(struct.unpack('>I', e[201][0])[0], 0)
        self.assertEqual(struct.unpack('>I', e[202][0])[0], 1)

    def test_last_records_are_flis_fcis_eof(self):
        _, m = self.build()
        self.assertEqual([r[:4] for r in m['recs'][-3:]], [b'FLIS', b'FCIS', b'\xe9\x8e\r\n'])

    def test_book_without_cover_images_or_author(self):
        b = bookio.Book(title='', chapters=[('Раз', ['Текст.'])])
        _, m = self.build(b)
        self.assertEqual(m['first_image'], 0xFFFFFFFF)
        self.assertNotIn(100, exth_records(m))
        self.assertNotIn(201, exth_records(m))

    def test_large_picture_is_scaled_down(self):
        b = sample_book(with_cover=False)
        big = Image.new('RGB', (3000, 2000), (10, 200, 10))
        buf = BytesIO()
        big.save(buf, 'PNG')
        b.images = [{'slot': 1, 'data': buf.getvalue(), 'name': 'big.png'}]
        _, m = self.build(b)
        img = Image.open(BytesIO(m['recs'][m['first_image']]))
        self.assertEqual(max(img.size), bookexport.MOBI_MAX_SIDE)

    def test_failed_write_leaves_the_old_file_untouched(self):
        self.path.write_bytes(b'OLD')
        with mock.patch.object(bookexport, 'build_mobi', side_effect=RuntimeError('boom')):
            with self.assertRaises(RuntimeError):
                bookio.write_any(sample_book(), self.path)
        self.assertEqual(self.path.read_bytes(), b'OLD')
        self.assertEqual([p.name for p in self.path.parent.iterdir()], [self.path.name])

    def test_kindleunpack_reads_the_file_back(self):
        try:
            import mobi
        except ImportError:
            self.skipTest('пакет mobi (KindleUnpack) не установлен')
        self.build()
        tmpdir, html = mobi.extract(str(self.path))
        self.addCleanup(shutil.rmtree, tmpdir, True)
        text = Path(html).read_text(encoding='utf-8')
        self.assertIn('Глава 2', text)
        self.assertEqual(text.count('<img src="Images/'), 5)                        # обложка + 4 картинки
        self.assertEqual(len(re.findall(r'<a href="#filepos\d+">', text)), 3)


class Fb2ImageTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / 'книга.fb2'

    def test_images_survive_a_save_and_open_round_trip_in_place(self):
        book = sample_book()
        bookio.write_any(book, self.path)
        back = bookio.read_fb2(self.path)
        self.assertEqual([t for t, _ in back.chapters], ['Глава 1', 'Глава 2', 'Глава 3'])
        self.assertEqual([(i['slot'], i['name']) for i in back.images],
                         [(0, 'начало.png'), (1, 'между.png'), (1, 'вторая.png'), (3, 'конец.png')])
        self.assertEqual([i['data'] for i in back.images], [i['data'] for i in book.images])

    def test_fb2_is_still_valid_xml_with_png_binaries(self):
        bookio.write_any(sample_book(), self.path)
        root = ET.parse(self.path).getroot()
        types = [e.get('content-type') for e in root if e.tag.endswith('binary')]
        self.assertEqual(types.count('image/png'), 4)

    def test_picture_names_with_quotes_and_angle_brackets_do_not_break_the_xml(self):
        book = sample_book()
        book.images[0]['name'] = 'a"b<c>&d.png'
        bookio.write_any(book, self.path)
        self.assertEqual(bookio.read_fb2(self.path).images[0]['name'], 'a"b<c>&d.png')
        epub = Path(self.tmp.name) / 'q.epub'
        bookio.write_any(book, epub)
        with zipfile.ZipFile(epub) as z:
            ET.fromstring(z.read('OEBPS/ch001.xhtml'))

    def test_foreign_inline_images_are_not_imported(self):
        bookio.write_any(sample_book(), self.path)
        text = self.path.read_text(encoding='utf-8').replace('id="bv-chapter-img-2"', 'id="other"')
        self.path.write_text(text, encoding='utf-8')
        back = bookio.read_fb2(self.path)
        self.assertEqual(len(back.images), 3)

    def test_txt_and_md_ignore_pictures_without_failing(self):
        for ext in ('.txt', '.md'):
            p = Path(self.tmp.name) / f'x{ext}'
            bookio.write_any(sample_book(), p)
            self.assertIn('Глава 2', p.read_text(encoding='utf-8'))

    def test_merging_files_keeps_pictures_with_their_chapters(self):
        a, b = Path(self.tmp.name) / '1.fb2', Path(self.tmp.name) / '2.fb2'
        one = bookio.Book(title='А', chapters=[('Первая', ['а'])], images=[{'slot': 1, 'data': make_png(), 'name': 'x'}])
        two = bookio.Book(title='Б', chapters=[('Вторая', ['б']), ('Третья', ['в'])],
                          images=[{'slot': 1, 'data': make_png(30, 30), 'name': 'y'}])
        bookio.write_any(one, a)
        bookio.write_any(two, b)
        merged = bookio.merge_files([a, b]).book
        self.assertEqual([(i['slot'], i['name']) for i in merged.images], [(1, 'x'), (2, 'y')])


class Var:
    def __init__(self, v=''):
        self.v = v

    def get(self):
        return self.v

    def set(self, v):
        self.v = v


class EditorImageLogicTests(unittest.TestCase):
    def make(self, n=3):
        tab = edit_tab.EditTab.__new__(edit_tab.EditTab)
        tab.items, tab.cur, tab.next_id = [], None, 1
        tab.tail_images, tab.next_img_id, tab.sel_img = [], 1, None
        tab.title_var, tab.author_var, tab.lang_var, tab.status = Var('К'), Var('А'), Var('ru'), Var()
        tab.cover, tab.snapshot, tab.accent_dirty = None, None, False
        tab.refresh_tree = lambda *a, **k: None
        tab.select_item = lambda it: setattr(tab, 'cur', it)
        tab.show_image = lambda img: setattr(tab, 'sel_img', img)
        for i in range(n):
            tab.items.append(tab.new_item(f'Глава {i + 1}', [f'текст {i + 1}']))
        tab.cur = tab.items[0] if tab.items else None
        return tab

    def add(self, tab, where, name='a.png', data=None):
        path = Path(tempfile.mkdtemp()) / name
        path.write_bytes(data or make_png())
        self.addCleanup(shutil.rmtree, path.parent, True)
        tab.insert_images(where, [str(path)])
        return tab.sel_img

    def layout(self, tab):
        return [(k, o['name'] if k == 'img' else o['title']) for k, o in tab.flat_sequence() if k != 'tail']

    def test_insert_before_and_after_a_chapter_and_at_the_end(self):
        tab = self.make()
        tab.cur = tab.items[1]
        self.add(tab, 'before', 'до.png')
        tab.sel_img = None
        tab.cur = tab.items[1]
        self.add(tab, 'after', 'после.png')
        tab.sel_img = None
        self.add(tab, 'end', 'конец.png')
        self.assertEqual([x[1] for x in self.layout(tab)],
                         ['Глава 1', 'Глава 2', 'до.png', 'после.png', 'Глава 3', 'конец.png'])

    def test_insert_image_is_owned_by_the_selected_chapter(self):
        tab = self.make()
        tab.cur = tab.items[1]
        self.add(tab, 'chapter', 'inside.png')
        book = tab.collect_book()
        self.assertEqual([(im['slot'], im['name']) for im in book.images], [(1, 'inside.png')])
        self.assertEqual(self.layout(tab), [('ch', 'Глава 1'), ('ch', 'Глава 2'),
                                            ('img', 'inside.png'), ('ch', 'Глава 3')])

    def test_insert_relative_to_the_selected_picture(self):
        tab = self.make()
        first = self.add(tab, 'after', 'раз.png')
        self.add(tab, 'after', 'два.png')
        tab.sel_img = first
        self.add(tab, 'before', 'ноль.png')
        self.assertEqual([x[1] for x in self.layout(tab)],
                         ['Глава 1', 'ноль.png', 'раз.png', 'два.png', 'Глава 2', 'Глава 3'])

    def test_moving_a_picture_across_chapters_and_to_the_end(self):
        tab = self.make()
        img = self.add(tab, 'after', 'p.png')                  # между главами 1 и 2
        for _ in range(4):
            tab.refresh_tree = lambda *a, **k: None
            tab.sel_img = img
            tab.move_image(1)
        self.assertEqual(self.layout(tab)[-1], ('img', 'p.png'))
        self.assertEqual(tab.tail_images, [img])
        tab.sel_img = img
        tab.move_image(1)                                        # дальше конца двигать некуда
        self.assertEqual(self.layout(tab)[-1], ('img', 'p.png'))
        for _ in range(10):
            tab.move_image(-1)
        self.assertEqual(self.layout(tab)[0], ('ch', 'Глава 1'))
        self.assertEqual(self.layout(tab)[1], ('img', 'p.png'))

    def test_collect_book_gives_slots_in_chapter_order(self):
        tab = self.make()
        tab.cur = tab.items[2]
        self.add(tab, 'before', 'три.png')
        tab.sel_img = None
        self.add(tab, 'end', 'хвост.png')
        book = tab.collect_book()
        self.assertEqual([(i['slot'], i['name']) for i in book.images], [(2, 'три.png'), (3, 'хвост.png')])

    def test_adding_a_picture_marks_the_book_unsaved(self):
        tab = self.make()
        tab.mark_clean()
        self.assertFalse(tab.is_dirty())
        self.add(tab, 'end')
        self.assertTrue(tab.is_dirty())

    def test_deleting_a_chapter_hands_its_pictures_to_the_next_one(self):
        tab = self.make()
        tab.cur = tab.items[1]
        self.add(tab, 'before', 'x.png')
        tab.sel_img = None
        tab.cur = tab.items[1]
        with mock.patch.object(edit_tab.messagebox, 'askyesno', return_value=True):
            tab.delete_chapter()
        self.assertEqual(self.layout(tab), [('ch', 'Глава 1'), ('ch', 'Глава 3'), ('img', 'x.png')])

    def test_merging_chapters_keeps_the_picture_between_them(self):
        tab = self.make()
        tab.cur = tab.items[1]
        self.add(tab, 'before', 'x.png')                        # между главами 1 и 2
        tab.sel_img = None
        tab.cur = tab.items[0]
        tab.set_paras = lambda it, paras, records=None: it.__setitem__('paras', paras)
        tab.merge_next()
        self.assertEqual([x[0] for x in self.layout(tab)], ['ch', 'img', 'ch'])
        self.assertEqual(len(tab.items), 2)

    def test_deleting_a_picture_keeps_the_chapters(self):
        tab = self.make()
        img = self.add(tab, 'end')
        tab.sel_img = img
        with mock.patch.object(edit_tab.messagebox, 'askyesno', return_value=True):
            tab.delete_image()
        self.assertEqual(tab.tail_images, [])
        self.assertEqual(len(tab.items), 3)

    def test_new_chapter_after_a_selected_picture_takes_the_pictures_before_it(self):
        tab = self.make()
        a = self.add(tab, 'after', 'a.png')
        self.add(tab, 'after', 'b.png')
        tab.sel_img = a
        tab.add_chapter()
        self.assertEqual([x[1] for x in self.layout(tab)],
                         ['Глава 1', 'a.png', 'b.png', 'Глава 4', 'Глава 2', 'Глава 3'])

    def test_a_broken_file_is_reported_and_nothing_is_added(self):
        tab = self.make()
        bad = Path(tempfile.mkdtemp()) / 'bad.png'
        bad.write_bytes(b'not a picture')
        self.addCleanup(shutil.rmtree, bad.parent, True)
        with mock.patch.object(edit_tab.messagebox, 'showwarning') as warn:
            tab.insert_images('end', [str(bad)])
        warn.assert_called_once()
        self.assertEqual(tab.tail_images, [])

    def test_load_book_distributes_pictures_and_skips_broken_ones(self):
        tab = self.make(0)
        tab.hide_image_panel = lambda: None
        tab.set_cover = lambda d: None
        tab.lang_var = Var()
        book = sample_book()
        book.images.append({'slot': 1, 'data': b'junk', 'name': 'junk'})
        tab.load_book(book)
        self.assertEqual([len(it['images']) for it in tab.items] + [len(tab.tail_images)], [1, 2, 0, 1])


if __name__ == '__main__':
    unittest.main()
