import unittest

from edit_tab import EditTab


class FakeWidget:
    def __init__(self, text, ranges):
        self.text = text
        self.ranges = ranges

    def tag_ranges(self, tag):
        return self.ranges.get(tag, ())

    def get(self, start, end):
        def offset(index):
            line, col = index.split('.')
            if line != '1':
                raise ValueError('test fake only supports one line')
            return int(col)
        return self.text[offset(start):offset(end)]


class FakeTTS:
    def prepare_paragraph_ex(self, text):
        return [(0, text)]


class FakeApp:
    tts = FakeTTS()


class EditorLiveEmphasisTests(unittest.TestCase):
    def test_build_live_units_carries_strong_tag_into_synthesis_text(self):
        text = 'С тех пор как они прибыли и одержали победу.'
        start = text.index('они')
        widget = FakeWidget(text, {'accent2': (f'1.{start}', f'1.{start + len("они")}')})
        subject = type('Subject', (), {'app': FakeApp()})()
        units = EditTab.build_live_units(subject, text, 0, widget=widget)
        self.assertEqual(len(units), 1)
        self.assertIn('**они**', units[0]['text'])

    def test_unmarked_text_remains_unmarked(self):
        text = 'С тех пор как они прибыли.'
        widget = FakeWidget(text, {})
        subject = type('Subject', (), {'app': FakeApp()})()
        units = EditTab.build_live_units(subject, text, 0, widget=widget)
        self.assertEqual(units[0]['text'], text)


if __name__ == '__main__':
    unittest.main()
