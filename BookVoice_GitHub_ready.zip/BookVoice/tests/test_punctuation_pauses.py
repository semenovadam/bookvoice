import unittest
from punctuation_pauses import (pause_ms, punctuation_pause_ms, prepare_tts_text,
                                 set_pause_level, get_pause_level)


class PunctuationPauseTests(unittest.TestCase):
    def tearDown(self):
        # Остальные тесты проверяют исходную таблицу (уровень 4 = 100%).
        set_pause_level(4)

    def test_five_pause_levels_scale_all_durations(self):
        expected = {1: 220, 2: 280, 3: 340, 4: 400, 5: 460}
        for level, duration in expected.items():
            with self.subTest(level=level):
                set_pause_level(level)
                self.assertEqual(get_pause_level(), level)
                self.assertEqual(punctuation_pause_ms('слово.'), duration)

    def test_paragraph_and_ellipsis_are_scaled_once(self):
        set_pause_level(3)
        self.assertEqual(pause_ms('слово.', 2), 468)  # 550 * 0.85
        self.assertEqual(pause_ms('слово…', 2), 978)  # 1150 * 0.85

    def test_distinct_basic_signs(self):
        cases = {
            'слово,': 120, 'слово–': 150, 'слово—': 180,
            'слово:': 220, 'слово;': 320, 'слово.': 400,
            'слово?': 450, 'слово!': 500, 'слово…': 900,
        }
        for text, expected in cases.items():
            with self.subTest(text=text):
                self.assertEqual(punctuation_pause_ms(text), expected)

    def test_repeated_signs_are_distinct(self):
        cases = {'слово!!': 600, 'слово!!!': 700,
                 'слово??': 650, 'слово???': 750,
                 'слово?!': 800, 'слово!?': 810,
                 'слово!!?': 850, 'слово?!?': 870,
                 'слово...!': 1050, 'слово...?': 1080,
                 'слово...?!': 1100}
        for text, expected in cases.items():
            with self.subTest(text=text):
                self.assertEqual(punctuation_pause_ms(text), expected)

    def test_paragraph_pauses_and_clamp(self):
        self.assertEqual(pause_ms('слово.', 1), 400)
        self.assertEqual(pause_ms('слово.', 2), 550)
        self.assertEqual(pause_ms('слово.', 3), 750)
        self.assertEqual(pause_ms('слово.', 99), 750)

    def test_ellipsis_paragraph_combinations_do_not_add(self):
        self.assertEqual(pause_ms('слово…', 1), 1000)
        self.assertEqual(pause_ms('слово...', 2), 1150)
        self.assertEqual(pause_ms('слово…', 3), 1300)

    def test_interjection_elongation_is_automatic(self):
        self.assertEqual(prepare_tts_text('А... Потом'), 'Аааа Потом')
        self.assertEqual(prepare_tts_text('О… да'), 'Оооо да')
        self.assertEqual(prepare_tts_text('Это... важно'), 'Это... важно')


if __name__ == '__main__':
    unittest.main()
