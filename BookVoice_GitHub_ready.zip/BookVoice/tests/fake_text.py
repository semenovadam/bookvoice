"""Небольшой макет окна Text для тестов без графики: текст, индексы «строка.столбец»,
'end', 'end-1c', 'insert', 'N.M+Kc' и теги с диапазонами, которые двигаются при вставке и удалении.

Настоящий Tk этим не заменяется; макет нужен, чтобы проверять логику акцентов редактора
(сохранение, перенос при замене текста, разбиение и объединение глав) без окон.
"""
import re


class FakeText:
    def __init__(self):
        self.s = ''                      # текст без завершающего перевода строки, который есть у настоящего Text
        self.tags = {}                   # имя -> [[начало, конец], ...] в смещениях, отсортировано и слито
        self.marks = {'insert': 0}

    # ------------------------------------------------------------ индексы
    def _off(self, index):
        index = str(index)
        delta = 0
        m = re.fullmatch(r'(.+?)([+-]\d+)c', index)
        if m:
            index, delta = m.group(1), int(m.group(2))
        if index == 'end':
            base = len(self.s) + 1
        elif index in self.marks:
            base = self.marks[index]
        else:
            line, col = index.split('.')
            lines = self.s.split('\n')
            line, col = int(line), int(col)
            if line > len(lines):
                base = len(self.s) + 1
            else:
                base = sum(len(x) + 1 for x in lines[:line - 1]) + min(col, len(lines[line - 1]))
        return max(0, min(len(self.s) + 1, base + delta))

    def index(self, index):
        off = self._off(index)
        before = (self.s + '\n')[:off]
        return f"{before.count(chr(10)) + 1}.{off - (before.rfind(chr(10)) + 1)}"

    def get(self, i1='1.0', i2=None):
        a = self._off(i1)
        b = self._off(i2) if i2 is not None else a + 1
        return (self.s + '\n')[a:b]

    def mark_set(self, name, index):
        self.marks[name] = self._off(index)

    def see(self, *_):
        pass

    def destroy(self):
        pass

    # ------------------------------------------------------------ правка текста
    def insert(self, index, chars, *_tags):
        pos = min(self._off(index), len(self.s))
        self.s = self.s[:pos] + chars + self.s[pos:]
        for ranges in self.tags.values():
            for r in ranges:
                if r[0] >= pos:
                    r[0] += len(chars)
                    r[1] += len(chars)
                elif r[1] > pos:
                    r[1] += len(chars)

    def delete(self, i1, i2=None):
        a = self._off(i1)
        b = self._off(i2) if i2 is not None else a + 1
        a, b = min(a, len(self.s)), min(b, len(self.s))
        if b <= a:
            return
        n = b - a
        self.s = self.s[:a] + self.s[b:]

        def shift(x):
            return x if x <= a else (a if x <= b else x - n)
        for name, ranges in self.tags.items():
            moved = [[shift(r[0]), shift(r[1])] for r in ranges]
            self.tags[name] = [r for r in moved if r[0] < r[1]]

    def edit_separator(self):
        pass

    def edit_reset(self):
        pass

    # ------------------------------------------------------------ теги
    def tag_add(self, tag, i1, i2):
        a, b = self._off(i1), self._off(i2)
        if a >= b:
            return
        ranges = self.tags.setdefault(tag, [])
        ranges.append([a, b])
        ranges.sort()
        merged = [ranges[0]]
        for r in ranges[1:]:
            if r[0] <= merged[-1][1]:
                merged[-1][1] = max(merged[-1][1], r[1])
            else:
                merged.append(r)
        self.tags[tag] = merged

    def tag_remove(self, tag, i1, i2):
        a, b = self._off(i1), self._off(i2)
        out = []
        for r in self.tags.get(tag, []):
            if r[1] <= a or r[0] >= b:
                out.append(r)
                continue
            if r[0] < a:
                out.append([r[0], a])
            if r[1] > b:
                out.append([b, r[1]])
        self.tags[tag] = out

    def tag_ranges(self, tag):
        flat = []
        for a, b in self.tags.get(tag, []):
            flat += [self.index(f'1.0+{a}c'), self.index(f'1.0+{b}c')]
        return tuple(flat)

    def tag_names(self, index=None):
        if index is None:
            return tuple(self.tags)
        off = self._off(index)
        return tuple(n for n, rs in self.tags.items() if any(a <= off < b for a, b in rs))
