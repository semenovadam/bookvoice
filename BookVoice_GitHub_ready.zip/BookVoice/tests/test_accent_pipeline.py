"""Порядок обработки текста: предложение целиком -> ударения/омографы/словарь -> нарезка -> движок.

RUAccent, словарь и pymorphy здесь подменены; проверяется ЛОГИКА: что видит каждый шаг, что происходит при
сбое RUAccent (возвраты), как режется готовый текст и что не ломается в editor/app/speak."""
import re
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import accent_pipeline as ap

try:
    from test_ruaccent_models import function_source
except ImportError:
    from tests.test_ruaccent_models import function_source


def toy_accent(text):
    """Подставной RUAccent: ставит «+» перед первой гласной каждого слова длиннее трёх букв и меняет «замок» по контексту."""
    def fix(m):
        w = m.group(0)
        if len(w) <= 3:
            return w
        for i, c in enumerate(w):
            if c in ap.VOWELS:
                return w[:i] + '+' + w[i:]
        return w
    return re.sub(r'[А-Яа-яЁё]+', fix, text)


def make_steps(**over):
    calls = []

    def accentize(t):
        calls.append(t)
        return toy_accent(t)
    kw = dict(accentize=accentize, log=lambda *a: None)
    kw.update(over)
    steps = ap.Steps(**kw)
    steps.calls = calls
    return steps


class SentenceFirstOrderTests(unittest.TestCase):
    def test_ruaccent_sees_the_whole_sentence_not_the_comma_pieces(self):
        steps = make_steps()
        out = ap.prepare_text('Он вошёл, и замок щёлкнул, а она ушла.', steps, at_commas=True, report=ap.Report())
        self.assertEqual(steps.calls, ['Он вошёл, и замок щёлкнул, а она ушла.'])      # один вызов, целое предложение
        self.assertEqual(len(out), 3)                                                   # нарезка по запятым осталась
        self.assertTrue(all(isinstance(f, ap.Prepared) for _k, f in out))
        self.assertTrue(all('+' in f for _k, f in out[:2]))                             # ударения уже стоят в каждом куске

    def test_dictionary_and_context_overrides_see_the_whole_sentence(self):
        seen = {}
        steps = make_steps(dictionary=lambda t: seen.setdefault('dict', t) and t,
                           overrides=lambda t: seen.setdefault('over', t) and t)
        ap.prepare_text('Закрыл, как всегда, замок на двери.', steps, report=ap.Report())
        self.assertIn('замок', seen['dict'].replace('+', ''))
        self.assertGreater(seen['dict'].count(','), 1)                                  # запятые на месте: это ВСЁ предложение
        self.assertEqual(seen['dict'].replace('+', ''), 'Закрыл, как всегда, замок на двери.')
        self.assertEqual(seen['over'], seen['dict'])

    def test_steps_run_in_the_documented_order(self):
        order = []
        steps = make_steps(
            accentize=lambda t: order.append('ruaccent') or t,
            undo_yo=lambda src, t: order.append('yo') or t,
            force_stress=lambda t: order.append('force') or t,
            fix_sam=lambda t: order.append('sam') or t,
            dictionary=lambda t: order.append('dict') or t,
            overrides=lambda t: order.append('homo') or t,
            yo_from_book=True)
        ap.accent_sentence('Всё хорошо.', steps, ap.Report())
        self.assertEqual(order, ['ruaccent', 'yo', 'force', 'sam', 'dict', 'homo'])

    def test_yo_step_is_skipped_when_not_requested(self):
        order = []
        steps = make_steps(undo_yo=lambda src, t: order.append('yo') or t, yo_from_book=False)
        ap.accent_sentence('Всё хорошо.', steps, ap.Report())
        self.assertEqual(order, [])

    def test_fragments_are_cut_only_after_the_text_is_final(self):
        steps = make_steps(dictionary=lambda t: t.replace('Бр+одог', 'БРОДОГ'))
        out = ap.prepare_text('Бродог, увидев это, ушёл.', steps, at_commas=True, report=ap.Report())
        self.assertEqual([str(f) for _k, f in out][0], 'БРОДОГ,')        # правило словаря применено ДО нарезки

    def test_without_comma_splitting_the_sentence_is_one_fragment(self):
        out = ap.prepare_text('Он вошёл, и замок щёлкнул. Она ушла.', make_steps(), at_commas=False, report=ap.Report())
        self.assertEqual([k for k, _f in out], [0, 1])

    def test_dialogue_remark_is_one_sentence_but_still_two_pauses(self):
        steps = make_steps()
        out = ap.prepare_text('— Привет! — сказал он.', steps, at_commas=True, report=ap.Report())
        self.assertEqual(len(steps.calls), 1)                  # RUAccent видит реплику вместе со словами автора
        self.assertEqual([str(f).rstrip()[-1] for _k, f in out], ['!', '.'])    # а пауза на «!» сохранена

    def test_sentences_without_letters_do_not_reach_ruaccent(self):
        steps = make_steps()
        text, how = ap.accent_sentence('* * *', steps, ap.Report())
        self.assertEqual((text, how, steps.calls), ('* * *', 'skip', []))


class VerificationAndFallbackTests(unittest.TestCase):
    def test_ruaccent_is_not_allowed_to_change_words(self):
        calls = []

        def drops_a_word(t):
            calls.append(t)
            return toy_accent(t).replace(' и ', ' ') if len(t) > 25 else toy_accent(t)
        report = ap.Report()
        steps = make_steps(accentize=drops_a_word)
        text, how = ap.accent_sentence('Он вошёл, и замок щёлкнул, а она ушла.', steps, report)
        self.assertEqual(how, 'clauses')                       # целое предложение отвергнуто, части приняты
        self.assertEqual(text.replace('+', ''), 'Он вошёл, и замок щёлкнул, а она ушла.')
        self.assertEqual(len(calls), 1 + 3)                     # целое + три части
        self.assertEqual(report.counts['clauses'], 1)
        self.assertEqual(report.problems[0][0], 'clauses')

    def test_a_clause_that_stays_wrong_is_left_without_ruaccent(self):
        def bad_for_the_middle(t):
            if 'замок' in t:
                return t.replace('замок', 'замков')               # искажает именно эту часть
            return toy_accent(t)
        report = ap.Report()
        text, how = ap.accent_sentence('Он вошёл, и замок щёлкнул, а она ушла.', make_steps(accentize=bad_for_the_middle), report)
        self.assertEqual(how, 'partial')
        self.assertIn('и замок щёлкнул,', text)                   # эта часть осталась как была
        self.assertIn('+', text)                                  # остальные получили ударения
        self.assertEqual(text.replace('+', ''), 'Он вошёл, и замок щёлкнул, а она ушла.')

    def test_ruaccent_failure_everywhere_gives_plain_text_and_dictionary_still_applies(self):
        def boom(t):
            raise RuntimeError('сбой')
        report = ap.Report()
        steps = make_steps(accentize=boom, dictionary=lambda t: t.replace('замок', 'зам+ок'),
                           force_stress=lambda t: t.replace('пять', 'п+ять'))
        text, how = ap.accent_sentence('Пять раз закрыл замок.', steps, report)
        self.assertEqual(how, 'plain')
        self.assertIn('зам+ок', text)
        self.assertEqual(report.counts['plain'], 1)

    def test_a_failing_post_step_is_skipped_and_the_rest_still_run(self):
        logged = []

        def broken(t):
            raise RuntimeError('pymorphy не загрузился')
        steps = make_steps(fix_sam=broken, dictionary=lambda t: t.replace('+ушла', '+ушла!'), log=logged.append)
        text, how = ap.accent_sentence('Она ушла.', steps, ap.Report())
        self.assertEqual(how, 'sentence')
        self.assertIn('+ушла!', text)                                     # словарь после сбойного шага всё равно сработал
        self.assertTrue(any('fix_sam' in line for line in logged))

    def test_exception_message_is_logged(self):
        logged = []

        def boom(t):
            raise ValueError('странный вход')
        ap.accent_sentence('Он ушёл.', make_steps(accentize=boom, log=logged.append), ap.Report())
        self.assertTrue(any('ValueError' in line for line in logged))

    def test_changes_of_yo_and_case_are_not_a_mismatch(self):
        self.assertTrue(ap.same_words('Небо над Москвой', 'Н+ёбо над Москв+ой'))
        self.assertTrue(ap.same_words('Hello мир', 'мир'))                 # латиницу RUAccent не трогает и не проверяем
        self.assertFalse(ap.same_words('он ушёл домой', 'он ушёл'))

    def test_sanitize_removes_broken_stress_marks_only(self):
        self.assertEqual(ap.sanitize_stress('зам+ок д+ом +к н+ет +++а к+'), 'зам+ок д+ом к н+ет +а к')
        self.assertEqual(ap.sanitize_stress('+ёж'), '+ёж')
        self.assertEqual(ap.sanitize_stress('plain + text'), 'plain + text')      # не кириллица: не трогаем

    def test_sanitize_runs_after_the_dictionary(self):
        steps = make_steps(dictionary=lambda t: t.replace('ушл+а', 'ушл+'))            # опечатка в словаре
        text, _ = ap.accent_sentence('Она ушла.', steps, ap.Report())
        self.assertNotIn('+.', text)


class EmphasisTests(unittest.TestCase):
    def test_emphasis_survives_the_pipeline_and_is_restored_on_the_right_word(self):
        out = ap.prepare_text('Это *замок* на двери.', make_steps(), report=ap.Report())
        self.assertEqual(len(out), 1)
        self.assertRegex(out[0][1], r'\*з\+?амок\*|\*зам\+ок\*')

    def test_emphasis_cut_by_a_comma_is_closed_and_reopened(self):
        out = ap.prepare_text('Он *вошёл, и замок* щёлкнул.', make_steps(), at_commas=True, report=ap.Report())
        texts = [str(f) for _k, f in out]
        self.assertEqual(len(texts), 2)
        for t in texts:
            self.assertEqual(t.count('*') % 2, 0, t)

    def test_lost_emphasis_is_reported_not_guessed(self):
        report = ap.Report()
        steps = make_steps(dictionary=lambda t: t.replace('з+амок', 'вовсе другое'))
        ap.accent_sentence('Это *замок* на двери.', steps, report)
        self.assertEqual(report.counts['emphasis_lost'], 1)

    def test_scene_break_stars_are_left_alone(self):
        self.assertEqual(ap.split_fragments('* * *', True, 250), ['* * *'])
        self.assertEqual(ap.balance_markers(['а *б', 'в* г']), ['а *б*', '*в* г'])
        self.assertEqual(ap.balance_markers(['а * б', 'в']), ['а * б', 'в'])      # непарные звёздочки не трогаем


class BoundaryTests(unittest.TestCase):
    def s(self, text):
        return ap.split_sentences(text)

    def test_initials_and_abbreviations_do_not_end_a_sentence(self):
        self.assertEqual(self.s('А. С. Пушкин родился в Москве. Он писал.'), ['А. С. Пушкин родился в Москве.', 'Он писал.'])
        self.assertEqual(self.s('Мы жили в г. Москва на ул. Ленина. Потом уехали.'),
                         ['Мы жили в г. Москва на ул. Ленина.', 'Потом уехали.'])
        self.assertEqual(self.s('Это т.е. брат. Конец.'), ['Это т.е. брат.', 'Конец.'])

    def test_etc_ends_a_sentence_only_before_a_capital(self):
        self.assertEqual(self.s('Ножи, вилки и т.д. Потом всё.'), ['Ножи, вилки и т.д.', 'Потом всё.'])
        self.assertEqual(self.s('Ножи и т.д. и т.п. кончились.'), ['Ножи и т.д. и т.п. кончились.'])

    def test_one_letter_pronoun_at_the_end_is_a_real_sentence_end(self):
        self.assertEqual(self.s('Это сделал я. Потом ушёл.'), ['Это сделал я.', 'Потом ушёл.'])

    def test_ellipsis_before_lowercase_continues_the_sentence_but_not_before_capital(self):
        self.assertEqual(self.s('Он... не знал. Он… Потом.'), ['Он... не знал.', 'Он…', 'Потом.'])

    def test_closing_quotes_belong_to_the_sentence_they_close(self):
        self.assertEqual(self.s('Он крикнул: «Иди!» Она ушла.'), ['Он крикнул: «Иди!»', 'Она ушла.'])

    def test_pause_fragments_keep_every_terminal_even_the_ellipsis_before_lowercase(self):
        self.assertEqual(ap.split_fragments('Он... не знал, что делать.', True, 250), ['Он...', 'не знал,', 'что делать.'])
        self.assertEqual(ap.split_fragments('Он... не знал, что делать.', False, 250), ['Он...', 'не знал, что делать.'])

    def test_abbreviations_are_not_cut_in_fragments_either(self):
        self.assertEqual(ap.split_fragments('А. С. Пушкин пришёл, увидел.', True, 250), ['А. С. Пушкин пришёл,', 'увидел.'])

    def test_sentence_spans_agree_with_sentences(self):
        text = 'Он ушёл. А. С. Пушкин остался.'
        self.assertEqual([text[a:b] for a, b in ap.sentence_spans(text)], self.s(text))

    def test_long_sentences_are_measured_without_stress_marks(self):
        words = ' '.join(['сл+ово'] * 30)
        self.assertEqual(ap.split_long(words, 250), [words])                        # 30*5+29 = 179 видимых, но 209 с «+»
        parts = ap.split_long(words, 100)
        self.assertTrue(all(ap.visible_len(p) <= 100 for p in parts))
        self.assertEqual(' '.join(parts), words)

    def test_comma_before_a_closing_quote_still_gets_a_pause_boundary(self):
        self.assertEqual(ap.split_fragments('«Иди,» — сказал он.', True, 250), ['«Иди,»', 'сказал он.'])
        self.assertEqual(ap.split_fragments('— Привет!', True, 250), ['Привет!'])          # как и раньше: тире реплики не озвучивается


class ReportTests(unittest.TestCase):
    def test_report_lists_fallbacks_and_homographs(self):
        report = ap.Report()
        steps = make_steps(omograph=lambda w: w == 'замок')
        ap.accent_sentence('Это замок на двери.', steps, report)
        text = report.text()
        self.assertIn('Предложений обработано: 1', text)
        self.assertIn('Омографы', text)
        self.assertRegex(text, r'замок -> з?[а-я+]*мок')

    def test_report_reset(self):
        report = ap.Report()
        ap.accent_sentence('Он ушёл.', make_steps(), report)
        report.reset()
        self.assertEqual(report.counts['sentences'], 0)
        self.assertEqual(report.problems, [])


# ---------------------------------------------------------------- подключение в speak.py / app.py / edit_tab.py
class SpeakWiringTests(unittest.TestCase):
    """Функции speak.py берутся из исходника (сам модуль тянет torch)."""

    def namespace(self, engine='silero'):
        log = []
        lock_state = {'held': False, 'seen_held': []}

        class Lock:
            def __enter__(self):
                lock_state['held'] = True

            def __exit__(self, *a):
                lock_state['held'] = False

        accentizer = SimpleNamespace(process_all=lambda t: log.append(('ruaccent', t)) or toy_accent(t),
                                     omographs={'замок': 1})
        ns = {'re': re, 'accent_pipeline': ap, 'TTS_LOCK': Lock(), 'SPLIT_AT_COMMAS': True, 'ENGINE': engine,
              'MAX_LEN': 250, 'accentizer': accentizer, 'SAM_FIX': False, 'YO_FROM_BOOK': True,
              'numbers_to_words': lambda t: t, 'clean': lambda t: t, 'undo_yo': lambda src, t: t,
              'force_stress': lambda t: t, 'fix_sam': lambda t: t,
              'apply_dictionary': lambda t, pairs: t, 'homographs': SimpleNamespace(apply_context_overrides=lambda t: t),
              'tera': SimpleNamespace(MAX_LEN=100), 'shtorm': SimpleNamespace(MAX_LEN=170),
              'shtorm_vox': SimpleNamespace(MAX_LEN=180), 'SPEAKER': 'xenia',
              'prepare_tts_text': lambda t: t + '<tts>'}
        for name in ('_max_len', '_normalize_paragraph', 'linguistic_steps', 'prepare_paragraph_ex', 'prepare_paragraph',
                     'split_long', '_say_sentence', 'say_sentence'):
            exec(function_source('speak.py', name), ns)
        synth = []
        ns['_synth'] = lambda text, voice: synth.append(text) or 'audio'
        return ns, log, synth, lock_state

    def test_with_dictionary_text_is_accented_whole_then_cut(self):
        ns, log, _synth, lock = self.namespace()
        out = ns['prepare_paragraph_ex']('Он вошёл, и замок щёлкнул.', pairs=[])
        self.assertEqual(log, [('ruaccent', 'Он вошёл, и замок щёлкнул.')])
        self.assertEqual(len(out), 2)
        self.assertTrue(all(isinstance(f, ap.Prepared) for _k, f in out))
        self.assertFalse(lock['held'])

    def test_without_dictionary_it_is_only_a_cut(self):
        ns, log, _s, _l = self.namespace()
        out = ns['prepare_paragraph_ex']('Он вошёл, и замок щёлкнул.')
        self.assertEqual(log, [])
        self.assertEqual([str(f) for _k, f in out], ['Он вошёл,', 'и замок щёлкнул.'])
        self.assertFalse(any(isinstance(f, ap.Prepared) for _k, f in out))

    def test_prepared_fragment_goes_to_the_engine_without_a_second_accent_pass(self):
        ns, log, synth, _l = self.namespace()
        frag = ap.Prepared('и зам+ок щ+ёлкнул.')
        self.assertEqual(ns['say_sentence'](frag, []), 'audio')
        self.assertEqual(log, [])                                         # RUAccent не вызывался
        self.assertEqual(synth, ['и зам+ок щ+ёлкнул.<tts>'])

    def test_raw_fragment_is_still_accented_the_old_way(self):
        ns, log, synth, _l = self.namespace()
        ns['say_sentence']('и замок щёлкнул.', [])
        self.assertEqual([c[0] for c in log], ['ruaccent'])
        self.assertIn('+', synth[0])

    def test_max_len_follows_the_engine(self):
        for engine, expected in (('silero', 250), ('tera', 100), ('shtorm', 170), ('voxcpm', 180)):
            ns, *_ = self.namespace(engine)
            self.assertEqual(ns['_max_len'](), expected)

    def test_missing_ruaccent_object_does_not_stop_the_book(self):
        ns, log, synth, _l = self.namespace()
        ns['accentizer'] = None
        out = ns['prepare_paragraph_ex']('Он ушёл.', pairs=[])
        self.assertEqual([str(f) for _k, f in out], ['Он ушёл.'])


class AppAndEditorWiringTests(unittest.TestCase):
    def test_build_units_passes_the_dictionary_through(self):
        got = []
        fake_speak = SimpleNamespace(prepare_paragraph=lambda text, pairs=None: got.append(pairs) or [text])
        ns = {'re': re, 'speak': fake_speak}
        exec(function_source('app.py', 'build_units'), ns)
        units = ns['build_units']('Глава', ['Текст.'], pairs=['правило'])
        self.assertEqual(got, [['правило'], ['правило']])
        self.assertEqual(units[-1], ('Текст.', 'par1'))
        got.clear()
        ns['build_units']('Глава', ['Текст.'])
        self.assertEqual(got, [None, None])                                # без словаря: быстрая нарезка для подсчёта

    def test_live_units_are_lazy_and_get_the_dictionary(self):
        try:
            from edit_tab import EditTab
        except Exception as e:
            self.skipTest(f'edit_tab не импортируется здесь: {e!r}')
        calls = []

        class FakeTTS:
            def prepare_paragraph_ex(self, text, pairs=None):
                calls.append((text, pairs))
                return [(0, text)]
        subject = SimpleNamespace(app=SimpleNamespace(tts=FakeTTS()))
        gen = EditTab.iter_live_units(subject, 'Первый абзац.\nВторой абзац.\nТретий.', 0, pairs=['p'])
        self.assertEqual(calls, [])                                       # пока не попросили, ничего не посчитано
        first = next(gen)
        self.assertEqual(first['text'], 'Первый абзац.')
        self.assertEqual(calls, [('Первый абзац.', ['p'])])               # только первый абзац
        self.assertTrue(first['par_end'])
        rest = list(gen)
        self.assertEqual([u['text'] for u in rest], ['Второй абзац.', 'Третий.'])
        self.assertEqual(len(calls), 3)

    def test_live_units_without_dictionary_keep_the_old_call(self):
        try:
            from edit_tab import EditTab
        except Exception as e:
            self.skipTest(f'edit_tab не импортируется здесь: {e!r}')

        class OldTTS:                                                     # как в test_editor_live_emphasis
            def prepare_paragraph_ex(self, text):
                return [(0, text)]
        subject = SimpleNamespace(app=SimpleNamespace(tts=OldTTS()))
        self.assertEqual([u['text'] for u in EditTab.build_live_units(subject, 'Абзац.', 0)], ['Абзац.'])

    def test_editor_sentences_follow_the_pipeline(self):
        try:
            import edit_tab
        except Exception as e:
            self.skipTest(f'edit_tab не импортируется здесь: {e!r}')
        text = 'А. С. Пушкин ушёл. Он вернулся.'
        self.assertEqual(edit_tab.sentence_spans(text), ap.sentence_spans(text))

    def test_portable_copy_and_docs_mention_the_new_module(self):
        import model_manager
        self.assertIn('accent_pipeline.py', model_manager.PORTABLE_CODE)


class RealStepsIntegrationTests(unittest.TestCase):
    """Настоящие clean/undo_yo/force_stress/apply_dictionary из speak.py (взяты из исходника) за подставным RUAccent."""

    def pipeline(self, pairs, yo_from_book=True):
        import homographs
        src = Path(__file__).resolve().parent.parent / 'speak.py'
        text = src.read_text(encoding='utf-8')
        import ast
        tree = ast.parse(text)
        wanted = {'clean', 'undo_yo', 'force_stress', 'apply_dictionary', '_norm_key'}
        consts = {'FORCE_STRESS', 'YO_MONO', 'WORD_RE'}
        ns = {'re': re, 'YO_FROM_BOOK': yo_from_book}
        for node in tree.body:
            if isinstance(node, ast.FunctionDef) and node.name in wanted:
                exec(ast.get_source_segment(text, node), ns)
            elif isinstance(node, ast.Assign) and any(getattr(t, 'id', None) in consts for t in node.targets):
                exec(ast.get_source_segment(text, node), ns)
        steps = ap.Steps(accentize=lambda t: ns['clean'](toy_accent(t)), undo_yo=ns['undo_yo'],
                         force_stress=ns['force_stress'], dictionary=lambda t: ns['apply_dictionary'](t, pairs),
                         overrides=homographs.apply_context_overrides, yo_from_book=yo_from_book, log=lambda *a: None)
        return steps

    def test_phrase_rule_works_across_a_comma_and_monosyllables_stay_clean(self):
        steps = self.pipeline([('*закрыл, замок на двери', 'закр+ыл, зам+ок на двери')])
        out = ap.prepare_text('Он вошёл, закрыл, замок на двери, и сел.', steps, report=ap.Report())
        joined = ' | '.join(str(f) for _k, f in out)
        self.assertIn('закр+ыл,', joined)
        self.assertIn('зам+ок на двери,', joined)
        self.assertNotRegex(joined, r'\b\w*\+\w\b')                        # «+» нет в односложных: он+, и+ ...

    def test_five_gets_its_stress_and_yo_follows_the_book(self):
        steps = self.pipeline([])
        out = ap.prepare_text('Пять небо.', steps, report=ap.Report())
        text = ' '.join(str(f) for _k, f in out)
        self.assertIn('П+ять', text)


class CompareToolTests(unittest.TestCase):
    def test_only_words_with_different_stress_are_reported(self):
        import accent_compare as cmp
        sentences = cmp.read_sentences('Это замок на двери. Мы ушли.\n\nКонец.')
        self.assertEqual(sentences, ['Это замок на двери.', 'Мы ушли.', 'Конец.'])
        a = cmp.accent_all(sentences, lambda s: s.replace('замок', 'зам+ок'))
        b = cmp.accent_all(sentences, lambda s: s.replace('замок', 'з+амок'))
        found = cmp.diff(sentences, a, b)
        self.assertEqual([(w, x, y) for w, x, y, _s in found], [('замок', 'зам+ок', 'з+амок')])
        text = cmp.report('turbo', 'turbo3.1', sentences, a, b)
        self.assertIn('замок: turbo зам+ок | turbo3.1 з+амок', text)
        self.assertIn('разных слов 1', text)

    def test_a_failing_sentence_is_skipped_not_fatal(self):
        import accent_compare as cmp

        def boom(s):
            raise RuntimeError('сбой')
        a = cmp.accent_all(['Он ушёл.'], boom)
        self.assertEqual(a, [None])
        self.assertEqual(cmp.diff(['Он ушёл.'], a, a), [])

    def test_sentence_limit(self):
        import accent_compare as cmp
        self.assertEqual(len(cmp.read_sentences('Раз. Два. Три. Четыре.', limit=2)), 2)


class BuildUnitsLimitTests(unittest.TestCase):
    def test_limit_stops_after_enough_fragments(self):
        calls = []
        fake_speak = SimpleNamespace(prepare_paragraph=lambda text, pairs=None: calls.append(text) or [text])
        ns = {'re': re, 'speak': fake_speak}
        exec(function_source('app.py', 'build_units'), ns)
        paras = [f'Абзац {i}.' for i in range(50)]
        units = ns['build_units']('Глава', paras, pairs=[], limit=3)
        self.assertLessEqual(len(calls), 5)                       # а не все 50 абзацев
        self.assertGreaterEqual(len(units), 3)


if __name__ == '__main__':
    unittest.main()
