import json
import tempfile
import unittest
from pathlib import Path

from homographs import apply_context_overrides


class ContextHomographTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / 'rules.json'
        self.path.write_text(json.dumps([
            {'word': 'замок', 'right': ['на', 'двери'], 'replacement': 'зам+ок'},
            {'word': 'замок', 'right': ['стоял', 'на', 'холме'], 'replacement': 'з+амок'},
            {'word': 'мука', 'left': ['невыносимая'], 'replacement': 'м+ука'},
        ], ensure_ascii=False), encoding='utf-8')

    def tearDown(self):
        self.tmp.cleanup()

    def test_right_context_selects_lock_meaning(self):
        self.assertEqual(apply_context_overrides('Закрыл замок на двери.', path=self.path),
                         'Закрыл зам+ок на двери.')

    def test_other_context_selects_castle_meaning(self):
        self.assertEqual(apply_context_overrides('Старый замок стоял на холме.', path=self.path),
                         'Старый з+амок стоял на холме.')

    def test_no_context_does_not_guess(self):
        self.assertEqual(apply_context_overrides('Он увидел замок.', path=self.path),
                         'Он увидел замок.')

    def test_punctuation_and_capitalization_are_preserved(self):
        self.assertEqual(apply_context_overrides('ЗАМОК на двери!', path=self.path),
                         'ЗАМ+ОК на двери!')
        self.assertEqual(apply_context_overrides('Замок на двери!', path=self.path),
                         'Зам+ок на двери!')


if __name__ == '__main__':
    unittest.main()
