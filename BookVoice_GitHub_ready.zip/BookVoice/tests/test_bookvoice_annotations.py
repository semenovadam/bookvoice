import re
import tempfile
import unittest
from pathlib import Path

import bookio


class BookVoiceAnnotationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / 'test.fb2'
        self.book = bookio.Book(
            title='Тест', author='Автор',
            chapters=[('Глава 1', ['Привет, мир!', 'Что ты делаешь?'])],
            annotations=[{'chapter': 0, 'paragraph': 1, 'start': 4, 'end': 6,
                          'level': 2, 'quote': 'ты', 'context': 'Что ты делаешь?'}])

    def tearDown(self):
        self.tmp.cleanup()

    def test_roundtrip_and_tts_markers(self):
        bookio.write_fb2(self.book, self.path)
        loaded = bookio.read_fb2(self.path)
        self.assertEqual(loaded.chapters, self.book.chapters)
        self.assertEqual(loaded.annotations[0]['quote'], 'ты')
        self.assertEqual(bookio.annotations_as_markers(loaded)[0][1][1], 'Что **ты** делаешь?')
        self.assertNotIn('**ты**', self.path.read_text(encoding='utf-8'))

    def test_comment_backup_recovery_and_atomic_backup(self):
        bookio.write_fb2(self.book, self.path)
        bookio.write_fb2(self.book, self.path)
        self.assertTrue(self.path.with_suffix('.fb2.bak').exists())
        content = self.path.read_text(encoding='utf-8')
        content = re.sub(r'<custom-info info-type="urn:bookvoice:annotations:v1">.*?</custom-info>', '', content)
        self.path.write_text(content, encoding='utf-8')
        self.assertEqual(bookio.read_fb2(self.path).annotations[0]['quote'], 'ты')


    def test_reanchor_after_text_shift(self):
        bookio.write_fb2(self.book, self.path)
        content = self.path.read_text(encoding='utf-8')
        content = content.replace('Что ты делаешь?', 'Эй, что ты делаешь?')
        self.path.write_text(content, encoding='utf-8')
        loaded = bookio.read_fb2(self.path)
        self.assertEqual(loaded.annotations[0]['quote'], 'ты')
        self.assertEqual(loaded.annotations[0]['start'], len('Эй, что '))

    def test_legacy_markers_and_scene_break(self):
        self.path.write_text('''<?xml version="1.0"?><FictionBook xmlns="http://www.gribuser.ru/xml/fictionbook/2.0"><description><title-info><book-title>Old</book-title><lang>ru</lang></title-info><document-info><author><nickname>x</nickname></author><date value="2020">2020</date><id>x</id><version>1.0</version></document-info></description><body><section><title><p>G</p></title><p>Это **важно** и *легко*. * * *</p></section></body></FictionBook>''', encoding='utf-8')
        loaded = bookio.read_fb2(self.path)
        self.assertEqual(loaded.chapters[0][1][0], 'Это важно и легко. * * *')
        self.assertEqual([a['level'] for a in loaded.annotations], [2, 1])


if __name__ == '__main__':
    unittest.main()
