"""Сборка одной книги из нескольких файлов, добавление файлов в редактор и меню правой кнопки (вырезать,
копировать, вставить). Окон здесь нет: логика проверяется на простых макетах виджетов."""
import os
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

import bookio
import textmenu


# ---------------------------------------------------------------- несколько файлов -> одна книга
class MergeFilesTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.dir = Path(self.tmp.name) / 'Моя книга'
        self.dir.mkdir()

    def put(self, name, text, folder=None):
        p = (folder or self.dir) / name
        p.write_text(text, encoding='utf-8')
        return p

    def test_files_are_ordered_by_number_not_by_letters(self):
        for n in (10, 2, 1):
            self.put(f'гл{n}.md', f'# Глава {n}\n\nТекст {n}.\n')
        names = [p.name for p in bookio.expand_paths([self.dir])]
        self.assertEqual(names, ['гл1.md', 'гл2.md', 'гл10.md'])

    def test_every_file_becomes_a_chapter_with_its_heading(self):
        self.put('01.md', '# Начало пути\n\nПервый абзац.\n\nВторой абзац.\n')
        self.put('02.md', '# Дорога\n\nТекст.\n')
        m = bookio.merge_files([self.dir])
        self.assertEqual([t for t, _ in m.book.chapters], ['Начало пути', 'Дорога'])
        self.assertEqual(len(m.book.chapters[0][1]), 2)
        self.assertEqual(m.used, ['01.md', '02.md'])
        self.assertEqual(m.skipped, [])

    def test_file_without_heading_is_named_after_the_file(self):
        self.put('пролог.md', 'Просто текст без заголовка.\n')
        self.put('b.txt', 'Ещё текст без заголовка.\n')
        m = bookio.merge_files([self.dir])
        self.assertEqual([t for t, _ in m.book.chapters], ['b', 'пролог'])

    def test_file_with_sections_gives_several_chapters(self):
        self.put('книга.md', '# Книга\n\n## Часть один\n\nТекст один.\n\n## Часть два\n\nТекст два.\n')
        self.put('конец.md', '# Конец\n\nФинал.\n')
        m = bookio.merge_files([self.dir])
        self.assertEqual([t for t, _ in m.book.chapters], ['Часть один', 'Часть два', 'Конец'])

    def test_broken_and_empty_files_are_skipped_but_reported(self):
        self.put('a.md', '# Первая\n\nТекст.\n')
        self.put('пустой.md', '\n\n')
        bad = self.put('b.bin', 'zz')
        m = bookio.merge_files([self.dir / 'a.md', self.dir / 'пустой.md', bad])
        self.assertEqual(m.used, ['a.md'])
        self.assertEqual(dict(m.skipped)['пустой.md'], 'в файле нет текста')
        self.assertIn('b.bin', dict(m.skipped))
        self.assertEqual(len(m.book.chapters), 1)

    def test_folder_name_becomes_the_title_of_a_multi_file_book(self):
        self.put('1.md', '# Раз\n\nТекст.\n')
        self.put('2.md', '# Два\n\nТекст.\n')
        self.assertEqual(bookio.merge_files([self.dir]).book.title, 'Моя книга')

    def test_single_file_keeps_its_own_title_and_author(self):
        self.put('x.md', '# Название книги\n*Иван Петров*\n\n## Глава\n\nТекст.\n')
        m = bookio.merge_files([self.dir / 'x.md'])
        self.assertEqual((m.book.title, m.book.author), ('Название книги', 'Иван Петров'))

    def test_only_book_files_are_taken_from_a_folder(self):
        self.put('a.md', 'Текст.\n')
        self.put('заметки.pdf', 'не книга')
        self.put('~$временный.docx', 'мусор')
        sub = self.dir / 'вложенная'
        sub.mkdir()
        self.put('глубоко.md', 'Текст.\n', folder=sub)
        self.assertEqual([p.name for p in bookio.expand_paths([self.dir])], ['a.md'])

    def test_same_file_twice_is_taken_once(self):
        p = self.put('a.md', 'Текст.\n')
        self.assertEqual(len(bookio.expand_paths([p, str(p), '{%s}' % p])), 1)

    def test_accents_travel_with_their_chapters(self):
        def book_with_accent(name, title):
            b = bookio.Book(title=name, chapters=[('Пустая', []), (title, ['Слово здесь.'])])
            b.annotations = [{'chapter': 1, 'paragraph': 0, 'start': 0, 'end': 5, 'level': 1,
                              'quote': 'Слово', 'context': 'Слово здесь.'}]
            path = self.dir / f'{name}.fb2'
            bookio.write_fb2(b, path)
            return path
        first, second = book_with_accent('a', 'Раз'), book_with_accent('b', 'Два')
        m = bookio.merge_files([first, second])
        self.assertEqual([t for t, _ in m.book.chapters], ['Раз', 'Два'])
        self.assertEqual(sorted(a['chapter'] for a in m.book.annotations), [0, 1])


# ---------------------------------------------------------------- редактор: открытие и добавление файлов
try:
    import edit_tab
except Exception as e:                                       # нет tkinter
    edit_tab = None
    _EDIT_ERR = repr(e)


class Var:
    def __init__(self, v=''):
        self.v = v

    def get(self):
        return self.v

    def set(self, v):
        self.v = v


@unittest.skipIf(edit_tab is None, 'edit_tab не импортируется здесь (нет tkinter)')
class EditorFilesTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.dir = Path(self.tmp.name) / 'Серия'
        self.dir.mkdir()
        for n, t in ((1, 'Раз'), (2, 'Два'), (10, 'Десять')):
            (self.dir / f'{n}.md').write_text(f'# {t}\n\nТекст {t}.\n', encoding='utf-8')
        self.calls = []
        for name in ('showinfo', 'showwarning', 'showerror'):
            p = mock.patch.object(edit_tab.messagebox, name, side_effect=lambda *a, n=name, **k: self.calls.append(n))
            p.start()
            self.addCleanup(p.stop)

    def fake(self, items=None, dirty=False):
        tab = SimpleNamespace(items=list(items or []), snapshot=0, accent_dirty=False, cover=None, next_id=1,
                              title_var=Var(''), author_var=Var(''), status=Var(''), save_path='старый.fb2',
                              loaded=[], shown=[], opened=[])
        tab.new_item = lambda t, p: {'id': len(tab.items) + 100 + len(tab.shown), 'title': t, 'paras': list(p),
                                     'w': None, 'annotations': []}
        tab.refresh_tree = lambda select=None: None
        tab.select_item = lambda it: tab.shown.append(it['title'])
        tab.set_cover = lambda data: setattr(tab, 'cover', data)
        tab.live_stop_all = lambda: None
        tab.is_dirty = lambda: dirty
        tab.load_book = lambda b: (tab.loaded.append(b), setattr(tab, 'items', [tab.new_item(t, p) for t, p in b.chapters]))
        tab.load_path = lambda p: tab.opened.append(Path(p).name)
        tab.report_skipped = lambda s: edit_tab.EditTab.report_skipped(tab, s)
        tab.append_paths = lambda p: edit_tab.EditTab.append_paths(tab, p)
        tab.load_paths = lambda p: edit_tab.EditTab.load_paths(tab, p)
        return tab

    def test_several_files_make_one_new_book_that_is_not_saved_yet(self):
        tab = self.fake()
        edit_tab.EditTab.load_paths(tab, [self.dir / '10.md', self.dir / '2.md', self.dir / '1.md'])
        self.assertEqual([t for t, _ in tab.loaded[0].chapters], ['Раз', 'Два', 'Десять'])
        self.assertIsNone(tab.snapshot)                 # «есть несохранённые правки»
        self.assertIsNone(tab.save_path)                # «Сохранить» спросит имя файла
        self.assertEqual(tab.src_name, 'Серия')
        self.assertIn('Собрана книга', tab.status.get())

    def test_single_file_is_opened_as_an_ordinary_book(self):
        tab = self.fake()
        edit_tab.EditTab.load_paths(tab, [self.dir / '1.md'])
        self.assertEqual(tab.opened, ['1.md'])
        self.assertEqual(tab.loaded, [])

    def test_replacing_a_book_with_unsaved_changes_asks_first(self):
        tab = self.fake(items=[{'id': 1}], dirty=True)
        with mock.patch.object(edit_tab.messagebox, 'askyesno', return_value=False) as ask:
            edit_tab.EditTab.load_paths(tab, [self.dir])
        ask.assert_called_once()
        self.assertEqual(tab.loaded, [])

    def test_nothing_to_open_is_explained(self):
        tab = self.fake()
        edit_tab.EditTab.load_paths(tab, [])
        self.assertIn('showinfo', self.calls)

    def test_added_files_go_to_the_end_and_fill_empty_metadata(self):
        existing = {'id': 1, 'title': 'Старая', 'paras': ['x'], 'w': None, 'annotations': []}
        tab = self.fake(items=[existing])
        edit_tab.EditTab.append_paths(tab, [self.dir])
        self.assertEqual([it['title'] for it in tab.items], ['Старая', 'Раз', 'Два', 'Десять'])
        self.assertEqual(tab.shown, ['Раз'])
        self.assertEqual(tab.title_var.get(), 'Серия')
        self.assertIn('Добавлено файлов: 3', tab.status.get())

    def test_added_files_do_not_overwrite_the_title_already_set(self):
        tab = self.fake(items=[{'id': 1, 'title': 'Старая', 'paras': ['x'], 'w': None, 'annotations': []}])
        tab.title_var.set('Моё название')
        edit_tab.EditTab.append_paths(tab, [self.dir / '1.md'])
        self.assertEqual(tab.title_var.get(), 'Моё название')

    def test_dropping_on_an_empty_editor_builds_a_book_and_on_a_full_one_appends(self):
        tab = self.fake()
        tab.add_or_open = lambda p: edit_tab.EditTab.add_or_open(tab, p)
        edit_tab.EditTab.add_or_open(tab, [self.dir])
        self.assertEqual(len(tab.loaded), 1)
        edit_tab.EditTab.add_or_open(tab, [self.dir / '1.md'])
        self.assertEqual(len(tab.loaded), 1)                         # книга уже есть: просто добавилось
        self.assertEqual(tab.items[-1]['title'], 'Раз')

    def test_skipped_files_are_listed_for_the_user(self):
        (self.dir / 'сломан.bin').write_text('zz', encoding='utf-8')
        tab = self.fake()
        edit_tab.EditTab.load_paths(tab, [self.dir / '1.md', self.dir / '2.md', self.dir / 'сломан.bin'])
        self.assertIn('showwarning', self.calls)

    def test_drop_event_with_spaces_in_paths(self):
        got = []
        tab = SimpleNamespace(tk=SimpleNamespace(splitlist=lambda s: ['C:/Моя папка/1.md', 'C:/2.md']),
                              after=lambda ms, fn: fn(), add_or_open=lambda p: got.append(list(p)))
        result = edit_tab.EditTab.on_drop(tab, SimpleNamespace(data='{C:/Моя папка/1.md} C:/2.md', action='copy'))
        self.assertEqual(got, [['C:/Моя папка/1.md', 'C:/2.md']])
        self.assertEqual(result, 'copy')

    def test_drag_and_drop_stays_off_without_the_package(self):
        tab = SimpleNamespace(dnd_ok=True, winfo_toplevel=lambda: SimpleNamespace())
        with mock.patch.dict('sys.modules', {'tkinterdnd2': None}):
            self.assertFalse(edit_tab.EditTab.setup_dnd(tab))
        self.assertFalse(tab.dnd_ok)


# ---------------------------------------------------------------- меню правой кнопки
class FakeField:
    """Макет Text (kind='text') или Entry (kind='entry'): текст, выделение, курсор, общий буфер обмена."""
    CLIP = ['']

    def __init__(self, kind, text='', state='normal', cls=None):
        self.kind, self.s, self.state = kind, text, state
        self.cls = cls or ('Text' if kind == 'text' else 'TEntry')
        self.sel, self.ins = None, len(text)
        self.log = []

    def _i(self, i):
        if isinstance(i, int):
            return i
        i = str(i)
        if i in ('end', 'end-1c'):
            return len(self.s)
        if i == 'insert':
            return self.ins
        if i == '1.0':
            return 0
        if i == 'sel.first':
            if self.sel is None:
                raise textmenu.tk.TclError('нет выделения')
            return self.sel[0]
        if i == 'sel.last':
            if self.sel is None:
                raise textmenu.tk.TclError('нет выделения')
            return self.sel[1]
        if i.startswith('@'):
            return min(int(i[1:].split(',')[0]), len(self.s))
        return int(i)

    def winfo_class(self):
        return self.cls

    def cget(self, name):
        return self.state

    def index(self, i):
        return self._i(i)

    def get(self, a=None, b=None):
        return self.s if a is None else self.s[self._i(a):self._i(b)]

    def delete(self, a, b=None):
        a, b = self._i(a), self._i(b)
        self.s = self.s[:a] + self.s[b:]
        self.ins = a
        self.sel = None

    def insert(self, i, data):
        i = self._i(i)
        self.s = self.s[:i] + data + self.s[i:]
        self.ins = i + len(data)

    def tag_add(self, tag, a, b):
        self.sel = (self._i(a), self._i(b))

    def tag_remove(self, tag, a, b):
        self.sel = None

    def selection_clear(self):
        self.sel = None

    def select_range(self, a, b):
        self.sel = (self._i(a), self._i(b))

    def icursor(self, i):
        self.ins = self._i(i)

    def mark_set(self, name, i):
        self.ins = self._i(i)

    def compare(self, a, op, b):
        return {'<=': a <= b, '<': a < b}[op]

    def see(self, i):
        pass

    def focus_set(self):
        self.log.append('focus')

    def edit_separator(self):
        self.log.append('sep')

    def event_generate(self, name):
        self.log.append(name)

    def clipboard_clear(self):
        FakeField.CLIP[0] = ''

    def clipboard_append(self, s):
        FakeField.CLIP[0] += s

    def clipboard_get(self):
        if not FakeField.CLIP[0]:
            raise textmenu.tk.TclError('буфер пуст')
        return FakeField.CLIP[0]


class TextMenuTests(unittest.TestCase):
    def setUp(self):
        FakeField.CLIP[0] = ''

    def field(self, kind='text', text='Привет, мир', sel=None, ins=None, **kw):
        f = FakeField(kind, text, **kw)
        f.sel = sel
        if ins is not None:
            f.ins = ins
        return f

    def test_copy_puts_the_selection_in_the_clipboard(self):
        for kind in ('text', 'entry'):
            f = self.field(kind, sel=(0, 6))
            self.assertTrue(textmenu.do_copy(f))
            self.assertEqual(FakeField.CLIP[0], 'Привет')
            self.assertEqual(f.s, 'Привет, мир')

    def test_copy_without_selection_does_nothing(self):
        f = self.field()
        self.assertFalse(textmenu.do_copy(f))
        self.assertFalse(textmenu.can_copy(f))

    def test_cut_removes_the_selection_and_keeps_it_in_the_clipboard(self):
        for kind in ('text', 'entry'):
            f = self.field(kind, sel=(8, 11))
            self.assertTrue(textmenu.do_cut(f))
            self.assertEqual((f.s, FakeField.CLIP[0]), ('Привет, ', 'мир'))

    def test_paste_goes_where_the_cursor_is(self):
        # выделил -> копировать; указал курсор -> вставить
        src = self.field(sel=(0, 6))
        textmenu.do_copy(src)
        for kind in ('text', 'entry'):
            dst = self.field(kind, text='Начало конец', ins=7)
            self.assertTrue(textmenu.do_paste(dst))
            self.assertEqual(dst.s, 'Начало Привет' + 'конец')

    def test_paste_replaces_the_selection(self):
        FakeField.CLIP[0] = 'XYZ'
        f = self.field(sel=(0, 6))
        textmenu.do_paste(f)
        self.assertEqual(f.s, 'XYZ, мир')

    def test_paste_makes_one_undo_step_and_tells_the_window(self):
        FakeField.CLIP[0] = 'XYZ'
        f = self.field()
        textmenu.do_paste(f)
        self.assertEqual(f.log.count('sep'), 2)
        self.assertIn('<KeyRelease>', f.log)                 # счётчик знаков главы обновится

    def test_paste_into_entry_flattens_line_breaks(self):
        FakeField.CLIP[0] = 'раз\r\nдва\nтри'
        f = self.field('entry', text='', ins=0)
        textmenu.do_paste(f)
        self.assertEqual(f.s, 'раз два три')

    def test_read_only_fields_can_copy_but_not_change(self):
        FakeField.CLIP[0] = 'XYZ'
        f = self.field(sel=(0, 6), state='disabled')         # окно журнала
        self.assertTrue(textmenu.can_copy(f))
        self.assertFalse(textmenu.can_cut(f))
        self.assertFalse(textmenu.can_paste(f))
        self.assertFalse(textmenu.do_paste(f))
        self.assertFalse(textmenu.do_cut(f))
        self.assertEqual(f.s, 'Привет, мир')

    def test_empty_clipboard_means_paste_is_disabled(self):
        self.assertFalse(textmenu.can_paste(self.field()))

    def test_select_all(self):
        t, e = self.field('text'), self.field('entry')
        textmenu.do_select_all(t)
        textmenu.do_select_all(e)
        self.assertEqual((t.sel, e.sel), ((0, 11), (0, 11)))

    def test_right_click_outside_the_selection_moves_the_cursor_there(self):
        for kind in ('text', 'entry'):
            f = self.field(kind, sel=(0, 3))
            textmenu.place_cursor(f, SimpleNamespace(x=8, y=0))
            self.assertIsNone(f.sel)
            self.assertEqual(f.ins, 8)

    def test_right_click_inside_the_selection_keeps_it(self):
        for kind in ('text', 'entry'):
            f = self.field(kind, sel=(0, 6), ins=11)
            textmenu.place_cursor(f, SimpleNamespace(x=2, y=0))
            self.assertEqual(f.sel, (0, 6))

    def menu_for(self, field, **event):
        calls = []

        class FakeMenu:
            def __init__(self, *a, **k):
                pass

            def add_command(self, **k):
                calls.append((k['label'], k['state']))

            def add_separator(self):
                calls.append('-')

            def tk_popup(self, *a):
                calls.append('popup')

            def grab_release(self):
                pass
        ev = SimpleNamespace(widget=field, x=event.get('x', 0), y=0, x_root=0, y_root=0)
        colors = dict(PANEL='#000', FG='#fff', ACCENT='#aaa', MUTED='#888')
        with mock.patch.object(textmenu.tk, 'Menu', FakeMenu):
            return textmenu.show_menu(ev, colors), calls

    def test_menu_has_the_four_standard_items(self):
        FakeField.CLIP[0] = 'буфер'
        result, calls = self.menu_for(self.field('entry', sel=(0, 3)), x=1)
        self.assertEqual(result, 'break')
        self.assertEqual([c for c in calls if c != 'popup'],
                         [('Вырезать', 'normal'), ('Копировать', 'normal'), ('Вставить', 'normal'),
                          '-', ('Выделить всё', 'normal')])
        self.assertIn('popup', calls)

    def test_menu_disables_what_cannot_be_done(self):
        _r, calls = self.menu_for(self.field('text'), x=1)       # ничего не выделено, буфер пуст
        states = dict(c for c in calls if isinstance(c, tuple))
        self.assertEqual((states['Вырезать'], states['Копировать'], states['Вставить']),
                         ('disabled', 'disabled', 'disabled'))
        self.assertEqual(states['Выделить всё'], 'normal')

    def test_no_menu_for_disabled_entries_and_choice_lists(self):
        self.assertIsNone(self.menu_for(self.field('entry', state='disabled'))[0])
        self.assertIsNone(self.menu_for(self.field('entry', state='readonly', cls='TCombobox'))[0])
        self.assertIsNone(self.menu_for(SimpleNamespace(winfo_class=lambda: 'TButton'))[0])

    def test_editor_word_menu_gets_the_same_items_plus_a_separator(self):
        calls = []
        menu = SimpleNamespace(add_command=lambda **k: calls.append(k['label']),
                               add_separator=lambda: calls.append('-'))
        textmenu.add_edit_items(menu, self.field())
        self.assertEqual(calls, ['Вырезать', 'Копировать', 'Вставить', '-', 'Выделить всё', '-'])

    def ctrl(self, keycode, keysym, field):
        return textmenu.on_ctrl_key(SimpleNamespace(keycode=keycode, keysym=keysym, widget=field))

    def test_ctrl_c_and_v_work_on_the_russian_layout(self):
        with mock.patch.object(textmenu.os, 'name', 'nt'):
            src = self.field('entry', sel=(0, 6))
            self.assertEqual(self.ctrl(67, 'Cyrillic_es', src), 'break')
            self.assertEqual(FakeField.CLIP[0], 'Привет')
            dst = self.field('entry', text='', ins=0)
            self.assertEqual(self.ctrl(86, 'Cyrillic_em', dst), 'break')
            self.assertEqual(dst.s, 'Привет')
            self.assertEqual(self.ctrl(65, 'Cyrillic_ef', dst), 'break')
            self.assertEqual(dst.sel, (0, 6))

    def test_latin_layout_is_left_to_tk(self):
        with mock.patch.object(textmenu.os, 'name', 'nt'):
            self.assertIsNone(self.ctrl(67, 'c', self.field('entry', sel=(0, 3))))
            self.assertEqual(FakeField.CLIP[0], '')

    def test_other_keys_and_other_systems_are_ignored(self):
        with mock.patch.object(textmenu.os, 'name', 'nt'):
            self.assertIsNone(self.ctrl(83, 'Cyrillic_yeru', self.field('entry')))
        with mock.patch.object(textmenu.os, 'name', 'posix'):
            self.assertIsNone(self.ctrl(67, 'Cyrillic_es', self.field('entry', sel=(0, 3))))

    def test_install_binds_every_text_class(self):
        bound = []
        root = SimpleNamespace(bind_class=lambda cls, seq, fn, add=None: bound.append((cls, seq, add)))
        textmenu.install(root, {})
        for cls in ('Text', 'TEntry', 'Entry'):
            self.assertIn((cls, '<Button-3>', '+'), bound)       # «+»: собственные привязки полей не затираются
            self.assertIn((cls, '<Control-KeyPress>', '+'), bound)


if __name__ == '__main__':
    unittest.main()
