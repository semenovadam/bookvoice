"""Shtorm-VoxCPM2-RU без настоящей модели: подготовка текста и обмен клиента shtorm_vox.py с воркером
shtorm_vox_worker.py в отдельном процессе с поддельным пакетом voxcpm (проверяются протокол, параметры,
которые доходят до модели, повторная загрузка образца без перезагрузки модели и перезапуск после падения).

Настоящая модель, видеокарта и звук здесь не проверяются."""
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import model_dirs
import shtorm_vox

# Поддельный voxcpm. Сигнатуры намеренно «старые и узкие» (нет **kwargs, нет denoise и device): воркер
# должен передать только то, что функция принимает. Каждое обращение к модели пишется в журнал.
FAKE_VOXCPM = '''
import json
import os

import numpy as np


class _TTS:
    sample_rate = 48000


def _log(record):
    path = os.environ.get('FAKE_VOX_LOG')
    if path:
        with open(path, 'a', encoding='utf-8') as f:
            f.write(json.dumps(record, ensure_ascii=False) + '\\n')


class VoxCPM:
    def __init__(self):
        self.tts_model = _TTS()

    @classmethod
    def from_pretrained(cls, hf_model_id, load_denoiser=True, optimize=True):
        _log({'event': 'load', 'path': str(hf_model_id), 'load_denoiser': load_denoiser, 'optimize': optimize})
        if 'crash' in str(hf_model_id):
            raise RuntimeError('boom')
        return cls()

    def generate(self, text, prompt_wav_path=None, prompt_text=None, reference_wav_path=None,
                 cfg_value=2.0, inference_timesteps=10, normalize=True):
        if text == 'КРАХ':
            os._exit(3)
        _log({'event': 'generate', 'text': text, 'prompt_wav_path': prompt_wav_path, 'prompt_text': prompt_text,
              'reference_wav_path': reference_wav_path, 'cfg_value': cfg_value,
              'inference_timesteps': inference_timesteps, 'normalize': normalize})
        return (np.sin(np.linspace(0, 50, 1200 + 10 * len(text))) * 0.5).astype(np.float32)
'''


class PrepareTextTests(unittest.TestCase):
    def test_stress_marks_are_kept_on_ordinary_words(self):
        self.assertEqual(shtorm_vox.prepare_text('Мы купили м+олоко, а на двери висел зам+ок.'),
                         'Мы купили м+олоко, а на двери висел зам+ок.')

    def test_capital_letter_keeps_its_mark(self):
        self.assertEqual(shtorm_vox.prepare_text('+Утро в с+основом б+оре.'), '+Утро в с+основом б+оре.')

    def test_marks_on_one_syllable_words_are_removed(self):
        # автор модели: метка на односложном слове читается как выделение и растягивает речь
        self.assertEqual(shtorm_vox.prepare_text('Это к+ак мн+е в+ы н+е зн+аете'), 'Это как мне вы не зн+аете')
        self.assertEqual(shtorm_vox.prepare_text('Дом, где ж+ил к+то-то'), 'Дом, где жил кто-то')

    def test_hyphenated_word_is_judged_by_each_part(self):
        self.assertEqual(shtorm_vox.prepare_text('по-пр+ежнему'), 'по-пр+ежнему')
        self.assertEqual(shtorm_vox.prepare_text('к+ое-к+ак'), 'к+ое-как')

    def test_yo_never_gets_a_mark(self):
        self.assertEqual(shtorm_vox.prepare_text('вс+ё, +ёлка, тепл+ёхонько'), 'всё, ёлка, теплёхонько')

    def test_silero_emphasis_markers_are_removed(self):
        self.assertEqual(shtorm_vox.prepare_text('*слово* и **фраза** зам+ок'), 'слово и фраза зам+ок')

    def test_stray_plus_is_removed(self):
        self.assertEqual(shtorm_vox.prepare_text('2 + 2 и +!'), '2  2 и !')

    def test_text_without_marks_is_untouched(self):
        text = 'Обычный текст: «цитата» — и всё; Hello, world!'
        self.assertEqual(shtorm_vox.prepare_text(text), text)

    def test_prompt_text_is_cleaned_for_the_model(self):
        self.assertEqual(shtorm_vox.prompt_for_model('  Точный  текст\n  образ+ца *без* меток '),
                         'Точный текст образца без меток')
        self.assertEqual(shtorm_vox.prompt_for_model(None), '')


class ShtormVoxProtocolTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        root = Path(self.tmp.name)
        self.model = root / 'model'
        self.model.mkdir()
        for name in shtorm_vox.REQUIRED_FILES:
            (self.model / name).write_bytes(b'x')
        self.fake = root / 'fake'
        (self.fake / 'voxcpm').mkdir(parents=True)
        (self.fake / 'voxcpm' / '__init__.py').write_text(FAKE_VOXCPM, encoding='utf-8')
        self.wav = root / 'voice.wav'
        self.wav.write_bytes(b'RIFF')
        self.wav2 = root / 'voice2.wav'
        self.wav2.write_bytes(b'RIFF')
        self.log = root / 'calls.jsonl'
        self.log.write_text('', encoding='utf-8')
        self.saved = (model_dirs.VOXCPM_DIR, shtorm_vox.PYTHON, shtorm_vox.CFG_VALUE, shtorm_vox.TIMESTEPS,
                      shtorm_vox.SAMPLE_RATE)
        model_dirs.VOXCPM_DIR = str(self.model)
        shtorm_vox.PYTHON = Path(sys.executable)           # вместо venv_voxcpm\Scripts\python.exe
        self.env = mock.patch.dict(os.environ, {'PYTHONPATH': str(self.fake), 'FAKE_VOX_LOG': str(self.log)})
        self.env.start()
        shtorm_vox.shutdown()

    def tearDown(self):
        shtorm_vox.shutdown()
        (model_dirs.VOXCPM_DIR, shtorm_vox.PYTHON, shtorm_vox.CFG_VALUE, shtorm_vox.TIMESTEPS,
         shtorm_vox.SAMPLE_RATE) = self.saved
        self.env.stop()
        self.tmp.cleanup()

    def calls(self, event=None):
        rows = [json.loads(line) for line in self.log.read_text(encoding='utf-8').splitlines() if line.strip()]
        return [r for r in rows if event is None or r['event'] == event]

    def test_load_and_synthesize(self):
        shtorm_vox.load(str(self.wav))
        self.assertTrue(shtorm_vox.is_loaded(str(self.wav)))
        self.assertEqual(shtorm_vox.SAMPLE_RATE, 48000)
        audio = shtorm_vox.synthesize('Привет, мир.')
        self.assertEqual(audio.dtype.name, 'float32')
        self.assertEqual(audio.ndim, 1)
        self.assertGreater(audio.size, 1000)
        self.assertLessEqual(float(abs(audio).max()), 1.0)

    def test_model_gets_the_safe_loading_options_the_author_requires(self):
        shtorm_vox.load(str(self.wav))
        shtorm_vox.synthesize('Зам+ок на двери.')
        load = self.calls('load')[0]
        self.assertEqual(load['path'], str(self.model))
        self.assertFalse(load['load_denoiser'])
        self.assertFalse(load['optimize'])                   # torch.compile на Windows без triton не нужен
        gen = self.calls('generate')[0]
        self.assertFalse(gen['normalize'])                   # встроенный нормализатор портит метки ударений
        self.assertEqual(gen['text'], 'Зам+ок на двери.')    # метка «+» уходит в модель как есть

    def test_without_prompt_text_only_the_timbre_is_used(self):
        shtorm_vox.load(str(self.wav))
        shtorm_vox.synthesize('Привет.')
        gen = self.calls('generate')[0]
        self.assertEqual(gen['reference_wav_path'], str(self.wav.resolve()))
        self.assertIsNone(gen['prompt_wav_path'])
        self.assertIsNone(gen['prompt_text'])

    def test_prompt_text_switches_on_hifi_cloning_without_marks(self):
        shtorm_vox.load(str(self.wav), 'Точный текст образ+ца.')
        shtorm_vox.synthesize('Привет.')
        gen = self.calls('generate')[0]
        self.assertEqual(gen['prompt_wav_path'], str(self.wav.resolve()))
        self.assertEqual(gen['reference_wav_path'], str(self.wav.resolve()))
        self.assertEqual(gen['prompt_text'], 'Точный текст образца.')

    def test_cfg_and_steps_reach_the_model_without_reloading(self):
        shtorm_vox.load(str(self.wav))
        shtorm_vox.CFG_VALUE, shtorm_vox.TIMESTEPS = 2.5, 15
        shtorm_vox.synthesize('Привет.')
        gen = self.calls('generate')[0]
        self.assertEqual((gen['cfg_value'], gen['inference_timesteps']), (2.5, 15))
        self.assertEqual(len(self.calls('load')), 1)

    def test_changing_sample_or_its_text_does_not_reload_the_model(self):
        shtorm_vox.load(str(self.wav), 'Первый текст.')
        shtorm_vox.load(str(self.wav), 'Первый текст.')              # то же самое: ничего не делает
        self.assertEqual(len(self.calls('load')), 1)
        shtorm_vox.load(str(self.wav2), 'Другой текст.')
        shtorm_vox.synthesize('Привет.')
        self.assertEqual(len(self.calls('load')), 1)                  # 4,6 ГБ второй раз не грузятся
        gen = self.calls('generate')[0]
        self.assertEqual(gen['reference_wav_path'], str(self.wav2.resolve()))
        self.assertEqual(gen['prompt_text'], 'Другой текст.')
        self.assertTrue(shtorm_vox.is_loaded(str(self.wav2), 'Другой текст.'))
        self.assertFalse(shtorm_vox.is_loaded(str(self.wav)))
        self.assertFalse(shtorm_vox.is_loaded(str(self.wav2), 'Не тот текст.'))

    def test_russian_text_with_capital_letters_arrives_intact(self):
        shtorm_vox.load(str(self.wav))
        text = 'Иван прочёл «Ёжика» — и ушёл.'
        shtorm_vox.synthesize(text)
        self.assertEqual(self.calls('generate')[0]['text'], text)

    def test_empty_text_returns_nothing_without_calling_the_model(self):
        self.assertEqual(shtorm_vox.synthesize('  ').size, 0)
        self.assertEqual(self.calls(), [])

    def test_synthesize_before_load_is_a_clear_error(self):
        with self.assertRaisesRegex(RuntimeError, 'не загружен'):
            shtorm_vox.synthesize('Привет.')

    def test_missing_model_file_is_named_in_the_error(self):
        (self.model / 'model.safetensors').unlink()
        self.assertFalse(shtorm_vox.installed())
        with self.assertRaisesRegex(RuntimeError, 'model.safetensors'):
            shtorm_vox.load(str(self.wav))

    def test_bad_sample_is_rejected_before_starting_the_process(self):
        with self.assertRaisesRegex(RuntimeError, 'выбери WAV'):
            shtorm_vox.load(None)
        with self.assertRaisesRegex(RuntimeError, 'не найден'):
            shtorm_vox.load(str(self.wav.with_name('нет.wav')))
        mp3 = self.wav.with_suffix('.mp3')
        mp3.write_bytes(b'x')
        with self.assertRaisesRegex(RuntimeError, 'WAV'):
            shtorm_vox.load(str(mp3))
        self.assertEqual(self.calls(), [])

    def test_worker_error_comes_back_as_runtime_error_and_engine_recovers(self):
        crash_dir = Path(self.tmp.name) / 'crash_model'      # поддельная модель падает при загрузке, если в пути «crash»
        crash_dir.mkdir()
        for name in shtorm_vox.REQUIRED_FILES:
            (crash_dir / name).write_bytes(b'x')
        model_dirs.VOXCPM_DIR = str(crash_dir)
        with self.assertRaises(RuntimeError) as ctx:
            shtorm_vox.load(str(self.wav))
        self.assertIn('boom', str(ctx.exception))
        self.assertFalse(shtorm_vox.is_loaded())
        model_dirs.VOXCPM_DIR = str(self.model)
        shtorm_vox.load(str(self.wav))
        self.assertTrue(shtorm_vox.is_loaded())

    def test_dead_worker_is_restarted_on_next_load(self):
        shtorm_vox.load(str(self.wav))
        with self.assertRaises(RuntimeError):
            shtorm_vox.synthesize('КРАХ')                    # процесс умирает посреди работы
        self.assertFalse(shtorm_vox.is_loaded())
        shtorm_vox.load(str(self.wav))                       # переключение движка запускает его заново
        self.assertGreater(shtorm_vox.synthesize('Снова работает.').size, 0)
        self.assertEqual(len(self.calls('load')), 2)

    def test_shutdown_frees_the_process_and_allows_a_fresh_load(self):
        shtorm_vox.load(str(self.wav))
        shtorm_vox.shutdown()
        self.assertFalse(shtorm_vox.is_loaded())
        shtorm_vox.load(str(self.wav))
        self.assertTrue(shtorm_vox.is_loaded())

    def test_module_name_does_not_shadow_the_voxcpm_package(self):
        # Воркер запускается из папки программы; модуль с именем voxcpm заслонил бы настоящий пакет.
        base = Path(shtorm_vox.__file__).resolve().parent
        self.assertFalse((base / 'voxcpm.py').exists())
        self.assertFalse((base / 'voxcpm').exists())

    def test_worker_drops_the_program_folder_from_the_import_path(self):
        import subprocess
        code = ("import sys, runpy; sys.argv=['w']; "
                f"sys.path.insert(0, {str(shtorm_vox.BASE)!r}); "
                "import io; sys.stdin = io.StringIO(''); "
                f"runpy.run_path({str(shtorm_vox.WORKER)!r}, run_name='worker_check'); "
                f"print(any(__import__('pathlib').Path(p or '.').resolve() == __import__('pathlib').Path({str(shtorm_vox.BASE)!r}).resolve() for p in sys.path))")
        out = subprocess.run([sys.executable, '-c', code], capture_output=True, text=True, encoding='utf-8')
        self.assertEqual(out.stdout.strip().splitlines()[-1], 'False', out.stderr)


SPEAK_CHECK = r'''
import json, os, sys, tempfile
os.environ['BOOKVOICE_MODELS_DIR'] = tempfile.mkdtemp()
sys.path.insert(0, PROJECT)
from unittest import mock
for name in ('soundfile', 'torch', 'num2words', 'ruaccent', 'sounddevice'):
    sys.modules[name] = mock.MagicMock()           # тяжёлые пакеты не нужны: проверяется только маршрутизация
sys.modules['torch'].hub.load.return_value = (mock.MagicMock(), None)
import numpy as np
import speak
import shtorm_vox

out = {}
seen = []
shtorm_vox.synthesize = lambda text: (seen.append(text), np.zeros(10, dtype=np.float32))[1]
try:
    speak.set_engine('voxcpm')
    out['early'] = 'no error'
except RuntimeError as e:
    out['early'] = str(e)
shtorm_vox.is_loaded = lambda *a, **k: True
shtorm_vox.SAMPLE_RATE = 48000
speak.set_engine('voxcpm')
out['engine'], out['rate'] = speak.ENGINE, speak.SAMPLE_RATE
speak._synth('Это к+ак *слово* зам+ок, вс+ё.', 'ignored')
out['sent'] = seen[-1]
out['out_dir'] = speak.out_dir('книга').name
long_sentence = ', '.join(['слово номер %d и ещё немного текста для длины' % i for i in range(40)]) + '.'
chunks = speak.split_long(long_sentence)
out['chunks'] = len(chunks)
out['longest'] = max(len(c) for c in chunks)
speak.set_engine('silero')
out['silero'] = [speak.ENGINE, speak.SAMPLE_RATE, speak.out_dir('книга').name]
print('RESULT' + json.dumps(out, ensure_ascii=False))
'''


class SpeakRoutingTests(unittest.TestCase):
    """speak.py отправляет текст в VoxCPM2 так, как описано в SHTORM_VOXCPM_ENGINE.md (в отдельном процессе:
    тяжёлые пакеты подменяются заглушками и не должны попасть в остальные тесты)."""

    @classmethod
    def setUpClass(cls):
        import subprocess
        project = str(Path(shtorm_vox.__file__).resolve().parent)
        proc = subprocess.run([sys.executable, '-c', SPEAK_CHECK.replace('PROJECT', repr(project))],
                              capture_output=True, text=True, encoding='utf-8', cwd=tempfile.gettempdir())
        line = next((x for x in proc.stdout.splitlines() if x.startswith('RESULT')), None)
        if line is None:
            raise AssertionError('speak не импортировался с заглушками:\n' + proc.stdout[-800:] + proc.stderr[-1500:])
        cls.out = json.loads(line[len('RESULT'):])

    def test_engine_cannot_be_selected_before_the_model_is_loaded(self):
        self.assertIn('ещё не загружен', self.out['early'])

    def test_selecting_the_engine_switches_the_sample_rate(self):
        self.assertEqual((self.out['engine'], self.out['rate']), ('voxcpm', 48000))

    def test_text_reaches_the_model_prepared(self):
        self.assertEqual(self.out['sent'], 'Это как слово зам+ок, всё.')

    def test_mp3_folder_is_separate_from_other_engines(self):
        self.assertEqual(self.out['out_dir'], 'книга_voxcpm')
        self.assertEqual(self.out['silero'], ['silero', 48000, 'книга'])

    def test_long_sentences_are_split_to_the_engine_limit(self):
        self.assertGreater(self.out['chunks'], 1)
        self.assertLessEqual(self.out['longest'], shtorm_vox.MAX_LEN)


class ClientConstantsTests(unittest.TestCase):
    def test_choices_include_the_authors_defaults(self):
        self.assertIn('2.0', shtorm_vox.CFG_CHOICES)
        self.assertIn('10', shtorm_vox.STEP_CHOICES)
        self.assertEqual(shtorm_vox.CFG_VALUE, 2.0)
        self.assertEqual(shtorm_vox.TIMESTEPS, 10)

    def test_model_folder_is_the_dedicated_one(self):
        self.assertEqual(Path(model_dirs.VOXCPM_DIR).name, 'shtorm-voxcpm2-ru')


if __name__ == '__main__':
    unittest.main()
