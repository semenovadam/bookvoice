import os
import re
import subprocess
import threading
from pathlib import Path

import model_dirs
model_dirs.apply()              # куда класть модели (см. model_dirs.py): до загрузки torch
import model_manager        # папка моделей ударений (⚙ → «Модели…»)

import numpy as np
import soundfile as sf
import torch
from num2words import num2words
from ruaccent import RUAccent

import tera                     # TeraTTS v2: грузится по кнопке, при старте не нужен
import shtorm                   # Shtorm-PocketTTS-RU: необязательный третий движок
import shtorm_vox               # Shtorm-VoxCPM2-RU: необязательный четвёртый движок (отдельная среда, видеокарта)
import homographs               # ручные контекстные исключения для омографов
import accent_pipeline          # порядок обработки: предложение целиком -> ударения -> словарь -> нарезка
from emphasis import extract_emphasis, restore_emphasis
from punctuation_pauses import pause_ms, prepare_tts_text

TTS_LOCK = threading.Lock()
BASE = Path(__file__).parent
PHRASES_FILE = BASE / 'phrases.txt'
DICT_FILE = BASE / 'словарь.txt'
OUT_DIR = BASE / 'out'

# ---------- движки: Silero, TeraTTS v2, Shtorm-PocketTTS-RU и Shtorm-VoxCPM2-RU ----------
ENGINE = 'silero'               # меняется только через set_engine()
SILERO_RATE = 48000
SAMPLE_RATE = SILERO_RATE       # частота текущего движка (у TeraTTS 44100)
SPEAKER = 'aidar'               # голос текущего движка
TERA_SPEED = 1.0                # TeraTTS: duration_scale, больше = медленнее
TERA_PHONETIC_G = False         # -ого/-его -> -ово/-ево и для TeraTTS; выключено, проверь на слух
PREFIX = ''             # раньше было ', ' - давало шипение в начале
PAUSE_SENTENCE = 0.30   # тишина между синтезируемыми предложениями, сек
MAX_LEN = 250           # предложения длиннее режем по запятым

def _load_accentizer():
    """RUAccent с выбранной в окне «Модели ударений RUAccent» моделью (по умолчанию turbo, словарь целиком,
    как раньше) и папкой моделей, если ударения скачаны туда. Возвращает (объект, параметры, заметка)."""
    acc = RUAccent()
    kw = model_manager.ruaccent_load_kwargs(acc)
    note = model_manager.ruaccent_effective()[2]
    acc.load(**kw)
    return acc, kw, note


accentizer, ACCENT_KW, _note = _load_accentizer()
print('RUAccent:', ', '.join(f'{k}={v}' for k, v in ACCENT_KW.items() if k != 'workdir'))
if _note:
    print('  ' + _note)


def reload_accentizer():
    """Загрузить RUAccent заново с нынешними настройками (модель, словарь, tiny_mode) без перезапуска.
    Идёт под замком озвучки: сначала освобождается прежний объект (иначе две копии словаря в памяти),
    при неудаче возвращается прежняя конфигурация. Возвращает параметры загрузки."""
    global accentizer, ACCENT_KW
    import gc
    with TTS_LOCK:
        old_kw = dict(ACCENT_KW)
        accentizer = None
        gc.collect()
        try:
            accentizer, ACCENT_KW, _n = _load_accentizer()
        except Exception:
            try:
                acc = RUAccent()
                acc.load(**old_kw)
                accentizer, ACCENT_KW = acc, old_kw
            except Exception:
                pass                                # останется None: озвучка пойдёт без RUAccent (см. _say_sentence)
            raise
    return ACCENT_KW

SILERO_NAME = None              # какая модель Silero загружена на самом деле


def _load_silero():
    """Модель Silero по настройке model_dirs.SILERO_MODEL. Не загрузилась (первая загрузка без
    интернета, в старом списке репозитория её ещё нет) - берём запасную model_dirs.SILERO_FALLBACK,
    чтобы программа всё равно запустилась."""
    global SILERO_NAME
    names = [model_dirs.SILERO_MODEL]
    if model_dirs.SILERO_FALLBACK not in names:
        names.append(model_dirs.SILERO_FALLBACK)
    for i, name in enumerate(names):
        try:
            m, _example = torch.hub.load(repo_or_dir='snakers4/silero-models',
                                         model='silero_tts',
                                         language='ru',
                                         speaker=name)
        except Exception as e:
            if i + 1 == len(names):
                raise
            print(f'Silero {name} не загрузилась ({type(e).__name__}: {str(e)[:150]}).')
            print(f'Беру запасную {names[i + 1]}. Проверьте интернет и нажмите ⚙ → «Обновить Silero».')
            continue
        SILERO_NAME = name
        print(f'Silero: модель {name}')
        return m


model = _load_silero()


# ---------- словарь замен ----------
_HEADER = re.compile(r'^\[(.+?)\]\s*(off)?\s*$', re.IGNORECASE)


def _norm_key(key):
    k = key.lower().replace('+', '').rstrip('*')
    return re.sub(r'\s+', ' ', k).strip()


def load_dictionary(path, book=None):
    """Читает словарь с группами: [Общий], [Список: ...], [Книга: имя] (+ ' off' = выключена).
    Строки до первой секции относятся к «Общему». Активны: «Общий», все «Список: ...»
    и «Книга: <открытая книга>». Одно слово в нескольких группах: побеждает книга,
    потом общий, потом списки. Замена '!' = «не менять» (глушит правила групп ниже)."""
    if not path.exists():
        print("  словарь.txt не найден, замен нет")
        return []
    group, enabled = 'Общий', True
    order, cand, used = {'Общий': 0}, [], []
    for n, line in enumerate(path.read_text(encoding='utf-8-sig').splitlines()):
        s = line.strip()
        if not s:
            continue
        m = _HEADER.match(s)
        if m:
            group, enabled = m.group(1).strip(), not m.group(2)
            order.setdefault(group, len(order))
            continue
        if s.startswith('#') or '=' not in s:
            continue
        is_book = group.startswith('Книга: ')
        if not enabled or (is_book and (book is None or group != f'Книга: {book}')):
            continue
        orig, repl = (x.strip() for x in s.split('=', 1))
        if not orig:
            continue
        prio = 1 if group == 'Общий' else (2 if is_book else 0)
        cand.append(((prio, order[group], n), _norm_key(orig[1:] if orig[0] in '~*' else orig),
                     orig, repl, group))
    best = {}
    for c in cand:
        if c[1] not in best or c[0] > best[c[1]][0]:
            best[c[1]] = c
    pairs = []
    for c in sorted(best.values(), key=lambda c: c[0]):
        if c[3] != '!':
            pairs.append((c[2], c[3]))
        if c[4] not in used:
            used.append(c[4])
    print(f"  словарь замен: {len(pairs)} записей (группы: {', '.join(used) or 'нет'})")
    return pairs


def apply_dictionary(text, pairs):
    for orig, repl in pairs:
        if orig.startswith(('~', '*')):
            # целые слова/сочетание: ищем по обычным словам, игнорируя '+' от RUAccent
            key = orig[1:].strip().replace('+', '')
            open_end = key.endswith('*')          # 'Бродог*' = любое окончание
            key = key.rstrip('*')
            rep = repl.rstrip('*')
            pat = ''.join(r'\+?' + re.escape(c) for c in key)
            # '+' (ударение RUAccent) стоит внутри слова: за ним нельзя начинать совпадение, иначе
            # правило «А? = А+аа?» ловит конец слова «дом+а?», а «я...» — конец слова «земл+я...».
            pat = r'(?<![А-Яа-яЁё+])' + pat
            pat += r'([А-Яа-яЁё+]*)' if open_end else r'(?![А-Яа-яЁё])'

            plain_rep = rep.replace('+', '')
            subst = '+' not in rep and len(plain_rep) == len(key)   # меняем только буквы

            def sub(m, rep=rep, open_end=open_end, subst=subst):
                full = m.group(0)
                tail = m.group(1) if open_end else ''
                if subst:                       # ударение RUAccent сохраняем как есть
                    out, k = [], 0
                    for ch in full[:len(full) - len(tail)]:
                        if ch == '+':
                            out.append('+')
                        else:
                            r = rep[k]
                            k += 1
                            out.append(r.upper() if ch.isupper() else r)
                    return ''.join(out) + tail
                new = rep
                if full.lstrip('+')[:1].isupper():
                    for i, ch in enumerate(rep):       # первая БУКВА (не '+') в верхний регистр
                        if ch.isalpha():
                            new = rep[:i] + ch.upper() + rep[i + 1:]
                            break
                if open_end:
                    new += tail.replace('+', '')
                return new
            text = re.sub(pat, sub, text, flags=re.IGNORECASE)
        elif orig in text:
            text = text.replace(orig, repl)
    return text


def clean(text):
    """Убирает '+' в односложных словах."""
    def fix(m):
        w = m.group(0)
        if len(re.findall(r'[аеёиоуыэюяАЕЁИОУЫЭЮЯ]', w)) <= 1:
            return w.replace('+', '')
        return w
    return re.sub(r'[А-Яа-яЁё+]+', fix, text)


# Односложные числительные, которые Silero глотает без ударения
FORCE_STRESS = {'пять': 'п+ять', 'шесть': 'ш+есть', 'семь': 'с+емь'}


# Односложные слова с «е», которые Silero без явного ударения иногда читает как «ё»
# (лет -> лёт). Действует только в режиме «ё как в книге» (YO_FROM_BOOK).
YO_MONO = {'лет': 'л+ет', 'мел': 'м+ел', 'сел': 'с+ел', 'смел': 'см+ел', 'лен': 'л+ен',
           'лень': 'л+ень', 'шлем': 'шл+ем', 'слез': 'сл+ез', 'черт': 'ч+ерт',
           'съем': 'съ+ем', 'стек': 'ст+ек'}


def force_stress(text):
    """пять/шесть/семь, лет и т.п. -> с явным ударением (после clean, который его вырезает)."""
    table = dict(FORCE_STRESS)
    if YO_FROM_BOOK:
        table.update(YO_MONO)

    def fix(m):
        w = m.group(0)
        new = table[w.lower()]
        return new.capitalize() if w[0].isupper() else new
    pattern = r'(?<![А-Яа-яЁё+])(' + '|'.join(table) + r')(?![А-Яа-яЁё+])'
    return re.sub(pattern, fix, text, flags=re.IGNORECASE)


# ---------- шаг B: подготовка абзаца ----------
def _fem(n):
    """Число в женском роде: 1 -> 'одна', 2 -> 'две', 21 -> 'двадцать одна'."""
    words = num2words(n, lang='ru').split()
    if n % 10 == 1 and n % 100 != 11:
        words[-1] = 'одна'
    elif n % 10 == 2 and n % 100 != 12:
        words[-1] = 'две'
    return ' '.join(words)


def _decimal_to_words(whole, frac):
    """3,5 -> 'три целых пять десятых'; 1,21 -> 'одна целая двадцать одна сотая'."""
    denoms = {1: ('десятая', 'десятых'),
              2: ('сотая', 'сотых'),
              3: ('тысячная', 'тысячных')}
    if len(frac) not in denoms:
        return (f"{num2words(int(whole), lang='ru')} запятая "
                f"{num2words(int(frac), lang='ru')}")
    w, f = int(whole), int(frac)
    whole_word = 'целая' if (w % 10 == 1 and w % 100 != 11) else 'целых'
    one, many = denoms[len(frac)]
    frac_word = one if (f % 10 == 1 and f % 100 != 11) else many
    return f"{_fem(w)} {whole_word} {_fem(f)} {frac_word}"


# ---------- числительные в родительном падеже (от 35 до 44,9) ----------
G_UNITS = {0: 'нуля', 1: 'одного', 2: 'двух', 3: 'трёх', 4: 'четырёх', 5: 'пяти',
           6: 'шести', 7: 'семи', 8: 'восьми', 9: 'девяти'}
G_TEENS = ['десяти', 'одиннадцати', 'двенадцати', 'тринадцати', 'четырнадцати',
           'пятнадцати', 'шестнадцати', 'семнадцати', 'восемнадцати', 'девятнадцати']
G_TENS = {2: 'двадцати', 3: 'тридцати', 4: 'сорока', 5: 'пятидесяти', 6: 'шестидесяти',
          7: 'семидесяти', 8: 'восьмидесяти', 9: 'девяноста'}
G_HUND = {1: 'ста', 2: 'двухсот', 3: 'трёхсот', 4: 'четырёхсот', 5: 'пятисот',
          6: 'шестисот', 7: 'семисот', 8: 'восьмисот', 9: 'девятисот'}
G_SCALES = [(10 ** 9, 'миллиарда', 'миллиардов', False),
            (10 ** 6, 'миллиона', 'миллионов', False),
            (1000, 'тысячи', 'тысяч', True)]
GEN_PREPS = 'от|до|из|без|около|после|для|у|кроме|вокруг'
MONTHS_GEN = {'января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа',
              'сентября', 'октября', 'ноября', 'декабря'}


def _gen_triplet(n, fem):
    w = []
    h, r = divmod(n, 100)
    if h:
        w.append(G_HUND[h])
    if 10 <= r <= 19:
        w.append(G_TEENS[r - 10])
    else:
        t, u = divmod(r, 10)
        if t >= 2:
            w.append(G_TENS[t])
        if u:
            w.append('одной' if (u == 1 and fem) else G_UNITS[u])
    return w


def gen_words(n, fem=False):
    """Целое число -> слова в родительном падеже: 35 -> 'тридцати пяти'."""
    if n == 0:
        return 'нуля'
    if n in (1000, 10 ** 6, 10 ** 9):
        return {1000: 'тысячи', 10 ** 6: 'миллиона', 10 ** 9: 'миллиарда'}[n]
    words = []
    for scale, one, many, sfem in G_SCALES:
        c = (n // scale) % 1000
        if c:
            words += _gen_triplet(c, sfem)
            words.append(one if (c % 10 == 1 and c % 100 != 11) else many)
    rest = n % 1000
    if rest:
        words += _gen_triplet(rest, fem)
    return ' '.join(words)


def _decimal_gen(whole, frac):
    denoms = {1: ('десятой', 'десятых'), 2: ('сотой', 'сотых'), 3: ('тысячной', 'тысячных')}
    if len(frac) not in denoms:
        return None
    w, f = int(whole), int(frac)
    whole_word = 'целой' if (w % 10 == 1 and w % 100 != 11) else 'целых'
    one, many = denoms[len(frac)]
    frac_word = one if (f % 10 == 1 and f % 100 != 11) else many
    return f"{gen_words(w, True)} {whole_word} {gen_words(f, True)} {frac_word}"


_GEN_RE = re.compile(
    r'(?<!\w)(' + GEN_PREPS + r'|с(?=\s+\d+(?:,\d+)?\s+до(?!\w)))(\s+)'
    r'(\d{1,3}(?:\s\d{3})+(?:,\d+)?|\d+(?:,\d+)?)(?!\d|,\d)',
    re.IGNORECASE)


def genitive_numbers(text):
    """'от 35 до 44,9' -> 'от тридцати пяти до сорока четырёх целых девяти десятых'.
    Только после предлогов, требующих родительного падежа; даты и годы не трогаем."""
    def sub(m):
        prep, sp, num = m.group(1), m.group(2), m.group(3)
        num = re.sub(r'\s', '', num)                      # 21 000 -> 21000
        nm = re.match(r'\s+([А-Яа-яЁё]+)', m.string[m.end():])
        nxt = nm.group(1).lower() if nm else ''
        if nxt in MONTHS_GEN or (nxt.startswith('год') and ',' not in num and len(num) == 4):
            return m.group(0)
        fem = len(nxt) > 2 and nxt.endswith(('ы', 'и'))      # минуты, недели
        if ',' in num:
            whole, frac = num.split(',')
            words = _decimal_gen(whole, frac)
            if words is None:
                return m.group(0)
        else:
            n = int(num)
            if n >= 10 ** 12:
                return m.group(0)
            words = gen_words(n, fem)
        return prep + sp + words
    return _GEN_RE.sub(sub, text)


def numbers_to_words(text):
    """Дроби через запятую -> 'три целых пять десятых'; целые -> слова."""
    text = genitive_numbers(text)
    def dec(m):
        return _decimal_to_words(m.group(1), m.group(2))

    def integer(m):
        return num2words(int(m.group(0)), lang='ru')

    text = re.sub(r'(?<![\d,])(\d+),(\d+)(?!\d|,\d)', dec, text)
    text = re.sub(r'\d+', integer, text)
    return text


def _max_len():
    """Предельная длина фрагмента для текущего движка."""
    return (tera.MAX_LEN if ENGINE == 'tera' else
            shtorm.MAX_LEN if ENGINE == 'shtorm' else
            shtorm_vox.MAX_LEN if ENGINE == 'voxcpm' else MAX_LEN)


def split_long(sentence, max_len=None):
    """Длинное предложение режем по запятым/тире, не по словам (длина без знаков «+» и «*»)."""
    return accent_pipeline.split_long(sentence, _max_len() if max_len is None else max_len)


# True: после запятой, точки с запятой, двоеточия и тире тоже начинается новый фрагмент, который
# озвучивается отдельно и получает свою паузу из таблицы punctuation_pauses.py (так работают
# ползунок пауз и паузы на запятых). Минус: интонация каждого фрагмента считается отдельно, и на
# слух речь может стать «рубленой». False: фрагменты только по концам предложений (. ! ? …),
# как было до таблицы пауз; внутри предложения паузы на запятых ставит сама модель.
SPLIT_AT_COMMAS = True


def _normalize_paragraph(text):
    text = text.replace('\u00a0', ' ')
    text = re.sub(r'\s+', ' ', text).strip()
    return numbers_to_words(text)


def linguistic_steps(pairs):
    """Шаги подготовки предложения (accent_pipeline.Steps): RUAccent, «ё как в книге», пять/шесть/семь,
    сам/самый, словарь, контекстные омографы. Всё, что зависит от смысла, делается здесь, ДО нарезки."""
    hom = getattr(accentizer, 'omographs', None)
    is_omograph = None
    if hasattr(hom, '__contains__'):
        def is_omograph(word):
            try:
                return word in hom or word.replace('ё', 'е') in hom
            except Exception:
                return False
    return accent_pipeline.Steps(
        accentize=lambda t: clean(accentizer.process_all(t)),
        undo_yo=undo_yo,
        force_stress=force_stress,
        fix_sam=fix_sam if SAM_FIX else None,
        dictionary=lambda t: apply_dictionary(t, pairs),
        overrides=homographs.apply_context_overrides,
        yo_from_book=YO_FROM_BOOK,
        log=print,
        omograph=is_omograph)


def prepare_paragraph_ex(text, pairs=None):
    """Абзац -> [(номер предложения, фрагмент)].
    С pairs (словарь): ПОРЯДОК ТАКОЙ: предложения по смыслу -> ударения/омографы/словарь на предложении целиком ->
    нарезка готового текста. Фрагменты приходят как accent_pipeline.Prepared: say_sentence их больше не
    обрабатывает. Без pairs: только нарезка (ударения поставит say_sentence на каждом фрагменте по отдельности,
    как раньше; контекст при этом обрезан запятыми)."""
    text = _normalize_paragraph(text)
    if pairs is None:
        out = []
        for k, sentence in enumerate(accent_pipeline.split_sentences(text)):
            out += [(k, f) for f in accent_pipeline.split_fragments(sentence, SPLIT_AT_COMMAS, _max_len())]
        return out
    with TTS_LOCK:                        # RUAccent один: книга, редактор и перезагрузка модели не мешают друг другу
        return accent_pipeline.prepare_text(text, linguistic_steps(pairs), SPLIT_AT_COMMAS, _max_len())


def prepare_paragraph(text, pairs=None):
    """Абзац -> список фрагментов для озвучки (см. prepare_paragraph_ex)."""
    return [f for _k, f in prepare_paragraph_ex(text, pairs)]


def accent_report_text():
    """Отчёт по ударениям: сколько предложений обработано целиком, где RUAccent пришлось обойти, какие омографы."""
    return accent_pipeline.REPORT.text()


def reset_accent_report():
    accent_pipeline.REPORT.reset()


# ---------- озвучка ----------
QUESTION_FOCUS = True   # интонационный центр вопроса: *последнее слово*
YO_FROM_BOOK = True     # «ё» только если она есть в тексте; иначе решает Silero

WORD_RE = re.compile(r'[А-Яа-яЁё+]+')

SAM_FIX = True          # самый / сам: с+амое, с+амого (до самого утра) или сам+ого (самого мага)
SAM_AMBIG = {'самого': ('с+амого', 'сам+ого'), 'самому': ('с+амому', 'сам+ому'),
             'самом': ('с+амом', 'сам+ом'), 'самой': ('с+амой', 'сам+ой')}
SAM_PREPS = {'до', 'с', 'со', 'в', 'во', 'на', 'по', 'от', 'к', 'ко', 'из'}
_morph = None


def _get_morph():
    global _morph
    if _morph is None:
        try:
            import pymorphy3
            _morph = pymorphy3.MorphAnalyzer()
        except Exception:
            _morph = False
    return _morph or None


def _adj_anim(word):
    """(похоже на прилагательное/числительное, похоже на одушевлённое существительное)."""
    m = _get_morph()
    if m is None or not word:
        return 0.0, 0.0
    adj = anim = 0.0
    for p in m.parse(word):
        if p.tag.POS in ('ADJF', 'ADJS', 'PRTF', 'PRTS', 'NUMR', 'COMP'):
            adj += p.score
        elif p.tag.POS == 'NOUN' and p.tag.animacy == 'anim':
            anim += p.score
    return adj, anim


def fix_sam(text):
    """«самое» всегда с+амое. «самого/самой/самому/самом» по соседним словам:
    перед прилагательным или после предлога времени/места (до самого утра) это «самый»
    (с+амого), а перед одушевлённым существительным и в прочих случаях «сам» (сам+ого мага)."""
    words = list(WORD_RE.finditer(text))
    plain = lambda m: m.group(0).replace('+', '').lower()
    out, last = [], 0
    for i, m in enumerate(words):
        p = plain(m)
        if p == 'самое':
            new = 'с+амое'
        elif p in SAM_AMBIG:
            prev = plain(words[i - 1]) if i > 0 else ''
            nxt = plain(words[i + 1]) if i + 1 < len(words) else ''
            adj, anim = _adj_anim(nxt)
            if adj >= 0.5:
                k = 0
            elif anim >= 0.5:
                k = 1
            elif prev in SAM_PREPS:
                k = 0
            else:
                k = 1
            new = SAM_AMBIG[p][k]
        else:
            continue
        if m.group(0).lstrip('+')[:1].isupper():
            new = new.capitalize()
        out.append(text[last:m.start()])
        out.append(new)
        last = m.end()
    out.append(text[last:])
    return ''.join(out)


PHONETIC_G = True       # -ого/-его читаем как -ова/-ево (четвёртого -> четвёртова)
# слова, где «г» в -ого остаётся (наречия и т.п.); дополняй при необходимости
KEEP_G = {'много', 'немного', 'строго', 'дорого', 'убого', 'итого', 'ого', 'лего'}
# Слова с корнем/окончанием «-много» сохраняют [г]: «намного», «ненамного».
# Иначе общее фонетическое правило ошибочно превращает их в «намново/ненамново».


def phonetic_g(text):
    """Произношение: 'четв+ёртого' -> 'четв+ёртово', 'сегодня' -> 'севодня'."""
    def fix(m):
        w = m.group(0)
        plain = w.replace('+', '').lower()
        if plain.startswith('сегодн'):
            w = re.sub(r'^(с\+?е)г(?=\+?одн)', r'\1в', w, flags=re.IGNORECASE)
        if (plain not in KEEP_G
                and not plain.endswith('много')
                and plain.endswith(('ого', 'его'))):
            w = re.sub(r'(\+?[оеОЕ])([гГ])(\+?[оО])$',
                       lambda k: k.group(1) + ('В' if k.group(2) == 'Г' else 'в') + k.group(3),
                       w)
        return w
    return WORD_RE.sub(fix, text)


def undo_yo(original, accented):
    """RUAccent иногда сам меняет е->ё (небо -> нёбо). Если в исходном
    предложении слово было с «е», возвращаем «е»; ё-фикацией займётся Silero."""
    ow = {w.replace('+', '').lower() for w in WORD_RE.findall(original)}

    def fix(m):
        w = m.group(0)
        if 'ё' not in w.lower():
            return w
        plain = w.replace('+', '').lower()
        if plain in ow:                      # в книге слово было с «ё»
            return w
        if plain.replace('ё', 'е') in ow:    # в книге была «е»
            return w.replace('ё', 'е').replace('Ё', 'Е')
        return w
    return WORD_RE.sub(fix, accented)


# Вопросительные интонации: сейчас как у самой модели Silero v5.6, без своих подстроек.
# Скрипт не меняет ни скорость, ни высоту тона (SSML <prosody> не используется); вопросов
# касаются только две настройки ниже. Прежние значения: 'general' и 1.
#
# Звёздочка вокруг последнего слова («Ты *дома*?») задаёт интонационный центр общего вопроса.
# У вопросов с вопросительным словом, с «или» и «не так ли?» модель и так интонирует сама
# (по описанию авторов Silero), а лишний акцент на последнем слове даёт заметный подъём тона.
QUESTION_STARS = 'off'          # 'off' - не ставим; 'general' - только общие вопросы; 'all' - все вопросы
# Параметр intensity (сила вопросительной интонации) Silero v5.6: None - не передаём, модель
# берёт своё значение по умолчанию; число (например 1) - передаём его только фразам на «?».
QUESTION_INTENSITY = None
QUESTION_WORDS = {'кто', 'что', 'где', 'когда', 'куда', 'откуда', 'почему', 'зачем', 'как',
                  'какой', 'какая', 'какое', 'какие', 'каков', 'каковы', 'который', 'которая',
                  'которое', 'которые', 'сколько', 'чей', 'чья', 'чьё', 'чьи', 'чем', 'чему',
                  'кого', 'кому', 'кем', 'ком', 'чего', 'отчего', 'разве', 'неужели', 'почём'}
_LEAD = {'а', 'и', 'ну', 'так', 'но', 'же', 'вот', 'тогда', 'значит'}


def is_general_question(text):
    """Общий вопрос (да/нет). Специальные, альтернативные и «хвостики» -> False."""
    plain = text.replace('+', '').replace('*', '').lower()
    words = re.findall(r'[а-яё]+', plain)
    if re.search(r',\s*(не так ли|не правда ли|правда|да|верно|нет|ладно|хорошо)\s*\?+\W*$', plain):
        return False                                        # вопрос-хвостик
    if 'или' in words:
        return False                                        # альтернативный
    head = [w for w in words[:3] if w not in _LEAD][:1]     # вопросительное слово в начале
    return not (head and head[0] in QUESTION_WORDS)


def mark_question(text):
    """Автоакцент общего вопроса; явные *слова* и **слова** сохраняются."""
    # Пользовательская разметка *слово* / **слово** важнее авторазметки вопроса.
    if QUESTION_STARS == 'off' or not QUESTION_FOCUS or '*' in text:
        return text
    if QUESTION_STARS == 'general' and not is_general_question(text):
        return text
    return re.sub(r'([А-Яа-яЁё+]+)(\W*\?+\W*)$', r'*\1*\2', text)


_BAD_KW = re.compile(r"(?:unexpected|unknown) keyword argument '(\w+)'", re.IGNORECASE)
_WARNED = set()


def _apply_tts(text, voice, kw):
    """model.apply_tts. Если у этой версии Silero нет какого-то необязательного параметра
    (put_accent, put_yo, intensity), повторяем без него: другая модель не роняет озвучку."""
    kw = dict(kw)
    while True:
        try:
            return model.apply_tts(text=text, speaker=voice, sample_rate=SILERO_RATE, **kw)
        except TypeError as e:
            m = _BAD_KW.search(str(e))
            if not m or m.group(1) not in kw:
                raise
            del kw[m.group(1)]
            if m.group(1) not in _WARNED:
                _WARNED.add(m.group(1))
                print(f'  у модели Silero {SILERO_NAME} нет параметра {m.group(1)}, дальше без него')


def _synth(text, voice):
    """Озвучить готовый текст («+» перед ударной гласной) текущим движком -> float32.
    Вызывать под TTS_LOCK: движок и частота на время вызова менять нельзя."""
    if ENGINE == 'tera':
        if TERA_PHONETIC_G:
            text = phonetic_g(text)
        print('  ', text)
        return tera.synthesize(text, voice, TERA_SPEED)     # «*слово*» и «<>» она вычистит сама
    if ENGINE == 'shtorm':
        # Shtorm ожидает акут после ударной гласной (ё́/а́), а не метку + перед ней.
        # Маркеры *...* нужны только Silero, поэтому удаляем их из копии для Shtorm.
        text = shtorm.plus_to_acute(text)
        print('  ', text)
        return shtorm.synthesize(text)
    if ENGINE == 'voxcpm':
        # VoxCPM2 понимает «+» перед ударной гласной как есть; снимаются только метки на односложных словах
        # и перед «ё», а также маркеры *...* (они нужны одному Silero).
        text = shtorm_vox.prepare_text(text)
        print('  ', text)
        return shtorm_vox.synthesize(text)
    if voice in tera.VOICES:                # голос другого движка (гонка при переключении)
        voice = 'aidar'
    if PHONETIC_G:
        text = phonetic_g(text)
    text = mark_question(text)
    print('  ', text)
    kw = {'put_accent': True, 'put_yo': not YO_FROM_BOOK}
    # intensity относится к вопросительной интонации Silero v5.6, не к общей громкости.
    if QUESTION_INTENSITY is not None and text.rstrip().endswith('?'):
        kw['intensity'] = int(QUESTION_INTENSITY)
    return _apply_tts(PREFIX + text, voice, kw).numpy()


def _say_sentence(sentence, pairs):
    """Фрагмент, который не прошёл подготовку (сырой текст): ударения по нему одному, как раньше."""
    restored, _how = accent_pipeline.accent_sentence(sentence, linguistic_steps(pairs))
    return _synth(restored, SPEAKER)


def say_sentence(sentence, pairs):
    """Озвучить фрагмент. Подготовленный (Prepared) идёт в движок как есть; сырой строке ударения ставятся тут."""
    if isinstance(sentence, accent_pipeline.Prepared):
        # Удлинение междометий перед многоточием делается в копии для TTS, уже после ударений.
        with TTS_LOCK:
            return _synth(prepare_tts_text(sentence), SPEAKER)
    sentence = prepare_tts_text(sentence)
    with TTS_LOCK:                    # модель одна: книга, редактор и словарь не мешают друг другу
        return _say_sentence(sentence, pairs)


def say_plain(text, voice=None):
    """Озвучить короткий текст как есть (слово из словаря или редактора, «+» уже в тексте).
    Возвращает (звук, частота)."""
    with TTS_LOCK:
        return _synth(text, voice or SPEAKER), SAMPLE_RATE


def set_engine(name):
    """Переключить движок. TeraTTS должен быть уже загружен (tera.load())."""
    global ENGINE, SAMPLE_RATE
    if name not in ('silero', 'tera', 'shtorm', 'voxcpm'):
        raise ValueError(f'неизвестный движок: {name}')
    if name == 'tera' and not tera.is_loaded():
        raise RuntimeError('TeraTTS ещё не загружен')
    if name == 'shtorm' and not shtorm.is_loaded():
        raise RuntimeError('Shtorm ещё не загружен: выбери образец голоса и загрузи модель')
    if name == 'voxcpm' and not shtorm_vox.is_loaded():
        raise RuntimeError('Shtorm-VoxCPM2-RU ещё не загружен: выбери образец голоса и загрузи модель')
    with TTS_LOCK:                    # дожидаемся конца начатой озвучки
        ENGINE = name
        SAMPLE_RATE = (tera.SAMPLE_RATE if name == 'tera' else
                       shtorm.SAMPLE_RATE if name == 'shtorm' else
                       shtorm_vox.SAMPLE_RATE if name == 'voxcpm' else SILERO_RATE)


def out_dir(book_stem):
    """Папка с mp3 книги: у Silero out/<книга>, у TeraTTS out/<книга>_tera, у VoxCPM2 out/<книга>_voxcpm
    (файлы не путаются)."""
    variant = shtorm._model_variant or 'fast'
    suffix = {'silero': '', 'tera': '_tera', 'shtorm': '_shtorm_' + variant, 'voxcpm': '_voxcpm'}[ENGINE]
    return OUT_DIR / (book_stem + suffix)


def say(text, name, pairs):
    sentences = prepare_paragraph(text, pairs)
    if not sentences:
        return
    pieces = []
    for index, sentence in enumerate(sentences):
        pieces.append(say_sentence(sentence, pairs))
        if index < len(sentences) - 1:
            duration_ms = pause_ms(sentence)
            if duration_ms:
                pieces.append(np.zeros(int(SAMPLE_RATE * duration_ms / 1000), dtype=np.float32))
    audio = np.concatenate(pieces)

    wav = str(OUT_DIR / (name + '.wav'))
    mp3 = str(OUT_DIR / (name + '.mp3'))
    sf.write(wav, audio, SAMPLE_RATE)
    subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', wav,
                    '-codec:a', 'libmp3lame', '-q:a', '3', mp3],
                   check=True)
    os.remove(wav)


def main():
    OUT_DIR.mkdir(exist_ok=True)
    pairs = load_dictionary(DICT_FILE)
    lines = [l.strip() for l in
             PHRASES_FILE.read_text(encoding='utf-8-sig').splitlines()
             if l.strip()]
    for i, line in enumerate(lines, 1):
        print(f"[{i}/{len(lines)}]")
        say(line, f"{i:03d}", pairs)
    print("готово")


if __name__ == "__main__":
    main()