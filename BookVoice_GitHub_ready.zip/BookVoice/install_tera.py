"""Разовая установка TeraTTS v2: скачивает модель в папку из model_dirs.py и проверяет,
что она работает. Запускается через install_tera.bat (нужен интернет, около 1,2 ГБ)."""
import sys
import traceback

import model_dirs

model_dirs.apply()               # до импорта huggingface_hub: он читает настройки при импорте

import soundfile as sf

import tera

# Проверяем все пути, которыми потом пользуется программа. Всё, что модель
# докачивает при первом обращении, должно скачаться сейчас, пока есть интернет.
CHECKS = [
    ('русская фраза со знаками ударения', 'Прив+ет! Это пров+ерка г+олоса.'),
    ('русская фраза без знаков ударения', 'Это проверка без ударений.'),
    ('английское слово в русской фразе', 'Это слово Hello звучит по-английски.'),
]


def check_stack():
    """Версии главных пакетов (пригодятся, если что-то пойдёт не так) и проверка,
    что установка transformers ничего не сломала."""
    print('Пакеты:')
    for mod in ('torch', 'transformers', 'huggingface_hub', 'onnxruntime', 'ruaccent', 'num2words'):
        try:
            m = __import__(mod)
            print(f'  {mod} {getattr(m, "__version__", "")}'.rstrip())
        except Exception as e:
            print(f'  ВНИМАНИЕ: {mod} не импортируется: {e!r}')


def old_hub():
    """huggingface_hub старше 0.23 при скачивании в папку оставляет большие файлы в общем
    кэше на диске C: (в папке лежат лишь ссылки на них); таким версиям ссылки запрещаем."""
    import huggingface_hub
    try:
        major, minor = (int(x) for x in huggingface_hub.__version__.split('.')[:2])
    except ValueError:
        return False
    return (major, minor) < (0, 23)


def main():
    from huggingface_hub import snapshot_download
    check_stack()
    dst = tera.model_dir()
    if not dst.is_dir():                 # папка не создалась (диск не подключён?): причина напечатана выше
        raise RuntimeError(f'Папка для модели недоступна: {dst}. '
                           'Подключи диск или поменяй путь в model_dirs.py.')
    print(f'Скачиваю {tera.REPO} в папку {dst}')
    print('(около 1,2 ГБ; если оборвётся, запусти ещё раз: докачает)…')
    kw = {'local_dir_use_symlinks': False} if old_hub() else {}
    path = snapshot_download(tera.REPO, local_dir=str(dst), **kw)
    print('Скачано в', path)
    print('Загружаю модель (первый раз это долго)…')
    tera.load()
    print('Голоса:', ', '.join(tera.VOICES))
    warnings = []
    for n, (what, text) in enumerate(CHECKS):
        try:
            wav = tera.synthesize(text, tera.VOICES[0], 1.0)
            if not len(wav):
                raise RuntimeError('модель вернула тишину')
            print(f'  ок: {what} ({len(wav) / tera.SAMPLE_RATE:.1f} с)')
            if n == 0:
                sf.write('tera_test.wav', wav, tera.SAMPLE_RATE)
        except Exception:
            if n == 0:
                raise               # без первой проверки программе с моделью делать нечего
            warnings.append(what)
            print(f'  ВНИМАНИЕ: не получилось: {what}')
            traceback.print_exc()
    print('Готово: послушай файл tera_test.wav (там голос', tera.VOICES[0] + ').')
    if warnings:
        print('Часть проверок не прошла (ошибки выше). Программа будет работать, но на таких '
              'фразах может пропускать предложения: пришли текст ошибки, разберёмся.')
    print('Теперь запускай bookvoice.bat.')


if __name__ == '__main__':
    try:
        main()
    except Exception:
        traceback.print_exc()
        print('\nУстановка не удалась. Текст ошибки выше можно прислать, разберёмся.')
        sys.exit(1)
