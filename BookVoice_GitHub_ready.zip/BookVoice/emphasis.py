"""Preserve BookVoice *...* / **...** emphasis through text normalisation.

Markers are removed before RUAccent because it may strip asterisks, then restored
around the corresponding word/phrase after dictionary and homograph processing.
Only standard-library dependencies are used so the behavior can be tested in isolation.
"""
from __future__ import annotations

import re
from layoutmarks import MARKS
from typing import List, Tuple

_MARKER_RE = re.compile(
    r'(?<!\w)\*\*([^*\n]+?)\*\*(?!\w)|(?<![\w*])\*([^\s*](?:[^*\n]*?[^\s*])?)\*(?!\w)'
)
_WORD_RE = re.compile(r'[A-Za-zА-Яа-яЁё+]+')


def _norm(word: str) -> str:
    return word.replace('+', '').lower()


def _token_spans(text: str):
    return [(m.start(), m.end(), _norm(m.group())) for m in _WORD_RE.finditer(text)]


def _find_sequences(tokens, target_words):
    if not target_words:
        return []
    found = []
    n = len(target_words)
    for i in range(len(tokens) - n + 1):
        if [t[2] for t in tokens[i:i+n]] == target_words:
            found.append((i, i+n-1))
    return found


def extract_emphasis(text: str):
    """Return (marker-free text, marks); each mark stores level, target words, occurrence.

    Conventional scene breaks (* * *) and star-only marks are deliberately left alone.
    Occurrence numbering disambiguates repeated words/phrases in the same sentence.
    """
    pieces = []
    pending = []
    cursor = 0
    plain_len = 0
    for match in _MARKER_RE.finditer(text):
        raw = match.group(1) if match.group(1) is not None else match.group(2)
        if not raw or not re.search(r'[A-Za-zА-Яа-яЁё]', raw):
            continue
        before = text[cursor:match.start()]
        pieces.append(before)
        plain_len += len(before)
        start = plain_len
        pieces.append(raw)
        plain_len += len(raw)
        level = 2 if match.group(1) is not None else 1
        target_words = [_norm(w) for w in _WORD_RE.findall(raw) if _norm(w)]
        if target_words:
            pending.append({'level': level, 'words': target_words, 'start': start})
        cursor = match.end()
    pieces.append(text[cursor:])
    plain = ''.join(pieces)
    tokens = _token_spans(plain)
    marks = []
    for item in pending:
        seqs = _find_sequences(tokens, item['words'])
        occurrence = sum(1 for a, _ in seqs if tokens[a][0] < item['start'])
        marks.append({'level': item['level'], 'words': item['words'], 'occurrence': occurrence})
    return plain, marks


def restore_emphasis(text: str, marks, *, report_missing: bool = False):
    """Restore markers around matching transformed words, retaining + stress marks.

    If dictionary rules changed the target beyond recognition, the marker is not
    guessed onto another word. A caller can log that the target was not restored.
    """
    if not marks:
        return (text, []) if report_missing else text
    tokens = _token_spans(text)
    insertions = []
    missing = []
    for mark in marks:
        seqs = _find_sequences(tokens, mark['words'])
        occ = mark['occurrence']
        if occ >= len(seqs):
            missing.append(mark)
            continue
        first, last = seqs[occ]
        start, end = tokens[first][0], tokens[last][1]
        marker = '**' if mark['level'] == 2 else '*'
        insertions.append((start, marker))
        insertions.append((end, marker))
    for pos, marker in sorted(insertions, reverse=True):
        text = text[:pos] + marker + text[pos:]
    return (text, missing) if report_missing else text


def inject_emphasis_ranges(text: str, ranges):
    """Inject BookVoice markers from (start, end, level) character ranges.

    Ranges are zero-based offsets in *text*. Invalid/out-of-bounds ranges are
    ignored. Insertions are applied right-to-left so offsets remain stable.
    This is used by the editor's live-reading path, where emphasis lives in Tk
    text tags rather than literal characters in the book text.
    """
    insertions = []
    for item in ranges or []:
        try:
            start, end, level = int(item[0]), int(item[1]), int(item[2])
        except (TypeError, ValueError, IndexError):
            continue
        if level not in (1, 2) or start < 0 or end <= start or end > len(text):
            continue
        marker = '**' if level == 2 else '*'
        insertions.append((start, marker))
        insertions.append((end, marker))
    for pos, marker in sorted(insertions, reverse=True):
        text = text[:pos] + marker + text[pos:]
    return text


def inject_absolute_emphasis_ranges(text: str, span_start: int, span_end: int, ranges):
    """Return one text span with intersecting absolute emphasis ranges marked.

    Absolute ranges are (start, end, level) offsets into the full editor text.
    A selection crossing sentence boundaries is clipped to each sentence span.
    """
    try:
        span_start, span_end = int(span_start), int(span_end)
    except (TypeError, ValueError):
        return ''
    if span_start < 0 or span_end < span_start or span_end > len(text):
        return ''
    sentence = text[span_start:span_end]
    local = []
    for item in ranges or []:
        try:
            start, end, level = int(item[0]), int(item[1]), int(item[2])
        except (TypeError, ValueError, IndexError):
            continue
        left, right = max(start, span_start), min(end, span_end)
        if left < right:
            local.append((left - span_start, right - span_start, level))
    return inject_emphasis_ranges(sentence, local)


def ranges_to_paragraph_annotations(text: str, ranges):
    """Переводит диапазоны (start, end, level) по тексту окна редактора в диапазоны по абзацам.

    Абзацы — это непустые строки text с обрезанными краями (так же считает EditTab.get_paras),
    поэтому пустые строки и отступы в начале строк номера и столбцы не сдвигают. Диапазон через
    несколько строк режется по строкам, пробелы по краям диапазона отбрасываются.
    Возвращает [{'paragraph', 'start', 'end', 'level'}]; start/end считаются внутри абзаца.
    """
    layout, pos = [], 0                     # (абсолютное начало абзаца, абзац)
    for line in text.split('\n'):
        stripped = line.strip()
        if stripped and stripped not in MARKS:          # строки-метки оформления («[пустая строка]») не абзацы
            layout.append((pos + len(line) - len(line.lstrip()), stripped))
        pos += len(line) + 1
    out = []
    for item in ranges or []:
        try:
            start, end, level = int(item[0]), int(item[1]), int(item[2])
        except (TypeError, ValueError, IndexError):
            continue
        if level not in (1, 2) or end <= start:
            continue
        for pi, (base, para) in enumerate(layout):
            if base >= end:
                break
            left, right = max(start, base), min(end, base + len(para))
            if left >= right:
                continue
            piece = para[left - base:right - base]
            left += len(piece) - len(piece.lstrip())
            right -= len(piece) - len(piece.rstrip())
            if left < right:
                out.append({'paragraph': pi, 'start': left - base, 'end': right - base, 'level': level})
    out.sort(key=lambda r: (r['paragraph'], r['start'], r['end'], r['level']))
    return out
