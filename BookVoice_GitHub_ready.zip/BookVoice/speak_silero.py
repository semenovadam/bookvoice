import os
import re
import subprocess
import threading
from pathlib import Path

import numpy as np
import soundfile as sf
import torch
from num2words import num2words
from ruaccent import RUAccent
from emphasis import extract_emphasis, restore_emphasis
from punctuation_pauses import pause_ms, prepare_tts_text

TTS_LOCK = threading.Lock()
BASE = Path(__file__).parent
PHRASES_FILE = BASE / 'phrases.txt'
DICT_FILE = BASE / 'словарь.txt'
OUT_DIR = BASE / 'out'
SPEAKER = 'aidar'
SAMPLE_RATE = 48000
PREFIX = ''             # раньше было ', ' - давало шипение в начале
PAUSE_SENTENCE = 0.30   # пауза между предложениями, сек
MAX_LEN = 250           # предложения длиннее режем по запятым

accentizer = RUAccent()
accentizer.load(omograph_model_size='turbo', use_dictionary=True)

model, _ = torch.hub.load(repo_or_dir='snakers4/silero-models',
                          model='silero_tts',
                          language='ru',
                          speaker='v5_4_ru')


# ---------- словарь замен ----------
_HEADER = re.compile(r'^\[(.+?)\]\s*(off)?\s*$', re.IGNORECASE)


def _norm_key(key):
    k = key.lower().replace('+', '').rstrip('*')
    return re.sub(r'\s+', ' ', k).strip()


def load_dictionary(path, book=None):
    """Читает словарь с группами: [Общий], [Список: ...], [Книга: имя] (+ ' off' = выключена).
    Строки до первой секции относятся к «Общему». Активны: «Общий», все «Список: ...»
    и «Книга: <открытая книга>». Одно слово в нескольких группах: побеждает книга,
    потом общий, потом списки. Замена '!' = «не менять» (глушит правила групп ниже)."""
    if not path.exists():
        print("  словарь.txt не найден, замен нет")
        return []
    group, enabled = 'Общий', True
    order, cand, used = {'Общий': 0}, [], []
    for n, line in enumerate(path.read_text(encoding='utf-8-sig').splitlines()):
        s = line.strip()
        if not s:
            continue
        m = _HEADER.match(s)
        if m:
            group, enabled = m.group(1).strip(), not m.group(2)
            order.setdefault(group, len(order))
            continue
        if s.startswith('#') or '=' not in s:
            continue
        is_book = group.startswith('Книга: ')
        if not enabled or (is_book and (book is None or group != f'Книга: {book}')):
            continue
        orig, repl = (x.strip() for x in s.split('=', 1))
        if not orig:
            continue
        prio = 1 if group == 'Общий' else (2 if is_book else 0)
        cand.append(((prio, order[group], n), _norm_key(orig[1:] if orig[0] in '~*' else orig),
                     orig, repl, group))
    best = {}
    for c in cand:
        if c[1] not in best or c[0] > best[c[1]][0]:
            best[c[1]] = c
    pairs = []
    for c in sorted(best.values(), key=lambda c: c[0]):
        if c[3] != '!':
            pairs.append((c[2], c[3]))
        if c[4] not in used:
            used.append(c[4])
    print(f"  словарь замен: {len(pairs)} записей (группы: {', '.join(used) or 'нет'})")
    return pairs


def apply_dictionary(text, pairs):
    for orig, repl in pairs:
        if orig.startswith(('~', '*')):
            # целые слова/сочетание: ищем по обычным словам, игнорируя '+' от RUAccent
            key = orig[1:].strip().replace('+', '')
            open_end = key.endswith('*')          # 'Бродог*' = любое окончание
            key = key.rstrip('*')
            rep = repl.rstrip('*')
            pat = ''.join(r'\+?' + re.escape(c) for c in key)
            # '+' (ударение RUAccent) стоит внутри слова: за ним нельзя начинать совпадение
            pat = r'(?<![А-Яа-яЁё+])' + pat
            pat += r'([А-Яа-яЁё+]*)' if open_end else r'(?![А-Яа-яЁё])'

            plain_rep = rep.replace('+', '')
            subst = '+' not in rep and len(plain_rep) == len(key)   # меняем только буквы

            def sub(m, rep=rep, open_end=open_end, subst=subst):
                full = m.group(0)
                tail = m.group(1) if open_end else ''
                if subst:                       # ударение RUAccent сохраняем как есть
                    out, k = [], 0
                    for ch in full[:len(full) - len(tail)]:
                        if ch == '+':
                            out.append('+')
                        else:
                            r = rep[k]
                            k += 1
                            out.append(r.upper() if ch.isupper() else r)
                    return ''.join(out) + tail
                new = rep
                if full.lstrip('+')[:1].isupper():
                    for i, ch in enumerate(rep):       # первая БУКВА (не '+') в верхний регистр
                        if ch.isalpha():
                            new = rep[:i] + ch.upper() + rep[i + 1:]
                            break
                if open_end:
                    new += tail.replace('+', '')
                return new
            text = re.sub(pat, sub, text, flags=re.IGNORECASE)
        elif orig in text:
            text = text.replace(orig, repl)
    return text


def clean(text):
    """Убирает '+' в односложных словах."""
    def fix(m):
        w = m.group(0)
        if len(re.findall(r'[аеёиоуыэюяАЕЁИОУЫЭЮЯ]', w)) <= 1:
            return w.replace('+', '')
        return w
    return re.sub(r'[А-Яа-яЁё+]+', fix, text)


# Односложные числительные, которые Silero глотает без ударения
FORCE_STRESS = {'пять': 'п+ять', 'шесть': 'ш+есть', 'семь': 'с+емь'}


# Односложные слова с «е», которые Silero без явного ударения иногда читает как «ё»
# (лет -> лёт). Действует только в режиме «ё как в книге» (YO_FROM_BOOK).
YO_MONO = {'лет': 'л+ет', 'мел': 'м+ел', 'сел': 'с+ел', 'смел': 'см+ел', 'лен': 'л+ен',
           'лень': 'л+ень', 'шлем': 'шл+ем', 'слез': 'сл+ез', 'черт': 'ч+ерт',
           'съем': 'съ+ем', 'стек': 'ст+ек'}


def force_stress(text):
    """пять/шесть/семь, лет и т.п. -> с явным ударением (после clean, который его вырезает)."""
    table = dict(FORCE_STRESS)
    if YO_FROM_BOOK:
        table.update(YO_MONO)

    def fix(m):
        w = m.group(0)
        new = table[w.lower()]
        return new.capitalize() if w[0].isupper() else new
    pattern = r'(?<![А-Яа-яЁё+])(' + '|'.join(table) + r')(?![А-Яа-яЁё+])'
    return re.sub(pattern, fix, text, flags=re.IGNORECASE)


# ---------- шаг B: подготовка абзаца ----------
def _fem(n):
    """Число в женском роде: 1 -> 'одна', 2 -> 'две', 21 -> 'двадцать одна'."""
    words = num2words(n, lang='ru').split()
    if n % 10 == 1 and n % 100 != 11:
        words[-1] = 'одна'
    elif n % 10 == 2 and n % 100 != 12:
        words[-1] = 'две'
    return ' '.join(words)


def _decimal_to_words(whole, frac):
    """3,5 -> 'три целых пять десятых'; 1,21 -> 'одна целая двадцать одна сотая'."""
    denoms = {1: ('десятая', 'десятых'),
              2: ('сотая', 'сотых'),
              3: ('тысячная', 'тысячных')}
    if len(frac) not in denoms:
        return (f"{num2words(int(whole), lang='ru')} запятая "
                f"{num2words(int(frac), lang='ru')}")
    w, f = int(whole), int(frac)
    whole_word = 'целая' if (w % 10 == 1 and w % 100 != 11) else 'целых'
    one, many = denoms[len(frac)]
    frac_word = one if (f % 10 == 1 and f % 100 != 11) else many
    return f"{_fem(w)} {whole_word} {_fem(f)} {frac_word}"


# ---------- числительные в родительном падеже (от 35 до 44,9) ----------
G_UNITS = {0: 'нуля', 1: 'одного', 2: 'двух', 3: 'трёх', 4: 'четырёх', 5: 'пяти',
           6: 'шести', 7: 'семи', 8: 'восьми', 9: 'девяти'}
G_TEENS = ['десяти', 'одиннадцати', 'двенадцати', 'тринадцати', 'четырнадцати',
           'пятнадцати', 'шестнадцати', 'семнадцати', 'восемнадцати', 'девятнадцати']
G_TENS = {2: 'двадцати', 3: 'тридцати', 4: 'сорока', 5: 'пятидесяти', 6: 'шестидесяти',
          7: 'семидесяти', 8: 'восьмидесяти', 9: 'девяноста'}
G_HUND = {1: 'ста', 2: 'двухсот', 3: 'трёхсот', 4: 'четырёхсот', 5: 'пятисот',
          6: 'шестисот', 7: 'семисот', 8: 'восьмисот', 9: 'девятисот'}
G_SCALES = [(10 ** 9, 'миллиарда', 'миллиардов', False),
            (10 ** 6, 'миллиона', 'миллионов', False),
            (1000, 'тысячи', 'тысяч', True)]
GEN_PREPS = 'от|до|из|без|около|после|для|у|кроме|вокруг'
MONTHS_GEN = {'января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа',
              'сентября', 'октября', 'ноября', 'декабря'}


def _gen_triplet(n, fem):
    w = []
    h, r = divmod(n, 100)
    if h:
        w.append(G_HUND[h])
    if 10 <= r <= 19:
        w.append(G_TEENS[r - 10])
    else:
        t, u = divmod(r, 10)
        if t >= 2:
            w.append(G_TENS[t])
        if u:
            w.append('одной' if (u == 1 and fem) else G_UNITS[u])
    return w


def gen_words(n, fem=False):
    """Целое число -> слова в родительном падеже: 35 -> 'тридцати пяти'."""
    if n == 0:
        return 'нуля'
    if n in (1000, 10 ** 6, 10 ** 9):
        return {1000: 'тысячи', 10 ** 6: 'миллиона', 10 ** 9: 'миллиарда'}[n]
    words = []
    for scale, one, many, sfem in G_SCALES:
        c = (n // scale) % 1000
        if c:
            words += _gen_triplet(c, sfem)
            words.append(one if (c % 10 == 1 and c % 100 != 11) else many)
    rest = n % 1000
    if rest:
        words += _gen_triplet(rest, fem)
    return ' '.join(words)


def _decimal_gen(whole, frac):
    denoms = {1: ('десятой', 'десятых'), 2: ('сотой', 'сотых'), 3: ('тысячной', 'тысячных')}
    if len(frac) not in denoms:
        return None
    w, f = int(whole), int(frac)
    whole_word = 'целой' if (w % 10 == 1 and w % 100 != 11) else 'целых'
    one, many = denoms[len(frac)]
    frac_word = one if (f % 10 == 1 and f % 100 != 11) else many
    return f"{gen_words(w, True)} {whole_word} {gen_words(f, True)} {frac_word}"


_GEN_RE = re.compile(
    r'(?<!\w)(' + GEN_PREPS + r'|с(?=\s+\d+(?:,\d+)?\s+до(?!\w)))(\s+)'
    r'(\d{1,3}(?:\s\d{3})+(?:,\d+)?|\d+(?:,\d+)?)(?!\d|,\d)',
    re.IGNORECASE)


def genitive_numbers(text):
    """'от 35 до 44,9' -> 'от тридцати пяти до сорока четырёх целых девяти десятых'.
    Только после предлогов, требующих родительного падежа; даты и годы не трогаем."""
    def sub(m):
        prep, sp, num = m.group(1), m.group(2), m.group(3)
        num = re.sub(r'\s', '', num)                      # 21 000 -> 21000
        nm = re.match(r'\s+([А-Яа-яЁё]+)', m.string[m.end():])
        nxt = nm.group(1).lower() if nm else ''
        if nxt in MONTHS_GEN or (nxt.startswith('год') and ',' not in num and len(num) == 4):
            return m.group(0)
        fem = len(nxt) > 2 and nxt.endswith(('ы', 'и'))      # минуты, недели
        if ',' in num:
            whole, frac = num.split(',')
            words = _decimal_gen(whole, frac)
            if words is None:
                return m.group(0)
        else:
            n = int(num)
            if n >= 10 ** 12:
                return m.group(0)
            words = gen_words(n, fem)
        return prep + sp + words
    return _GEN_RE.sub(sub, text)


def numbers_to_words(text):
    """Дроби через запятую -> 'три целых пять десятых'; целые -> слова."""
    text = genitive_numbers(text)
    def dec(m):
        return _decimal_to_words(m.group(1), m.group(2))

    def integer(m):
        return num2words(int(m.group(0)), lang='ru')

    text = re.sub(r'(?<![\d,])(\d+),(\d+)(?!\d|,\d)', dec, text)
    text = re.sub(r'\d+', integer, text)
    return text


def split_long(sentence, max_len=MAX_LEN):
    """Длинное предложение режем по запятым/тире, не по словам."""
    if len(sentence) <= max_len:
        return [sentence]
    parts = re.split(r'(?<=[,;:—–])\s+', sentence)
    chunks, cur = [], ''
    for p in parts:
        if cur and len(cur) + 1 + len(p) > max_len:
            chunks.append(cur)
            cur = p
        else:
            cur = (cur + ' ' + p).strip()
    if cur:
        chunks.append(cur)
    return chunks


def prepare_paragraph_ex(text):
    """Как prepare_paragraph, но с номером предложения: [(номер, кусок)]."""
    text = text.replace('\u00a0', ' ')
    text = re.sub(r'\s+', ' ', text).strip()
    text = numbers_to_words(text)
    out, k = [], 0
    for s in re.split(r'(?<=[,;:—–.!?…])\s+', text):
        s = s.strip()
        if s:
            out += [(k, ch) for ch in split_long(s)]
            k += 1
    return out


def prepare_paragraph(text):
    """Абзац -> список коротких предложений для озвучки."""
    text = text.replace('\u00a0', ' ')
    text = re.sub(r'\s+', ' ', text).strip()
    text = numbers_to_words(text)
    sentences = re.split(r'(?<=[,;:—–.!?…])\s+', text)
    result = []
    for s in sentences:
        s = s.strip()
        if s:
            result.extend(split_long(s))
    return result


# ---------- озвучка ----------
QUESTION_FOCUS = True   # интонационный центр вопроса: *последнее слово*
YO_FROM_BOOK = True     # «ё» только если она есть в тексте; иначе решает Silero

WORD_RE = re.compile(r'[А-Яа-яЁё+]+')

SAM_FIX = True          # самый / сам: с+амое, с+амого (до самого утра) или сам+ого (самого мага)
SAM_AMBIG = {'самого': ('с+амого', 'сам+ого'), 'самому': ('с+амому', 'сам+ому'),
             'самом': ('с+амом', 'сам+ом'), 'самой': ('с+амой', 'сам+ой')}
SAM_PREPS = {'до', 'с', 'со', 'в', 'во', 'на', 'по', 'от', 'к', 'ко', 'из'}
_morph = None


def _get_morph():
    global _morph
    if _morph is None:
        try:
            import pymorphy3
            _morph = pymorphy3.MorphAnalyzer()
        except Exception:
            _morph = False
    return _morph or None


def _adj_anim(word):
    """(похоже на прилагательное/числительное, похоже на одушевлённое существительное)."""
    m = _get_morph()
    if m is None or not word:
        return 0.0, 0.0
    adj = anim = 0.0
    for p in m.parse(word):
        if p.tag.POS in ('ADJF', 'ADJS', 'PRTF', 'PRTS', 'NUMR', 'COMP'):
            adj += p.score
        elif p.tag.POS == 'NOUN' and p.tag.animacy == 'anim':
            anim += p.score
    return adj, anim


def fix_sam(text):
    """«самое» всегда с+амое. «самого/самой/самому/самом» по соседним словам:
    перед прилагательным или после предлога времени/места (до самого утра) это «самый»
    (с+амого), а перед одушевлённым существительным и в прочих случаях «сам» (сам+ого мага)."""
    words = list(WORD_RE.finditer(text))
    plain = lambda m: m.group(0).replace('+', '').lower()
    out, last = [], 0
    for i, m in enumerate(words):
        p = plain(m)
        if p == 'самое':
            new = 'с+амое'
        elif p in SAM_AMBIG:
            prev = plain(words[i - 1]) if i > 0 else ''
            nxt = plain(words[i + 1]) if i + 1 < len(words) else ''
            adj, anim = _adj_anim(nxt)
            if adj >= 0.5:
                k = 0
            elif anim >= 0.5:
                k = 1
            elif prev in SAM_PREPS:
                k = 0
            else:
                k = 1
            new = SAM_AMBIG[p][k]
        else:
            continue
        if m.group(0).lstrip('+')[:1].isupper():
            new = new.capitalize()
        out.append(text[last:m.start()])
        out.append(new)
        last = m.end()
    out.append(text[last:])
    return ''.join(out)


PHONETIC_G = True       # -ого/-его читаем как -ова/-ево (четвёртого -> четвёртова)
# слова, где «г» в -ого остаётся (наречия и т.п.); дополняй при необходимости
KEEP_G = {'много', 'немного', 'строго', 'дорого', 'убого', 'итого', 'ого', 'лего'}


def phonetic_g(text):
    """Произношение: 'четв+ёртого' -> 'четв+ёртово', 'сегодня' -> 'севодня'."""
    def fix(m):
        w = m.group(0)
        plain = w.replace('+', '').lower()
        if plain.startswith('сегодн'):
            w = re.sub(r'^(с\+?е)г(?=\+?одн)', r'\1в', w, flags=re.IGNORECASE)
        if plain not in KEEP_G and plain.endswith(('ого', 'его')):
            w = re.sub(r'(\+?[оеОЕ])([гГ])(\+?[оО])$',
                       lambda k: k.group(1) + ('В' if k.group(2) == 'Г' else 'в') + k.group(3),
                       w)
        return w
    return WORD_RE.sub(fix, text)


def undo_yo(original, accented):
    """RUAccent иногда сам меняет е->ё (небо -> нёбо). Если в исходном
    предложении слово было с «е», возвращаем «е»; ё-фикацией займётся Silero."""
    ow = {w.replace('+', '').lower() for w in WORD_RE.findall(original)}

    def fix(m):
        w = m.group(0)
        if 'ё' not in w.lower():
            return w
        plain = w.replace('+', '').lower()
        if plain in ow:                      # в книге слово было с «ё»
            return w
        if plain.replace('ё', 'е') in ow:    # в книге была «е»
            return w.replace('ё', 'е').replace('Ё', 'Е')
        return w
    return WORD_RE.sub(fix, accented)


# Звёздочки (интонационный центр) нужны только общим вопросам («Ты дома?»). У вопросов с
# вопросительным словом, с «или» и «не так ли?» модель и так интонирует сама (по описанию
# авторов Silero), а лишний акцент на последнем слове даёт заметный подъём тона.
QUESTION_STARS = 'off'          # 'off' - значения модели по умолчанию; 'general' - только общие вопросы; 'all' - все
QUESTION_INTENSITY = None       # сила вопросительной интонации (по умолчанию в модели 3); None = не задавать
QUESTION_WORDS = {'кто', 'что', 'где', 'когда', 'куда', 'откуда', 'почему', 'зачем', 'как',
                  'какой', 'какая', 'какое', 'какие', 'каков', 'каковы', 'который', 'которая',
                  'которое', 'которые', 'сколько', 'чей', 'чья', 'чьё', 'чьи', 'чем', 'чему',
                  'кого', 'кому', 'кем', 'ком', 'чего', 'отчего', 'разве', 'неужели', 'почём'}
_LEAD = {'а', 'и', 'ну', 'так', 'но', 'же', 'вот', 'тогда', 'значит'}


def is_general_question(text):
    """Общий вопрос (да/нет). Специальные, альтернативные и «хвостики» -> False."""
    plain = text.replace('+', '').replace('*', '').lower()
    words = re.findall(r'[а-яё]+', plain)
    if re.search(r',\s*(не так ли|не правда ли|правда|да|верно|нет|ладно|хорошо)\s*\?+\W*$', plain):
        return False                                        # вопрос-хвостик
    if 'или' in words:
        return False                                        # альтернативный
    head = [w for w in words[:3] if w not in _LEAD][:1]     # вопросительное слово в начале
    return not (head and head[0] in QUESTION_WORDS)


def mark_question(text):
    """'Ты уже дом+а?' -> 'Ты уже *дом+а*?' (для v5_4_ru), по QUESTION_STARS."""
    if QUESTION_STARS == 'off' or not QUESTION_FOCUS or '*' in text:
        return text
    if QUESTION_STARS == 'general' and not is_general_question(text):
        return text
    return re.sub(r'([А-Яа-яЁё+]+)(\W*\?+\W*)$', r'*\1*\2', text)


def _say_sentence(sentence, pairs):
    # Ручные акценты извлекаются до RUAccent, который может удалить звёздочки
    # как пунктуацию. После расстановки ударений маркеры возвращаются на место.
    source_text, emphasis_marks = extract_emphasis(sentence)
    try:
        accented = clean(accentizer.process_all(source_text))
        if YO_FROM_BOOK:
            accented = undo_yo(source_text, accented)
        accented = force_stress(accented)
        if SAM_FIX:
            accented = fix_sam(accented)
        accented = apply_dictionary(accented, pairs)
        auto = False
    except Exception as e:
        # запасной вариант: ударения ставит сам Silero
        print('  RUAccent сбой, ударения ставит Silero:', repr(e)[:80])
        accented = apply_dictionary(fix_sam(source_text) if SAM_FIX else source_text, pairs)
        auto = True
    if PHONETIC_G:
        accented = phonetic_g(accented)
    accented = mark_question(accented)
    accented, missing_marks = restore_emphasis(accented, emphasis_marks, report_missing=True)
    for mark in missing_marks:
        target = ' '.join(mark['words'])
        print(f'  предупреждение: акцент уровня {mark["level"]} не восстановлен '
              f'(фрагмент изменён обработкой: {target!r})')
    print('  ', accented)
    kw = {}
    if QUESTION_INTENSITY is not None and accented.rstrip().endswith('?'):
        kw['intensity'] = QUESTION_INTENSITY
    try:
        audio = model.apply_tts(text=PREFIX + accented, speaker=SPEAKER,
                                sample_rate=SAMPLE_RATE,
                                put_accent=True, put_yo=not YO_FROM_BOOK, **kw)
    except TypeError:                       # модель без параметра intensity
        audio = model.apply_tts(text=PREFIX + accented, speaker=SPEAKER,
                                sample_rate=SAMPLE_RATE,
                                put_accent=True, put_yo=not YO_FROM_BOOK)
    return audio

def say_sentence(sentence, pairs):
    # Удлинение междометий перед многоточием делается только в копии для TTS.
    # Исходная пунктуация остаётся доступной вызывающему коду для расчёта паузы.
    sentence = prepare_tts_text(sentence)
    with TTS_LOCK:                    # модель одна: книга, редактор и словарь не мешают друг другу
        return _say_sentence(sentence, pairs)


def say(text, name, pairs):
    sentences = prepare_paragraph(text)
    if not sentences:
        return
    pieces = []
    for index, sentence in enumerate(sentences):
        pieces.append(say_sentence(sentence, pairs))
        if index < len(sentences) - 1:
            duration_ms = pause_ms(sentence)
            if duration_ms:
                pieces.append(np.zeros(int(SAMPLE_RATE * duration_ms / 1000), dtype=np.float32))
    audio = np.concatenate(pieces)

    wav = str(OUT_DIR / (name + '.wav'))
    mp3 = str(OUT_DIR / (name + '.mp3'))
    sf.write(wav, audio, SAMPLE_RATE)
    subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', wav,
                    '-codec:a', 'libmp3lame', '-q:a', '3', mp3],
                   check=True)
    os.remove(wav)


def main():
    OUT_DIR.mkdir(exist_ok=True)
    pairs = load_dictionary(DICT_FILE)
    lines = [l.strip() for l in
             PHRASES_FILE.read_text(encoding='utf-8-sig').splitlines()
             if l.strip()]
    for i, line in enumerate(lines, 1):
        print(f"[{i}/{len(lines)}]")
        say(line, f"{i:03d}", pairs)
    print("готово")


if __name__ == "__main__":
    main()