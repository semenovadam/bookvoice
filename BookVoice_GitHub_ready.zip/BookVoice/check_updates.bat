@echo off
cd /d "%~dp0"
if not exist "venv\Scripts\python.exe" goto novenv
set "VIRTUAL_ENV=%~dp0venv"
set "PATH=%~dp0venv\Scripts;%PATH%"
set "PYTHONHOME="
echo === Outdated packages (nothing is installed) ===
python -m pip list --outdated
echo.
echo === Refreshing Silero repo cache (new models appear here) ===
python -c "import model_dirs; model_dirs.apply(); import torch; torch.hub.load('snakers4/silero-models','silero_tts',language='ru',speaker=model_dirs.SILERO_MODEL,force_reload=True); print('ok:', model_dirs.SILERO_MODEL)"
goto done
:novenv
echo venv\Scripts\python.exe was not found in %~dp0
:done
echo.
pause
