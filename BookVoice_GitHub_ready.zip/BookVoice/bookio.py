"""Чтение и запись книг: fb2, txt, md, docx на входе; fb2, epub, mobi, txt, md на выходе.
Старый бинарный .doc не поддерживается (сохрани его как .docx)."""
import base64
import datetime
import difflib
import hashlib
import json
import os
import re
import shutil
import tempfile
import uuid
import xml.etree.ElementTree as ET
import zipfile
from dataclasses import dataclass, field, replace
from pathlib import Path
from xml.sax.saxutils import escape

import bookexport
import layoutmarks as lm
from book import CH_RE, read_txt

SKIP_IDS = {'titlepage', 'toc'}                 # служебные разделы, которые пишем сами
SKIP_TITLES = ('содержание', 'оглавление')
_CTRL = re.compile(r'[\x00-\x08\x0b\x0c\x0e-\x1f]')


@dataclass
class Book:
    title: str = ''
    author: str = ''
    lang: str = 'ru'
    cover: bytes = None
    chapters: list = field(default_factory=list)      # [(название, [абзацы])]
    annotations: list = field(default_factory=list)   # [{chapter, paragraph, start, end, level, quote, context}]
    images: list = field(default_factory=list)        # картинки внутри главы: [{slot, data, name}]; slot = индекс главы
    layout: list = field(default_factory=list)        # оформление: [{chapter, paragraph, kind}], kind = empty | page | verse
                                                      # (см. layoutmarks; в fb2 это empty-line, новая секция, poem)
    number_from: object = None                        # номер главы (с нуля), с которой начинается «Глава 1»; None = без нумерации
    number_format: str = lm.DEFAULT_NUMBER_FORMAT     # как подписывать: «Глава {n} - {title}»
    number_excluded: list = field(default_factory=list)  # индексы глав, исключённых из автоматической нумерации


def _clean(s):
    return re.sub(r'\s+', ' ', s.replace('\u00a0', ' ')).strip()


def _read_text(path):
    raw = Path(path).read_bytes()
    try:
        return raw.decode('utf-8-sig')
    except UnicodeDecodeError:
        return raw.decode('cp1251')


# ---------------------------------------------------------------- чтение
_BV_INFO_TYPE = 'urn:bookvoice:annotations:v1'
_BV_COMMENT_PREFIX = 'BOOKVOICE-ANNOTATIONS-V1:'
_BV_NUMBERING_TYPE = 'urn:bookvoice:numbering:v1'


def _annotation_payload(annotations, chapters):
    """Validate and canonicalize annotations before storing them in FB2."""
    clean = []
    for a in annotations or []:
        try:
            ci, pi = int(a['chapter']), int(a['paragraph'])
            start, end, level = int(a['start']), int(a['end']), int(a['level'])
            text = chapters[ci][1][pi]
            if level not in (1, 2) or start < 0 or end <= start or ci < 0 or pi < 0:
                continue                 # отрицательные номера в Python означают «с конца»
            quote = str(a.get('quote', ''))
            if not quote:
                continue
            context = str(a.get('context', ''))
            end = start + len(quote)
            if end > len(text) or text[start:end] != quote:
                # The paragraph may have been edited before BookVoice reopened it.
                # Re-anchor only when the exact quote has one clear, context-supported location.
                hits, pos = [], 0
                while True:
                    pos = text.find(quote, pos)
                    if pos < 0:
                        break
                    hits.append(pos); pos += max(1, len(quote))
                if not hits:
                    continue
                if len(hits) == 1:
                    start = hits[0]
                elif context:
                    scored = []
                    for pos in hits:
                        candidate = text[max(0, pos-24):min(len(text), pos+len(quote)+24)]
                        score = difflib.SequenceMatcher(None, context, candidate, autojunk=False).ratio()
                        scored.append((score, pos))
                    scored.sort(reverse=True)
                    if len(scored) > 1 and scored[0][0] - scored[1][0] < 0.08:
                        continue
                    start = scored[0][1]
                else:
                    continue
                end = start + len(quote)
            clean.append({'chapter': ci, 'paragraph': pi, 'start': start, 'end': end,
                          'level': level, 'quote': quote,
                          'context': text[max(0, start-24):min(len(text), end+24)]})
        except (KeyError, TypeError, ValueError, IndexError):
            continue
    clean.sort(key=lambda x: (x['chapter'], x['paragraph'], x['start'], x['end'], x['level']))
    # Overlapping ranges are ambiguous; keep the first deterministic range only.
    out = []
    for a in clean:
        if out and (a['chapter'], a['paragraph']) == (out[-1]['chapter'], out[-1]['paragraph']) and a['start'] < out[-1]['end']:
            continue
        out.append(a)
    return out


normalize_annotations = _annotation_payload     # публичное имя для редактора


def _payload_text(annotations):
    body = json.dumps(annotations, ensure_ascii=False, separators=(',', ':'), sort_keys=True)
    digest = hashlib.sha256(body.encode('utf-8')).hexdigest()
    return json.dumps({'version': 1, 'sha256': digest, 'annotations': annotations},
                      ensure_ascii=False, separators=(',', ':'), sort_keys=True)


def _decode_payload(raw):
    try:
        obj = json.loads(raw or '')
        if not isinstance(obj, dict) or obj.get('version') != 1 or not isinstance(obj.get('annotations'), list):
            return None
        body = json.dumps(obj['annotations'], ensure_ascii=False, separators=(',', ':'), sort_keys=True)
        if hashlib.sha256(body.encode('utf-8')).hexdigest() != obj.get('sha256'):
            return None
        return obj['annotations']
    except (ValueError, TypeError):
        return None


def _extract_legacy_markers(book):
    """One-time migration from older BookVoice files with literal *…* markers."""
    found = []
    pattern = re.compile(r'(?<!\w)\*\*([^*\n]+?)\*\*(?!\w)|(?<![\w*])\*([^\s*](?:[^*\n]*?[^\s*])?)\*(?!\w)')
    for ci, (title, paras) in enumerate(book.chapters):
        for pi, paragraph in enumerate(paras):
            out, cursor, plain_pos = [], 0, 0
            for m in pattern.finditer(paragraph):
                before = paragraph[cursor:m.start()]
                out.append(before); plain_pos += len(before)
                marked = m.group(1) if m.group(1) is not None else m.group(2)
                # Do not treat conventional scene separators such as '* * *' as accents.
                if not marked.strip() or not re.search(r'[A-Za-zА-Яа-яЁё]', marked):
                    out.append(paragraph[cursor:m.end()])
                    plain_pos += len(paragraph[cursor:m.end()])
                    cursor = m.end()
                    continue
                level = 2 if m.group(1) is not None else 1
                start = plain_pos
                out.append(marked); plain_pos += len(marked)
                found.append({'chapter': ci, 'paragraph': pi, 'start': start, 'end': plain_pos,
                              'level': level, 'quote': marked,
                              'context': paragraph[max(0, m.start()-24):min(len(paragraph), m.end()+24)]})
                cursor = m.end()
            out.append(paragraph[cursor:])
            paras[pi] = ''.join(out)
    return found


def annotations_as_markers(book):
    """Return a copy of chapters with Silero markers injected only for TTS."""
    chapters = [(t, list(p)) for t, p in book.chapters]
    anns = _annotation_payload(book.annotations, chapters)
    by_para = {}
    for a in anns:
        by_para.setdefault((a['chapter'], a['paragraph']), []).append(a)
    for (ci, pi), ranges in by_para.items():
        text = chapters[ci][1][pi]
        for a in sorted(ranges, key=lambda x: x['start'], reverse=True):
            marker = '**' if a['level'] == 2 else '*'
            text = text[:a['start']] + marker + text[a['start']:a['end']] + marker + text[a['end']:]
        chapters[ci][1][pi] = text
    return chapters


def read_fb2(path):
    # Preserve XML comments so a BookVoice backup payload can be recovered if custom-info is removed.
    parser = ET.XMLParser(target=ET.TreeBuilder(insert_comments=True))
    root = ET.parse(path, parser=parser).getroot()
    # Комментарии XML теперь тоже узлы дерева (insert_comments=True): у них tag не строка.
    # Для них имя пустое, поэтому все проверки по имени тега их просто пропускают.
    ln = lambda e: e.tag.rsplit('}', 1)[-1] if isinstance(e.tag, str) else ''
    def text_of(e):
        # При сохранении XML-комментариев Element.itertext() включает их содержимое.
        # Для текста книги комментарии должны быть прозрачны, но их хвостовой текст сохраняется.
        parts = []
        for node in e.iter():
            if isinstance(node.tag, str) and node.text:
                parts.append(node.text)
            if node is not e and node.tail:
                parts.append(node.tail)
        return _clean(''.join(parts))

    def find(e, name):
        for x in e.iter():
            if ln(x) == name:
                return x
        return None

    b = Book()
    ti = find(root, 'title-info')
    if ti is not None:
        t = find(ti, 'book-title')
        b.title = text_of(t) if t is not None else ''
        a = find(ti, 'author')
        if a is not None:
            parts = []
            for n in ('first-name', 'middle-name', 'last-name', 'nickname'):
                x = find(a, n)
                if x is not None and text_of(x):
                    parts.append(text_of(x))
            b.author = ' '.join(parts)
        lang = find(ti, 'lang')
        if lang is not None and text_of(lang):
            b.lang = text_of(lang)
        cp = find(ti, 'coverpage')
        img = find(cp, 'image') if cp is not None else None
        if img is not None:
            href = next((v for k, v in img.attrib.items() if k.endswith('href')), '')
            for x in root:
                if ln(x) == 'binary' and x.get('id') == href.lstrip('#'):
                    try:
                        b.cover = base64.b64decode(x.text or '')
                    except Exception:
                        b.cover = None

    ids = {}                    # номер главы у читателя -> номер при записи (id="chN")
    binaries = {x.get('id'): x for x in root if ln(x) == 'binary' and x.get('id')}

    def take_images(sec, chapters_before, appended):
        """Картинки BookVoice, привязанные к главе. Новые файлы имеют id «bv-chapter-img-…»; старые
        id «bv-first-…» и «bv-img-…» продолжаем читать для обратной совместимости. Чужие картинки не трогаем."""
        for ch in sec:
            if ln(ch) != 'image':
                continue
            iid = ch.get('id') or ''
            if not iid.startswith(('bv-first-', 'bv-img-', 'bv-chapter-img-')):
                continue
            href = next((v for k, v in ch.attrib.items() if k.endswith('href')), '').lstrip('#')
            node = binaries.get(href)
            try:
                data = base64.b64decode((node.text or '') if node is not None else '')
            except Exception:
                data = b''
            if data:
                slot = (chapters_before if iid.startswith(('bv-first-', 'bv-chapter-img-'))
                        else chapters_before + (1 if appended else 0))
                b.images.append({'slot': slot, 'data': data, 'name': ch.get('alt') or ''})

    def read_block(el, paras, lay):
        """Эпиграф, стихотворение, цитата: строки стиха (v) помечаются как verse, пустая строка между строфами
        и пустые строки (empty-line) становятся оформлением, абзацы p читаются как раньше."""
        stanzas = 0
        for x in el:
            name = ln(x)
            if name == 'p':
                text = text_of(x)
                if text:
                    paras.append(text)
            elif name == 'v':
                text = text_of(x)
                if text:
                    lay.append({'paragraph': len(paras), 'kind': lm.KIND_VERSE})
                    paras.append(text)
            elif name == 'empty-line':
                lay.append({'paragraph': len(paras), 'kind': lm.KIND_EMPTY})
            elif name == 'stanza':
                if stanzas:
                    lay.append({'paragraph': len(paras), 'kind': lm.KIND_EMPTY})
                stanzas += 1
                read_block(x, paras, lay)
            elif name in ('poem', 'epigraph', 'cite', 'title'):
                read_block(x, paras, lay)

    def walk(sec):
        title, paras, lay = '', [], []
        for ch in sec:
            t = ln(ch)
            if t == 'title':
                title = text_of(ch)
            elif t == 'p':
                p = text_of(ch)
                if p:
                    if 'center' in (ch.get('style') or '').lower() and any(ln(y) == 'emphasis' for y in ch.iter()):
                        lay.append({'paragraph': len(paras), 'kind': lm.KIND_CENTER})
                    paras.append(p)
            elif t == 'empty-line':
                lay.append({'paragraph': len(paras), 'kind': lm.KIND_EMPTY})
            elif t in ('epigraph', 'poem', 'cite'):
                read_block(ch, paras, lay)
        skip = sec.get('id') in SKIP_IDS or title.lower().startswith(SKIP_TITLES)
        before = len(b.chapters)
        if (sec.get('id') or '').startswith('bv-page-') and not title and b.chapters:
            # продолжение предыдущей главы «с новой страницы»: BookVoice пишет такой кусок отдельной секцией
            ci = len(b.chapters) - 1
            head, prev = b.chapters[ci]
            b.layout.append({'chapter': ci, 'paragraph': len(prev), 'kind': lm.KIND_PAGE})
            b.layout += [dict(e, chapter=ci, paragraph=e['paragraph'] + len(prev)) for e in lay]
            b.chapters[ci] = (head, prev + paras)
        elif paras and not skip:
            m = re.fullmatch(r'ch(\d+)', sec.get('id') or '')
            if m:
                ids[len(b.chapters)] = int(m.group(1)) - 1
            b.layout += [dict(e, chapter=len(b.chapters)) for e in lay]
            b.chapters.append((title or f'Глава {len(b.chapters) + 1}', paras))
        take_images(sec, before, len(b.chapters) > before)
        for ch in sec:
            if ln(ch) == 'section':
                walk(ch)

    for body in root:
        if ln(body) == 'body' and body.get('name') != 'notes':
            for sec in body:
                if ln(sec) == 'section':
                    walk(sec)
    # Нумерация глав («Глава 1 - …»): с какой главы и по какому формату. Названия в книге хранятся без номера.
    for x in root.iter():
        if isinstance(x.tag, str) and ln(x) == 'custom-info' and x.get('info-type') == _BV_NUMBERING_TYPE:
            try:
                info = json.loads(x.text or '')
                fmt, written = info['format'], int(info['start'])
                excluded_written = set(int(x) for x in info.get('excluded', []))
            except (ValueError, KeyError, TypeError):
                break
            if lm.valid_number_format(fmt) and written >= 0:
                start = next((r for r in range(len(b.chapters)) if ids.get(r, r) >= written), None)
                if start is not None:
                    b.number_from, b.number_format = start, fmt
                    b.number_excluded = [r for r in range(len(b.chapters)) if ids.get(r, r) in excluded_written]
                    num = 0
                    for i in range(start, len(b.chapters)):
                        if i in b.number_excluded:
                            continue
                        num += 1
                        title, paras = b.chapters[i]
                        b.chapters[i] = (lm.strip_number(title, fmt, num), paras)
            break
    # Preferred storage: standard FB2 custom-info. Fallback: a BookVoice XML comment.
    raw = None
    for x in root.iter():
        if isinstance(x.tag, str) and x.tag.rsplit('}', 1)[-1] == 'custom-info' and x.get('info-type') == _BV_INFO_TYPE:
            candidate = _decode_payload(x.text or '')
            if candidate is not None:
                raw = candidate
                break
    if raw is None:
        for x in root.iter():
            if x.tag is ET.Comment and (x.text or '').startswith(_BV_COMMENT_PREFIX):
                try:
                    comment_data = base64.urlsafe_b64decode((x.text or '')[len(_BV_COMMENT_PREFIX):].encode('ascii')).decode('utf-8')
                except Exception:
                    comment_data = ''
                raw = _decode_payload(comment_data)
                if raw is not None:
                    break
    legacy = _extract_legacy_markers(b) if raw is None else []
    if raw and ids:
        # В файле номера глав считались по списку при записи. Пустые главы и разделы
        # «Содержание/Оглавление» при чтении пропускаются, поэтому номера надо пересчитать.
        back = {w: r for r, w in ids.items()}
        raw = [dict(a, chapter=back[a['chapter']]) for a in raw
               if isinstance(a, dict) and a.get('chapter') in back]
    b.annotations = _annotation_payload((raw or []) + legacy, b.chapters)
    return b


MD_STARS_ARE_ACCENTS = True     # True: *курсив* и **жирный** в .md остаются маркерами акцента Silero;
                                # False: убираются, как было раньше (читаются без акцентов)


def _md_clean(s):
    s = re.sub(r'!\[[^\]]*\]\([^)]*\)', '', s)
    s = re.sub(r'\[([^\]]*)\]\([^)]*\)', r'\1', s)
    # *…* и **…** в BookVoice — управляющие маркеры акцента Silero, они должны переживать
    # сохранение и повторное открытие Markdown. Подчёркивания (_курсив_, __жирный__) маркерами
    # не являются, их убираем, как раньше: иначе они попадут в озвучку как есть.
    s = re.sub(r'__(.+?)__', r'\1', s)
    s = re.sub(r'(?<![\w*_])_(\S(?:.*?\S)?)_(?![\w*_])', r'\1', s)
    if not MD_STARS_ARE_ACCENTS:
        s = re.sub(r'\*\*(.+?)\*\*', r'\1', s)
        s = re.sub(r'(?<![\w*])\*(\S(?:.*?\S)?)\*(?![\w*])', r'\1', s)
    s = re.sub(r'`([^`]*)`', r'\1', s)
    return _clean(s)


def _md_paras(lines):
    paras, cur = [], []

    def flush():
        if cur:
            paras.append(_md_clean(' '.join(cur)))
            cur.clear()

    for l in lines + ['']:
        s = l.strip()
        if not s or re.fullmatch(r'[-*_]{3,}', s):
            flush()
            continue
        s = re.sub(r'^>\s?', '', s)
        if re.match(r'^[-*+]\s+', s):
            flush()
            s = re.sub(r'^[-*+]\s+', '', s)
        cur.append(s)
    return [p for p in paras if p]


def read_md(path):
    lines = _read_text(path).replace('\r\n', '\n').split('\n')
    heads = [len(m.group(1)) for l in lines if (m := re.match(r'^(#{1,6})\s+\S', l))]
    h1_is_title = heads.count(1) == 1 and any(h >= 2 for h in heads)
    b = Book(title=Path(path).stem)
    title, buf = 'Начало', []

    def flush():
        paras = _md_paras(buf)
        if paras:
            b.chapters.append((title, paras))
        buf.clear()

    expect_author = False
    for l in lines:
        if expect_author and l.strip():
            expect_author = False
            a = re.fullmatch(r'[*_]([^*_]+)[*_]', l.strip())
            if a:                                   # строка *Автор* сразу под заголовком книги
                b.author = a.group(1).strip()
                continue
        m = re.match(r'^(#{1,6})\s+(.*?)\s*#*\s*$', l)
        if m:
            lvl, t = len(m.group(1)), _md_clean(m.group(2))
            if lvl == 1 and h1_is_title:
                b.title = t
                expect_author = True
                continue
            flush()
            title = t or 'Глава'
        else:
            buf.append(l)
    flush()
    return b


def read_docx(path):
    W = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
    with zipfile.ZipFile(path) as z:
        root = ET.fromstring(z.read('word/document.xml'))
        meta = {}
        try:
            core = ET.fromstring(z.read('docProps/core.xml'))
            for x in core:
                meta[x.tag.rsplit('}', 1)[-1]] = (x.text or '').strip()
        except Exception:
            pass
    items = []
    for p in root.iter(W + 'p'):
        st = p.find(f'{W}pPr/{W}pStyle')
        style = (st.get(W + 'val') if st is not None else '') or ''
        txt = ''.join((n.text or '') if n.tag == W + 't' else ' '
                      for n in p.iter() if n.tag in (W + 't', W + 'tab', W + 'br'))
        txt = _clean(txt)
        if txt:
            items.append((style.lower(), txt))
    b = Book(title=meta.get('title', '') or Path(path).stem, author=meta.get('creator', ''))
    is_head = lambda s: s.startswith(('heading', 'заголовок'))
    has_heads = any(is_head(s) for s, _ in items)
    title, paras = 'Начало', []

    def flush():
        if paras:
            b.chapters.append((title, list(paras)))
            paras.clear()

    for style, txt in items:
        if style.startswith(('title', 'название')) and not b.chapters and not paras:
            b.title = txt
        elif (has_heads and is_head(style)) or (not has_heads and CH_RE.match(txt) and len(txt) < 80):
            flush()
            title = txt
        else:
            paras.append(txt)
    flush()
    return b


def read_any(path):
    p = Path(path)
    ext = p.suffix.lower()
    if ext == '.fb2':
        b = read_fb2(p)
    elif ext == '.docx':
        b = read_docx(p)
    elif ext in ('.md', '.markdown'):
        b = read_md(p)
    elif ext in ('.txt', ''):
        b = Book(chapters=read_txt(p))
    elif ext == '.doc':
        raise ValueError('Старый формат .doc не поддерживается. '
                         'Открой файл в Word или LibreOffice и сохрани как .docx.')
    else:
        raise ValueError(f'Неизвестный формат: {ext}')
    if not b.title:
        b.title = p.stem
    return b


# ---------------------------------------------------------------- несколько файлов -> одна книга
BOOK_EXTS = ('.fb2', '.md', '.markdown', '.txt', '.docx')
GENERIC_TITLES = ('', 'начало')            # так читалки называют кусок текста без заголовка


def natural_key(path):
    """Ключ «человеческой» сортировки: гл2.md идёт раньше гл10.md, регистр не важен."""
    name = Path(path).name.lower()
    return [(0, int(t), '') if t.isdigit() else (1, 0, t) for t in re.split(r'(\d+)', name)]


def expand_paths(paths):
    """Список файлов для книги: папки заменяются своими книжными файлами (md, txt, docx, fb2; вложенные папки
    не берём), повторы убираются, порядок естественный (по папке, затем по имени с числами по величине)."""
    seen, found = set(), []
    for raw in paths:
        p = Path(str(raw).strip().strip('{}'))
        if p.is_dir():
            try:
                items = [c for c in p.iterdir()
                         if c.is_file() and c.suffix.lower() in BOOK_EXTS and not c.name.startswith(('.', '~$'))]
            except OSError:
                items = []
        else:
            items = [p]
        for c in items:
            key = str(c).lower()
            if key not in seen:
                seen.add(key)
                found.append(c)
    found.sort(key=lambda c: (str(c.parent).lower(), natural_key(c)))
    return found


@dataclass
class Merged:
    book: Book
    used: list = field(default_factory=list)          # имена файлов, из которых взят текст
    skipped: list = field(default_factory=list)       # [(имя файла, причина)]


def merge_files(paths):
    """Собрать одну книгу из нескольких файлов. Каждый файл даёт главу (или несколько, если в нём несколько
    заголовков, как у fb2 и md с разделами). Безымянный кусок получает имя из заголовка файла или самого файла.
    Файл, который не читается или пуст, пропускается и попадает в skipped, остальные не страдают.
    Название книги: у одного файла своё, у нескольких имя общей папки (иначе название первого файла);
    автор, язык и обложка берутся из первого файла, где они есть."""
    files = expand_paths(paths)
    out = Merged(book=Book())
    first_meta = None
    for f in files:
        try:
            b = read_any(f)
        except Exception as e:
            out.skipped.append((f.name, str(e) or type(e).__name__))
            continue
        kept = [i for i, (_t, ps) in enumerate(b.chapters) if ps]
        if not kept:
            out.skipped.append((f.name, 'в файле нет текста'))
            continue
        chapters = [(b.chapters[i][0], list(b.chapters[i][1])) for i in kept]
        if len(chapters) == 1 and chapters[0][0].strip().lower() in GENERIC_TITLES:
            chapters[0] = (b.title or f.stem, chapters[0][1])
        offset = len(out.book.chapters)
        position = {old: offset + new for new, old in enumerate(kept)}
        for a in getattr(b, 'annotations', []):           # акценты BookVoice переезжают вместе с главами
            try:
                new_index = position[int(a['chapter'])]
            except (KeyError, TypeError, ValueError):
                continue
            out.book.annotations.append(dict(a, chapter=new_index))
        for e in getattr(b, 'layout', []):                # оформление (стихи, пустые строки, страницы) тоже
            try:
                out.book.layout.append(dict(e, chapter=position[int(e['chapter'])]))
            except (KeyError, TypeError, ValueError):
                continue
        for im in getattr(b, 'images', []):               # изображения переезжают вместе с привязанными главами
            try:
                slot = int(im['slot'])
            except (KeyError, TypeError, ValueError):
                continue
            out.book.images.append(dict(im, slot=offset + sum(1 for k in kept if k < slot)))
        out.book.chapters.extend(chapters)
        out.used.append(f.name)
        if first_meta is None:
            first_meta = (b.title or f.stem)
        if not out.book.author and b.author:
            out.book.author = b.author
        if not out.book.cover and b.cover:
            out.book.cover = b.cover
        if b.lang and out.book.lang == 'ru':
            out.book.lang = b.lang
    if len(out.used) == 1:
        out.book.title = first_meta
    elif out.used:
        parents = {f.parent for f in files if f.name in out.used}
        folder = next(iter(parents)).name if len(parents) == 1 else ''
        out.book.title = folder or first_meta
    return out


# ---------------------------------------------------------------- запись
def _x(s):
    return escape(_CTRL.sub('', s))


def _layout_by_chapter(book):
    out = {}
    for e in getattr(book, 'layout', None) or []:
        try:
            out.setdefault(int(e['chapter']), []).append(e)
        except (KeyError, TypeError, ValueError):
            continue
    return out


def _tokens(paras, layout):
    """Абзацы + оформление главы -> метки пустых строк/страниц и абзацы со стихом или центрированным курсивом."""
    before, verse, center = {}, set(), set()
    for e in lm.clamp_layout(layout, len(paras)):
        if e['kind'] == lm.KIND_VERSE:
            verse.add(e['paragraph'])
        elif e['kind'] == lm.KIND_CENTER:
            center.add(e['paragraph'])
        else:
            before.setdefault(e['paragraph'], []).append(e['kind'])
    toks = []
    for p in range(len(paras) + 1):
        toks += [(kind,) for kind in before.get(p, [])]
        if p < len(paras):
            toks.append(('p', paras[p], p in verse, p in center))
    return toks


def _split_pages(toks):
    pieces, cur = [], []
    for t in toks:
        if t[0] == lm.KIND_PAGE:
            pieces.append(cur)
            cur = []
        else:
            cur.append(t)
    pieces.append(cur)
    return pieces


def _verse_block(stanzas, epigraph):
    inner = ''.join('<stanza>' + ''.join(f'<v><emphasis>{_x(v)}</emphasis></v>' for v in st) + '</stanza>'
                    for st in stanzas)
    tag = 'epigraph' if epigraph else 'cite'
    return f'<{tag}><poem>{inner}</poem></{tag}>'


def _fb2_body(tokens):
    """Один кусок главы (между «новыми страницами») -> (эпиграфы, остальное) в виде строк fb2.
    Строки стиха идут стихотворением (курсив через emphasis, строфы по пустым строкам между ними).
    Стих, стоящий сразу после названия, это эпиграф (так принято для вводных стихов); если перед ним поставлена
    пустая строка, стих пишется цитатой, чтобы пустая строка осталась на месте (эпиграф по схеме обязан идти первым)."""
    lead, out, i = [], [], 0
    while i < len(tokens):
        t = tokens[i]
        if t[0] == lm.KIND_EMPTY:
            out.append('<empty-line/>')
            i += 1
        elif not t[2]:
            if len(t) > 3 and t[3]:
                out.append(f'<p style="text-align: center"><emphasis>{_x(t[1])}</emphasis></p>')
            else:
                out.append(f'<p>{_x(t[1])}</p>')
            i += 1
        else:
            end = k = i
            while k < len(tokens):                      # стих и пустые строки между его строками
                if tokens[k][0] == 'p' and tokens[k][2]:
                    end = k + 1
                elif tokens[k][0] != lm.KIND_EMPTY:
                    break
                k += 1
            stanzas = [[]]
            for tok in tokens[i:end]:
                if tok[0] == lm.KIND_EMPTY:
                    if stanzas[-1]:
                        stanzas.append([])
                else:
                    stanzas[-1].append(tok[1])
            stanzas = [st for st in stanzas if st]
            (lead if not out else out).append(_verse_block(stanzas, not out))
            i = end
    return lead, out


def display_titles(book):
    """Названия глав с номерами («Глава 1 - Дием»), если в книге задано, с какой главы они начинаются."""
    return lm.display_titles([t for t, _ in book.chapters], book.number_from, book.number_format,
                             getattr(book, 'number_excluded', []))


def export_view(book):
    """Книга для форматов без собственного оформления (epub, mobi, txt, md): те же главы, но с номерами в названиях."""
    titles = display_titles(book)
    return replace(book, chapters=[(t, p) for t, (_o, p) in zip(titles, book.chapters)])


def write_fb2(book, path, titlepage=True, toc=True):
    annotations = _annotation_payload(book.annotations, book.chapters)
    payload = _payload_text(annotations) if annotations else ''
    L = ['<?xml version="1.0" encoding="utf-8"?>',
         '<FictionBook xmlns="http://www.gribuser.ru/xml/fictionbook/2.0" '
         'xmlns:l="http://www.w3.org/1999/xlink">',
         '<description>', '<title-info>', '<genre>prose</genre>']
    parts = book.author.split()
    if len(parts) >= 2:
        L.append(f'<author><first-name>{_x(" ".join(parts[:-1]))}</first-name>'
                 f'<last-name>{_x(parts[-1])}</last-name></author>')
    else:
        L.append(f'<author><nickname>{_x(parts[0] if parts else "unknown")}</nickname></author>')
    L.append(f'<book-title>{_x(book.title or "Без названия")}</book-title>')
    if book.cover:
        L.append('<coverpage><image l:href="#cover"/></coverpage>')
    L.append(f'<lang>{_x(book.lang or "ru")}</lang>')
    today = datetime.date.today().isoformat()
    L += ['</title-info>',
          '<document-info><author><nickname>Silero</nickname></author>',
          f'<date value="{today}">{today}</date><id>{uuid.uuid4()}</id>'
          '<version>1.0</version></document-info>']
    if payload:
        # По схеме FictionBook 2.0 custom-info стоит прямо в description после document-info
        # (внутри document-info его строгие читалки не принимают). Старые файлы, где он лежал
        # внутри document-info, читаются как раньше: read_fb2 ищет его по всему дереву.
        L.append(f'<custom-info info-type="{_x(_BV_INFO_TYPE)}">{_x(payload)}</custom-info>')
        # Backup is intentionally a comment: ignored by ordinary XML text extraction.
        L.append(f'<!--{_BV_COMMENT_PREFIX}{base64.urlsafe_b64encode(payload.encode("utf-8")).decode("ascii")}-->')
    titles = display_titles(book)
    if book.number_from is not None and lm.valid_number_format(book.number_format):
        info = json.dumps({'start': int(book.number_from), 'format': book.number_format,
                           'excluded': list(getattr(book, 'number_excluded', []))}, ensure_ascii=False)
        L.append(f'<custom-info info-type="{_x(_BV_NUMBERING_TYPE)}">{_x(info)}</custom-info>')
    L += ['</description>', '<body>']

    if titlepage and (book.cover or book.title or book.author):
        L.append('<section id="titlepage">')
        if book.title:
            L.append(f'<title><p>{_x(book.title)}</p></title>')
        if book.cover:
            L.append('<image l:href="#cover"/>')
        if book.author:
            L.append(f'<p>{_x(book.author)}</p>')
        L.append('</section>')
    if toc and book.chapters:
        L.append('<section id="toc"><title><p>Содержание</p></title>')
        for i, title in enumerate(titles, 1):
            L.append(f'<p><a l:href="#ch{i}">{_x(title)}</a></p>')
        L.append('</section>')
    slots = bookexport.images_by_slot(book)
    n_img = 0
    fb2_images = []                                     # (id двоичных данных, картинка)

    def image_tag(img, prefix):
        nonlocal n_img
        n_img += 1
        fb2_images.append((f'bvimg{n_img}', img))
        alt = _x(img.get('name') or '').replace('"', '&quot;')
        return f'<image l:href="#bvimg{n_img}" id="{prefix}-{n_img}" alt="{alt}"/>'

    by_chapter = _layout_by_chapter(book)
    for i, (title, paras) in enumerate(book.chapters, 1):
        pieces = _split_pages(_tokens(paras, by_chapter.get(i - 1, [])))
        for k, piece in enumerate(pieces):
            lead, body = _fb2_body(piece)
            if k == 0:
                L.append(f'<section id="ch{i}"><title><p>{_x(titles[i - 1])}</p></title>')
            else:                                       # «с новой страницы»: новая секция без названия
                L.append(f'<section id="bv-page-{i}-{k}">')
            L += lead
            chapter_images = [image_tag(im, 'bv-chapter-img') for im in slots.get(i - 1, [])] if k == 0 else []
            last = [image_tag(im, 'bv-img') for im in slots.get(len(book.chapters), [])] if (i == len(book.chapters) and k == len(pieces) - 1) else []
            L += chapter_images + body
            if not body and (k == 0 or not last):               # у секции после эпиграфа должно быть содержание
                L.append('<empty-line/>')
            L += last
            L.append('</section>')
    L.append('</body>')
    if book.cover:
        ct = 'image/png' if book.cover[:8] == b'\x89PNG\r\n\x1a\n' else 'image/jpeg'
        b64 = base64.b64encode(book.cover).decode()
        chunks = '\n'.join(b64[i:i + 76] for i in range(0, len(b64), 76))
        L.append(f'<binary id="cover" content-type="{ct}">{chunks}</binary>')
    for bid, img in fb2_images:
        b64 = base64.b64encode(img['data']).decode()
        chunks = '\n'.join(b64[i:i + 76] for i in range(0, len(b64), 76))
        L.append(f'<binary id="{bid}" content-type="{bookexport.sniff_image(img["data"])[1]}">{chunks}</binary>')
    L.append('</FictionBook>')
    # Atomic replace: never truncate the target file before the new FB2 is complete.
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    data = ('\n'.join(L)).encode('utf-8')
    fd, temp_name = tempfile.mkstemp(prefix=target.name + '.', suffix='.tmp', dir=str(target.parent))
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        # Validate the exact temporary output before touching the existing file.
        ET.parse(temp_name)
        backup = target.with_suffix(target.suffix + '.bak')
        if target.exists():
            shutil.copy2(target, backup)
        os.replace(temp_name, target)
    except Exception:
        try:
            os.unlink(temp_name)
        except OSError:
            pass
        raise


def write_txt(book, path, **_):
    out = []
    if book.title:
        out.append(book.title)
    if book.author:
        out.append(book.author)
    for title, paras in book.chapters:
        out += ['', title, ''] + ['\n\n'.join(paras)]
    Path(path).write_text('\n'.join(out).strip() + '\n', encoding='utf-8')


def write_md(book, path, **_):
    out = [f'# {book.title}' if book.title else '']
    if book.author:
        out.append(f'*{book.author}*')
    for title, paras in book.chapters:
        out += ['', f'## {title}', ''] + ['\n\n'.join(paras)]
    Path(path).write_text('\n'.join(out).strip() + '\n', encoding='utf-8')


def write_any(book, path, **kw):
    ext = Path(path).suffix.lower()
    if ext == '.fb2':
        write_fb2(book, path, **kw)
    elif ext == '.epub':
        bookexport.write_epub(export_view(book), path, **kw)
    elif ext == '.mobi':
        bookexport.write_mobi(export_view(book), path, **kw)
    elif ext in ('.md', '.markdown'):
        write_md(export_view(book), path)
    else:
        write_txt(export_view(book), path)
