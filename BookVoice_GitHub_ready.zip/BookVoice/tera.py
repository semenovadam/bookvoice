"""TeraTTS v2 (ONNX Runtime): загрузка модели и озвучка одного куска текста.

Модель ставится один раз из программы (⚙ → «Модели…», нужен интернет, около 1,2 ГБ) или install_tera.bat
в папку моделей (model_dirs.py). Программа берёт её только оттуда: сеть при запуске не
нужна, на диск C: модель не обращается, а версия кода модели остаётся той, что скачана
при установке (модель идёт с trust_remote_code, поэтому обновлять её сами по себе не даём).
"""
import os
import re
import threading
from pathlib import Path

import numpy as np

import model_dirs

REPO = 'TeraSpace/TeraTTSv2'
SAMPLE_RATE = 44100
# Голоса из README модели; после загрузки список сверяется с папкой styles/ в кэше.
VOICES = ['ru_f1', 'ru_m5', 'ru_f2', 'ru_m1', 'eng_f3', 'eng_f4_whisper', 'eng_f5',
          'eng_m2_whisper', 'eng_m3', 'eng_m4']
DIFFUSION_MODEL = 'distilled'    # 'distilled' - быстрый (8 шагов); 'teacher' - медленнее
PROVIDER = 'CPUExecutionProvider'
THREADS = max(2, min(8, (os.cpu_count() or 4) // 2))
MAX_LEN = 200                    # модель учили на фразах до 25 с: длинные предложения режем

_tts = None
_load_lock = threading.Lock()


def is_loaded():
    return _tts is not None


def _sort_voices(names):
    """Сначала рекомендованные ru_f1 и ru_m5, потом остальные русские, потом английские."""
    pref = ['ru_f1', 'ru_m5']
    return sorted(names, key=lambda v: (pref.index(v) if v in pref else 9,
                                        not v.startswith('ru_'), v))


def _voices_in(snapshot):
    """Голос = подпапка styles/ в снимке модели."""
    try:
        return [p.name for p in (Path(snapshot) / 'styles').iterdir() if p.is_dir()]
    except OSError:
        return []


def model_dir():
    """Папка с файлами модели (задаётся в model_dirs.py)."""
    return Path(model_dirs.TERA_DIR)


def installed():
    d = model_dir()
    return (d / 'config.json').is_file() and (d / 'styles').is_dir()


def not_installed_message():
    return (f'Модель TeraTTS v2 не найдена в папке {model_dir()}.\n'
            'Скачай её: ⚙ → «Модели…» (нужен интернет, около 1,2 ГБ), '
            'затем снова выбери TeraTTS v2.')


def load():
    """Загрузить модель из её папки (долго: transformers + четыре графа ONNX)."""
    global _tts
    with _load_lock:
        if _tts is not None:
            return
        if not installed():
            raise RuntimeError(not_installed_message())
        snap = model_dir()
        try:
            from transformers import AutoModel
        except ImportError as e:
            raise RuntimeError('Не установлен пакет transformers. '
                               'Поставь его: pip install "transformers>=4.40" (или start.bat / install_tera.bat).') from e
        # Грузим по пути к папке, а не по имени репозитория: так ни сеть, ни кэш HuggingFace
        # не нужны (local_files_only для готовой папки ничего не значит и не передаётся).
        base = dict(trust_remote_code=True, provider=PROVIDER,
                    threads=THREADS, diffusion_model=DIFFUSION_MODEL)
        # ударения нам ставит основной конвейер (RUAccent + словарь); встроенный
        # аккуратист в облегчённом режиме работает лишь запасным вариантом для кусков
        # без единого «+». Если у версии модели нет такого параметра, пробуем без него.
        attempts = [dict(base, ruaccent_mode='dictionary'), base]
        err = None
        for kw in attempts:
            try:
                model = AutoModel.from_pretrained(str(snap), **kw)
                break
            except TypeError as e:
                if 'unexpected' not in str(e) and 'keyword' not in str(e):
                    raise
                err = e
        else:
            raise err
        names = _voices_in(snap)
        if names:
            VOICES[:] = _sort_voices(names)
        _tts = model


# ---------- подготовка текста ----------
# Рантайм требует, чтобы весь текст был в тегах <ru>…</ru> / <en>…</en>.
_WORD = r"[A-Za-z]+(?:['’\-][A-Za-z]+)*"
_LATIN = re.compile(_WORD + r'(?:\s+' + _WORD + r')*')       # «New York» - один кусок
_LETTER = re.compile(r'[A-Za-zА-Яа-яЁё]')
_CLOSE = re.compile(r'[,.;:!?…»”’"\')\]]+')      # знаки, которыми кончается слово
_OPEN = re.compile(r'[«“„‘"\'(\[]+$')            # знаки, которыми слово начинается


def to_tagged(text):
    """'Привет, world!' -> '<ru>Привет,</ru> <en>world!</en>'.

    Латиница уходит в <en>, остальное в <ru>; знаки препинания остаются в куске, к
    которому прилегают. Убираем то, что рантайм не принимает: «*» (интонационный
    маркер Silero) и угловые скобки. Пустой результат -> ''."""
    text = text.replace('*', '')
    text = re.sub(r'[<>]', ' ', text)
    # «+» нужен рантайму только как знак ударения перед гласной; любой другой («C++», «2+2»)
    # превращаем в пробел, иначе он отключит автоударения для всего куска
    text = re.sub(r'\+(?![аеёиоуыэюяАЕЁИОУЫЭЮЯ])', ' ', text)
    text = re.sub(r'\s+', ' ', text).strip()
    runs, pos = [], 0
    for m in _LATIN.finditer(text):
        if m.start() > pos:
            runs.append(['ru', text[pos:m.start()]])
        runs.append(['en', m.group(0)])
        pos = m.end()
    if pos < len(text):
        runs.append(['ru', text[pos:]])
    # Скобки и кавычки, вплотную прижатые к английскому слову, и знаки сразу после него
    # идут в английский кусок: «(hedgehog)», «"Hello",», «New York,». Так ни один кусок
    # не начинается со знака препинания и не кончается открывающей скобкой.
    for i, run in enumerate(runs):
        if run[0] != 'en':
            continue
        if i > 0:
            m = _OPEN.search(runs[i - 1][1])
            if m:
                runs[i - 1][1] = runs[i - 1][1][:m.start()]
                run[1] = m.group(0) + run[1]
        if i + 1 < len(runs):
            m = _CLOSE.match(runs[i + 1][1])
            if m:
                run[1] += m.group(0)
                runs[i + 1][1] = runs[i + 1][1][m.end():]
    out, pending = [], ''
    for lang, s in runs:
        if not _LETTER.search(s):               # одни знаки: приклеиваем к соседнему куску
            if out:
                out[-1][1] += s
            else:
                pending += s
            continue
        s, pending = pending + s, ''
        if out and out[-1][0] == lang:          # «Hello, world»: два en подряд -> один
            out[-1][1] += s
        else:
            out.append([lang, s])
    parts = []
    for lang, s in out:
        s = s.strip()
        if lang == 'en':
            s = s.replace('+', '')
        if s:
            parts.append(f'<{lang}>{s}</{lang}>')
    return ' '.join(parts)


def synthesize(text, voice=None, speed=1.0):
    """Текст (с «+» перед ударной гласной) -> float32, моно, 44100 Гц.

    speed - это duration_scale модели: больше значит медленнее."""
    if _tts is None:
        raise RuntimeError('TeraTTS не загружен')
    tagged = to_tagged(text)
    if not tagged:
        return np.zeros(0, dtype=np.float32)
    if voice not in VOICES:
        voice = VOICES[0]
    wav = _tts.generate_speech(tagged, voice=voice, duration_scale=float(speed))
    return np.clip(np.asarray(wav, dtype=np.float32).reshape(-1), -1.0, 1.0)
