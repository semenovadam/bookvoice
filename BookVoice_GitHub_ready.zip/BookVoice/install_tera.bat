@echo off
setlocal
cd /d "%~dp0"
if not exist "venv\Scripts\python.exe" goto novenv
set "VIRTUAL_ENV=%~dp0venv"
set "PATH=%~dp0venv\Scripts;%PATH%"
set "PYTHONHOME="
rem bookvoice.bat works offline; here the internet is needed once
set "HF_HUB_OFFLINE="
set "TRANSFORMERS_OFFLINE="
echo === 1/2. Installing the transformers package ===
python -m pip install "transformers>=4.40"
if errorlevel 1 goto fail
echo.
echo === 2/2. Downloading TeraTTS v2 (about 1.2 GB) and testing it ===
python install_tera.py
if errorlevel 1 goto fail
echo.
echo Done. Run bookvoice.bat and press the TeraTTS button at the top right.
pause
exit /b 0
:novenv
echo venv\Scripts\python.exe was not found in %~dp0
pause
exit /b 1
:fail
echo.
echo Something went wrong, see the messages above.
pause
exit /b 1
