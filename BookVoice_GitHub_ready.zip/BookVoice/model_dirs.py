r"""Где лежат большие файлы моделей: Silero, RUAccent, TeraTTS v2, Shtorm-PocketTTS-RU, Shtorm-VoxCPM2-RU и ffmpeg.

Без этой настройки Python складывает их в кэш пользователя на диске C:
(папка .cache внутри C:/Users/<имя>). Теперь всё лежит в одной папке моделей, и менять её
можно прямо в программе: значок ⚙ справа вверху, «Папка моделей…». Выбор запоминается в
settings.json (ключ models_dir). Порядок выбора папки:
  1. переменная окружения BOOKVOICE_MODELS_DIR (её ставит сама программа для скачивания);
  2. models_dir из settings.json (выбрано в ⚙);
  3. D:\AI\models, если такая папка уже есть (так было до появления ⚙, у основного компьютера);
  4. папка models рядом с программой (удобно для копии программы на другом компьютере).
Внутри папки моделей: silero, ruaccent, ttsv2 (TeraTTS), shtorm-pockettts-ru, shtorm-voxcpm2-ru и ffmpeg.
Что и где лежит сейчас, покажет ⚙ → «Что где лежит» (или python model_dirs.py).

Здесь же выбирается модель Silero (SILERO_MODEL): её берут и программа, и скачивание из ⚙.

Silero при первом запуске сам копирует свой старый кэш с диска C: (один раз, если он там
есть). Когда голоса проверены, старые копии на диске C: удаляет ⚙ → «Очистить старый кэш»
(или python model_dirs.py clean): он стирает их только если на новом месте уже лежит целая копия.
"""
import importlib.util
import json
import os
import shutil
import stat
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent
SETTINGS_FILE = BASE / 'settings.json'
LEGACY_BASE = r'D:\AI\models'                       # где модели лежали до появления выбора папки в ⚙
SUBDIRS = {'silero': 'silero',                       # Silero: код silero-models и файл с голосами
           'ruaccent': 'ruaccent',                   # RUAccent: модели расстановки ударений
           'tera': 'ttsv2',                          # TeraTTS v2: все файлы модели (около 1,2 ГБ)
           'shtorm': 'shtorm-pockettts-ru',          # Shtorm-PocketTTS-RU: fast/slow и токенизатор
           'voxcpm': 'shtorm-voxcpm2-ru',            # Shtorm-VoxCPM2-RU: веса модели (около 5 ГБ)
           'ffmpeg': 'ffmpeg'}                       # ffmpeg.exe для сохранения mp3


def _saved_base():
    """Папка моделей, выбранная в ⚙ (settings.json), или None."""
    try:
        d = json.loads(SETTINGS_FILE.read_text(encoding='utf-8-sig'))
        v = d.get('models_dir') if isinstance(d, dict) else None
        return v.strip() if isinstance(v, str) and v.strip() else None
    except Exception:
        return None


def default_base():
    """Какая папка моделей действует сейчас (порядок выбора описан вверху файла)."""
    env = os.environ.get('BOOKVOICE_MODELS_DIR', '').strip()
    if env:
        return env
    saved = _saved_base()
    if saved:
        return saved
    try:
        if Path(LEGACY_BASE).is_dir():
            return LEGACY_BASE
    except OSError:
        pass
    return str(BASE / 'models')


def _sub(base, key):
    return str(Path(base) / SUBDIRS[key])


MODELS_DIR = default_base()
SILERO_DIR = _sub(MODELS_DIR, 'silero')              # Silero: код silero-models и файл с голосами
RUACCENT_DIR = _sub(MODELS_DIR, 'ruaccent')          # RUAccent: модели расстановки ударений
TERA_DIR = _sub(MODELS_DIR, 'tera')                  # TeraTTS v2: все файлы модели (около 1,2 ГБ)
SHTORM_DIR = _sub(MODELS_DIR, 'shtorm')              # Shtorm-PocketTTS-RU: fast/slow и токенизатор
VOXCPM_DIR = _sub(MODELS_DIR, 'voxcpm')              # Shtorm-VoxCPM2-RU: веса модели (около 5 ГБ)
FFMPEG_DIR = _sub(MODELS_DIR, 'ffmpeg')              # ffmpeg.exe для сохранения mp3

SILERO_MODEL = 'v5_6_ru'                 # модель Silero: самая новая русская (на октябрь 2026), раньше была v5_4_ru
SILERO_FALLBACK = 'v5_4_ru'              # если SILERO_MODEL не загрузилась, программа берёт эту

SILERO_REPO = 'snakers4_silero-models_master'      # так torch.hub называет папку репозитория
TERA_CACHE = 'models--TeraSpace--TeraTTSv2'        # так HuggingFace называет папку в своём кэше

# значения до нашей подмены: по ним отчёт находит старые места на диске C:
_ENV0 = {k: os.environ.get(k) for k in ('TORCH_HOME', 'HF_HOME', 'XDG_CACHE_HOME')}
_problems = None


def _make(path):
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def _model_file(name=None):
    """Где torch.hub держит файл модели Silero (.pt) внутри папки репозитория."""
    return (Path(SILERO_DIR) / 'hub' / SILERO_REPO / 'src' / 'silero' / 'model'
            / f'{name or SILERO_MODEL}.pt')


def _adopt_old_silero(home):
    """Silero уже скачан в обычный кэш на диске C:, а в новой папке его ещё нет: копируем
    оттуда один раз, чтобы не качать заново (и чтобы запуск не зависел от интернета).
    Старая копия остаётся на месте, её можно удалить самому (where_models.bat покажет, где она).
    Возвращает False, если старая копия есть, но перенести её не получилось: тогда лучше
    оставить Silero в старом кэше, чем заставлять его качаться заново."""
    name = SILERO_REPO
    new = home / 'hub' / name
    part = new.with_name(name + '.part')
    try:
        old = _old_places()[0] / name
    except RuntimeError:                                # домашняя папка не определена: старого кэша нет
        return True
    if new.exists() or not old.is_dir():
        return True
    try:
        print(f'Копирую Silero из старого кэша {old} в {new} (один раз)...')
        if part.exists():
            shutil.rmtree(part)                         # остаток прерванного копирования
        shutil.copytree(old, part)
        part.rename(new)                                # папка появляется сразу целиком
        return True
    except OSError as e:
        print(f'Не получилось скопировать Silero ({e}).')
        shutil.rmtree(part, ignore_errors=True)
        return False


def configure(base):
    """Сменить папку моделей на лету (⚙ → «Папка моделей…»). Уже загруженные модели остаются в
    памяти; новые загрузки и скачивание идут в новую папку, а Silero и ударения она подхватит
    после перезапуска программы. Файлы из прежней папки не переносятся."""
    global MODELS_DIR, SILERO_DIR, RUACCENT_DIR, TERA_DIR, SHTORM_DIR, VOXCPM_DIR, FFMPEG_DIR, _problems
    MODELS_DIR = str(base)
    SILERO_DIR, RUACCENT_DIR = _sub(base, 'silero'), _sub(base, 'ruaccent')
    TERA_DIR, SHTORM_DIR, FFMPEG_DIR = _sub(base, 'tera'), _sub(base, 'shtorm'), _sub(base, 'ffmpeg')
    VOXCPM_DIR = _sub(base, 'voxcpm')
    if _problems is not None:               # apply() уже работал: направляем кэши на новое место
        _problems = None
        apply()


def apply():
    """Направить кэши в папки выше. Вызывается один раз при старте, до загрузки torch и
    transformers (они читают переменные окружения при импорте), повторные вызовы ничего
    не делают. Возвращает список проблем (пустой, если всё хорошо); их же печатает."""
    global _problems
    if _problems is not None:
        return _problems
    problems = []
    try:
        silero = _make(SILERO_DIR)
        if _adopt_old_silero(silero):
            # torch.hub кладёт сюда репозиторий silero-models и скачанный файл голосов (подпапка hub)
            os.environ['TORCH_HOME'] = str(silero)
        else:
            problems.append(f'Silero: не получилось перенести его в {silero}. '
                            'Пока он работает из старого кэша на диске C:, как раньше.')
    except OSError as e:
        problems.append(f'Silero: не могу открыть папку {SILERO_DIR} ({e}). Беру обычный кэш '
                        'на диске C:. Подключи диск или поменяй путь в файле model_dirs.py.')
    try:
        tera_dir = _make(TERA_DIR)
        # служебные кэши transformers и huggingface_hub (копия кода модели, кэш докачки)
        # держим рядом с моделью, чтобы и они не попадали на C:
        os.environ['HF_MODULES_CACHE'] = str(tera_dir / '.hf_modules')
        os.environ['HF_XET_CACHE'] = str(tera_dir / '.hf_xet')
    except OSError as e:
        problems.append(f'TeraTTS: не могу открыть папку {TERA_DIR} ({e}). '
                        'Подключи диск или поменяй путь в файле model_dirs.py.')
    for p in problems:
        print('ВНИМАНИЕ:', p)
    _problems = problems
    return problems


# ---------- отчёт: python model_dirs.py (или where_models.bat) ----------
def _size(path):
    total = 0
    for root, _dirs, files in os.walk(path):
        for name in files:
            f = os.path.join(root, name)
            try:
                if not os.path.islink(f):       # ссылки кэша HuggingFace считаем один раз
                    total += os.path.getsize(f)
            except OSError:
                pass
    return total


def _fmt(n):
    if n >= 1 << 30:
        return f'{n / (1 << 30):.1f} ГБ'.replace('.', ',')
    return f'{n / (1 << 20):.0f} МБ'


def _show(label, path, note=''):
    p = Path(path)
    try:
        info = _fmt(_size(p)) if p.is_dir() else 'папки пока нет'
    except OSError as e:
        info = f'не удалось прочитать ({e})'
    print(f'  {label:<9} {p}  -  {info}{note}')


def _subdirs(base):
    try:
        return sorted(c for c in base.iterdir() if c.is_dir())
    except OSError:                                     # нет папки или нет прав
        return []


def _label(name):
    n = name.lower()
    if 'ruaccent' in n or 'accentuator' in n:
        return 'RUAccent (ударения), нужен программе'
    if 'silero' in n:
        return 'Silero'
    if 'teratts' in n:
        return 'TeraTTS'
    if 'voxcpm' in n:
        return 'Shtorm-VoxCPM2-RU'
    if 'shtorm' in n or 'pocket' in n:
        return 'Shtorm-PocketTTS-RU'
    return ''


def _old_places():
    """Где Python держит кэши по умолчанию (без нашей подмены)."""
    xdg = _ENV0['XDG_CACHE_HOME']
    cache = Path(xdg) if xdg else Path.home() / '.cache'
    torch_home = Path(_ENV0['TORCH_HOME']) if _ENV0['TORCH_HOME'] else cache / 'torch'
    hf_home = Path(_ENV0['HF_HOME']) if _ENV0['HF_HOME'] else cache / 'huggingface'
    return torch_home / 'hub', hf_home


def _show_model():
    f = _model_file()
    try:
        state = (f'файл на месте ({_fmt(f.stat().st_size)})' if f.is_file()
                 else 'файла ещё нет, он скачается при первом запуске программы (нужен интернет)')
    except OSError as e:
        state = f'не удалось прочитать ({e})'
    print(f'  Модель Silero: {SILERO_MODEL}  -  {state}')
    print(f'  Если она не загрузится, программа возьмёт запасную: {SILERO_FALLBACK}')


def report():
    print('Считаю размеры, это может занять несколько секунд...\n')
    print(f'Папка моделей: {MODELS_DIR}   (меняется в программе: ⚙ → «Папка моделей…»)')
    _show('Silero', SILERO_DIR)
    _show('RUAccent', RUACCENT_DIR, '   (если пусто, модели ударений лежат в пакете ruaccent, см. ниже)')
    _show('TeraTTS', TERA_DIR)
    _show('Shtorm', SHTORM_DIR, '   (fast/slow веса и токенизатор)')
    _show('VoxCPM2', VOXCPM_DIR, '   (Shtorm-VoxCPM2-RU, около 5 ГБ)')
    _show('ffmpeg', FFMPEG_DIR, '   (нужен для mp3; если пусто, берётся ffmpeg из PATH)')
    _show_model()

    torch_hub, hf_home = _old_places()
    print('\nОбычный кэш пользователя (сюда всё попадало раньше):')
    shown = False
    for base in (torch_hub, hf_home / 'hub'):
        for child in _subdirs(base):
            if child.name != 'checkpoints':
                lab = _label(child.name)
                _show('', child, f'   <- {lab}' if lab else '')
                shown = True
    for child in _subdirs(hf_home):
        if child.name in ('modules', 'xet'):
            _show('', child, '   <- служебный кэш HuggingFace')
            shown = True
    if shown:
        print('  Старые копии Silero/TeraTTS и кэш докачки безопасно удалит ⚙ → «Очистить старый кэш»:')
        print('  модели он стирает только если на новом месте уже лежит целая копия.')
        print('  Папку huggingface целиком не удаляйте: там могут лежать модели RUAccent,')
        print('  без них программа не запустится.')
    else:
        print('  там ничего нет')

    print('\nОстальное, что к моделям не относится, но тоже занимает место:')
    try:
        spec = importlib.util.find_spec('ruaccent')
        ruaccent = Path(spec.origin).parent if spec and spec.origin else None
    except Exception:
        ruaccent = None
    if ruaccent:
        _show('RUAccent', ruaccent, '   (пакет в venv, модели ударений могут лежать здесь)')
    _show('Программа', BASE, '   (вместе с venv, готовыми mp3 в out и словарём)')
    print('\nПапка моделей меняется в программе (⚙ → «Папка моделей…»), модель Silero в файле model_dirs.py (SILERO_MODEL).')


# ---------- удаление старых копий на C: : python model_dirs.py clean (clean_old_cache.bat) ----------
def _ask(prompt):
    try:
        return input(prompt)
    except EOFError:                                    # ввода нет (запуск без консоли): считаем «нет»
        return ''


def _rmtree(path):
    def fix(func, p, _exc):                             # Windows: файл «только для чтения»
        os.chmod(p, stat.S_IWRITE)
        func(p)
    if sys.version_info >= (3, 12):
        shutil.rmtree(path, onexc=fix)
    else:
        shutil.rmtree(path, onerror=fix)


def _norm(p):
    return os.path.normcase(os.path.abspath(str(p)))


def _nested(a, b):
    """Одна папка лежит внутри другой (или это одна и та же папка)."""
    x, y = _norm(a), _norm(b)
    return x == y or x.startswith(y.rstrip(os.sep) + os.sep) or y.startswith(x.rstrip(os.sep) + os.sep)


def _overlaps_new(path):
    """Старое место совпадает с новыми папками моделей или связано с ними вложением:
    такое не удаляем ни при каких условиях."""
    return _nested(path, MODELS_DIR) or _nested(path, SILERO_DIR) or _nested(path, TERA_DIR)


def _covered(src, dst, big=0):
    """Каждый файл из src есть и в dst; файлы размером от big байт и крупнее ещё и того же
    размера (big=0: все файлы одного размера)."""
    def fail(e):                                        # папку не удалось прочитать: считать проверенной нельзя
        raise e
    try:
        for root, _dirs, files in os.walk(src, onerror=fail):
            for name in files:
                a = Path(root) / name
                b = Path(dst) / a.relative_to(src)
                size = a.stat().st_size
                if not b.is_file() or (size >= big and b.stat().st_size != size):
                    return False
    except OSError:
        return False
    return True


def _hf_snapshot(repo_cache):
    """Папка текущей версии в кэше HuggingFace (snapshots/<хэш>); None, если там ничего нет."""
    snaps = repo_cache / 'snapshots'
    try:
        ref = (repo_cache / 'refs' / 'main').read_text(encoding='utf-8').strip()
        if ref and (snaps / ref).is_dir():
            return snaps / ref
    except OSError:
        pass
    found = _subdirs(snaps)
    if not found:
        return None
    try:
        return max(found, key=lambda p: p.stat().st_mtime)
    except OSError:
        return found[0]


def _has_current_model():
    """Файл нынешней модели (SILERO_MODEL) уже лежит на новом месте и не пустой."""
    try:
        f = _model_file()
        return f.is_file() and f.stat().st_size > 0
    except OSError:
        return False


def _silero_ready(old):
    """На новом месте есть репозиторий Silero и либо все файлы *.pt старой копии, либо файл
    нынешней модели (SILERO_MODEL): тогда остальные *.pt старой копии это прежние версии,
    программе они больше не нужны."""
    new = Path(SILERO_DIR) / 'hub' / SILERO_REPO
    if not (new / 'hubconf.py').is_file():
        return False
    for p in old.rglob('*.pt'):
        q = new / p.relative_to(old)
        try:
            if not q.is_file() or q.stat().st_size != p.stat().st_size:
                return _has_current_model()
        except OSError:
            return False
    return True


def _tera_ready(old):
    """На новом месте лежит модель, и в ней есть всё из старой копии (крупные файлы того же размера)."""
    new = Path(TERA_DIR)
    if not ((new / 'config.json').is_file() and (new / 'styles').is_dir()):
        return False
    snap = _hf_snapshot(old)
    return snap is None or _covered(snap, new, big=1 << 20)


def clean_plan():
    """Что можно удалить из старого кэша на диске C: -> (todo, keep). Элементы списков:
    (название, папка, размер, причина). В todo на новом месте уже лежит целая копия, в keep её
    нет и удалять рано. Бросает RuntimeError, если домашняя папка пользователя не определена."""
    torch_hub, hf_home = _old_places()
    todo, keep = [], []
    old = torch_hub / SILERO_REPO
    if old.is_dir() and not _overlaps_new(old):
        if _silero_ready(old):
            todo.append(('Silero', old, _size(old), ''))
        else:
            keep.append(('Silero', old, _size(old),
                         'на новом месте нет целой копии: запусти программу один раз и проверь голос Silero'))
    old = hf_home / 'hub' / TERA_CACHE
    if old.is_dir() and not _overlaps_new(old):
        if _tera_ready(old):
            todo.append(('TeraTTS', old, _size(old), ''))
        else:
            keep.append(('TeraTTS', old, _size(old),
                         'на новом месте нет такой же целой модели: скачай её в ⚙ → «Модели…»'))
    old = hf_home / 'xet'
    if old.is_dir() and not _overlaps_new(old):
        todo.append(('Кэш xet', old, _size(old), ''))   # служебный кэш докачки HuggingFace
    return todo, keep


def clean_run(todo):
    """Удалить папки из списка todo. Возвращает (освобождено байт, [(папка, ошибка), ...])."""
    freed, errors = 0, []
    for _label, path, size, _why in todo:
        try:
            _rmtree(path)
            freed += size
        except OSError as e:
            errors.append((path, e))
    return freed, errors


def clean_cli():
    try:
        todo, keep = clean_plan()
    except RuntimeError:
        print('Не удалось определить папку пользователя, чистить нечего.')
        return 0
    if not todo and not keep:
        print('На диске C: старых копий не найдено, удалять нечего.')
        return 0
    if todo:
        print('Можно удалить (на новом месте всё есть, это просто старые копии и кэш):')
        for label, path, size, _why in todo:
            print(f'  {label:<9} {path}  -  {_fmt(size)}')
    for label, path, size, why in keep:
        print(f'  ОСТАВЛЯЮ  {label}: {path}  -  {_fmt(size)}\n            причина: {why}')
    print('Остальное (RUAccent, чужие модели) не трогаю.')
    if not todo:
        return 0
    total = sum(item[2] for item in todo)
    ans = _ask(f'\nУдалить то, что в списке «Можно удалить» (освободится {_fmt(total)})?\n'
               'Введите да и нажмите Enter, иначе ничего не удалю: ')
    if ans.strip().lower() not in ('да', 'д', 'yes', 'y'):
        print('Ничего не удалено.')
        return 0
    freed, errors = clean_run(todo)
    for _label, path, _size_, _why in todo:
        if not any(path == e[0] for e in errors):
            print(f'  удалено: {path}')
    for path, e in errors:
        print(f'  не удалось удалить {path}: {e} (закройте программу и повторите)')
    print(f'\nОсвобождено {_fmt(freed)}.')
    return 1 if errors else 0


def main(argv):
    cmd = argv[1].lower() if len(argv) > 1 else 'report'
    if cmd == 'report':
        report()
        return 0
    if cmd == 'clean':
        return clean_cli()
    print('Команды: report (по умолчанию), clean')
    return 2


if __name__ == '__main__':
    sys.exit(main(sys.argv))
