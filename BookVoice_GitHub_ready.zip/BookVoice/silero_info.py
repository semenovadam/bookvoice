r"""Что умеет модель Silero: голоса, параметры apply_tts и исходный текст из файла модели.

Запускается через silero_info.bat (можно с номером модели: silero_info.bat v5_4_ru). Коротко
печатается в окно, полностью сохраняется в silero_info.txt рядом с программой. Этот файл
можно приложить к вопросу о настройке звучания: в нём видно, какие параметры и пометки в
тексте (эмфазы, восклицания, вопросы) понимает именно эта версия модели.
Интернет нужен только если файла модели ещё нет на диске.
"""
import inspect
import re
import sys
import zipfile
from pathlib import Path

import model_dirs

OUT = Path(__file__).resolve().parent / 'silero_info.txt'
KEYS = re.compile(r'emphas|exclam|intensity|question|stress_homo|put_yo|put_accent|asterisk|ssml',
                  re.IGNORECASE)
MAX_FUNC = 400          # строк исходного текста apply_tts
MAX_HITS = 150          # строк с ключевыми словами из всех файлов модели


def func_source(text, name):
    """Текст функции name: от def до следующей строки с таким же или меньшим отступом."""
    lines = text.splitlines()
    for i, line in enumerate(lines):
        m = re.match(r'(\s*)def\s+' + re.escape(name) + r'\b', line)
        if not m:
            continue
        indent, end = len(m.group(1)), len(lines)
        for j in range(i + 1, len(lines)):
            s = lines[j]
            if s.strip() and len(s) - len(s.lstrip()) <= indent and not s.lstrip().startswith(('#', ')')):
                end = j
                break
        return '\n'.join(lines[i:end])
    return None


def inspect_package(path):
    """Файлы .py внутри файла модели (это архив torch.package): их список, текст apply_tts и
    строки с ключевыми словами. Возвращает список (заголовок, текст)."""
    parts = []
    with zipfile.ZipFile(path) as z:
        py = [n for n in z.namelist() if n.endswith('.py')]
        parts.append(('файлы .py внутри модели', '\n'.join(py) or 'нет: исходного текста в файле модели нет'))
        func, hits = None, []
        for n in py:
            text = z.read(n).decode('utf-8', errors='replace')
            if func is None:
                src = func_source(text, 'apply_tts')
                if src:
                    func = (n, src)
            hits += [f'{n}:{k}: {line.rstrip()}' for k, line in enumerate(text.splitlines(), 1)
                     if KEYS.search(line)]
    if func:
        parts.append((f'исходный текст apply_tts ({func[0]})', '\n'.join(func[1].splitlines()[:MAX_FUNC])))
    more = f'\n... и ещё {len(hits) - MAX_HITS} строк' if len(hits) > MAX_HITS else ''
    parts.append(('строки про эмфазу, восклицания, вопросы, ssml и параметры',
                  '\n'.join(hits[:MAX_HITS]) + more or 'не найдено'))
    return parts


def main(argv):
    name = argv[1] if len(argv) > 1 else model_dirs.SILERO_MODEL
    model_dirs.apply()                  # кэши моделей на нужные диски, до загрузки torch
    import torch

    parts = [('модель', f'{name}\ntorch {getattr(torch, "__version__", "?")}')]
    summary = []                        # то, что покажем в окне
    model = None
    try:
        model, _ = torch.hub.load(repo_or_dir='snakers4/silero-models', model='silero_tts',
                                  language='ru', speaker=name)
    except Exception as e:
        parts.append(('модель не загрузилась', f'{type(e).__name__}: {str(e)[:300]}'))
    if model is not None:
        try:
            parts.append(('голоса', ', '.join(map(str, getattr(model, 'speakers', None) or ['(список не найден)']))))
            summary.append(parts[-1])
        except Exception as e:
            parts.append(('голоса', f'не удалось получить: {e!r}'))
        try:
            sig = str(inspect.signature(model.apply_tts))
            doc = inspect.getdoc(model.apply_tts) or '(описания нет)'
            parts.append(('apply_tts: параметры', sig))
            parts.append(('apply_tts: описание', doc))
            summary.append(parts[-2])
        except Exception as e:
            parts.append(('apply_tts', f'не удалось прочитать: {e!r}'))
        parts.append(('методы модели', ', '.join(n for n in dir(model) if not n.startswith('_'))))
    path = Path(torch.hub.get_dir()) / model_dirs.SILERO_REPO / 'src' / 'silero' / 'model' / f'{name}.pt'
    try:
        parts += inspect_package(path)
    except (OSError, zipfile.BadZipFile) as e:
        parts.append(('файл модели', f'не удалось прочитать {path}: {e}'))

    OUT.write_text('\n\n'.join(f'===== {t} =====\n{b}' for t, b in parts) + '\n', encoding='utf-8')
    for t, b in [parts[0]] + summary:
        print(f'{t}: {b}')
    print(f'\nПодробный отчёт сохранён: {OUT}')
    print('Пришлите этот файл в чат, если хотите разобрать настройку звучания.')
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
