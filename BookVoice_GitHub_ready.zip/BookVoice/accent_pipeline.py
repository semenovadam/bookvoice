"""Подготовка текста к озвучке: СНАЧАЛА смысл, ПОТОМ нарезка.

Порядок (для каждого абзаца):
  1. Предложения по смыслу (split_sentences): с защитой сокращений и инициалов, без разрыва на «…» перед
     строчной буквой и на «! — сказал он».
  2. Для каждого ЦЕЛОГО предложения: RUAccent -> сверка (accent_sentence) -> «ё как в книге» -> пять/шесть/семь ->
     сам/самый -> словарь -> контекстные омографы -> проверка знаков ударения -> возврат акцентов *...*.
     RUAccent, словарь и омографы видят всё предложение, а не обрывок между запятыми.
  3. Только теперь готовое предложение режется на фрагменты для синтеза (split_fragments): по запятым, если так
     настроено, и по длине. Знаки ударения «+» и акценты *...* уже стоят в тексте и режутся вместе с ним.
  4. Движок (Silero/Shtorm/...) получает готовый фрагмент и ничего не пересчитывает.

Сверка и возвраты: RUAccent не имеет права менять слова. Если слова после него не совпали с исходными
(сбой, слишком длинное предложение, непривычные символы), предложение обрабатывается по частям (клаузам), а
часть, которую RUAccent снова исказил, остаётся без его ударений (ударения поставит сам движок). Каждый такой
случай попадает в отчёт, чтобы не искать ошибки на слух.

Модуль не зависит от torch и звука: всё тяжёлое (RUAccent, словарь, pymorphy) подаётся как функции (Steps).
"""
import re
from collections import OrderedDict

from emphasis import extract_emphasis, restore_emphasis

_CYR_WORD = re.compile(r'[А-Яа-яЁё+]+')
_CYR_TOKEN = re.compile(r'\+*[А-Яа-яЁё][А-Яа-яЁё+]*')        # слово с хотя бы одной буквой (одинокий «+» не слово)
_ANY_WORD = re.compile(r'[A-Za-zА-Яа-яЁё+]+')
VOWELS = 'аеёиоуыэюяАЕЁИОУЫЭЮЯ'
CLOSERS = '»”"\'’)]}'
OPENERS = '«„“"\'‘([{'
DASHES = '—–-'

# Сокращения: после них точка НЕ конец предложения (даже перед заглавной буквой: «г. Москва», «ул. Ленина»).
NEVER_END_WORDS = {
    'г', 'гг', 'ул', 'д', 'дд', 'кв', 'корп', 'стр', 'пр', 'пер', 'просп', 'пл', 'им', 'проф', 'акад', 'доц', 'св',
    'гр', 'тов', 'ген', 'полк', 'подп', 'лейт', 'кап', 'ст', 'мл', 'см', 'рис', 'табл', 'гл', 'т', 'тт', 'ср',
    'напр', 'тыс', 'млн', 'млрд', 'руб', 'коп', 'обл', 'пос', 'им', 'др', 'проч', 'etc', 'mr', 'mrs', 'ms', 'dr',
    'mt', 'st', 'г-н', 'г-жа',
}
# Цепочки вида «т.е.», «т.к.»: внутри предложения всегда.
NEVER_END_CHAINS = {'т.е.', 'т.к.', 'т.н.', 'т.ч.', 'т.о.', 'в т.ч.', 'т.е', 'т.к'}
# Эти сокращения нередко стоят в конце предложения: перед заглавной буквой это граница.
MAY_END_CHAINS = {'т.д.', 'т.п.', 'и т.д.', 'и т.п.', 'и пр.', 'и др.', 'и проч.'}

_TERMINAL = re.compile(r'(?P<term>[.!?…]+)(?P<close>[' + re.escape(CLOSERS) + r']*)(?P<ws>\s+)')
_SOFT = re.compile(r'(?P<term>[,;:—–])(?P<close>[' + re.escape(CLOSERS) + r']*)(?P<ws>\s+)')
_LAST_WORD = re.compile(r'([A-Za-zА-Яа-яЁё]+)$')
_SINGLE_LETTER_DOT = re.compile(r'(?<![A-Za-zА-Яа-яЁё])([A-Za-zА-Яа-яЁё])\.\s?$')


class Prepared(str):
    """Фрагмент, у которого ударения, словарь и омографы уже учтены: say_sentence не пересчитывает его."""
    accented = True


def visible_len(text):
    """Длина без знаков ударения и акцентов: они не звучат и не должны сокращать предложение."""
    return len(text.replace('+', '').replace('*', ''))


def _next_char_info(text, pos):
    """Первый «значимый» символ после границы: пропускаем открывающие кавычки/скобки и тире с пробелом."""
    i, n = pos, len(text)
    while i < n:
        ch = text[i]
        if ch in OPENERS or ch in DASHES or ch.isspace() or ch in '*':
            i += 1
            continue
        return ch
    return ''


def _abbreviation_blocks(text, dot_pos, term, next_char):
    """True: точка в позиции dot_pos относится к сокращению или инициалу, а не к концу предложения."""
    if term != '.':
        return False
    before = text[:dot_pos]
    m = _LAST_WORD.search(before)
    if not m:
        return False
    words, pos = [m.group(1)], m.start(1)
    while True:                                               # «т.е», «А.С»: цепочка из однобуквенных частей
        mm = _SINGLE_LETTER_DOT.search(before[:pos])
        if not mm:
            break
        words.insert(0, mm.group(1))
        pos = mm.start(1)
    chain = '.'.join(words)
    m_start = pos
    low = re.sub(r'\s', '', chain.lower())                  # «т. е» -> «т.е»
    lead = before[:m_start].lower()
    ctx = re.search(r'(?:^|\s)(и|в)\s+$', lead)
    full = f'{ctx.group(1)} {low}.' if ctx else f'{low}.'
    if full in MAY_END_CHAINS or f'{low}.' in MAY_END_CHAINS:
        return not next_char.isupper()                      # «и т.д. Потом»: конец; «и т.д. и т.п.»: нет
    if full in NEVER_END_CHAINS or f'{low}.' in NEVER_END_CHAINS:
        return True
    if len(chain) == 1 and chain.isalpha() and chain.isupper():      # инициал «А.»
        return True
    parts = chain.split('.')
    if len(parts) > 1 and all(len(p) == 1 and p.isupper() for p in parts):   # «А.С.» подряд
        return True
    return low.split('.')[-1] in NEVER_END_WORDS


def _boundaries(text, mode, at_commas=True):
    """Позиции (конец_фрагмента, начало_следующего) границ.
    mode 'context': только концы предложений по смыслу (строчная буква дальше = не граница);
    mode 'pause': все места, где после знака должна быть пауза (концы предложений всегда; запятые и т.п. -
    если at_commas)."""
    found = []
    for rx, soft in ((_TERMINAL, False), (_SOFT, True)):
        if soft and (mode == 'context' or not at_commas):
            continue
        for m in rx.finditer(text):
            term_end = m.start('term') + len(m.group('term'))
            nxt = _next_char_info(text, m.end())
            if not soft:
                term = m.group('term')
                dot_pos = m.start('term') + len(term) - 1
                if _abbreviation_blocks(text, dot_pos, term, nxt):
                    continue
                if mode == 'context' and nxt and nxt.islower():
                    continue                    # «Он... не знал», «Привет! — сказал он»
            end = m.start('close') + len(m.group('close'))
            found.append((end, m.end('ws')))
    found.sort()
    return found


_HAS_LETTER = re.compile(r'[A-Za-zА-Яа-яЁё]')


def _cut(text, bounds, letterless='merge'):
    """Режет текст по границам. Кусок без букв («—» реплики, «...» сам по себе) не живёт отдельно:
    letterless='merge' присоединяет его к следующему куску (для предложений: контекст не теряется),
    'drop' выбрасывает (для фрагментов озвучки: так программа и раньше не озвучивала одинокое тире)."""
    parts, start = [], 0
    for end, nxt in bounds:
        if end <= start:
            continue
        parts.append(text[start:end])
        start = nxt
    parts.append(text[start:])
    parts = [p.strip() for p in parts if p.strip()]
    if letterless == 'drop':
        kept = [p for p in parts if _HAS_LETTER.search(p)]
        return kept if kept else parts
    merged, carry = [], ''
    for p in parts:
        if not _HAS_LETTER.search(p):
            carry = (carry + ' ' + p).strip()
            continue
        merged.append((carry + ' ' + p).strip() if carry else p)
        carry = ''
    if carry:
        if merged:
            merged[-1] = merged[-1] + ' ' + carry
        else:
            merged.append(carry)
    return merged


def split_sentences(text):
    """Абзац -> предложения по смыслу (для контекста RUAccent, омографов и словаря)."""
    return _cut(text, _boundaries(text, 'context'))


def sentence_spans(text):
    """Границы предложений [(начало, конец)] в абзаце (для подсветки в редакторе)."""
    spans, start = [], 0
    for end, nxt in _boundaries(text, 'context'):
        if end > start:
            spans.append((start, end))
            start = nxt
    spans.append((start, len(text)))
    return [(a, b) for a, b in spans if text[a:b].strip()]


# Слова, перед которыми начинается новая часть фразы: если длинную фразу без запятых приходится резать по словам,
# режем перед ними (а не посреди оборота), чтобы стык звучал как естественный разрыв.
BREAK_BEFORE = {'и', 'а', 'но', 'или', 'либо', 'что', 'чтобы', 'когда', 'если', 'как', 'где', 'куда', 'откуда',
                'пока', 'хотя', 'будто', 'словно', 'потому', 'тогда', 'который', 'которая', 'которое', 'которые',
                'которого', 'которой', 'которому', 'которым', 'которых', 'которую', 'причём', 'затем'}


def _cut_by_words(words, max_len):
    """Фраза без запятых длиннее max_len -> части. Режем перед союзом/относительным словом из последних 45%
    части; нет такого места режем по длине, как раньше."""
    chunks, cur = [], []
    for word in words:
        if cur and visible_len(' '.join(cur + [word])) > max_len:
            cut = len(cur)
            for i in range(len(cur) - 1, 0, -1):
                if visible_len(' '.join(cur[i:])) > 0.45 * max_len:
                    break
                if re.sub(r'[^\wА-Яа-яЁё]', '', cur[i].lower().replace('+', '')) in BREAK_BEFORE:
                    cut = i
                    break
            chunks.append(' '.join(cur[:cut]))
            cur = cur[cut:]
        cur.append(word)
    if cur:
        chunks.append(' '.join(cur))
    return chunks


def split_long(sentence, max_len):
    """Длинный кусок режем по запятым/тире, потом по словам (см. _cut_by_words). Длина без знаков «+» и «*»."""
    if visible_len(sentence) <= max_len:
        return [sentence]
    parts = re.split(r'(?<=[,;:—–])\s+', sentence)
    chunks, cur = [], ''
    for part in parts:
        if visible_len(part) > max_len:
            if cur:
                chunks.append(cur)
                cur = ''
            pieces = _cut_by_words(part.split(), max_len)
            chunks.extend(pieces[:-1])
            cur = pieces[-1] if pieces else ''
        elif cur and visible_len(cur) + 1 + visible_len(part) > max_len:
            chunks.append(cur)
            cur = part
        else:
            cur = (cur + ' ' + part).strip()
    if cur:
        chunks.append(cur)
    return chunks


_MARK = re.compile(r'\*\*|\*')


def _walk_markers(fragments):
    """Проход по знакам акцентов: возвращает (что открыто в конце каждого фрагмента, что открыто в самом конце)."""
    stack, states = [], []
    for frag in fragments:
        for m in _MARK.finditer(frag):
            tok = m.group(0)
            if stack and stack[-1] == tok:
                stack.pop()
            elif tok in stack:
                stack.remove(tok)
            else:
                stack.append(tok)
        states.append(list(stack))
    return states, stack


def balance_markers(fragments):
    """Акцент *...* / **...**, который при нарезке оказался разрезан, закрывается в конце фрагмента и
    открывается заново в начале следующего (иначе звёздочки остаются одинокими). Если звёздочки в предложении
    и так не парные (например, «* * *»), текст не трогаем."""
    states, rest = _walk_markers(fragments)
    if rest or not any(states):
        return list(fragments)
    out, opened = [], []
    for frag, state in zip(fragments, states):
        out.append(''.join(opened) + frag + ''.join(reversed(state)))
        opened = state
    return out


def split_fragments(text, at_commas=True, max_len=250):
    """Готовое предложение -> фрагменты для синтеза (после всех лингвистических шагов)."""
    pieces = _cut(text, _boundaries(text, 'pause', at_commas), letterless='drop')
    out = []
    for piece in pieces:
        out.extend(split_long(piece, max_len))
    return balance_markers(out)


# ---------------------------------------------------------------- сверка и очистка
def words_key(text):
    """Кириллические слова без ударений, в нижнем регистре, ё = е: то, что RUAccent менять не вправе."""
    keys = []
    for w in _CYR_WORD.findall(text):
        k = w.replace('+', '').lower().replace('ё', 'е')
        if k:
            keys.append(k)
    return keys


def same_words(source, accented):
    return words_key(source) == words_key(accented)


def sanitize_stress(text):
    """Знак «+» стоит только перед гласной и только один раз перед ней: всё остальное убираем
    (ошибка RUAccent или опечатка в словаре не должна дойти до синтезатора)."""
    def fix(m):
        w = m.group(0)
        if '+' not in w:
            return w
        out, i = [], 0
        while i < len(w):
            ch = w[i]
            if ch == '+':
                j = i
                while j < len(w) and w[j] == '+':
                    j += 1
                if j < len(w) and w[j] in VOWELS:
                    out.append('+')
                i = j
                continue
            out.append(ch)
            i += 1
        return ''.join(out)
    return _CYR_TOKEN.sub(fix, text)


# ---------------------------------------------------------------- предложение целиком
class Steps:
    """Лингвистические шаги, подаваемые из speak.py. Каждый шаг: функция строка -> строка.
    accentize(текст) -> текст с «+» (RUAccent + clean); может бросить исключение.
    undo_yo(исходный, текст) вызывается только если yo_from_book. Остальные шаги: текст -> текст."""

    def __init__(self, accentize, undo_yo=None, force_stress=None, fix_sam=None, dictionary=None,
                 overrides=None, yo_from_book=True, log=print, omograph=None):
        self.accentize = accentize
        self.undo_yo = undo_yo
        self.force_stress = force_stress
        self.fix_sam = fix_sam
        self.dictionary = dictionary
        self.overrides = overrides
        self.yo_from_book = yo_from_book
        self.log = log
        self.omograph = omograph                 # функция слово -> bool: «омограф ли это» (для отчёта), необязательно


class Report:
    """Что произошло при подготовке: счётчики и список подозрительных мест (читается как отчёт, не на слух)."""

    def __init__(self):
        self.reset()

    def reset(self):
        self.counts = OrderedDict((k, 0) for k in ('sentences', 'sentence', 'clauses', 'partial', 'plain',
                                                   'emphasis_lost'))
        self.problems = []                       # (вид, фрагмент текста)
        self.homographs = OrderedDict()          # (слово, форма с ударением) -> первое предложение

    def add_problem(self, kind, text):
        if len(self.problems) < 500:
            self.problems.append((kind, text))

    def text(self):
        c = self.counts
        lines = [f'Предложений обработано: {c["sentences"]}',
                 f'  целиком (лучший случай): {c["sentence"]}',
                 f'  по частям (RUAccent исказил предложение): {c["clauses"]}',
                 f'  частично без RUAccent: {c["partial"]}',
                 f'  совсем без RUAccent: {c["plain"]}',
                 f'  акцентов *...* не восстановлено: {c["emphasis_lost"]}']
        if self.problems:
            lines += ['', 'Места, которые стоит посмотреть:']
            lines += [f'  [{k}] {t}' for k, t in self.problems]
        if self.homographs:
            lines += ['', 'Омографы: что выбрано (проверь по смыслу, на слух искать не нужно):']
            lines += [f'  {w} -> {form}   «{s}»' for (w, form), s in self.homographs.items()]
        return '\n'.join(lines) + '\n'


REPORT = Report()


def split_clauses(text):
    """Предложение -> куски по запятым/тире (запасной вариант при сбое RUAccent на всём предложении)."""
    return _cut(text, _boundaries(text, 'pause', True))


def _accent_with_returns(source, steps, report):
    """RUAccent с возвратами: всё предложение -> по частям -> без RUAccent. (текст, как получилось)."""
    def attempt(chunk):
        try:
            acc = steps.accentize(chunk)
        except Exception as e:
            steps.log(f'  RUAccent сбой ({type(e).__name__}): {str(e)[:60]}')
            return None
        return acc if isinstance(acc, str) and same_words(chunk, acc) else None

    acc = attempt(source)
    if acc is not None:
        return acc, 'sentence'
    clauses = split_clauses(source)
    if len(clauses) > 1:
        parts, bad = [], 0
        for c in clauses:
            a = attempt(c)
            parts.append(a if a is not None else c)
            bad += a is None
        if bad < len(clauses):
            kind = 'partial' if bad else 'clauses'
            report.add_problem(kind, source[:160])
            return ' '.join(parts), kind
    report.add_problem('plain', source[:160])
    return source, 'plain'


def _guarded(steps, name, func, text):
    """Сбой одного шага (например, pymorphy) не должен ронять озвучку: шаг пропускается, текст остаётся как был."""
    try:
        out = func(text)
        return out if isinstance(out, str) else text
    except Exception as e:
        steps.log(f'  шаг «{name}» пропущен из-за сбоя: {type(e).__name__}: {str(e)[:60]}')
        return text


def accent_sentence(sentence, steps, report=None):
    """Одно предложение целиком -> текст с ударениями и акцентами. Возвращает (текст, как получилось)."""
    report = report if report is not None else REPORT
    source, marks = extract_emphasis(sentence)
    if not _CYR_WORD.search(source.replace('+', '')):        # «* * *», «—», латиница: RUAccent тут не нужен
        return sentence, 'skip'
    text, how = _accent_with_returns(source, steps, report)
    report.counts['sentences'] += 1
    report.counts[how] += 1
    text = _guarded(steps, 'undo_yo', lambda t: steps.undo_yo(source, t), text) \
        if steps.yo_from_book and steps.undo_yo else text
    for name in ('force_stress', 'fix_sam', 'dictionary', 'overrides'):
        step = getattr(steps, name)
        if step:
            text = _guarded(steps, name, step, text)
    text = sanitize_stress(text)
    if steps.omograph:
        for w in _CYR_WORD.findall(text):
            plain = w.replace('+', '').lower()
            if '+' in w and steps.omograph(plain):
                report.homographs.setdefault((plain, w.lower()), source[:120])
    restored, missing = restore_emphasis(text, marks, report_missing=True)
    for mark in missing:
        report.counts['emphasis_lost'] += 1
        steps.log(f'  предупреждение: акцент уровня {mark["level"]} не восстановлен '
                  f'(фрагмент изменён обработкой: {" ".join(mark["words"])!r})')
        report.add_problem('акцент', ' '.join(mark['words']))
    return restored, how


def prepare_text(text, steps, at_commas=True, max_len=250, report=None):
    """Абзац -> [(номер предложения, Prepared-фрагмент)]: смысл, ударения, словарь, и только потом нарезка."""
    out = []
    for k, sentence in enumerate(split_sentences(text)):
        accented, _how = accent_sentence(sentence, steps, report)
        for frag in split_fragments(accented, at_commas, max_len):
            out.append((k, Prepared(frag)))
    return out
