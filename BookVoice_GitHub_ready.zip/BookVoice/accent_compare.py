"""Сравнение двух моделей RUAccent на вашем тексте: слушать нужно только слова, где модели разошлись.

    python accent_compare.py книга.txt turbo turbo3.1 [--limit 500] [--out сравнение.txt]

Каждая модель грузится по очереди (в памяти одна), текст режется на предложения так же, как при озвучке.
В отчёт попадают слова, у которых ударение разное, с предложением, где это случилось. Размеченных эталонов
нет: скрипт не говорит, какая модель права, он сводит работу к проверке нескольких десятков спорных слов
вместо прослушивания книги. Если разошлись только редкие слова, модели практически равны."""
import re
import sys
from collections import Counter
from pathlib import Path

import accent_pipeline as ap

_WORD = re.compile(r'[А-Яа-яЁё+]*[А-Яа-яЁё][А-Яа-яЁё+]*')


def read_sentences(text, limit=None):
    out = []
    for para in text.splitlines():
        para = re.sub(r'\s+', ' ', para).strip()
        if para:
            out.extend(ap.split_sentences(para))
        if limit and len(out) >= limit:
            break
    return out[:limit] if limit else out


def accent_all(sentences, accentize):
    """Ударения для каждого предложения; сбойное предложение даёт None (в сравнении пропускается)."""
    result = []
    for s in sentences:
        try:
            result.append(accentize(s))
        except Exception:
            result.append(None)
    return result


def diff(sentences, a_out, b_out):
    """[(слово без ударения, форма A, форма B, предложение)] по словам, где ударение разное."""
    found = []
    for s, a, b in zip(sentences, a_out, b_out):
        if a is None or b is None:
            continue
        wa, wb = _WORD.findall(a), _WORD.findall(b)
        if len(wa) != len(wb):
            continue
        for x, y in zip(wa, wb):
            if x.lower() != y.lower():
                found.append((x.replace('+', '').lower(), x, y, s))
    return found


def report(name_a, name_b, sentences, a_out, b_out):
    found = diff(sentences, a_out, b_out)
    compared = sum(1 for a, b in zip(a_out, b_out) if a is not None and b is not None)
    words = Counter((w, x, y) for w, x, y, _s in found)
    lines = [f'Сравнение {name_a} и {name_b}: предложений {len(sentences)}, сопоставлено {compared}, '
             f'разных мест {len(found)}, разных слов {len(words)}.', '']
    for (w, x, y), n in words.most_common():
        sample = next(s for ww, xx, yy, s in found if (ww, xx, yy) == (w, x, y))
        lines.append(f'{w}: {name_a} {x} | {name_b} {y}  (раз: {n})  «{sample[:100]}»')
    return '\n'.join(lines) + '\n'


def load_model(name):
    import model_dirs
    model_dirs.apply()
    import model_manager
    from ruaccent import RUAccent
    inst = model_manager.ruaccent_installed_models()
    kw = {'omograph_model_size': name, 'use_dictionary': model_manager.ruaccent_use_dictionary()}
    own = Path(model_dirs.RUACCENT_DIR)
    if name in inst and Path(inst[name]) == own:
        kw['workdir'] = str(own)
    acc = RUAccent()
    acc.load(**kw)
    return acc


def main(argv):
    args = [a for a in argv[1:] if not a.startswith('--')]
    opts = dict(zip(argv[1:], argv[2:]))
    if len(args) < 3:
        print(__doc__)
        return 2
    path, a_name, b_name = Path(args[0]), args[1], args[2]
    limit = int(opts['--limit']) if opts.get('--limit', '').isdigit() else None
    sentences = read_sentences(path.read_text(encoding='utf-8-sig'), limit)
    outs = []
    for name in (a_name, b_name):
        print(f'Загружаю {name}…', flush=True)
        acc = load_model(name)
        outs.append(accent_all(sentences, acc.process_all))
        del acc
    text = report(a_name, b_name, sentences, *outs)
    target = opts.get('--out')
    if target:
        Path(target).write_text(text, encoding='utf-8')
        print('Отчёт:', target)
    print(text)
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
